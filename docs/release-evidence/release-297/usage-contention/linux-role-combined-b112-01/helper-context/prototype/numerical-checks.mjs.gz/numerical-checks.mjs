import assert from 'node:assert/strict';
import { RELEASE_ENABLED_PROFILE, capacityAcceptance } from '../release-enabled-profile.mjs';
import { POOL_LIMITS, LIFECYCLE_EVENTS } from './profile.mjs';

// Original numerical/authority/ownership checks are evaluated unchanged. A
// passing run is not accepted capacity until its complete campaign is verified.
export function numericalRunChecks(metrics, mode) {
  assert.ok(['diagnostic', 'capacity-candidate'].includes(mode));
  const original = capacityAcceptance(metrics);
  const phase = metrics.phases?.find(row => row.name === 'combined');
  const traffic = phase?.traffic?.heartbeats;
  return {
    ...original,
    candidateMode: mode === 'capacity-candidate' && metrics.diagnosticOnly === false,
    fullOffering: traffic?.offered === 6000 && traffic.started === 6000 && traffic.succeeded === 6000
      && traffic.failed === 0 && traffic.refusedAtInFlightLimit === 0 && traffic.lateOffers === 0,
    exactPools: metrics.pools && Object.keys(metrics.pools).length === Object.keys(POOL_LIMITS).length
      && Object.entries(POOL_LIMITS).every(([name,max]) => metrics.pools[name] === max),
    prewarm: metrics.prewarmed === 16 && metrics.readiness === true && metrics.redisReady === true,
    currentFocusProtocol: phase?.traffic?.lifecycle?.passed === true
      && phase.traffic.lifecycle.simulatedClientAcknowledgements === true
      && phase.traffic.lifecycle.browserEnforcementClaimed === false
      && JSON.stringify(phase.traffic.lifecycle.events) === JSON.stringify([...LIFECYCLE_EVENTS, ...LIFECYCLE_EVENTS]),
    fullReportMatrix: RELEASE_ENABLED_PROFILE.reportOffers.total === 64,
  };
}
