import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { randomBytes, createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync, createWriteStream } from 'node:fs';
import { join } from 'node:path';
import os from 'node:os';
const repo='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot';
const id=randomBytes(6).toString('hex'), root=join(os.tmpdir(),'release297-fair-serial-'+id);
mkdirSync(root); const password=randomBytes(24).toString('hex'), appPassword=randomBytes(24).toString('hex');
const pgName='schoolpilot-fair-serial-'+id, redisName=pgName+'-redis', label='codex.fair-serial';
const endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
const base={...process.env};for(const key of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS','BUILDX_BUILDER','DATABASE_URL','ADMIN_DATABASE_URL','DATABASE_URL_PRIVILEGED','RLS_TEST_ROLE','RLS_TEST_PASSWORD','TEST_REDIS_URL','RLS_GUC_ENABLED','RLS_ENABLED_TABLES','RUN_LEGACY_MIGRATIONS_ONLY','RUN_MIGRATIONS_ONLY','RUN_MIGRATIONS_ON_STARTUP','CLASSPILOT_USAGE_ROLLUP_MODE','CLASSPILOT_DIGITAL_USAGE_MODE'])delete base[key];
Object.assign(base,{NODE_ENV:'test',SCHEDULER_ENABLED:'false',REDIS_URL:'',DOTENV_CONFIG_PATH:join(root,'absent-dotenv'),DOTENV_CONFIG_QUIET:'true',JWT_SECRET:randomBytes(32).toString('hex'),SESSION_SECRET:randomBytes(32).toString('hex'),STUDENT_TOKEN_SECRET:randomBytes(32).toString('hex')});
const docker=(args,input)=>{const r=spawnSync('docker',['--host',endpoint,...args],{env:base,encoding:'utf8',input,timeout:30000,windowsHide:true});if(r.status!==0)throw new Error('Owned Docker command failed: '+args[0]);return r.stdout.trim();};
const records=[], created=[];
const sourcePaths=spawnSync('git',['ls-files','--cached','--others','--exclude-standard','--','src','tests','scripts','package.json','package-lock.json','tsconfig.json'],{cwd:repo,encoding:'utf8'}).stdout.trim().split(/\r?\n/).filter(Boolean).sort();
const snapshot=()=>Object.fromEntries(sourcePaths.map(p=>[p,createHash('sha256').update(readFileSync(join(repo,p))).digest('hex')]));
const before=snapshot();writeFileSync(join(root,'source-before.json'),JSON.stringify(before,null,2));
async function step(name,args,env,timeout=180000){
 const log=createWriteStream(join(root,name+'.log'),{flags:'wx'}), startedAt=new Date().toISOString();
 const child=spawn(process.execPath,args,{cwd:repo,env,stdio:['ignore','pipe','pipe'],windowsHide:true});child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});
 let expired=false;const timer=setTimeout(()=>{expired=true;spawnSync('taskkill',['/pid',String(child.pid),'/t','/f'],{windowsHide:true,timeout:20000});},timeout);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve);});clearTimeout(timer);await new Promise(resolve=>log.end(resolve));
 records.push({name,command:['node',...args],startedAt,finishedAt:new Date().toISOString(),exitCode:code,expired,timeoutMs:timeout});writeFileSync(join(root,'checks.json'),JSON.stringify(records,null,2));return code===0&&!expired;
}
let failure, cleanup=true;
try{
 assert.equal(docker(['info','--format','{{.OSType}}']),'linux');
 const pgImage='sha256:44c4ee9810eff91f7eab4d822642e01115b1a9eccce4bcbdde7604752d68eac6';assert.equal(docker(['image','inspect',pgImage,'--format','{{.Id}}']),pgImage);
 const redisImage=docker(['image','inspect','redis:7-alpine','--format','{{.Id}}']);assert.match(redisImage,/^sha256:[a-f0-9]{64}$/);
 for(const [name,image,port,memory,args] of [[pgName,pgImage,5432,'2g',['--env','POSTGRES_DB=fair_ordinary','--env','POSTGRES_PASSWORD='+password]],[redisName,redisImage,6379,'256m',[]]]){
  docker(['run','--detach','--name',name,'--label',label+'='+id,'--cpus',name===pgName?'2':'1','--memory',memory,'--memory-swap',memory,'--publish','127.0.0.1::'+port,...args,image]);created.push({name,image,port});
 }
 const inspectors=created.map(({name})=>JSON.parse(docker(['inspect',name]))[0]);
 const port=Number(inspectors[0].NetworkSettings.Ports['5432/tcp'][0].HostPort),redisPort=Number(inspectors[1].NetworkSettings.Ports['6379/tcp'][0].HostPort);
 writeFileSync(join(root,'fixture.json'),JSON.stringify({id,endpoint,images:created,ports:{postgres:port,redis:redisPort},caps:inspectors.map(x=>({name:x.Name,cpus:x.HostConfig.NanoCpus,memory:x.HostConfig.Memory})),productionChanges:0},null,2));
 for(let i=0;i<80;i++){const r=spawnSync('docker',['--host',endpoint,'exec',pgName,'pg_isready','-h','127.0.0.1','-U','postgres','-d','fair_ordinary'],{env:base,encoding:'utf8',windowsHide:true,timeout:3000});if(r.status===0)break;if(i===79)throw new Error('Owned PostgreSQL readiness timeout');await new Promise(r=>setTimeout(r,250));}
 const url=db=>'postgresql://postgres:'+password+'@127.0.0.1:'+port+'/'+db;
 const ordinary={...base,DATABASE_URL:url('fair_ordinary'),ADMIN_DATABASE_URL:url('fair_ordinary'),TEST_REDIS_URL:'redis://127.0.0.1:'+redisPort};
 assert.ok(await step('ordinary-schema',['node_modules/drizzle-kit/bin.cjs','push','--force'],ordinary));
 assert.ok(await step('ordinary-appointments',['--import','tsx','tests/setup-passpilot-appointments-ci.ts'],ordinary));
 await step('ordinary-db',['scripts/run-test-lane.mjs','db'],ordinary,900000);
 docker(['exec','-i',pgName,'psql','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1'], 'CREATE DATABASE fair_restricted;');
 const registry=JSON.parse(readFileSync(join(repo,'src/config/rlsRegistry.json'),'utf8'));
 const rls={...base,DATABASE_URL:url('fair_restricted'),ADMIN_DATABASE_URL:url('fair_restricted'),RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables.join(','),RLS_TEST_ROLE:'fair_app_'+id,RLS_TEST_PASSWORD:appPassword};
 assert.ok(await step('restricted-schema',['node_modules/drizzle-kit/bin.cjs','push','--force'],rls));
 assert.ok(await step('restricted-convergence',['dist/index.js'],{...rls,RUN_LEGACY_MIGRATIONS_ONLY:'true',RUN_MIGRATIONS_ON_STARTUP:'false',REQUIRE_RLS_TABLE_ENFORCEMENT:'classpilot_schedule_change_pairs,classpilot_schedule_changes,classpilot_schedule_change_legs'}));
 assert.ok(await step('restricted-role',['--import','tsx','tests/setup-rls-ci.ts'],rls));
 rls.DATABASE_URL='postgresql://'+rls.RLS_TEST_ROLE+':'+appPassword+'@127.0.0.1:'+port+'/fair_restricted';
 await step('restricted-rls',['scripts/run-test-lane.mjs','rls'],rls,900000);
}catch(error){failure=String(error.message).replaceAll(password,'[REDACTED]').replaceAll(appPassword,'[REDACTED]');process.exitCode=1;}
finally{
 for(const {name,image}of created.reverse()){try{const c=JSON.parse(docker(['inspect',name]))[0];assert.equal(c.Name,'/'+name);assert.equal(c.Config.Labels[label],id);assert.equal(c.Config.Image,image);assert.equal(c.Image,image);docker(['rm','--force',name]);}catch(error){cleanup=false;}}
 const after=snapshot();writeFileSync(join(root,'source-after.json'),JSON.stringify(after,null,2));
 const result={id,root,sourceHead:spawnSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).stdout.trim(),records,failure:failure??null,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),ownedCleanupPassed:cleanup,platform:'Windows native Node; actual Linux Poppler binaries unavailable, any resulting failures retained',productionChanges:0};
 writeFileSync(join(root,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(!cleanup||failure||records.some(x=>x.exitCode!==0)||!result.sourceUnchanged)process.exitCode=1;
}
