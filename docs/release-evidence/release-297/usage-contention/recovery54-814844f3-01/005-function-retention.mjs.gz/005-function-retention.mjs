import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const hash=value=>createHash('sha256').update(value).digest('hex');
const signature='public.classpilot_heartbeat_screenshot_evidence_v1(text,text,text,text)';
export async function readFunctionRetention(connection){
  const row=(await connection.query(`SELECT p.prosrc AS body,p.provolatile,p.prosecdef,p.proparallel,p.proconfig,p.proisstrict,p.proleakproof,
    pg_catalog.has_function_privilege(current_user,p.oid,'EXECUTE') AS executable,
    EXISTS(SELECT 1 FROM pg_catalog.aclexplode(COALESCE(p.proacl,pg_catalog.acldefault('f',p.proowner))) a WHERE a.grantee=0 AND a.privilege_type='EXECUTE') AS public_execute,
    p.proacl::text AS acl,p.proowner::regrole::text AS owner
    FROM pg_catalog.pg_proc p WHERE p.oid=pg_catalog.to_regprocedure($1)`,[signature])).rows[0];
  assert.ok(row);assert.equal(row.provolatile,'v');assert.equal(row.prosecdef,false);assert.equal(row.proparallel,'u');assert.deepEqual(row.proconfig,['search_path=pg_catalog']);
  assert.equal(row.proisstrict,false);assert.equal(row.proleakproof,false);assert.equal(row.executable,true);assert.equal(row.public_execute,false);
  assert.equal(hash(row.body),'e198ab4901f23dd31aa286e90e3c7401302cd5220510af9b5facf306cf80c30b');
  const rows=(await connection.query('SELECT id,checksum,mode,status,application_sha FROM schema_migrations ORDER BY id')).rows;
  assert.equal(rows.length,54);assert.ok(rows.every(row=>row.status==='complete'));
  const migration=rows.find(row=>row.id==='classpilot-heartbeat-screenshot-evidence-v1-20261003');assert.ok(migration);
  assert.equal(migration.checksum,'2e7ff0728fd875c151e641b506c2e5d650d818ece2e54977db4f9fe4cefed036');assert.equal(migration.mode,'transactional');
  return{signature,bodySha256:hash(row.body),attributes:{volatile:true,invoker:true,parallelUnsafe:true,searchPath:'pg_catalog',strict:false,leakproof:false},runtimeExecute:true,publicExecute:false,owner:row.owner,aclSha256:hash(row.acl),ledgerEntries:54,ledgerSha256:hash(JSON.stringify(rows)),migrationChecksum:migration.checksum};
}
