import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='<USER_HOME>/.codex/worktrees/release-stabilization-297/SchoolPilot';
const source=readFileSync(root+'/scripts/load/usage/release-enabled-scale.mjs','utf8');
const query=source.match(/const fixtureCounts = \(await observer\.query\(`([\s\S]*?)`,\s*\[\.\.\.observationBounds/)[1];
assert.ok(query && !/\b(?:INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|COPY)\b/i.test(query));
const base={heartbeats:[{student_id:'a',school_id:'school',timestamp:'2026-10-03 02:02:32.500001'}],classpilot_session_students:[{student_id:'a',school_id:'school',teaching_session_id:'session',group_id:'group',captured_at:'2026-10-03 01:00:00+00'}],teaching_sessions:[{id:'session',school_id:'school',start_time:'2026-10-03 01:00:00',end_time:null,scheduled_end_at:null}],groups:[{id:'group',school_id:'school'}],classpilot_ai_decisions:[]};
const types={heartbeats:'student_id text,school_id text,timestamp timestamp',classpilot_session_students:'student_id text,school_id text,teaching_session_id text,group_id text,captured_at timestamptz',teaching_sessions:'id text,school_id text,start_time timestamp,end_time timestamp,scheduled_end_at timestamptz',groups:'id text,school_id text',classpilot_ai_decisions:'school_id text,created_at timestamp'};
const literal=value=>"'"+value.replaceAll("'","''")+"'";
const cases=[['valid',()=>{},0,0],['missing_roster',d=>d.classpilot_session_students=[],0,1],['second_session',d=>{d.classpilot_session_students.push({...d.classpilot_session_students[0],teaching_session_id:'second'});d.teaching_sessions.push({...d.teaching_sessions[0],id:'second'});},0,1],['wrong_class',d=>{d.classpilot_session_students[0].group_id='other';d.groups.push({id:'other',school_id:'school'});},0,1],['late_capture',d=>d.classpilot_session_students[0].captured_at='2026-10-03 02:02:32.500002+00',0,1],['ended_session',d=>d.teaching_sessions[0].end_time='2026-10-03 02:02:32.500001',0,1],['scheduled_expiry',d=>d.teaching_sessions[0].scheduled_end_at='2026-10-03 02:02:32.500001+00',0,1],['authority_limit',d=>d.teaching_sessions[0].start_time='2026-10-02 14:02:32.500001',0,1],['ai_decision',d=>d.classpilot_ai_decisions.push({school_id:'school',created_at:'2026-10-03 02:02:32.6'}),1,0],['foreign_session',d=>d.teaching_sessions[0].school_id='foreign',0,1],['foreign_group',d=>d.groups[0].school_id='foreign',0,1],['before_day_irrelevant',d=>d.classpilot_ai_decisions.push({school_id:'school',created_at:'2026-10-02 02:02:32.6'}),0,0]];
const results=[];
for(const [name,mutate,ai,roster] of cases){
 const data=structuredClone(base);mutate(data);
 const ctes=Object.entries(types).map(([name,columns])=>`${name} AS (SELECT * FROM jsonb_to_recordset(${literal(JSON.stringify(data[name]))}::jsonb) AS item(${columns}))`).join(',');
 let sql=query.replace(/^WITH /,`WITH ${ctes},`);
 const params={1:literal('school'),2:literal('2026-10-03 00:00:00'),3:literal('2026-10-03 02:02:33'),4:literal(JSON.stringify([{student_id:'a',group_id:'group'}]))};
 sql=sql.replace(/\$(\d)/g,(_,index)=>params[index]);
 const raw=execFileSync('docker',['--host','npipe:////./pipe/dockerDesktopLinuxEngine','exec','-i','schoolpilot-db','psql','-U','schoolpilot','-d','postgres','-v','ON_ERROR_STOP=1','-X','-A','-t','-F',','],{input:sql,encoding:'utf8'}).trim();
 assert.equal(raw,`${ai},${roster}`,name);results.push({case:name,currentAiDecisionRows:ai,invalidRosterStudents:roster,passed:true});
}
const record={schemaVersion:1,at:new Date().toISOString(),scope:'Exact release-enabled current-day fixture invariant query against read-only synthetic CTEs. No application tables or production database read or write.',sourceSha256:createHash('sha256').update(source).digest('hex'),querySha256:createHash('sha256').update(query).digest('hex'),passed:true,cases:results};
writeFileSync(new URL('./native-invariant-parity.json',import.meta.url),JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));
