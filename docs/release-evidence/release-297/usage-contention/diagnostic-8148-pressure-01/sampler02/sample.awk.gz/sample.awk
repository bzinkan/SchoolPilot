# Read-only, numeric-only observer. Runs in one bounded exec per exact container.
# Never reads arguments, environment, SQL, logs or workload data.
function rawline(file,    line,ok) { ok=(getline line < file); close(file); return ok>0?line:"" }
function number(x) { return x ~ /^[0-9]+([.][0-9]+)?$/ ? x : "null" }
function numeric(file) { return number(rawline(file)) }
function uptime(    a) { split(rawline("/proc/uptime"),a," "); return a[1]+0 }
function pair(file,    a,n) { n=split(rawline(file),a," "); return n==2?"{\"quota\":"number(a[1])",\"unlimited\":"(a[1]=="max"?"true":"false")",\"period\":"number(a[2])"}":"null" }
function counters(file,    line,a,n,out,count) { out="";count=0; while((getline line < file)>0){n=split(line,a," ");if(n==2&&a[1]~/^[a-z_]+$/&&number(a[2])!="null"&&++count<=100)out=out (out?",":"") "\""a[1]"\":"a[2];}close(file);return "{"out"}" }
function pressure(file,    line,a,n,b,out,values,i,kind) { out="";while((getline line<file)>0){n=split(line,a," ");kind=a[1];if(kind!="some"&&kind!="full")continue;values="";for(i=2;i<=n;i++){split(a[i],b,"=");if(b[1]!~/^(avg10|avg60|avg300|total)$/||number(b[2])=="null")continue;values=values (values?",":"")"\""b[1]"\":"b[2];}out=out (out?",":"")"\""kind"\":{"values"}";}close(file);return "{"out"}" }
function cpuset(file,    line,a,n,b,i,total) { line=rawline(file);if(line==""||line!~/^[0-9,-]+$/)return "null";n=split(line,a,",");total=0;for(i=1;i<=n;i++){if(split(a[i],b,"-")==1)total+=1;else if(b[2]+0>=b[1]+0)total+=b[2]-b[1]+1;else return "null";}return total }
function io(file,    line,a,n,b,i,out,row,count) { out="";count=0;while((getline line<file)>0){n=split(line,a," ");if(a[1]!~/^[0-9]+:[0-9]+$/||++count>64)continue;split(a[1],b,":");row="\"major\":"b[1]",\"minor\":"b[2];for(i=2;i<=n;i++){split(a[i],b,"=");if(b[1]~/^(rbytes|wbytes|rios|wios|dbytes|dios)$/&&number(b[2])!="null")row=row",\""b[1]"\":"b[2];}out=out (out?",":"")"{"row"}";}close(file);return "["out"]" }
function selfcpu(    s,a,n) { s=rawline("/proc/self/stat");sub(/^.*\) /,"",s);n=split(s,a," ");if(n<15)return "null";return "{\"userTicks\":"number(a[12])",\"systemTicks\":"number(a[13])",\"childUserTicks\":"number(a[14])",\"childSystemTicks\":"number(a[15])"}" }
function procstat(    line,a,n,i,count,out,cpu,names) { count=0;out="";cpu="";split("user nice system idle iowait irq softirq steal guest guest_nice",names," ");while((getline line<"/proc/stat")>0){n=split(line,a," ");if(a[1]~/^cpu[0-9]+$/)count++;if(a[1]=="cpu")for(i=2;i<=n&&i<=11;i++)cpu=cpu (cpu?",":"")"\""names[i-1]"\":"number(a[i]);if(a[1]~/^(procs_running|procs_blocked|ctxt|processes)$/)out=out",\""a[1]"\":"number(a[2]);}close("/proc/stat");return "{\"logicalCpus\":"count",\"cpuTicks\":{"cpu"}"out"}" }
function meminfo(    line,a,n,out,key) { out="";while((getline line<"/proc/meminfo")>0){n=split(line,a,/[: ]+/);key=a[1];if(key!~/^(MemTotal|MemFree|MemAvailable|SwapTotal|SwapFree|Dirty|Writeback|PageTables)$/)continue;out=out (out?",":"")"\""key"KiB\":"number(a[2]);}close("/proc/meminfo");return "{"out"}" }
function vmstat(    line,a,out) { out="";while((getline line<"/proc/vmstat")>0){split(line,a," ");if(a[1]!~/^(pgfault|pgmajfault|pswpin|pswpout|pgpgin|pgpgout|oom_kill)$/)continue;out=out (out?",":"")"\""a[1]"\":"number(a[2]);}close("/proc/vmstat");return "{"out"}" }
function discover(    line,a,cg,mountroot,rel) {
  leaf="/sys/fs/cgroup";visibleAncestors=0;
  while((getline line<"/proc/self/cgroup")>0)if(substr(line,1,3)=="0::")cg=substr(line,4);close("/proc/self/cgroup");
  while((getline line<"/proc/self/mountinfo")>0){split(line,a," ");if(a[5]=="/sys/fs/cgroup"&&line~/ - cgroup2 /)mountroot=a[4];}close("/proc/self/mountinfo");
  if(cg!~/^\/[A-Za-z0-9_.:\/-]*$/||mountroot!~/^\/[A-Za-z0-9_.:\/-]*$/||cg~/\.\./||mountroot~/\.\./)return;
  if(mountroot=="/")rel=cg;else if(cg==mountroot)rel="/";else if(index(cg,mountroot"/")==1)rel=substr(cg,length(mountroot)+1);else return;
  if(rel!="/"&&rawline("/sys/fs/cgroup"rel"/cpu.stat")!=""){leaf="/sys/fs/cgroup"rel;visibleAncestors=1;}
}
function ancestors(    p,out,d,nextp) { out="";p=leaf;for(d=1;d<=8&&p!="/sys/fs/cgroup";d++){nextp=p;sub(/\/[^/]+$/,"",nextp);if(index(nextp,"/sys/fs/cgroup")!=1||rawline(nextp"/cpu.max")=="")break;p=nextp;out=out (out?",":"")"{\"distance\":"d",\"cpuMax\":"pair(p"/cpu.max")",\"cpuWeight\":"numeric(p"/cpu.weight")",\"effectiveCpuCount\":"cpuset(p"/cpuset.cpus.effective")"}";}return "["out"]" }
BEGIN {
  CONVFMT="%.12g"; OFMT="%.12g"; discover(); start=uptime(); previous=start;
  for(sample=0;sample<=150;sample++) {
    now=uptime();if(now-start>=duration)break;
    record="{\"schemaVersion\":1,\"unixSeconds\":"systime()",\"sample\":"sample",\"uptimeSeconds\":"now",\"elapsedSeconds\":"(now-start)",\"gapSeconds\":"(sample?now-previous:0)",\"cpuMax\":"pair(leaf"/cpu.max")",\"cpuWeight\":"numeric(leaf"/cpu.weight")",\"effectiveCpuCount\":"cpuset(leaf"/cpuset.cpus.effective")",\"cpu\":"counters(leaf"/cpu.stat")",\"cpuPressure\":"pressure(leaf"/cpu.pressure")",\"io\":"io(leaf"/io.stat")",\"ioPressure\":"pressure(leaf"/io.pressure")",\"memoryCurrent\":"numeric(leaf"/memory.current")",\"memoryMax\":"numeric(leaf"/memory.max")",\"memorySwapCurrent\":"numeric(leaf"/memory.swap.current")",\"memorySwapMax\":"numeric(leaf"/memory.swap.max")",\"memoryEvents\":"counters(leaf"/memory.events")",\"memoryStat\":"counters(leaf"/memory.stat")",\"memoryPressure\":"pressure(leaf"/memory.pressure")",\"visibleAncestorCounters\":"(visibleAncestors?"true":"false")",\"ancestors\":"ancestors()",\"observerCpuTicks\":"selfcpu();
    if(vm==1)record=record",\"vm\":{\"stat\":"procstat()",\"memory\":"meminfo()",\"vmstat\":"vmstat()",\"cpuPressure\":"pressure("/proc/pressure/cpu")",\"ioPressure\":"pressure("/proc/pressure/io")",\"memoryPressure\":"pressure("/proc/pressure/memory")"}";
    print record"}";fflush();previous=now;
    if(system("sleep 1")!=0)exit 70;
  }
}
