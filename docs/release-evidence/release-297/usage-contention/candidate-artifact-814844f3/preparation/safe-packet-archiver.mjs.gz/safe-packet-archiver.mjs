import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream,readFileSync,writeFileSync,mkdirSync,existsSync,statSync,lstatSync} from 'node:fs';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';

const source='814844f344a45159152415b0fb6d7027f05b093e';
const temp='<TEMP>';
const artifact='C:/Users/zinka/.codex/artifacts/release297-candidate-814844f3-01';
const packet=join(temp,'release297-candidate-8148-evidence-01/candidate-artifact-814844f3');
const sha=x=>createHash('sha256').update(x).digest('hex');
const hash=async path=>{const digest=createHash('sha256');for await(const chunk of createReadStream(path))digest.update(chunk);return digest.digest('hex');};
const read=path=>JSON.parse(readFileSync(path,'utf8'));
const rawManifest=readFileSync(join(artifact,'artifact-manifest.json'));
assert.equal(sha(rawManifest),'ea951bb79e40d9de7f56ef44df3adc84d068d5f9c4cf98451dbe96297cccece0');
const original=JSON.parse(rawManifest);assert.equal(original.source,source);assert.equal(original.passed,true);
const candidate=read(join(artifact,'candidate-preparation.json')),scan=read(join(artifact,'scan-receipt.json'));
for(const key of ['passed','sourceInitiallyClean','sourceUnchangedAtFinish','inspectorCleanupPassed'])assert.equal(candidate[key],true);
assert.equal(candidate.source,source);assert.equal(scan.sourceSha,source);assert.equal(scan.passed,true);
assert.equal(scan.gate,'All HIGH and CRITICAL findings block regardless of fix availability');
const counts={UNKNOWN:0,LOW:0,MEDIUM:0,HIGH:0,CRITICAL:0};
for(const result of read(join(artifact,'reports/trivy.json')).Results??[])for(const vulnerability of result.Vulnerabilities??[])counts[vulnerability.Severity]=(counts[vulnerability.Severity]??0)+1;
assert.deepEqual(counts,scan.counts);assert.equal(counts.HIGH,0);assert.equal(counts.CRITICAL,0);
assert.equal(await hash(join(artifact,'reports/trivy.json')),scan.reportSha256);
const binding=read(join(temp,'release297-reader-8148-final-binding.json'));
assert.equal(binding.source,source);assert.equal(binding.testedFileCount,1260);assert.equal(binding.testedWorkingFilesByteIdentical,true);assert.equal(binding.cleanLfClone.otherDifferences,0);
const frontend=read(join(temp,'release297-frontend-8148-source-equivalence-01.json'));
assert.equal(frontend.source,source);assert.equal(frontend.sourceFiles,632);assert.equal(frontend.allSourceBlobsMatch,true);assert.equal(frontend.artifactUnchanged,true);
assert.equal(existsSync(packet),false);mkdirSync(packet,{recursive:true});
const sources=[];
for(const item of original.files){
  const path=resolve(artifact,item.path);assert.ok(path.startsWith(resolve(artifact)+'/')||path.startsWith(resolve(artifact)+'\\'));
  assert.equal(lstatSync(path).isSymbolicLink(),false);assert.equal(await hash(path),item.sha256,item.path);
  if(item.path==='input/image.tar')continue;
  assert.ok(!/(^|\/)\.env(?:\.|$)|\.dump$|credentials/i.test(item.path));
  sources.push({path,relative:item.path});
}
sources.push({path:join(artifact,'artifact-manifest.json'),relative:'artifact-manifest.json'},
  {path:join(temp,'release297-reader-8148-final-binding.json'),relative:'preparation/final-source-binding.json'},
  {path:join(temp,'release297-frontend-8148-source-equivalence-01.json'),relative:'preparation/frontend-source-equivalence.json'},
  {path:join(temp,'release297-verify-frontend-8148-01.mjs'),relative:'preparation/verify-frontend.mjs'},
  {path:join(temp,'release297-archive-candidate-814844f3.mjs'),relative:'preparation/permanent-artifact-archiver.mjs'},
  {path:fileURLToPath(import.meta.url),relative:'preparation/safe-packet-archiver.mjs'});
const scrub=s=>s.replace(/(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi,'<REDACTED_LOCAL_URL>')
  .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_TOKEN>')
  .replace(/C:[\\/]+Users[\\/]+zinka[\\/]+AppData[\\/]+Local[\\/]+Temp/gi,'<TEMP>');
const files=[];let changed=0;
for(const item of sources){
  const raw=readFileSync(item.path),text=raw.toString('utf8');assert.equal(Buffer.from(text).equals(raw),true,'Only UTF-8 metadata/log/source allowed');
  const safe=Buffer.from(scrub(text));if(!safe.equals(raw))changed++;
  assert.equal(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/.test(safe.toString('utf8')),false,'Unexpected credential material');
  const compressed=gzipSync(safe,{level:9}),path=item.relative+'.gz';mkdirSync(dirname(join(packet,path)),{recursive:true});writeFileSync(join(packet,path),compressed,{flag:'wx'});
  assert.equal(sha(gunzipSync(compressed)),sha(safe));
  files.push({path,originalRelativePath:item.relative,originalBytes:raw.length,originalSha256:sha(raw),sanitizedSha256:sha(safe),gzipSha256:sha(compressed)});
}
const limitations=['Retained embedded compatibility probe proves 129-table/floors/Usage-off posture but does not independently inspect migration 54 or the new function inside the image. Native source/ACL proof is separate; actual final-image recovery remains pending.',
  'No accepted capacity campaign, production readiness, registry push, deployment, new frontend build, or new browser execution is claimed.'];
const summary={schemaVersion:1,source,passed:true,buildMode:candidate.buildMode,scanCounts:counts,image:candidate.image,
  artifactDirectory:artifact,artifactManifestSha256:sha(rawManifest),candidatePreparationSha256:sha(readFileSync(join(artifact,'candidate-preparation.json'))),scanReceiptSha256:sha(readFileSync(join(artifact,'scan-receipt.json'))),
  sourceBindingSha256:sha(readFileSync(join(temp,'release297-reader-8148-final-binding.json'))),frontendBindingSha256:sha(readFileSync(join(temp,'release297-frontend-8148-source-equivalence-01.json'))),
  frontend:{sourceFiles:632,tree:frontend.frontendTree,archiveSha256:frontend.frontendArchiveSha256,unchanged:true,rebuildPerformed:false},
  productionMutations:0,registryPushes:0,taskRegistrations:0,capacityAccepted:false,limitations};
const privacy={schemaVersion:1,source,records:files.length,redactedRecords:changed,allowed:'UTF-8 build/scan metadata, logs, helper source, source/frontend hash bindings',
  imageArchiveIncluded:false,databaseDumpIncluded:false,environmentFileIncluded:false,credentialsIncluded:false,
  redactions:['local database/Redis URLs','JWT-shaped tokens','temporary-directory prefix'],privateKeyAndAccessKeyPatternCheckPassed:true,
  scope:'Reviewed candidate-only build packet; no fixture, request, student, school, or production data.'};
const summaryRaw=JSON.stringify(summary,null,2)+'\n',privacyRaw=JSON.stringify(privacy,null,2)+'\n';
writeFileSync(join(packet,'summary.json'),summaryRaw,{flag:'wx'});writeFileSync(join(packet,'privacy-review.json'),privacyRaw,{flag:'wx'});
const image=original.files.find(item=>item.path==='input/image.tar');assert.ok(image);assert.equal(image.sha256,candidate.exportSha256);
const manifest={schemaVersion:1,source,diagnosticOnly:true,finalReleaseArtifactSelected:false,capacityAccepted:false,
  artifactDirectory:artifact,artifactManifestSha256:sha(rawManifest),image:candidate.image,exportSha256:candidate.exportSha256,imageExportRetainedAt:join(artifact,'input/image.tar'),
  files,hashOnly:[{path:'input/image.tar',bytes:image.bytes,sha256:image.sha256,storage:'Verified permanent artifact; not copied into repository packet'}],
  summarySha256:sha(summaryRaw),privacyReviewSha256:sha(privacyRaw),omittedFromPacket:['image.tar','replaceable Trivy cache'],limitations};
writeFileSync(join(packet,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
for(const record of files){const bytes=readFileSync(join(packet,record.path));assert.equal(sha(bytes),record.gzipSha256);assert.equal(sha(gunzipSync(bytes)),record.sanitizedSha256);}
console.log(JSON.stringify({packet,records:files.length,manifestSha256:sha(readFileSync(join(packet,'manifest.json'))),summarySha256:manifest.summarySha256,privacyReviewSha256:manifest.privacyReviewSha256,frontendBindingSha256:summary.frontendBindingSha256}));
