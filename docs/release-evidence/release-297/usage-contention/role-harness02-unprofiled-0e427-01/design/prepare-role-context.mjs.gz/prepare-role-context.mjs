import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const sha=text=>createHash('sha256').update(text).digest('hex');
const replace=(text,from,to)=>{assert.equal(text.split(from).length-1,1,`Unique anchor: ${from.slice(0,80)}`);return text.replace(from,()=>to);};
export function patchUnprofiledIngestCoordinator(text) {
  assert.equal(text.split("assert.equal(process.env.USAGE_RELEASE_CPU_PROFILE, 'false');").length-1,1);
  return replace(text,"assert.equal(process.env.USAGE_RELEASE_PHASE, 'combined');","assert.equal(process.env.USAGE_RELEASE_PHASE, 'ingest');");
}
export function patchRunner(original) {
  let text=replace(original,"if ($Phase -cne 'combined' -or $CollectApiCpuProfile) { throw 'This Linux prototype supports only the complete combined diagnostic.' }","if ($Phase -cne 'ingest' -or $CollectApiCpuProfile) { throw 'This separate role diagnostic requires full6000-offer ingestion WITHOUT CPU profiling.' }");
  text=replace(text,"node (Join-Path $prototypeDirectory 'launch-linux-diagnostic.mjs') $dockerExecutable $pinnedDockerHost $DiagnosticImageManifest $run $pgIdentity $output *> (Join-Path $output 'linux-launcher.log')", "node (Join-Path $prototypeDirectory '../prototype/launch-role-preflight.mjs') $dockerExecutable $pinnedDockerHost $DiagnosticImageManifest $run $pgIdentity $output ([IO.Path]::Combine([IO.Path]::GetTempPath(), 'schoolpilot-role-control-' + $run)) combined *> (Join-Path $output 'role-launcher.log')");
  text=replace(text,"Get-Content -LiteralPath (Join-Path $output 'scale.log') | Where-Object", "Get-Content -LiteralPath (Join-Path $output 'coordinator.log') | Where-Object");
  text=replace(text,"workloadProfile='release-enabled-linux-shared-namespace-diagnostic-100rps-v1'", "workloadProfile='release-enabled-linux-role-cgroups-ingest-unprofiled-100rps-v2'");
  text=replace(text,"node (Join-Path $prototypeDirectory 'cleanup-linux-fixtures.mjs') $dockerExecutable", "node (Join-Path $prototypeDirectory 'cleanup-role-fixtures.mjs') $dockerExecutable");
  return {text,receipt:{inputSha256:sha(original),outputSha256:sha(text),allowedChanges:['Owned role launcher/log/cleanup','Explicit separate diagnostic profile name','Closed ingest-only guard refusing CPU profiling'],workloadChanged:false,preparationAndColdGateChanged:false}};
}
export function patchRoleProfile(original) {
  assert.equal(original.split("assert.equal(env.USAGE_RELEASE_CPU_PROFILE, 'false');").length-1,1);
  let text=replace(original,'release-enabled-linux-shared-namespace-diagnostic-100rps-v1','release-enabled-linux-role-cgroups-ingest-unprofiled-100rps-v2');
  text=replace(text,'Linux candidate runtime; shared owned PostgreSQL network namespace; separate forked processes','Linux candidate runtime; separate role containers with explicit CPU and RSS ceilings; shared owned PostgreSQL namespace');
  text=replace(text,"assert.equal(env.USAGE_RELEASE_PHASE, 'combined');","assert.equal(env.USAGE_RELEASE_PHASE, 'ingest');");
  return {text,receipt:{inputSha256:sha(original),outputSha256:sha(text),onlyChanges:['Diagnostic name/topology','Closed ingest phase; existing CPU=false retained'],workloadChanged:false}};
}
