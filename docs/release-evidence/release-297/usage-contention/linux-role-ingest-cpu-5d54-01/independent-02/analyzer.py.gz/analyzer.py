from pathlib import Path
import json,hashlib,collections
raw=Path(r'<TEMP>/release297-role-ingest-cpu-5d54-01')
out=Path(r'<TEMP>/release297-cpu5d-independent-02')
out.mkdir(exist_ok=False)
p=json.loads((raw/'api.cpuprofile').read_text());r=json.loads((raw/'usage-scale.json').read_text())
phase=next(x for x in r['phases'] if x.get('api',{}).get('measurementStartedHrtimeMicroseconds'))
lo=phase['api']['measurementStartedHrtimeMicroseconds'];hi=phase['api']['snapshotHrtimeMicroseconds']
assert p['startTime']<=lo<hi<=p['endTime']
n={x['id']:x for x in p['nodes']};parent={c:x['id'] for x in p['nodes'] for c in x.get('children',[])}
exclusive=collections.Counter();inclusive=collections.Counter();groups=collections.Counter();callers=collections.Counter();t=p['startTime'];latest_end=t;samples=0;negative_deltas=[];overlap_us=0
def key(id):
 f=n[id]['callFrame'];return (f['functionName'] or '(anonymous)',f['url'],f['lineNumber']+1)
for index,(id,dt) in enumerate(zip(p['samples'],p['timeDeltas'])):
 end=t+dt;start=max(t,latest_end);overlap_us+=max(0,min(end,latest_end)-t) if dt>0 else 0
 if dt<0:negative_deltas.append({'index':index,'microseconds':dt})
 weight=max(0,min(end,hi)-max(start,lo));latest_end=max(latest_end,end);t=end
 if not weight:continue
 samples+=1;k=key(id);exclusive[k]+=weight
 name,url,line=k
 group='other'
 if '/drizzle-orm/' in url:group='drizzle'
 elif any('/node_modules/'+s+'/' in url for s in ['pg','pg-pool','pg-protocol','pg-types']):group='pg-driver'
 elif name=='(garbage collector)':group='gc'
 elif name=='(idle)':group='idle'
 elif '/app/dist/' in url:group='application'
 elif '/diagnostic/' in url:group='diagnostic'
 groups[group]+=weight
 stack=[];seen=set();at=id
 while at:
  frame=key(at);stack.append(frame)
  if frame not in seen:inclusive[frame]+=weight;seen.add(frame)
  at=parent.get(at)
 family=None
 if any('/drizzle-orm/utils.' in f[1] and f[0]=='mapResultRow' for f in stack):family='Drizzle row decoding inclusive'
 elif any('/drizzle-orm/' in f[1] and f[0] in ['buildQueryFromSourceParams','buildSelectQuery','sqlToQuery','orderSelectedFields','prepareFields'] for f in stack):family='Drizzle construction inclusive'
 if family:
  app=next((f for f in stack if '/app/dist/' in f[1]),None)
  callers[(family,app)]+=weight
def rows(counter,predicate=lambda k:True,limit=35):
 return [{'function':k[0],'url':k[1],'line':k[2],'sampledMs':v/1000} for k,v in counter.most_common() if predicate(k)][:limit]
result={'schemaVersion':1,'source':r['sourceRevision'],'profileSha256':hashlib.sha256((raw/'api.cpuprofile').read_bytes()).hexdigest(),'window':{'start':lo,'end':hi,'wallMs':(hi-lo)/1000,'selectedSampleCount':samples,'weightedSampledMs':sum(groups.values())/1000},'timeDeltaAnomalies':negative_deltas,'overlapMicrosecondsExcluded':overlap_us,'exclusiveGroupsMs':{k:v/1000 for k,v in groups.most_common()},'topExclusive':rows(exclusive),'drizzleExclusive':rows(exclusive,lambda k:'/drizzle-orm/' in k[1]),'drizzleInclusive':rows(inclusive,lambda k:'/drizzle-orm/' in k[1]),'applicationInclusive':rows(inclusive,lambda k:'/app/dist/' in k[1]),'rowDecodeInclusive':rows(inclusive,lambda k:k[0] in ['mapResultRow','mapFromDriverValue','parseRow','parseDataRowMessage']), 'constructionOrDecodeApplicationAncestors':[{'family':k[0],'nearestAppFrame':k[1],'sampledMs':v/1000} for k,v in callers.most_common()][:35],'limitations':['Weighted statistical wall samples, not exclusive CPU totals.','Inclusive frames overlap and cannot be added.','Async continuations may omit the originating query builder callsite.','No SQL text/parameters, identity or request contents retained.','Read-only profile analysis; no tests, SQL or application edits.']}
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
