$ErrorActionPreference = 'Stop'
$repo = '<WORKTREE>'
$docker = 'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$daemon = 'npipe:////./pipe/dockerDesktopLinuxEngine'
$run = [guid]::NewGuid().ToString('N').Substring(0,12)
$container = 'schoolpilot-worker-admission-' + $run
$database = 'usage_native_' + $run
$owner = 'fixture_' + $run
$password = [guid]::NewGuid().ToString('N')
$out = Join-Path $env:TEMP ('release297-worker-admission-native-' + $run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $repo
$created = $false
$testExit = 1
try {
  $schema = Join-Path $out 'schema.sql'
  & $docker --host $daemon exec schoolpilot-db pg_dump -U schoolpilot -d schoolpilot_redesign_usage_release297_20261002 --schema-only --no-owner --no-privileges | Set-Content -LiteralPath $schema -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw 'Read-only schema export failed' }
  $image = (& $docker --host $daemon inspect schoolpilot-db --format '{{.Image}}').Trim()
  & $docker --host $daemon run --detach --name $container --label "codex.worker-admission=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
  if ($LASTEXITCODE -ne 0) { throw 'Fixture create failed' }
  $created = $true
  $ready = $false
  for ($attempt=0; $attempt -lt 40; $attempt++) {
    & $docker --host $daemon exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null
    if ($LASTEXITCODE -eq 0) { $ready=$true; break }
    Start-Sleep -Milliseconds 250
  }
  if (-not $ready) { throw 'Fixture not ready' }
  $ports = & $docker --host $daemon inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
  if ($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1') { throw 'Fixture must remain loopback-only' }
  $port = $ports.'5432/tcp'[0].HostPort
  Get-Content -LiteralPath $schema -Raw | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
  if ($LASTEXITCODE -ne 0) { throw 'Schema restore failed' }
  $env:JWT_SECRET = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
  $env:SESSION_SECRET=$env:JWT_SECRET; $env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
  $env:NODE_ENV='test'; $env:REDIS_URL=''; $env:SCHEDULER_ENABLED='false'
  Remove-Item Env:RLS_TEST_ROLE -ErrorAction SilentlyContinue
  $env:RLS_GUC_ENABLED='true'
  $registry=Get-Content src/config/rlsRegistry.json -Raw | ConvertFrom-Json
  $env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
  $env:DATABASE_URL="<REDACTED_CONNECTION_URL>"
  $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL; $env:ADMIN_DATABASE_URL=$env:DATABASE_URL
  node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-usage-rollup.test.ts *> (Join-Path $out 'ordinary.log')
  $testExit=$LASTEXITCODE
  [ordered]@{ordinaryExit=$testExit;source=(git rev-parse HEAD).Trim();worktreeDirty=$true;container=$container;database=$database;schemaDonor='schoolpilot_redesign_usage_release297_20261002';productionMutations=0;role='owner';schemaOnly=$true;sourceExecution='tsx';sharedDistRebuilt=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json')
  Write-Output ([ordered]@{evidence=$out;ordinaryExit=$testExit} | ConvertTo-Json -Compress)
} finally {
  if ($created) {
    $labels = & $docker --host $daemon inspect $container --format '{{json .Config.Labels}}' | ConvertFrom-Json
    if ($container -cne ('schoolpilot-worker-admission-'+$run) -or $labels.'codex.worker-admission' -cne $run) { throw 'Cleanup ownership mismatch' }
    & $docker --host $daemon rm -f $container *> (Join-Path $out 'cleanup.log')
  }
}
exit $testExit
