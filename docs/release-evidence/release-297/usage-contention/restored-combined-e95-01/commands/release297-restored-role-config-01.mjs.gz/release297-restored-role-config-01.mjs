import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const temp=process.env.TEMP,review=join(temp,'release297-restored-role-integration-review-02'),source='e95a2b56476b1225434c1b0f3907db46c9d84fe3';
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const build=join(temp,'release297-restored-role-e95-build-01'),bindingFile=join(build,'role-image-binding.json'),runtimeProofFile=join(build,'runtime-proof.json');
const sourceDirectory=join(temp,'release297-restored-role-e95-host-01');
assert.equal(execFileSync('git',['-C',sourceDirectory,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),source);
assert.equal(execFileSync('git',['-C',sourceDirectory,'status','--porcelain'],{encoding:'utf8'}).trim(),'');
const options={run:randomBytes(6).toString('hex'),source,mode:'diagnostic',phase:'combined',sourceDirectory,
  snapshotDirectory:'C:/Users/zinka/.codex/artifacts/release297-synthetic-prepared-e95-75d8f6205c5c',snapshotManifestSha256:'847c9b8d7a0e717e77b72f75ca06f2e89d3d5050cce17b8b5cd731bde4070330',
  expectedSchemaSha256:'f11bfcf7a44d202bbb6e5828cf556b69db3524b218b388678ac46e481c8194a1',
  bindingFile,bindingSha256:hash(bindingFile),runtimeProofFile,runtimeProofSha256:hash(runtimeProofFile),
  candidatePreparationFile:join(temp,'schoolpilot-image-scan-8iUaJg/candidate-preparation.json'),
  candidatePreparationSha256:'89dd7c735ba8c2f8d745db4bceba99a29e6890d59898ced0d0478cdf79b19318',
  evidenceDirectory:join(temp,'release297-role-restored-combined-e95-01'),privateDirectory:join(temp,'release297-role-restored-combined-e95-01-private'),
  endpoint:'npipe:////./pipe/dockerDesktopLinuxEngine',docker:'C:/Program Files/Docker/Docker/resources/bin/docker.exe',
  redisImage:'sha256:e7723ff73d963f5cc6d9c4643ea3d989527a402a319239054e9472a7fb9219a2'};
for(const path of[options.evidenceDirectory,options.privateDirectory])assert.equal(existsSync(path),false);
const config=join(review,'actual-run-config.json');writeFileSync(config,JSON.stringify(options,null,2)+'\n',{flag:'wx'});
const receipt={source,config,configSha256:hash(config),bindingSha256:options.bindingSha256,runtimeProofSha256:options.runtimeProofSha256,
  hostClean:true,hostInstallLogSha256:hash(join(temp,'release297-restored-role-host-ci-01.log')),hostBuildLogSha256:hash(join(temp,'release297-restored-role-host-build-01.log')),
  helperCleanup:JSON.parse(readFileSync(join(build,'runtime-probe-cleanup.json'))),capacityAccepted:false,createdAt:new Date().toISOString()};
writeFileSync(join(review,'preparation-checkpoint.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({run:options.run,config,configSha256:receipt.configSha256,output:options.evidenceDirectory}));
