import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';

const SOURCE='814844f344a45159152415b0fb6d7027f05b093e';
const ENDPOINT='npipe:////./pipe/dockerDesktopLinuxEngine';
const limits={api:[1,2147483648],worker:[.5,1073741824],generator:[2,1073741824],coordinator:[.5,1073741824],postgres:[4,4294967296],redis:[1,268435456]};
const hash=b=>createHash('sha256').update(b).digest('hex');
const configFile=path.resolve(process.argv[2]??'');
assert.equal(process.argv.length,3,'Pass one reviewed exact-ID config');
const configRaw=fs.readFileSync(configFile),c=JSON.parse(configRaw.toString('utf8').replace(/^\uFEFF/,''));
assert.deepEqual(Object.keys(c).sort(),['schemaVersion','run','source','docker','endpoint','outputFile','durationSeconds','containers','samplerSha256','awkSha256'].sort());
assert.equal(c.schemaVersion,1);assert.equal(c.source,SOURCE);assert.match(c.run,/^[a-f0-9]{12}$/);assert.equal(c.endpoint,ENDPOINT);
assert.ok(Number.isInteger(c.durationSeconds)&&c.durationSeconds>=1&&c.durationSeconds<=140);
assert.ok(path.isAbsolute(c.docker)&&fs.statSync(c.docker).isFile());
assert.ok(path.isAbsolute(c.outputFile)&&!fs.existsSync(c.outputFile));assert.ok(fs.statSync(path.dirname(c.outputFile)).isDirectory());
const scriptFile=new URL(import.meta.url),awkFile=new URL('./sample.awk',import.meta.url),awk=fs.readFileSync(awkFile);
assert.equal(hash(fs.readFileSync(scriptFile)),c.samplerSha256);assert.equal(hash(awk),c.awkSha256);
assert.equal(c.containers.length,6);assert.deepEqual(c.containers.map(r=>r.role).sort(),Object.keys(limits).sort());
for(const row of c.containers){assert.deepEqual(Object.keys(row).sort(),['role','imageId'].sort());assert.match(row.imageId,/^sha256:[a-f0-9]{64}$/);}
const expectedName=role=>(role==='postgres'?'schoolpilot-usage-scale-':role==='redis'?'schoolpilot-usage-redis-':'schoolpilot-role-'+role+'-')+c.run;
const env=Object.fromEntries(['SystemRoot','WINDIR','PATH','PATHEXT','TEMP','TMP','COMSPEC'].filter(k=>process.env[k]).map(k=>[k,process.env[k]]));
const active=new Set();let interrupted=false;
process.once('SIGINT',()=>{interrupted=true;});process.once('SIGTERM',()=>{interrupted=true;});
const start=performance.now(),startedAt=new Date().toISOString(),cpuStart=process.cpuUsage();
function command(args,{input,deadlineMs,maxBytes=65536}={}){
  return new Promise(resolve=>{
    const child=spawn(c.docker,['--host',ENDPOINT,...args],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});active.add(child);
    let stdout='',bytes=0,stderrBytes=0,overLimit=false,spawnFailed=false,timedOut=false;
    const timer=setTimeout(()=>{timedOut=true;child.kill();},deadlineMs);
    child.stdout.on('data',b=>{bytes+=b.length;if(bytes<=maxBytes)stdout+=b.toString('utf8');else if(!overLimit){overLimit=true;child.kill();}});
    child.stderr.on('data',b=>{stderrBytes+=b.length;});
    child.on('error',()=>{spawnFailed=true;});child.stdin.on('error',()=>{});
    child.on('close',(code,signal)=>{clearTimeout(timer);active.delete(child);resolve({code,signal,stdout,stdoutBytes:bytes,stderrBytes,overLimit,spawnFailed,timedOut});});
    child.stdin.end(input);
  });
}
// Explicit fields only: no raw Docker configuration, command, environment or mounts.
const format='{"id":{{json .Id}},"name":{{json .Name}},"imageId":{{json .Image}},"run":{{json (index .Config.Labels "codex.usage-scale")}},"roleLabel":{{json (index .Config.Labels "codex.usage-role")}},"sourceLabel":{{json (index .Config.Labels "codex.usage-source")}},"restoreLabel":{{json (index .Config.Labels "codex.usage-snapshot-restore")}},"running":{{json .State.Running}},"startedAt":{{json .State.StartedAt}},"nanoCpus":{{json .HostConfig.NanoCpus}},"memory":{{json .HostConfig.Memory}},"memorySwap":{{json .HostConfig.MemorySwap}},"network":{{json .HostConfig.NetworkMode}}}';
let inspected,containers,discoveryPolls=0;
const discoveries=[];
while(performance.now()-start<45000){
  assert.equal(interrupted,false,'Interrupted during exact owner discovery');discoveryPolls++;
  const listed=await command(['container','ls','--all','--no-trunc','--filter','label=codex.usage-scale='+c.run,'--format','{"id":{{json .ID}},"name":{{json .Names}}}'],{deadlineMs:3000});
  assert.equal(listed.code,0,'Owner listing unavailable; cannot infer absence');assert.equal(listed.overLimit,false);assert.equal(listed.timedOut,false);
  const rows=listed.stdout.split(/\r?\n/).filter(Boolean).map(line=>JSON.parse(line));
  assert.equal(new Set(rows.map(r=>r.id)).size,rows.length);assert.equal(new Set(rows.map(r=>r.name)).size,rows.length);
  for(const row of rows){assert.match(row.id,/^[a-f0-9]{64}$/);assert.ok(c.containers.some(r=>expectedName(r.role)===row.name),'Unexpected exact-run owner');}
  discoveries.push({elapsedMs:performance.now()-start,ownersFound:rows.length});
  if(rows.length===6){
    const resolved=c.containers.map(row=>({...row,id:rows.find(r=>r.name===expectedName(row.role)).id}));
    const pg=resolved.find(r=>r.role==='postgres');
    const checked=await Promise.all(resolved.map(async row=>{
      const result=await command(['inspect','--type','container','--format',format,row.id],{deadlineMs:5000});
      assert.equal(result.code,0,'Owned-container verification failed');assert.equal(result.overLimit,false);assert.equal(result.timedOut,false);
      const actual=JSON.parse(result.stdout);assert.equal(actual.id,row.id);assert.equal(actual.imageId,row.imageId);assert.equal(actual.run,c.run);
      assert.equal(actual.name,'/'+expectedName(row.role));
      if(row.role==='postgres')assert.equal(actual.restoreLabel,c.run);else assert.equal(actual.network,'container:'+pg.id);
      if(['api','worker','generator','coordinator'].includes(row.role)){assert.equal(actual.roleLabel,row.role);assert.equal(actual.sourceLabel,SOURCE);}
      assert.equal(actual.nanoCpus,limits[row.role][0]*1e9);assert.equal(actual.memory,limits[row.role][1]);assert.equal(actual.memorySwap,limits[row.role][1]);return{role:row.role,...actual};
    }));
    if(checked.every(row=>row.running===true)){containers=resolved;inspected=checked;break;}
  }
  await new Promise(resolve=>setTimeout(resolve,1000));
}
assert.ok(containers&&inspected,'Exact six running owners were not available within bounded discovery');
const durationSeconds=Math.min(c.durationSeconds,140,Math.floor((148000-(performance.now()-start))/1000)-6);
assert.ok(durationSeconds>=1,'No bounded observer window remains');
assert.equal(interrupted,false,'Interrupted before sampling');
const captures=await Promise.all(containers.map(async row=>{
  // timeout owns the guest observer even if the Windows Docker client dies.
  // At maximum configuration: TERM at142s, KILL at144s, host bound at148s.
  const result=await command(['exec','-i',row.id,'sh','-c','command -v awk >/dev/null && command -v timeout >/dev/null && command -v sleep >/dev/null || exit 69; exec timeout -k 2 -s TERM "$@"','owned-counter-observer',String(durationSeconds+2),'awk','-v','duration='+durationSeconds,'-v','vm='+(row.role==='postgres'?'1':'0'),'-f','-'],{input:awk,deadlineMs:Math.max(1,148000-(performance.now()-start)),maxBytes:6*1024*1024});
  const series=[];let malformedLines=0,invalidCounters=0;
  for(const line of result.stdout.split(/\r?\n/).filter(Boolean)){
    try{const value=JSON.parse(line);assert.equal(value.schemaVersion,1);assert.equal(value.sample,series.length);assert.ok(Number.isFinite(value.unixSeconds)&&Number.isFinite(value.uptimeSeconds)&&Number.isFinite(value.elapsedSeconds)&&value.elapsedSeconds>=0&&value.elapsedSeconds<150);assert.ok(value.cpuMax&&value.cpuMax.quota/value.cpuMax.period===limits[row.role][0]);assert.equal(value.memoryMax,limits[row.role][1]);assert.equal(value.memorySwapMax,0);assert.ok(Number.isFinite(value.cpu.usage_usec));for(const k of ['userTicks','systemTicks','childUserTicks','childSystemTicks'])assert.ok(Number.isFinite(value.observerCpuTicks?.[k]));assert.equal(Object.hasOwn(value,'vm'),row.role==='postgres');if(series.length)assert.ok(value.uptimeSeconds>=series.at(-1).uptimeSeconds);series.push(value);}catch{malformedLines++;}
  }
  if(!series.length)invalidCounters++;
  const gaps=series.slice(1).map(r=>r.gapSeconds),first=series[0],last=series.at(-1);
  const observerTicks=first&&last&&first.observerCpuTicks&&last.observerCpuTicks?Object.fromEntries(Object.keys(first.observerCpuTicks).map(k=>[k,last.observerCpuTicks[k]-first.observerCpuTicks[k]])):null;
  const {stdout,...exit}=result;
  return{role:row.role,containerId:row.id,inspection:inspected.find(r=>r.role===row.role),exit,samples:series.length,malformedLines,invalidCounters,maxGapSeconds:gaps.length?Math.max(...gaps):null,observerCpuTickDeltas:observerTicks,ancestorEvidence:series.some(r=>r.ancestors.length)?'visible-subset-only':'not-visible-in-container-cgroup-namespace',series};
}));
const cpu=process.cpuUsage(cpuStart),elapsedMs=performance.now()-start;
const result={schemaVersion:1,run:c.run,source:SOURCE,diagnosticOnly:true,capacityAccepted:false,productionMutations:0,readOnly:true,endpoint:ENDPOINT,configSha256:hash(configRaw),samplerSha256:c.samplerSha256,awkSha256:c.awkSha256,startedAt,finishedAt:new Date().toISOString(),durationRequestedSeconds:c.durationSeconds,durationEffectiveSeconds:durationSeconds,discoveryPolls,discoveries,hostElapsedMs:elapsedMs,interrupted,hostObserverCpuMicroseconds:cpu,hostObserverActiveChildren:active.size,captureComplete:!interrupted&&captures.every(r=>r.exit.code===0&&!r.exit.overLimit&&!r.exit.spawnFailed&&!r.exit.timedOut&&r.malformedLines===0&&r.invalidCounters===0),captures,limitations:['Counters do not establish an environment cause or capacity pass.','Leaf cgroups cannot expose hidden ancestors; missing ancestor counters are unknown, not unlimited.','PG-only /proc summaries are the Docker Linux VM view, not Windows host pressure.','Guest observer CPU is raw USER_HZ ticks (self plus reaped sleep children); host CPU excludes Docker CLI/daemon cost and final serialization/write.','Existing workload owner may stop a container before requested duration; retain that nonzero/partial capture without inventing missing samples.','No Windows process inventory or VM-wide unrelated-container inventory is captured.']};
fs.writeFileSync(c.outputFile,JSON.stringify(result)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({run:c.run,outputFile:c.outputFile,sha256:hash(fs.readFileSync(c.outputFile)),captureComplete:result.captureComplete,samples:captures.map(r=>({role:r.role,samples:r.samples,exitCode:r.exit.code})),diagnosticOnly:true,capacityAccepted:false}));
if(!result.captureComplete)process.exitCode=1;
