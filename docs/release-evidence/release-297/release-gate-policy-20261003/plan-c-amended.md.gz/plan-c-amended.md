> OWNER-ADOPTED AMENDMENT — October 3, 2026
>
> SchoolPilot/ClassPilot 2.9.7 may proceed with both new Usage modes off after passing final-source regression, classroom, current-school capacity and recovery checks. Usage activation requires its separate completed development, synthetic capacity acceptance and deployed observation. Historical single-task 100-heartbeat/second failures remain preserved and are not reclassified as passes.
>
> The owner approved bounded non-regression margins (5% CPU, 10% p95 plus absolute
> bounds), sticky three-to-two failure evidence and an existing-Linux-host fallback.
> The current implementation specification is docs/RELEASE_297_DEPLOY_READINESS.md
> on SchoolPilot release branch #603. It supersedes this proposal's pending decisions
> and release/activation steps below. Original proposal preserved separately with
> SHA-256 b1c32fff6660a64748a0bdb83a583a74db5251b0412e7d7db7b468092a72053b.
>
> Fewer SQL statements do not prove non-regression. Passing 64 reports and worker
> timings does not prove Usage acceptance: the latest diagnostic failed lifecycle
> and drain and did not run post-load correctness. Host interference is suspected,
> not established. Three tasks do not prove balanced sticky-client traffic.

# Release 2.9.7 Usage capacity gate: Plan C (split the gate)

Prepared 2026-10-03 for the agent working on `codex/release-stabilization-297` (PR #603), at the request of Brian, the release owner.

**What this is.** A read-only analysis of why the Usage capacity gate keeps failing, and the plan Brian chose from three options. Two multi-agent passes read the evidence under `docs/release-evidence/release-297/usage-contention/` and the code at HEAD `c237cd7a` (application `814844f3`); a second pass tried to refute the findings and attacked the proposed designs. Nothing was executed: no harness run, no Docker, no tests, no AWS call. Nothing in your worktree was modified. Every number below is read from your evidence or is arithmetic on it. Treat each as a claim to verify; the supporting reports with file and line citations are in `analysis/` beside this file.

**What Brian decided.** Direction only: Plan C. The exact replacement wording for the checklist and roadmap (section 6) is a draft. Do not commit it until he approves the text.

---

## 1. Summary of the ask

1. Stop spending runs on heartbeat throughput tuning against the single-task 100/s profile. It is not passable by tuning (section 2).
2. Preserve the failed campaign properly before anyone edits the validator (step 0.2).
3. **Release track.** With both Usage modes off, as the release deploys, produce two results: a black-box baseline pair showing the candidate is no worse than the production-serving source, and a measured single-task envelope from a rate sweep. Draft the wording that makes these the release precondition.
4. **Activation track.** Before either Usage mode is switched on, later and separately: a posture-shaped profile with the full Usage load, heartbeat admission control, and the Usage write-path fixes in section 5. None of this blocks 2.9.7.

The registered profile `release-enabled-linux-role-default-100rps-v1`, its contract hash and its failed attempt stay exactly as recorded.

---

## 2. Why: what the analysis established

| Finding | Basis | Where to verify |
|---|---|---|
| No run has ever passed the gate: 0 of 28 measured runs across 19 commits | read | `analysis/evidence-timeline.md`, `analysis/production-reality.md` section 5 |
| The Usage-specific criteria pass in the latest clean run: 64/64 reports, rollups 11.8 s and 29.6 s against 48 s | read | `diagnostic-8148-pressure-01/summary.json` |
| Heartbeat ingest fails without any Usage work: capped ingestion-only runs delivered 4,158 to 5,139 of 6,000 on `5d543f40`, `0e427e3c`, `e95a2b56`. No ingestion-only run exists on `814844f3` | read | `analysis/skeptic-usage-wal.md` verdict 1 |
| Root constraint is main-thread time in the API process. Latest clean run: 66.2 CPU-s in 67.4 s, event-loop utilization 0.978, cgroup throttled in 627 of 674 periods, about 86% of sampled API Postgres backends idle on ClientRead. Even the uncapped 6,000/6,000 run was at 0.9855 utilization with a 7.1 s median | read, re-derived | `analysis/skeptic-mechanics.md` |
| Redis, lock serialization and pool size were tested as alternative explanations and rejected. The Redis rejection is indirect: no Redis or Postgres container CPU was ever recorded | inference from evidence | `analysis/skeptic-mechanics.md` |
| One heartbeat is at least 21 Postgres statements over 3 sequential pool checkouts (1 + 4 + 16), measured mean 23.9, plus 7 Redis commands (code count; Redis is not instrumented). The statement counters reconcile exactly: 81,750 = 16 x 4,334 + 5 x 990 + 4 x 1,864 | read, reconciled | `analysis/heartbeat-route-code.md` |
| The 904 HTTP 500s are 5,000 ms pool-acquisition timeouts, split 300 / 299 / 305 across the three checkouts. The 305 had already inserted their row. Heartbeats have no admission control | read | `analysis/pool-admission-code.md` |
| "CPU per started heartbeat" is close to a tautology under the quota (quota seconds divided by requests the generator managed to start). Do not use it to compare commits. Use CPU per HTTP 200 below saturation, and service rate at saturation | reasoning | `analysis/skeptic-mechanics.md` |
| Usage work costs roughly 28 to 48% of the combined-run shortfall. Heartbeat rows persist at about 53 to 60/s while reports and rollups run and 78 to 94/s after | re-derived | `analysis/skeptic-usage-wal.md` verdict 2 |
| The multi-second stalls are a storage-flush stall inside the Docker Desktop VM, triggered while Usage work writes. Per-fdatasync proxy 17 to 83 ms in the three capped stalled runs against 0.5 to 4.4 ms otherwise. WAL volume is the same in stalled and clean runs. Every capped stalled run also fails on the generator alone (late offers 408, 199, 293) | re-derived; mechanism unproven | `analysis/skeptic-usage-wal.md`, `analysis/attack-design-usage-contention.md` blocker 1 |
| The "107 to 182 MB of WAL in a second" is a statistics artefact: the rollup writes WAL steadily for 11 to 25 s and the counters publish at commit | read | `analysis/skeptic-usage-wal.md` new findings |
| Not a 2.9.7 regression by code count: production source `7af9d0dd` runs 56 statements over 6 checkouts for the gate's client profile; the candidate runs 21 over 3. Never measured | counted from source | `analysis/skeptic-baseline.md` |
| After every proposed heartbeat-path change, forecast cost is 8.6 to 11.2 ms per heartbeat (reviewer) or 7.3 to 10.3 ms (designer). Break-even at 100/s on one CPU is 10 ms; a stable queue needs about 7 ms | forecast, unmeasured | `analysis/design-fused-heartbeat.md`, `analysis/attack-design-fused-heartbeat.md` |
| The gate shape is not a documented requirement. The 100/s profile first appears on 2026-10-02; the checklist never names a task count or CPU cap; the 1-CPU single-task shape comes from the role harness of 2026-10-03. Live runs three API tasks on school days; the documented posture is 13 to 27 heartbeats/s per task | read (git history) | `analysis/skeptic-gate-origin.md` |

Two consequences drive the plan. First, tuning cannot close a gap of about 45% when each adopted optimization was worth 0.5 to 0.85 ms and same-source results differ by more than that (`814844f3`: 3,042 and 4,334). Second, a "three consecutive" rule on this host is exposed to a stall that no application change removes.

---

## 3. Decision status

Chosen by Brian on 2026-10-03: **Plan C**. Shipping 2.9.7 with Usage off is judged on what deploys. Switching Usage on is judged separately, later.

Still his to decide. Bring these back to him; do not settle them yourself:

1. The exact replacement text in section 6.
2. The baseline acceptance rule in step 1.1 (what "no worse" means in numbers).
3. Which capability flags production runs today, for baseline arms A and B, or permission to read the live task definition read-only.
4. For the later posture gate: the comparison-run rule and the position on losing one of three tasks (step 2.1).
5. Whether registered runs move to a Linux host if the stall survives on a quiet, validated host.

---

## 4. Release track

### Step 0. Before any code

**0.1 Stop the tuning loop.** No further optimization runs against the 100/s profile. Any future A/B needs an A/A noise block first; reviewers estimate 6 to 16 alternating pairs per change to resolve 0.5 ms.

**0.2 Close the registered campaign.** `capacity-8148-attempt-01/campaign-journal/` holds only `campaign.json.gz`, `001.registration.json.gz` and `001.completion.json.gz`. There is no journal closure, and `roles/campaign-journal.mjs` allows further attempts in an open campaign. Close it with the unmodified `814844f3` roles files and retain the journal hash. If its output directory is gone, record an abandonment note beside the archived journal. Do this before touching `campaign-validation.mjs` or `campaign-journal.mjs`. When you first change the validator, add a test that pins the default-profile contract hash as a literal; today `campaign-validation.test.mjs` uses the imported constant, so a refactor could change the hash and still pass.

**0.3 Mine the existing runs.** Tabulate the 16 combined runs by stall yes or no against: fresh seed or restored snapshot, restore-to-release delay, restart signature (`wal.statsReset` relative to the restart, baseline `checkpoints_req`), `wal_sync` count, late offers, generator and idle-worker event-loop maxima. Record host logical CPUs and `docker info` NCPU. This costs no run and may settle whether the stall is the host.

**0.4 Optional, only before the current snapshot expires.** Three ingestion-only repeats at 100/s on the existing `814844f3` image, helper and snapshot give the first same-source noise estimate on the candidate. Snapshots are valid only on the school-local day they were prepared (`roles/snapshot-contract.mjs:11-12`). If the day has rolled over, fold this into step 1.2 instead.

### Step 1.1 Black-box baseline pair

Purpose: turn "the candidate is cheaper than what production serves" from a code count into a measurement, in the configuration that actually deploys.

The role harness cannot start on `7af9d0dd`: `scripts/load/usage/` does not exist there, `release-enabled-process.mjs` imports three modules that source lacks, the rollout map names capabilities that make the old API refuse to boot, and the catalog check expects 129 RLS tables against 121. Full list in `analysis/skeptic-baseline.md` under "Feasibility".

Minimum fair variant: measure only from outside the application and run the identical driver against both commits. New files only; no existing file modified.

| File | Purpose |
|---|---|
| `blackbox-api-entry.mjs` | Start the API using only modules present on both commits. No pool or query wrappers |
| `blackbox-generator.mjs` | Mint tokens with each arm's own `createStudentToken`; send the gate's heartbeat body; record status histogram, latency, refused and late offers |
| `open-loop-heartbeats.mjs` | Reused unchanged. It imports nothing from the application |
| `blackbox-env.mjs` | Rollout map limited to the capabilities both commits support; both Usage modes unset; pools 16 and 2; each commit's own RLS table list |
| `blackbox-fixture.mjs` | Seed only tables common to both schemas: 2 schools, licences, settings, classes, 500 students each, devices, sessions, open live teaching sessions; then each commit's own `backfillOpenTeachingSessionRosterSnapshots` |
| `run-blackbox.ps1` | Postgres 4 CPU / 4 GiB, Redis 1 CPU / 256 MiB, API 1 CPU / 2 GiB, generator 2 CPU. Capture API container `cpu.stat` before and after, and `pg_stat_database` / `pg_stat_statements` deltas |

Arms:

| Arm | Image | Flags |
|---|---|---|
| A | `7af9d0dd` | as production serves |
| B | `814844f3` | same as A; both Usage modes unset. This is deploy day |
| C, optional | `814844f3` | release-enabled, to tie black-box numbers to the gate configuration |

Runs: 34/s and 100/s, at least two repetitions per arm per rate, alternating A and B in one host session. Add a third at 100/s if the arms' ranges overlap.

Requirements:

- Both arms must take the same path. Assert on every 200 that `scopedAuthorityChecksV1` and `screenshotTrackingWindowLeaseV1` were accepted, which proves both took the lease path (56 statements on A).
- Record `node --version` per image. Both Dockerfiles use the floating `node:22-alpine` base.
- The seeder may use only columns present in both schemas. Not verified.
- Each arm migrates its own schema. The candidate needs migration 54 and its function grant or it refuses to start.
- The fixture is small, so absolute numbers are not comparable with gate numbers. Only the paired difference means anything.
- Apply the validity rule in step 1.3.

Proposed acceptance, for Brian's approval:

- At 34/s every offer returns HTTP 200 in both arms, and arm B's API CPU per HTTP 200 and heartbeat p95 are no worse than arm A's, judged on the ranges across repetitions.
- At 100/s arm B completes at least as many HTTP 200 as arm A.
- Report the paired differences with their ranges. If arm A fails at 34/s, that is itself the finding; report it and stop.

### Step 1.2 Single-task envelope from a rate sweep

Purpose: every one of the 28 runs was offered exactly 100/s and every capped run is saturated, so the intrinsic cost per heartbeat and the highest zero-failure rate have never been measured. The checklist already asks to "preserve ... the measured capacity envelope"; this produces it.

New named diagnostic profile, for example `release-enabled-linux-role-rate-sweep-diagnostic-v1`. Canonical files stay byte-identical: `open-loop-heartbeats.mjs`, `release-enabled-*.mjs`, `RELEASE_ENABLED_PROFILE`, and `PROFILE` in `roles/profile.mjs`.

Parameters per rate r, keeping the 10 s cadence and six offers per device: `devicesPerSchool = 5r`, `maxInFlight = 10r`, `durationMs = 60000`.

| Rate /s | devicesPerSchool | maxInFlight | Offers |
|---:|---:|---:|---:|
| 30 | 150 | 300 | 1,800 |
| 34 | 170 | 340 | 2,040 |
| 40 | 200 | 400 | 2,400 |
| 45 | 225 | 450 | 2,700 |
| 50 | 250 | 500 | 3,000 |
| 60 | 300 | 600 | 3,600 |
| 70 | 350 | 700 | 4,200 |
| 80 | 400 | 800 | 4,800 |

Ingestion-only at all eight rates, with repeats at 34 and 50, interleaved so drift is not confounded with rate. Then combined-phase points at 34 and 50 with the full Usage load. The highest combined zero-failure rate is the envelope the documents may cite.

Plumbing defects the review found in the first design. All must be fixed or a 60/s run will silently offer 100/s under the registered profile name:

- `makeRoleEnvironment` builds the role environment from `FIXTURE_KEYS` only (`roles/role-environment.mjs:21`). A variable added to `ENV_KEYS` is dropped. Pass the rate explicitly, next to `USAGE_RELEASE_PHASE` (lines 24 to 35).
- The generator merges only `durationMs` from the coordinator (`release-enabled-generator.mjs:222`), and the role overlay's traffic options return `{}` (`roles/patch-coordinator.mjs:20`).
- `PROFILE` is one constant returned by `assertExecutionMode` (`roles/profile.mjs:25`) and written into the role plan, the generated profile, and the preparation and execution receipts. Thread a profile object (name plus offering) through all of them.
- `inheritWorkloadContract` asserts the offering deep-equals the canonical 100/s constant (`roles/role-environment.mjs:39-41`).
- Have the coordinator assert that `phase.traffic.heartbeats.configured.requestsPerSecond` equals the declared rate and fail the run otherwise. Use a control at a non-default rate; a control at 100 cannot detect a dropped variable.
- Build the sweep helper from its own context with final argument `diagnostic`. The profile name is baked into the overlay at context creation.
- Keep 5-second buckets of started, 200, failed and p95 instead of discarding per-request timings.

Open point to check before the combined-phase points: the report and current-day rollup oracles may assume all 500 students per school have current-day rows (`roles/campaign-validation.mjs` around lines 186 to 189). At 34/s only 170 per school do.

Constraints that set the run count: a snapshot is same-source and same-day only, so capture one per source per day; every restore has a 16-minute validity horizon, so each run needs its own restore and cold restart; planning figure 20 to 30 minutes per run. Any PR touching `scripts/load/**` triggers the roughly 30-minute `rollout-safety` job.

Record the result as `docs/release-evidence/release-297/usage-contention/single-task-envelope-8148-01/`: one row per run (source, profile, offered, started, 200s, failed, refused, late, p50, p95, max, cgroup API CPU seconds, CPU ms per 200 over the whole window and over t = 15 to 60 s, throttled periods, event-loop utilization, pool max wait, validity flag). Derived lines: highest zero-failure rate ingestion-only and combined; highest rate meeting p95 at or below 500 ms and CPU below 60%; saturated service rate. Label it "heartbeats per second, synthetic, local Docker, 4-CPU Postgres; not production headroom and not a device ceiling". Real traffic per device is several times a bare heartbeat.

### Step 1.3 Run-validity rule

Declare it before the first run of steps 1.1 and 1.2 and write it into the new profiles. It does not apply retroactively to any recorded run.

- Generator: zero late offers, zero throttled periods.
- An idle canary process: event-loop maximum under a stated bound.
- Coordinator: largest sampling gap under a stated bound.
- Restart signature: baseline `wal.statsReset` precedes the cold restart and baseline `checkpoints_req` is 0. In `capacity-8148-attempt-01` the statistics were reset at restart and a 16,301-buffer checkpoint with 3,240 ms sync preceded measurement.
- Restore-to-release delay inside a fixed band. It varied from 99.7 s to 270 s.
- Quiet host: no test suites or image builds during measurement.
- WAL and I/O timing on, under a diagnostic variant only: two separate `ALTER SYSTEM SET` statements in two separate `psql -c` invocations after ANALYZE. One combined statement is invalid, and `restore-snapshot.mjs` is shared with candidate runs.
- Record `docker info` NCPU in every receipt.

A run that breaches the rule is a preparation failure: retained, labelled, never deleted and never counted as a pass. Report excluded runs per arm.

Sampler notes: the earlier sampler failed on a BusyBox awk regex. It also runs through `docker exec` inside each container, so its cost is charged to the saturated API quota, and it hard-codes the source SHA. Sample at about 0.2 Hz or keep sampled and unsampled runs separate.

### Step 1.4 Wording and remaining release checks

Draft the documentation changes in section 6 and send the diff to Brian. Commit only after he approves the text. Everything else in "Acceptance before an operator green light" is unchanged, including green CI on the final head.

---

## 5. Activation track: required before either Usage mode is switched on

Not release-blocking. Listed so the work is not lost and so the review's corrections travel with it.

**2.1 Posture profile**, for example `release-enabled-linux-role-posture-34rps-v1`: one 1-CPU API role offered 34/s (2 x 170 devices, 2,040 offers) with the full Usage load unchanged. Review corrections:

- Keep canonical files untouched. `campaign-validation.mjs:4` imports the canonical `capacityAcceptance`, which hard-codes 6,000 (`release-enabled-profile.mjs:58-66`); the role overlay cannot reach it. Wrap it in the roles layer and replace exactly the three count-dependent keys (`allHeartbeats`, `heartbeatCompletionDeadline`, `observationsRecorded`); assert the remaining key set is identical and true.
- Derive every bound from the contract. `campaign-validation.mjs:171` requires `offerWindowMs >= 59990`, but at 34/s the last offer is scheduled at 59,970.6 ms, so a clean run fails. Others: `peakInFlight <= 1000` (line 168), 3,000 per school (line 175), the 204 allowance, current-day row counts. Add a test that enumerates every numeric literal in the validator.
- A posture campaign cannot close today: closure requires a passing native 100/s comparison (`campaign-validation.mjs:229-232`, `campaign-journal.mjs:53-58`), which has never passed. Brian must decide the comparison rule first. Recommended: the posture contract declares no original comparison and the baseline pair from step 1.1 replaces it.
- New profile name, new contract hash, new campaign directory. Add tests that a posture attempt cannot register in a default-profile campaign, and the reverse.
- Criteria: every existing zero-failure check at 34/s, heartbeat p95 at or below 500 ms, API CPU below 60% of quota. Decide the measurement window (whole run or t = 15 to 60 s) before the first registered attempt. Treat throttled periods as an observation, not a threshold.
- Add one zero-failure survival run at 50/s. With one of three tasks lost, 1,000 devices put 50/s on each remaining task.
- One or two diagnostic rehearsals and a negative control before declaring the campaign.

**2.2 Heartbeat admission control.** Shed before the first database checkout with 503 and Retry-After. `classpilotTileAdmission.ts` is the precedent; `studentAuthenticationServiceError` is the precedent for mapping a pool timeout to 503. It must produce zero 503s at posture load (`docs/SCALE_READINESS.md:343-344`). The 2.9.7 extension retries a 500 or 503 heartbeat once after about 1 s and honours Retry-After for that delay; confirm in the extension source. This protects production; it cannot pass a gate that counts every non-200 as a failure.

**2.3 One connection lease per heartbeat**, first stage only. Review corrections, each a blocker in the first design:

- The entitlement read stays a separate first statement on the lease. Do not fold it into the persistence-context read: the outside-tracking-window branch (`devices.ts:3909-3922`) returns before that read.
- The 204 short-circuit path (`devices.ts:3838-3897`) returns before the lease opens. Run the entitlement read inside that path's own context, or keep the middleware for requests that can short-circuit. Add tests that an unentitled school gets 403 on both branches.
- Use the single lease only on the negotiated teaching-session path. For legacy, supervision and non-negotiated clients, decide suspend immediately after phase 1, before `devices.ts:4250`; their publisher opens its own lease and a nested checkout can deadlock a 16-connection pool.
- Do not wrap the whole handler in one tenant scope. The `db` proxy resolves the tenant store with an unchecked AsyncLocalStorage read (`src/db.ts:185-191`), so detached work would capture a live or released client. Audit every detached call inside phase 1, starting with `devices.ts:4048`.
- Ship the Redis-slow breaker in the same change, defaulting to suspend when Redis is not ready.
- Forecast saving 0.3 to 0.5 ms per heartbeat. Its value is removing two of three queue passes and the saved-then-500 outcome, not passing a gate.

**2.4 Pool lanes.** Label the pre-admission membership and role lookups `user_identity` (`requireSchoolContext.ts:14-19`, `requireRole.ts:15-19`) and give heartbeats their own lane, so staff requests stop waiting about 4.3 s behind them under overload. Ordering only, active only with Digital Usage on. `tests/fair-main-pool.test.mjs` pins the current lane semantics. This fixes the pool wait; a CPU-saturated event loop still limits staff latency.

**2.5 Rollup writes only changed grains.** The gate measures a first compute (30 rows deleted against 172,802 inserted), so this does nothing for any gate. In production the hourly recompute rewrites the whole school-day. Use three sibling data-modifying CTEs joined to `grains` in the existing transaction and advisory lock: UPDATE rows whose values differ, INSERT grains with no row, DELETE rows with no grain. Do not use `ON CONFLICT DO UPDATE ... WHERE`: it row-locks every conflicting row and writes WAL for unchanged rows. Acceptance: a recompute EXPLAIN at 84,000 existing rows showing hash joins inside the 60 s budget; a no-change recompute with no WAL from unchanged rows; row identity against the old writer; a concurrent student delete still cascading. Update `docs/CLASSPILOT_DIGITAL_USAGE.md` lines 41 and 89 in the same PR.

**2.6 Report cost.** Decide on disabling parallel workers only from a measured single-threaded `EXPLAIN (ANALYZE, BUFFERS)` of the 365-day school report and a reports-only run with eight distinct reports per school. If that does not fit the 15 s statement and 20 s request budgets, the fix is a per-day summary. Coalescing identical in-flight reports is not a safety margin: duplicates exist because the generator sends every report twice.

**2.7 Harness determinism.** The lifecycle poll's timeout shrinks toward zero (`release-enabled-generator.mjs:114-120`), which turned one slow run into an aborted response, an unverifiable drain and a forced API exit. Fixing it changes a canonical file, so it needs a new source commit and image. Add a clean-restart assertion to the cold-restart step.

**Held or not recommended**

| Item | Position |
|---|---|
| `synchronous_commit = off` on heartbeat transactions | Hold. It targets a stall that looks like the host. Revisit only if commit-flush wait survives on a validated quiet host, and then behind a default-off switch |
| Server-side fusion of the delivery sequence (a 55th migration) | Only if a capped prototype shows at least about 1 ms per heartbeat. Forecast is break-even at best, and a 55-entry ledger invalidates the current evidence set and recovery rehearsal |
| Merging the global and per-device limiters into one script | Do not. They sit on opposite sides of authentication |
| A context function that sets the tenant scope | Do not. The tracking-settings read runs before it and would run unscoped |
| Garbage-collector flags | Measurement only (GC trace, per-thread CPU keyed by TID). No flag change in this release |
| Dropping the redundant prefix index on `classpilot_usage_rollups` | Defer until a migration is shipping anyway |

---

## 6. Draft wording, for Brian's approval before any commit

`<date>` is the date he approves the text.

**`docs/RELEASE_2_9_7_OPERATOR_CHECKLIST.md`, lines 253 to 261.** Current text begins "Require three consecutive cold, release-enabled final-source/schema runs before requesting release execution." Proposed replacement:

> Before requesting release execution, record two synthetic results on the final source with both Usage modes off, as the release deploys. First, a black-box baseline pair against the production-serving source under identical flags, one 1-vCPU API task and the same fixture: at 34 heartbeats/second every offer returns HTTP 200 in both arms and the candidate's API CPU per HTTP 200 and heartbeat p95 are no worse than the baseline's; at 100/second the candidate completes at least as many HTTP 200 responses as the baseline. Second, the measured single-task envelope: the highest zero-failure rate, heartbeats only and with the full Usage load. The single-task 100/second profile `release-enabled-linux-role-default-100rps-v1` remains a recorded failure and is not a release precondition; its registered attempt and every diagnostic stay preserved. Do not describe any of these results as production headroom.

**Same file, lines 263 to 265.** Current: "The current release decision requires completed Usage development and synthetic acceptance before requesting execution. Its deployed shadow/rollup observation still gates later reporting activation." Proposed:

> The release decision of `<date>` separates two gates. Requesting release execution requires the baseline pair and envelope above, with both Usage modes off at deploy. Turning either Usage mode on requires three consecutive cold passes of the posture profile with the full Usage load, a zero-failure run at 50/second, and heartbeat admission control in the serving source. Deployed shadow/rollup observation still gates later reporting activation.

**`docs/SCHOOLPILOT_COMPETITIVE_ROADMAP.md`, lines 12 to 15.** Current: "The owner's subsequent decision requires all Usage development and synthetic capacity acceptance before requesting coordinated release execution." Proposed:

> The owner's decision of `<date>` separates the two gates. Coordinated release execution, with both Usage modes off, requires a measured baseline pair showing the candidate is no worse than the production-serving source. Usage activation requires synthetic acceptance of the posture-shaped profile and heartbeat admission control. The single-task 100/second profile is retained as a failed stress record with a measured envelope. Usage's deployed observation remains a later activation gate.

Also keep consistent: `docs/RELEASE_297_USAGE_AND_RUNTIME_EVIDENCE.md` (around lines 224 to 232 and 239 to 240), a new section in `scripts/load/usage/roles/README.md` naming every profile and its purpose, and the PR #603 description.

History worth stating plainly in whatever is written: the first checklist (`3819a6e7`, 2026-10-02 13:42 ET) said "Usage capacity/observation does not hold up an otherwise accepted classroom release"; `cb66014d` (19:13 ET the same day) changed it to "before requesting release execution" after both cold runs had already failed, and no reason is recorded.

---

## 7. Do not

- Do not relabel, reinterpret or delete any recorded failure. The registered profile, its hash and its attempt stay byte-identical.
- Do not edit canonical harness files for the sweep or the baseline. A canonical edit is a new source commit and invalidates the `814844f3` image, scan receipt, helper binding and snapshot.
- Do not commit the section 6 wording before Brian approves it.
- Do not deploy, merge, turn on either Usage mode, or publish anything as part of this plan.
- Do not call any synthetic figure production headroom or a device ceiling.
- Do not add hot-path changes from section 5 to the 2.9.7 candidate without Brian's say-so. They are scoped to the activation track.

---

## 8. Report back

1. Campaign closure hash, or the abandonment note (step 0.2).
2. The stall table from existing runs and what it shows (step 0.3).
3. Baseline pair: per run, HTTP 200 / failed / refused / late, p50 / p95 / max, API CPU seconds, CPU ms per 200, throttled periods, statements and commits per heartbeat; the paired differences; invalid runs listed.
4. Envelope table and the three derived lines.
5. The documentation diff, waiting for approval.
6. Anything in section 2 that your own verification contradicts. The analysis ran nothing, so your measurements outrank it.

Reviewers' estimates, uncertain: about 3 to 5 working days for the baseline pair, about 1 to 2 for the sweep plumbing and runs, and 7 to 9 working days to a first registered posture attempt on the activation track.

---

## 9. Supporting analysis

In `analysis/` beside this file. First-pass reader reports, then the second pass that tried to refute them and reviewed each design.

| File | Covers |
|---|---|
| `evidence-timeline.md` | All 28 runs, every optimization tried and its whole-run effect, variance |
| `latest-runs-forensics.md` | The two `814844f3` runs: failure mechanics, per-phase timings, Postgres side |
| `heartbeat-route-code.md` | Ordered inventory of the 21 statements and 7 Redis commands, locks, repeated checks |
| `pool-admission-code.md` | Pools, fair pool lanes, timeouts, absence of shedding, extension retry behaviour |
| `cpu-profile-evidence.md` | Where API CPU goes, prior prototypes, budget arithmetic, cgroup throttling |
| `harness-validity.md` | Exact workload, payload, thresholds, what the test does and does not model |
| `production-reality.md` | Live shape, documented posture, origin of the gate numbers |
| `usage-worker-reports-code.md` | What reports and rollups cost, locks, indexes |
| `git-delta-hot-path.md` | Hot-path changes between production main and the candidate |
| `skeptic-mechanics.md` | Refutation attempt on the root cause; alternatives tested |
| `skeptic-baseline.md` | Independent baseline count; why the harness cannot run on `7af9d0dd`; black-box spec |
| `skeptic-usage-wal.md` | Usage share; the stall re-examined run by run |
| `skeptic-gate-origin.md` | Commit-by-commit history of the gate wording and shape |
| `design-fused-heartbeat.md`, `attack-design-fused-heartbeat.md` | Heartbeat-path redesign and its review (five blockers) |
| `design-usage-contention.md`, `attack-design-usage-contention.md` | Usage-side fixes and their review |
| `design-gate-and-measurement.md`, `attack-design-gate-and-measurement.md` | Sweep, baseline, posture profile, and the six harness defects |

Where a design file and its review disagree, the review is the later word. Some reports cite scratch scripts under a temporary session folder that no longer exists; the evidence paths they cite are yours and are stable.
