import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,realpathSync,existsSync,mkdirSync,readdirSync,lstatSync} from 'node:fs';
import {resolve,join,dirname,basename,relative,isAbsolute,sep} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash,randomBytes} from 'node:crypto';

// Configuration only. No Docker, DB, campaign mutation, attempt registration,
// gate publication, retry, or acceptance decision is performed by this helper.
export const SOURCE='814844f344a45159152415b0fb6d7027f05b093e';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=value=>JSON.stringify(value,null,2)+'\n';
const read=file=>JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const sha=value=>assert.match(value,/^[a-f0-9]{64}$/);
const digest=value=>assert.match(value,/^sha256:[a-f0-9]{64}$/);
const KEYS=['sourceDirectory','harnessDirectory','candidatePreparationFile','candidatePreparationSha256','bindingFile','bindingSha256','runtimeProofFile','runtimeProofSha256','snapshotDirectory','snapshotManifestSha256','redisImage','docker','endpoint','campaignDirectory','evidenceDirectory','privateDirectory','configurationDirectory'];
export function disjoint(a,b){for(const[parent,child]of[[a,b],[b,a]]){const r=relative(parent,child);assert.ok(r&&(r==='..'||r.startsWith('..'+sep)||isAbsolute(r)),'Paths must be disjoint');}}
function absolute(value){assert.equal(typeof value,'string');assert.ok(isAbsolute(value)&&!/[\r\n,]/.test(value));return resolve(value);}
function futurePath(value){const full=absolute(value);return join(realpathSync(dirname(full)),basename(full));}
function bound(file,expected){sha(expected);const raw=readFileSync(file);assert.equal(hash(raw),expected,'Receipt hash mismatch');return JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''));}
function committed(root,file){assert.ok(!file.includes('..'));return execFileSync('git',['show',SOURCE+':'+file],{cwd:root,encoding:null,maxBuffer:16*1024**2,windowsHide:true});}
export function originalScriptHashes(sourceDirectory){return Object.fromEntries(readdirSync(join(sourceDirectory,'scripts/load/usage')).filter(name=>name.startsWith('release-enabled-')||name==='run-release-enabled-scale.ps1'||name==='prepare-release-control-ownership.mjs'||name==='local-usage-scale.mjs').map(name=>[name,hash(readFileSync(join(sourceDirectory,'scripts/load/usage',name)))]));}

export async function prepare(input){
  assert.deepEqual(Object.keys(input).sort(),[...KEYS].sort(),'Closed input schema; no mode/resource/deadline overrides');
  const sourceDirectory=realpathSync(absolute(input.sourceDirectory));
  const git=args=>execFileSync('git',args,{cwd:sourceDirectory,encoding:'utf8',windowsHide:true}).trim();
  assert.equal(git(['rev-parse','HEAD']),SOURCE);assert.equal(git(['status','--porcelain']),'');
  assert.ok(lstatSync(join(sourceDirectory,'.git')).isDirectory(),'Use the self-contained clean source clone');
  assert.equal(existsSync(join(sourceDirectory,'.git/objects/info/alternates')),false);
  const harnessDirectory=realpathSync(absolute(input.harnessDirectory));
  const snapshotDirectory=realpathSync(absolute(input.snapshotDirectory));
  const candidatePreparationFile=realpathSync(absolute(input.candidatePreparationFile));
  const bindingFile=realpathSync(absolute(input.bindingFile));
  const runtimeProofFile=realpathSync(absolute(input.runtimeProofFile));
  const candidate=bound(candidatePreparationFile,input.candidatePreparationSha256);
  const binding=bound(bindingFile,input.bindingSha256),proof=bound(runtimeProofFile,input.runtimeProofSha256);
  assert.equal(candidate.source,SOURCE);assert.equal(candidate.passed,true);
  assert.equal(binding.schemaVersion,2);assert.equal(binding.applicationSource,SOURCE);assert.equal(binding.applicationChanges,0);
  assert.equal(binding.passed,true);assert.equal(binding.cleanupPassed,true);
  assert.equal(binding.predeclaredExecutionMode,'capacity-candidate');assert.deepEqual(binding.allowedModes,['diagnostic','capacity-candidate']);
  assert.equal(binding.candidateImageId,candidate.image.indexDigest);assert.equal(binding.candidateConfigDigest,candidate.image.configDigest);
  assert.equal(proof.runtimeSha256,binding.runtimeSha256);assert.match(proof.node,/^v\d+\.\d+\.\d+$/);
  const scan=bound(candidate.scan.receiptPath,candidate.scan.receiptSha256);
  assert.equal(binding.candidateScanReceiptSha256,candidate.scan.receiptSha256);
  assert.equal(scan.sourceSha,SOURCE);assert.equal(scan.imageId,candidate.image.indexDigest);assert.equal(scan.configDigest,candidate.image.configDigest);
  assert.equal(scan.passed,true);assert.equal(scan.os,'linux');assert.equal(scan.architecture,'amd64');assert.equal(scan.counts.HIGH,0);assert.equal(scan.counts.CRITICAL,0);
  for(const[name,expected]of Object.entries(binding.roleHarnessSha256)){
    assert.match(name,/^[a-z0-9][a-z0-9.-]+\.(?:mjs|ps1)$/);sha(expected);
    assert.equal(hash(readFileSync(join(harnessDirectory,name))),expected);
    assert.equal(hash(committed(sourceDirectory,'scripts/load/usage/roles/'+name)),expected,'Harness is not exact committed LF source');
  }
  assert.equal(binding.harnessIdentity,hash(JSON.stringify(binding.roleHarnessSha256)));
  // These static-import dependencies also sit outside the role-file inventory.
  for(const name of ['release-enabled-profile.mjs','open-loop-heartbeats.mjs','release-enabled-drain.mjs','release-schema-fingerprint.mjs'])
    assert.equal(hash(readFileSync(join(harnessDirectory,'..',name))),hash(committed(sourceDirectory,'scripts/load/usage/'+name)));
  for(const name of ['run-campaign.mjs','campaign-journal.mjs','campaign-validation.mjs','run-restored-role-scale.mjs','snapshot-contract.mjs','profile.mjs','receipt-loader.mjs'])assert.ok(binding.roleHarnessSha256[name]);
  const load=name=>import(pathToFileURL(join(harnessDirectory,name)).href);
  const {loadSnapshot}=await load('snapshot-contract.mjs');
  const {canonicalHash}=await load('receipt-loader.mjs');
  const {CAMPAIGN_CONTRACT_SHA256,validateCandidateRun}=await load('campaign-validation.mjs');
  const {PROFILE}=await load('profile.mjs');
  const {RELEASE_ENABLED_PROFILE}=await import(pathToFileURL(join(harnessDirectory,'../release-enabled-profile.mjs')).href);
  const today=new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const snapshot=loadSnapshot(snapshotDirectory,input.snapshotManifestSha256,{source:SOURCE,today});
  const schemaSha256=snapshot.data['schema-fingerprint.json'].canonicalSha256;sha(schemaSha256);
  const migrations=snapshot.data['preparation-fixture-contract.json'].migrations;
  assert.equal(migrations.length,54);assert.equal(new Set(migrations.map(row=>row.id)).size,54);
  for(const row of migrations){assert.equal(row.status,'complete');sha(row.checksum);}
  const registryFile=join(sourceDirectory,'src/config/rlsRegistry.json');
  assert.equal(hash(readFileSync(registryFile)),hash(committed(sourceDirectory,'src/config/rlsRegistry.json')));
  assert.equal(read(registryFile).inventories.classpilotPrivateChatLifecyclePostExpand.tables.length,129);
  const identity={candidate:{indexDigest:candidate.image.indexDigest,platformManifestDigest:candidate.image.platformManifestDigest,configDigest:candidate.image.configDigest,scanReceiptSha256:binding.candidateScanReceiptSha256},
    helper:{imageId:binding.roleImageId,runtimeConfigDigest:binding.runtimeConfigDigest,bindingSha256:input.bindingSha256,runtimeSha256:binding.runtimeSha256},
    harness:{identity:binding.harnessIdentity,files:binding.roleHarnessSha256,executed:binding.harnessHashes},profileSha256:binding.roleHarnessSha256['profile.mjs'],validatorSha256:binding.roleHarnessSha256['campaign-validation.mjs'],contractSha256:CAMPAIGN_CONTRACT_SHA256,
    schemaSha256,registrySha256:hash(readFileSync(registryFile)),migrationSha256:hash(JSON.stringify(migrations))};
  const scriptHashes=originalScriptHashes(sourceDirectory);
  for(const[name,expected]of Object.entries(scriptHashes))assert.equal(expected,hash(committed(sourceDirectory,'scripts/load/usage/'+name)));
  const declaration={mode:'capacity-candidate',source:SOURCE,profile:PROFILE,phase:'combined',diagnosticOnly:false,identity,
    originalComparison:{source:SOURCE,schemaSha256,profile:RELEASE_ENABLED_PROFILE.name,phase:'combined',diagnosticOnly:false,collectApiCpuProfile:false,nodeOldSpaceMiB:512,scriptHashes}};
  const trustedCampaignSha256=canonicalHash(declaration);
  const plan={schemaVersion:2,run:'0'.repeat(12),nonce:'0'.repeat(64),source:SOURCE,mode:'capacity-candidate',profile:PROFILE,phase:'combined',diagnosticOnly:false,cpuProfile:false,declaredAt:new Date().toISOString(),campaignSha256:trustedCampaignSha256,ordinal:1,previousEntrySha256:trustedCampaignSha256,identity};
  const planRaw=json(plan),validation=validateCandidateRun({plan,planRaw,final:{source:SOURCE,clean:true,unchanged:true,harnessSha256:binding.harnessIdentity}},hash(planRaw));
  assert.ok(!validation.failures.includes('plan'),'Canonical plan/identity validation failed');
  // Other validation groups lack owner receipts and remain failed; no pass is fabricated.
  const campaignDirectory=futurePath(input.campaignDirectory),evidenceDirectory=futurePath(input.evidenceDirectory),privateDirectory=futurePath(input.privateDirectory),configurationDirectory=futurePath(input.configurationDirectory);
  const outputs=[campaignDirectory,evidenceDirectory,privateDirectory,configurationDirectory];
  for(let i=0;i<outputs.length;i++){for(let j=i+1;j<outputs.length;j++)disjoint(outputs[i],outputs[j]);for(const existing of[sourceDirectory,snapshotDirectory,harnessDirectory,dirname(candidatePreparationFile),dirname(bindingFile),dirname(runtimeProofFile)])disjoint(outputs[i],existing);}
  for(const path of[evidenceDirectory,privateDirectory,configurationDirectory])assert.equal(existsSync(path),false,'Output must be new');
  const campaignExists=existsSync(campaignDirectory);
  if(campaignExists){assert.equal(realpathSync(campaignDirectory),campaignDirectory);const existing=read(join(campaignDirectory,'campaign.json'));assert.equal(existing.schemaVersion,1);assert.equal(canonicalHash(existing.campaign),trustedCampaignSha256);assert.deepEqual(existing.campaign,declaration);}
  assert.equal(input.endpoint,'npipe:////./pipe/dockerDesktopLinuxEngine');digest(input.redisImage);
  const docker=realpathSync(absolute(input.docker));assert.ok(lstatSync(docker).isFile());
  const run=randomBytes(6).toString('hex');
  const attempt={mode:'capacity-candidate',phase:'combined',source:SOURCE,run,sourceDirectory,snapshotDirectory,snapshotManifestSha256:input.snapshotManifestSha256,
    candidatePreparationFile,candidatePreparationSha256:input.candidatePreparationSha256,bindingFile,bindingSha256:input.bindingSha256,runtimeProofFile,runtimeProofSha256:input.runtimeProofSha256,
    expectedSchemaSha256:schemaSha256,docker,endpoint:input.endpoint,redisImage:input.redisImage,campaignDirectory,trustedCampaignSha256,evidenceDirectory,privateDirectory};
  // All validation precedes the only mutation. Preserve a partial directory on
  // write failure; never overwrite it or retry automatically.
  mkdirSync(configurationDirectory);
  const save=(name,value)=>writeFileSync(join(configurationDirectory,name),json(value),{flag:'wx',mode:0o600});
  if(!campaignExists)save('declare.json',{campaignDirectory,declaration});
  save('attempt.json',attempt);
  const entrypoint=join(harnessDirectory,'run-campaign.mjs');
  const result={schemaVersion:1,source:SOURCE,configurationDirectory,run,trustedCampaignSha256,campaignAlreadyDeclared:campaignExists,capacityAccepted:false,
    commands:[...(!campaignExists?[{program:'node',args:[entrypoint,'declare',join(configurationDirectory,'declare.json')]}]:[]),{program:'node',args:[entrypoint,'attempt',join(configurationDirectory,'attempt.json')]}],
    manualGate:true,automaticallyReleased:false,automaticallyRetried:false,snapshotManifestSha256:input.snapshotManifestSha256,preparedSchoolLocalDate:today,
    configurationFiles:Object.fromEntries(readdirSync(configurationDirectory).map(name=>[name,hash(readFileSync(join(configurationDirectory,name)))]))};
  save('generation-receipt.json',result);return result;
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){assert.equal(process.argv.length,3);console.log(JSON.stringify(await prepare(read(process.argv[2]))));}
