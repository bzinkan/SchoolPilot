import assert from 'node:assert/strict';
import {readFileSync,existsSync,openSync,writeFileSync,fsyncSync,closeSync,linkSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
// Manual publication only. Root supplies the independently inspected ready hash
// and nonce; this file is never called by fixture preparation or a retry loop.
const [configPath,expectedConfigSha,expectedReadySha,expectedNonce]=process.argv.slice(2);
assert.equal(process.argv.length,6);
assert.equal(resolve(configPath),resolve('<TEMP>/release297-role-diagnostic-8148-pressure-config-01/diagnostic.json'));
assert.equal(expectedConfigSha,'96fa4503b57186da05c2ab7c82a96b3a7c84b7423096628dddbb7db426d5b396');
assert.match(expectedReadySha,/^[a-f0-9]{64}$/);assert.match(expectedNonce,/^[a-f0-9-]{32,64}$/);
const hash=x=>createHash('sha256').update(x).digest('hex');
const bound=(file,sha)=>{const raw=readFileSync(file);assert.equal(hash(raw),sha);return JSON.parse(raw);};
const config=bound(configPath,expectedConfigSha);
assert.equal(config.source,'814844f344a45159152415b0fb6d7027f05b093e');assert.equal(config.run,'182ac78636d4');
assert.equal(config.mode,'diagnostic');assert.equal(config.phase,'combined');
for(const key of ['campaignDirectory','trustedCampaignSha256','registrationSha256'])assert.equal(Object.hasOwn(config,key),false);
assert.equal(config.bindingSha256,'428e3896c3d01fd0a0f106211404512254434362d071ae622631f7f0603117b1');
const readyPath=join(config.evidenceDirectory,'measurement-ready.json'),ready=bound(readyPath,expectedReadySha);
const binding=bound(config.bindingFile,config.bindingSha256),plan=JSON.parse(readFileSync(join(config.evidenceDirectory,'run-plan.json')));
assert.equal(binding.applicationSource,config.source);assert.equal(binding.passed,true);assert.equal(binding.cleanupPassed,true);assert.ok(binding.allowedModes.includes('diagnostic'));
for(const key of ['run','source','mode','phase']){assert.equal(ready[key],config[key]);assert.equal(plan[key],config[key]);}
for(const key of ['campaignSha256','registrationSha256','campaignDirectory','trustedCampaignSha256'])assert.equal(Object.hasOwn(plan,key),false);
assert.equal(ready.nonce,expectedNonce);assert.equal(plan.nonce,expectedNonce);
assert.equal(ready.imageId,binding.roleImageId);assert.equal(ready.bindingSha256,config.bindingSha256);assert.equal(ready.harnessSha256,binding.harnessIdentity);
assert.equal(plan.identity.helper.imageId,binding.roleImageId);assert.equal(plan.identity.helper.bindingSha256,config.bindingSha256);assert.equal(plan.identity.harness.identity,binding.harnessIdentity);
assert.equal(ready.profile,plan.profile);assert.equal(ready.diagnosticOnly,true);assert.equal(plan.diagnosticOnly,true);assert.equal(ready.capacityAccepted,false);assert.equal(plan.capacityAccepted,false);assert.equal(plan.cpuProfile,false);
assert.ok(Date.now()>=Date.parse(ready.preparedAt)&&Date.now()-Date.parse(ready.preparedAt)<600000,'Fresh held measurement gate required');
const restoreReady=JSON.parse(readFileSync(join(config.evidenceDirectory,'ready.json')));
assert.equal(restoreReady.run,config.run);assert.equal(restoreReady.source,config.source);assert.equal(restoreReady.snapshotManifestSha256,config.snapshotManifestSha256);assert.equal(restoreReady.restorationPassed,true);assert.ok(Date.now()<Date.parse(restoreReady.expiresAt),'Restore handoff expired');
const git=args=>execFileSync('git',['-C',config.sourceDirectory,...args],{encoding:'utf8',windowsHide:true}).trim();
assert.equal(git(['rev-parse','HEAD']),config.source);assert.equal(git(['status','--porcelain']),'');
const harness=join(config.sourceDirectory,'scripts/load/usage/roles');
for(const [name,expected]of Object.entries(binding.roleHarnessSha256)){assert.match(name,/^[a-z0-9.-]+\.(mjs|ps1)$/);assert.equal(hash(readFileSync(join(harness,name))),expected);}
const {validateRelease}=await import(pathToFileURL(join(harness,'measurement-gate.mjs')));
const release={...ready,action:'release-role-measurement'};validateRelease(ready,release);
const destination=join(config.evidenceDirectory,'measurement-go.json');
const absent=()=>{for(const name of ['measurement-go.json','measurement-abort.json','measurement-release-receipt.json','measurement-abort-receipt.json'])assert.equal(existsSync(join(config.evidenceDirectory,name)),false);};
absent();const raw=JSON.stringify(release,null,2)+'\n',partial=join(config.evidenceDirectory,'measurement-go.'+randomUUID()+'.partial');
const fd=openSync(partial,'wx',0o600);try{writeFileSync(fd,raw);fsyncSync(fd);}finally{closeSync(fd);}
bound(configPath,expectedConfigSha);bound(readyPath,expectedReadySha);bound(config.bindingFile,config.bindingSha256);absent();
linkSync(partial,destination);
console.log(JSON.stringify({source:config.source,run:config.run,diagnosticOnly:true,releaseSha256:hash(raw),readySha256:expectedReadySha,capacityAccepted:false}));
