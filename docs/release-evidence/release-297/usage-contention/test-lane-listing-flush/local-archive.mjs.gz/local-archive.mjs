import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs';
import { resolve, relative } from 'node:path';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const root = String.raw`<LOCAL_USER_PROFILE>\.codex\worktrees\release-stabilization-297\SchoolPilot`;
const local = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-test-lane-listing-01`;
const backend = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-ci-35712eb-backend-01`;
const rollout = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-ci-35712eb-rollout-01`;
const out = resolve(root, 'docs/release-evidence/release-297/usage-contention/test-lane-listing-flush');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const units = json(resolve(local, 'full-unit/result.json'));
const infrastructure = json(resolve(local, 'full-infrastructure/result.json'));
for (const result of [units, infrastructure]) { assert.equal(result.exitCode, 0); assert.equal(result.sourceUnchanged, true); }
const final = json(resolve(local, 'final-source-proof.json'));
const linux = json(resolve(local, 'linux-result.json'));
assert.deepEqual(final.appChangedPaths, []);
assert.equal(linux.results[0].exitCode, 1); assert.equal(linux.results[1].exitCode, 0);
assert.ok(linux.results.every(result => result.cleanupPassed));
assert.equal(existsSync(out), false); mkdirSync(out, { recursive: true });
const sanitize = raw => {
  let value = raw.toString('utf8');
  for (const prefix of [String.raw`<LOCAL_USER_PROFILE>`, String.raw`<LOCAL_USER_PROFILE>`, '<LOCAL_USER_PROFILE>']) value = value.replaceAll(prefix, '<LOCAL_USER_PROFILE>');
  value = value.replace(/\x1b\[[0-9;]*[A-Za-z]/g, '').replace(/\b(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi, '<REDACTED_DATABASE_URL>');
  value = value.replace(/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g, '<REDACTED_ACCESS_KEY>');
  return Buffer.from(value);
};
const walk = directory => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
  const path = resolve(directory, entry.name);
  return entry.isDirectory() ? walk(path) : /\.(?:log|json|ps1|mjs|patch|txt)$/.test(entry.name) ? [path] : [];
});
const files = [];
for (const [directory, prefix] of [[local, 'local'], [backend, 'ci-backend'], [rollout, 'ci-rollout']]) {
  for (const path of walk(directory).sort()) {
    const name = relative(directory, path).replaceAll('\\', '/');
    const raw = readFileSync(path), sanitized = sanitize(raw), compressed = gzipSync(sanitized, { level: 9 });
    const file = `${prefix}-${name.replaceAll('/', '--')}.gz`;
    writeFileSync(resolve(out, file), compressed, { flag: 'wx' });
    assert.deepEqual(gunzipSync(readFileSync(resolve(out, file))), sanitized);
    assert.equal(hash(readFileSync(path)), hash(raw));
    files.push({ file, originalRelativePath: `${prefix}/${name}`, rawBytes: raw.length, rawSha256: hash(raw), sanitizedBytes: sanitized.length, sanitizedSha256: hash(sanitized), gzipSha256: hash(compressed) });
  }
}
const counts = path => {
  const text = readFileSync(path, 'utf8');
  const get = name => Number([...text.matchAll(new RegExp(`^# ${name} (\\d+)`, 'gm'))].at(-1)?.[1]);
  return { tests: get('tests'), passed: get('pass'), failed: get('fail'), skipped: get('skipped'), skipNames: text.split(/\r?\n/).filter(line => line.includes('# SKIP')).map(line => line.trim().replace(/^ok \d+ - /, '').replace(/ # SKIP.*/, '')) };
};
const manifest = {
  schemaVersion: 1, recordedAt: new Date().toISOString(), source: final.head,
  sourceState: 'Uncommitted runner/test correction on35712; application source unchanged. These are test tooling and fixture changes, not a rebuilt or deployed release.',
  status: 'stdout_flush_regression_corrected_and_tested',
  defect: 'The list branch forced process.exit immediately after asynchronous writes. A Linux slow-reader subprocess loses buffered lane inventory; classification and selected test suites are unchanged.',
  change: 'Write the complete inventory once and await its stdout callback before the existing successful exit.',
  baselineWindows: { ...json(resolve(local, 'windows-result.json')), limitation: 'Windows baseline passed; this platform did not reproduce the asynchronous POSIX stdout defect. Initial Windows tests preceded cleanup-only fixture guards.' },
  linuxRegression: { ...linux, assertions: 'Same final fixture test, greater than256KiB expected output, paused pipe reader, exact complete bytes, all four lane classes, exit status and cleanup. Old runner failed, corrected runner passed.', networkAccess: false },
  focused: { tests: 9, passed: 9, failed: 0, skipped: 0, command: 'node --env-file-if-exists=.env --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-tile-auth-plan-readiness-governance.test.ts tests/test-lane-listing.test.mjs' },
  fullUnit: { ...units, ...counts(resolve(local, 'full-unit/test.log')) },
  fullInfrastructure: { ...infrastructure, ...counts(resolve(local, 'full-infrastructure/test.log')) },
  sourceHashes: { runner: final.runnerSha256, test: final.testSha256 },
  ci35712: { runId: 37114624863, conclusion: 'failure', backend: 'Lane listing omitted the deploy gate path; this correction addresses the independently reproduced listing defect.', rollout: 'Separate failure: generic-valid-401 monitor refused a generator binding as not live. New bounded failure artifact retained; no production monitor change in this correction.', originalUnavailableProbe: 'Retained artifact now shows expected load:tenant-isolation-probe-unavailable. Original204 monitor_exception remains unexplained, not retroactively repaired.' },
  limitations: ['Fresh CI is required after committing the runner correction.', 'This does not resolve the separate AWS fixture startup failure.', 'Four pre-existing unit skips are retained and named; no skip was added.', 'No application, production timeout, pool, infrastructure or capacity threshold changed.'],
  capacityAccepted: false, productionActions: 0,
  sanitation: 'Local user profile prefixes, ANSI escapes, database URL and access-key-shaped text sanitized; raw originals retained unchanged outsideGit. Only bounded synthetic CI mock evidence was downloaded; no secrets/configuration files captured.', files,
};
writeFileSync(resolve(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
writeFileSync(resolve(out, 'README.md'), '# Complete test-lane listing\n\nThe listing branch now waits for stdout to flush before exiting. On the exact Linux candidate image, the old runner failed the paused-reader regression and the corrected runner passed. The Windows baseline also passed, and remains recorded without a false red-test claim.\n\nThe existing governance test and new listing test passed9/9. Full unit and infrastructure evidence, source hashes, original failed CI logs, and bounded rollout artifacts are preserved separately in the manifest. The unrelated AWS fixture startup failure remains open. No application or production behavior changed.\n', { flag: 'wx' });
console.log(JSON.stringify({ directory: out, files: files.length, manifestSha256: hash(readFileSync(resolve(out, 'manifest.json'))), fullUnit: manifest.fullUnit, fullInfrastructure: manifest.fullInfrastructure }));
