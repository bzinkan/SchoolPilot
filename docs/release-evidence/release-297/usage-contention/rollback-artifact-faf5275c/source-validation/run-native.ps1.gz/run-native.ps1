param()
$ErrorActionPreference = 'Stop'
Remove-Item Env:DOCKER_HOST -ErrorAction SilentlyContinue
Remove-Item Env:DOCKER_CONTEXT -ErrorAction SilentlyContinue
Remove-Item Env:RLS_TEST_ROLE -ErrorAction SilentlyContinue
$repo = '[USERPROFILE]\.codex\worktrees\release297-compatible-rollback\SchoolPilot'
$run = [guid]::NewGuid().ToString('N').Substring(0,12)
$container = 'schoolpilot-chat-sso-' + $run
$database = 'usage_native_' + $run
$owner = 'fixture_' + $run
$role = 'application_' + $run
$password = [guid]::NewGuid().ToString('N')
$rolePassword = [guid]::NewGuid().ToString('N')
$out = Join-Path $env:TEMP ('release297-rollback-sso-native-' + $run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $repo
$created = $false
try {
  $schema = Join-Path $out 'schema.sql'
  docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec schoolpilot-db pg_dump -U schoolpilot -d schoolpilot_redesign_usage_release297_20261002 --schema-only --no-owner --no-privileges | Set-Content -LiteralPath $schema -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw 'Read-only schema export failed' }
  $image = (docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect schoolpilot-db --format '{{.Image}}').Trim()
  docker --host npipe:////./pipe/dockerDesktopLinuxEngine run --detach --name $container --label "codex.chat-sso=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
  if ($LASTEXITCODE -ne 0) { throw 'Fixture create failed' }
  $created = $true
  $ready = $false
  for ($attempt=0; $attempt -lt 40; $attempt++) {
    docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null
    if ($LASTEXITCODE -eq 0) { $ready=$true; break }
    Start-Sleep -Milliseconds 250
  }
  if (-not $ready) { throw 'Fixture not ready' }
  $ports = docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
  if ($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1') { throw 'Fixture must remain loopback-only' }
  $port = $ports.'5432/tcp'[0].HostPort
  Get-Content -LiteralPath $schema -Raw | docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
  if ($LASTEXITCODE -ne 0) { throw 'Schema restore failed' }
  "CREATE ROLE $role LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$rolePassword'; GRANT USAGE ON SCHEMA public TO $role; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $role; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $role;" | docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'role.log')
  if ($LASTEXITCODE -ne 0) { throw 'Restricted role grants failed' }
  $env:JWT_SECRET = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
  $env:SESSION_SECRET=$env:JWT_SECRET; $env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
  $env:NODE_ENV='test'; $env:REDIS_URL=''; $env:SCHEDULER_ENABLED='false'
  $env:RLS_GUC_ENABLED='true'
  $registry=Get-Content src/config/rlsRegistry.json -Raw | ConvertFrom-Json
  $env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
  $env:DATABASE_URL="[REDACTED_DATABASE_URL]"
  $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL; $env:ADMIN_DATABASE_URL=$env:DATABASE_URL
  $tests = @('tests/classpilot-private-chat-lifecycle.integration.test.ts')
  node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 --test-name-pattern 'pending-reply bootstrap|dark-deployment bridge|sticky fence survives|signed-in student|binding transfer|expired .* outbox' @tests *> (Join-Path $out 'ordinary.log')
  $ordinary=$LASTEXITCODE
  $env:DATABASE_URL="[REDACTED_DATABASE_URL]"
  $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL
  $env:RLS_TEST_ROLE=$role
  node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 --test-name-pattern 'pending-reply bootstrap|dark-deployment bridge|sticky fence survives|signed-in student|binding transfer|expired .* outbox' @tests *> (Join-Path $out 'restricted.log')
  $restricted=$LASTEXITCODE
  [ordered]@{ordinaryExit=$ordinary;restrictedExit=$restricted;source=(git rev-parse HEAD).Trim();worktreeDirty=$true;container=$container;database=$database;schemaDonor='schoolpilot_redesign_usage_release297_20261002';productionMutations=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json')
  Write-Output ([ordered]@{evidence=$out;ordinaryExit=$ordinary;restrictedExit=$restricted} | ConvertTo-Json -Compress)
} finally {
  if ($created) {
    $labels=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .Config.Labels}}' | ConvertFrom-Json
    if ($container -cne ('schoolpilot-chat-sso-'+$run) -or $labels.'codex.chat-sso' -cne $run) { throw 'Cleanup ownership mismatch' }
    docker --host npipe:////./pipe/dockerDesktopLinuxEngine rm -f $container *> (Join-Path $out 'cleanup.log')
  }
}





