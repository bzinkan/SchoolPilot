# Exact8148 recovery54 preparation

External-only adaptation of the retained corrected b112 → 6e251 → b112 runner and reviewed `release297-recovery54-plan-01`. Nothing here has launched a fixture or a recovery probe. No application, dependency, image, registry or production mutation is performed by preparation.

The **current executable binding is `final-config-02.json`** (SHA256 `b5252254606fab4c608824c17525a2b21205b9fcced0e9dc37db6bd2d2f97e3c`). `final-config.json` is retained preparation history, invalidated by stricter schema/cleanup binding and rejected by the final launcher. It was never executed.

Root's reviewed execution command, after scheduling a quiet fixture window:

```powershell
node C:/Users/zinka/AppData/Local/Temp/release297-recovery54-launcher-814844f3-01/run.mjs C:/Users/zinka/AppData/Local/Temp/release297-recovery54-launcher-814844f3-01/final-config-02.json
```

Minimal behavior changes:

- `binding.mjs`/`bind-config.mjs` pin clean source `814844f344a45159152415b0fb6d7027f05b093e`, actual candidate and fallback index/platform/config plus pinned scan receipts, complete source-reentry54 ledger, the captured read-only schema receipt, independent source-fixture cleanup and all executed adapter hashes. Missing or changed evidence fails before Docker.
- `probe.mjs` retains every original adopted chat epoch/generation/expired reply/history and offline Stop Focus assertion. The reviewed template adds whole54 ledger, immutable function body and exact ACL retention before/after all three phases. One further addition invokes the actual candidate's runtime function assertion in candidate phases. Fallback never imports a module it lacks.
- `grant.mjs` runs once in the actual candidate image, grants only the generated restricted fixture role via the bundled helper and verifies through that runtime credential. It never installs/replaces the function. No repair occurs between seed/fallback/return, so ACL/body/ledger drift cannot be hidden.
- `run.mjs` reuses the retained one-PG restricted-role behavior fixture: 4 CPU/4 GiB PG, 1 CPU/2 GiB app phases, both Usage modes off, read-only image and adapter mounts, process-local realtime capability fixture. The PG image comes from the successful source rehearsal. The synthetic ledger copy is explicitly labelled as bootstrap, not independent migration application.
- Exact name/ID/label/requested-and-observed image ownership is recorded before startup; failed create outcomes are recovered only by successful exact-name listing/inspection. Every cleanup is attempted after admin-close failure. PG is stopped gracefully, and removal still proceeds after failed stop. Successful exact listings must prove container and its recorded anonymous volume absent. An uncertain lookup or forced app termination cannot pass.

Actual inputs: candidate index `60b3cfa9…53f8`, fallback `7bbe89bd…8ab1`; rehearsal `release297-source-rehearsal-814844f3-01`; captured schema SHA256 `1da63b3755cd976491e16c2122dc46b281d319869399c1c907516656014faa65`. Full paths/hashes are in the config. Raw process logs, credentials and adopted private state remain in a fresh private directory; the public receipt includes content hashes and bounded outcomes.

Validation so far is syntax, exact local evidence binding and pure rejection tests only. This is not service traffic rollback, browser delivery, a Redis relay proof, capacity acceptance, production catalog proof or deployment authorization. The original b112 results remain historical. New execution creates a unique output directory and preserves failures.
