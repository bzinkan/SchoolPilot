#requires -Version 7.5
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Repository,[Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{40}$')][string]$SourceSha,[Parameter(Mandatory=$true)][ValidatePattern('^sha256:[a-f0-9]{64}$')][string]$CandidateImageId,[Parameter(Mandatory=$true)][string]$CandidateScanReceipt,[Parameter(Mandatory=$true)][string]$HostFixtureDirectory,[Parameter(Mandatory=$true)][string]$ContextDirectory)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'reviewed-linux-base/prepare-context.ps1') @PSBoundParameters
if($LASTEXITCODE -ne 0){throw 'Base exact-source preparation failed.'}
node (Join-Path $PSScriptRoot 'adopt-role-context.mjs') $ContextDirectory $HostFixtureDirectory
if($LASTEXITCODE -ne 0){throw 'Role overlay adoption failed; preserve partial context.'}
