$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repository = 'C:\Users\zinka\.codex\worktrees\release-stabilization-297\SchoolPilot'
$outputRoot = Join-Path $env:TEMP 'release297-clock-boundary-proof-01'
New-Item -ItemType Directory -Path $outputRoot -ErrorAction Stop | Out-Null
. (Join-Path $repository 'tests/deploy-git-bash-timezone.test.ps1')
$shim = @'
clock_test_epoch=__BEFORE__
date() {
  if [[ "$#" == 1 && "$1" == '+%u %H%M' ]]; then
    command date --date="@$clock_test_epoch" "$1"
  else
    command date "$@"
  fi
}
'@
$cases = @(
    @{ name='minute'; before='2026-10-03T17:55:59Z'; after='2026-10-03T17:56:00Z'; original=$false; invalid=$false; exit=0 },
    @{ name='day'; before='2026-10-04T03:59:59Z'; after='2026-10-04T04:00:00Z'; original=$false; invalid=$false; exit=0 },
    @{ name='original-minute-failure'; before='2026-10-03T17:55:59Z'; after='2026-10-03T17:56:00Z'; original=$true; invalid=$false; exit=94 },
    @{ name='wrong-result-refused'; before='2026-10-03T17:55:59Z'; after='2026-10-03T17:56:00Z'; original=$false; invalid=$true; exit=94 }
)
$records = @()
foreach ($case in $cases) {
    $beforeEpoch = ([DateTimeOffset]::Parse($case.before)).ToUnixTimeSeconds()
    $afterEpoch = ([DateTimeOffset]::Parse($case.after)).ToUnixTimeSeconds()
    $injected = $probe.Replace($library, $library + "`n" + $shim.Replace('__BEFORE__', [string]$beforeEpoch))
    $marker = 'actual_now=$(production_eastern_weekday_hhmm) || exit 93'
    if (-not $injected.Contains($marker)) { throw 'Missing actual clock probe' }
    $injected = $injected.Replace($marker, "clock_test_epoch=$afterEpoch`n$marker")
    if ($case.original) {
        $injected = $injected.Replace('[[ "$actual_now" == "$expected_before" || "$actual_now" == "$expected_after" ]]', '[[ "$actual_now" == "$expected_before" ]]')
    }
    if ($case.invalid) {
        $injected = $injected.Replace($marker, 'production_eastern_weekday_hhmm() { printf ''1 0000\n''; }' + "`n" + $marker)
    }
    $result = @($injected | & $bash -s 2>&1)
    $code = $LASTEXITCODE
    $text = ($result | ForEach-Object { [string]$_ }) -join "`n"
    [IO.File]::WriteAllText((Join-Path $outputRoot ($case.name + '.log')), $text + "`n")
    if ($code -ne $case.exit) { throw "Unexpected exit for $($case.name): $code" }
    if ($text -notmatch '(?m)^winter=4 0700 -0500 EST$' -or $text -notmatch '(?m)^summer=3 0800 -0400 EDT$') { throw 'Real TZif checks were not preserved' }
    $records += @{name=$case.name; exitCode=$code; expectedExit=$case.exit; before=$case.before; after=$case.after; realTzifChecksRetained=$true}
}
$record = @{passed=$true; productionScriptChanged=$false; wallClockChanged=$false; sourceCommit='e95a2b56476b1225434c1b0f3907db46c9d84fe3'; cases=$records; limitation='Deterministic external clock-boundary reproduction. The original CI did not retain its two differing minute values, so its exact cause is inferred, not proven.'}
[IO.File]::WriteAllText((Join-Path $outputRoot 'result.json'), ($record | ConvertTo-Json -Depth 8) + "`n")
$record | ConvertTo-Json -Depth 8
