import { readFileSync, writeFileSync } from 'node:fs';
const root='<user-home>/.codex/worktrees/release297-compatible-rollback/SchoolPilot';
const primary='<user-home>/.codex/worktrees/release-stabilization-297/SchoolPilot';
const path=root+'/src/services/storage.ts';
let source=readFileSync(path,'utf8');
const nl=source.includes('\r\n')?'\r\n':'\n';
function replaceOnce(before,after){ if(source.split(before).length!==2) throw new Error('expected exactly one match: '+before.slice(0,100)); source=source.replace(before,after); }
replaceOnce('import { assertClasspilotEntitled } from "./classpilotEntitlement.js";', 'import { assertClasspilotEntitled, classpilotEntitledSchoolPredicate } from "./classpilotEntitlement.js";');
replaceOnce('export async function withClasspilotStudentControlDeliveryAuthority<','async function withClasspilotStudentControlDeliveryAuthorityCore<');
const begin=source.indexOf('async function withClasspilotStudentControlDeliveryAuthorityCore<');
const end=source.indexOf('export async function withClasspilotStudentWebSocketBootstrapAuthority<',begin);
let body=source.slice(begin,end);
const oldSignature='  ) => T'+nl+'): Promise<{ authorized: true; value: T } | { authorized: false }> {';
if(body.split(oldSignature).length!==2) throw new Error('signature mismatch');
body=body.replace(oldSignature,'  ) => T,'+nl+'  heartbeatFinalFence = false,'+nl+'): Promise<{ authorized: true; value: T } | { authorized: false }> {');
const oldFinal='      const prepared = await prepareAuthorized(transactionDb);'+nl+'      if (!(await hasExactClasspilotTelemetryBinding(options, transactionDb))) {'+nl+'        throw new ClasspilotTeacherChatBindingLostError();'+nl+'      }';
if(body.split(oldFinal).length!==2) throw new Error('final fence mismatch');
body=body.replace(oldFinal,'      const prepared = await prepareAuthorized(transactionDb);'+nl+'      if (heartbeatFinalFence) {'+nl+'        await assertClasspilotHeartbeatDeliveryCurrent(options, transactionDb);'+nl+'      } else if (!(await hasExactClasspilotTelemetryBinding(options, transactionDb))) {'+nl+'        throw new ClasspilotTeacherChatBindingLostError();'+nl+'      }');
const current=readFileSync(primary+'/src/services/storage.ts','utf8');
const helperStart=current.indexOf('/** Final heartbeat-only clock fence.');
const helperEnd=current.indexOf('export async function withClasspilotStudentControlDeliveryAuthority<',helperStart);
if(helperStart<0||helperEnd<=helperStart) throw new Error('primary helper not found');
let helper=current.slice(helperStart,helperEnd).replace(/\r?\n/g,nl);
helper=helper.replace('during preparation or'+nl+' * transport.', 'during asynchronous'+nl+' * preparation.');
const wrappers=`export async function withClasspilotStudentControlDeliveryAuthority<
  Prepared,
  T extends ClasspilotSynchronousAuthorityResult,
>(
  options: ClasspilotTeacherChatBinding,
  prepareAuthorized: (transactionDb: typeof db) => Prepared | Promise<Prepared>,
  onAuthorized: (claimed: ClasspilotClaimedTeacherChatDelivery[], prepared: Prepared) => T,
): Promise<{ authorized: true; value: T } | { authorized: false }> {
  return withClasspilotStudentControlDeliveryAuthorityCore(options, prepareAuthorized, onAuthorized);
}

/** Heartbeat-only final clock recheck. Generic and WebSocket delivery retain
 * their existing linearization; no telemetry transport or projection is fused. */
export async function withClasspilotHeartbeatDeliveryAuthority<
  Prepared,
  T extends ClasspilotSynchronousAuthorityResult,
>(
  options: ClasspilotTeacherChatBinding,
  prepareAuthorized: (transactionDb: typeof db) => Prepared | Promise<Prepared>,
  onAuthorized: (claimed: ClasspilotClaimedTeacherChatDelivery[], prepared: Prepared) => T,
): Promise<{ authorized: true; value: T } | { authorized: false }> {
  return withClasspilotStudentControlDeliveryAuthorityCore({ ...options }, prepareAuthorized, onAuthorized, true);
}

`.replaceAll('\n',nl);
source=source.slice(0,begin)+body+helper+wrappers+source.slice(end);
writeFileSync(path,source);
const routePath=root+'/src/routes/classpilot/devices.ts';
let route=readFileSync(routePath,'utf8');
route=route.replace('  withClasspilotStudentControlDeliveryAuthority,','  withClasspilotStudentControlDeliveryAuthority,'+nl+'  withClasspilotHeartbeatDeliveryAuthority,');
const routeStart=route.indexOf('    const finalDelivery = await runWithTenantContext(');
if(routeStart<0) throw new Error('final route absent');
route=route.slice(0,routeStart)+route.slice(routeStart).replace('() => withClasspilotStudentControlDeliveryAuthority(', '() => withClasspilotHeartbeatDeliveryAuthority(');
writeFileSync(routePath,route);
const testPath=root+'/tests/classpilot-late-signin-contract.test.ts';
let contract=readFileSync(testPath,'utf8');
contract=contract.replace('"export async function withClasspilotStudentControlDeliveryAuthority",','"async function withClasspilotStudentControlDeliveryAuthorityCore",');
writeFileSync(testPath,contract);
