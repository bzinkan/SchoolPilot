import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,copyFileSync,existsSync} from 'node:fs';
import {join,relative} from 'node:path';
import {createHash} from 'node:crypto';
import os from 'node:os';
const original=join(os.tmpdir(),'schoolpilot-image-scan-um7qsf'),destination='C:/Users/zinka/.codex/artifacts/release297-candidate-204ae93d-01';
assert.equal(existsSync(destination),false);mkdirSync(destination);
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex'),files=[];
function copy(dir){for(const e of readdirSync(dir,{withFileTypes:true})){if(e.name==='cache')continue;const src=join(dir,e.name),rel=relative(original,src),dst=join(destination,rel);if(e.isDirectory()){mkdirSync(dst);copy(src);}else{copyFileSync(src,dst,1);const originalHash=hash(src),copyHash=hash(dst);assert.equal(copyHash,originalHash);files.push({path:rel.replaceAll('\\','/'),bytes:readFileSync(dst).length,sha256:copyHash});}}}
copy(original);const receipt=JSON.parse(readFileSync(join(destination,'candidate-preparation.json'),'utf8'));
assert.equal(receipt.source,'204ae93d0869f4fe6dda33e663a4f91d5321eee7');assert.equal(receipt.passed,true);
assert.equal(hash(join(destination,'input/image.tar')),receipt.exportSha256);
const manifest={schemaVersion:1,createdAt:new Date().toISOString(),artifactType:'local_release_candidate_image_with_full_security_evidence',sourceRevision:receipt.source,sourceInitiallyClean:receipt.sourceInitiallyClean,sourceUnchangedAtBuildFinish:receipt.sourceUnchangedAtFinish,localOnly:true,productionMutations:0,registryPushes:0,taskRegistrations:0,productionDeployed:false,usageActivationApproved:false,capacityAccepted:false,image:receipt.image,export:{path:'input/image.tar',sha256:receipt.exportSha256},scan:{passed:true,scanner:receipt.scanner,gate:receipt.gate,counts:receipt.scanCounts},syntheticFloor:receipt.syntheticFloor,sourceReceiptPath:join(original,'candidate-preparation.json'),sourceReceiptSha256:hash(join(original,'candidate-preparation.json')),files,caveat:'Compatible local artifact only. Current combined diagnostic failed; final release source acceptance, actual production catalog/admission and operator deployment bindings remain separate.'};
writeFileSync(join(destination,'artifact-manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({destination,manifestSha256:hash(join(destination,'artifact-manifest.json')),files:files.length,exportSha256:receipt.exportSha256}));
