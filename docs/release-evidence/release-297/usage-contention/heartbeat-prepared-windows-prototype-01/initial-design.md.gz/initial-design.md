# Contingent explicit owned-client SELECT executor

Architecture proposal only. No implementation, database workload, migration or accepted capacity claim.

## Why consider it

The unprofiled0e427 ingestion attempt used70.991CPU seconds in71.138seconds with1CPU,0.99877ELU and144 checkout failures. Final delivery executes21.497 queries per successful heartbeat, with176.16ms average lease hold. PostgreSQL primarily waits for its client. Existing six-shape construction savings (~1.72–1.9seconds extrapolated) are insufficient evidence of a complete fix.

Flat parameterized SQL passed to `transactionDb.execute` preserves a simple application interface but still constructs the Drizzle query wrapper and executes its placeholder/cache/tracing Promise chain. A narrowly owned `PoolClient.query` executor could remove those layers for selected fixed reads and, with bounded names, omit repeated PostgreSQL Parse/SQL-text transmission on a physical connection. It does not eliminate Bind/Execute, any roundtrip, row/parameter encoding or statement snapshot. Historical5d54 Drizzle10.65s self, pg5.969s self and native writev4.482s are overlapping-family evidence, not additive recoverable budgets. No particular saving is established.

## Ownership and transaction boundary

1. The private heartbeat core captures `getOwnedTenantStore()` before starting its transaction. Only this owned path can opt in. It must call exactly `capturedStore.db.transaction(callback)`; it must not pair an arbitrary caller-supplied tx with an ambient client. The ordinary public, WebSocket, unowned/RLS-off and nested-transaction paths retain the existing reference implementation.
2. Mint the executor token inside that actual callback. It retains the exact store object, physical client, an active flag and a private set of initiated-query promises. Each call validates that the token is active and `getOwnedTenantStore() === capturedStore` before invoking the client. A reborrowed client with another fresh store is rejected. A query started while valid remains owned until its real completion; invalidating a token does not release/return a client early.
3. Stop accepting calls before callback cleanup and settle every initiated query before allowing Drizzle COMMIT/ROLLBACK and tenant RESET/release. Do not expose the token/client beyond private storage helpers. No `tx.session`, global pool lookup, guessed GUC ownership or response-finish release is permitted.
4. Drizzle keeps all BEGIN, SAVEPOINT, RELEASE, ROLLBACK, COMMIT and rare writes. Direct reads remain at their exact existing await positions. Mandatory final school/license/binding fences, SSO advisory ordering, optional rollback isolation, transport ownership and after-release fallback remain unchanged.

The installed public `drizzle(physicalClient).transaction` implementation uses that physical client (node-postgres/session.js:179–198); its schema wrapper is already cached by tenantContext.ts:27–44. The proposal uses that explicitly created root transaction, not implementation introspection into an arbitrary transaction.

## Query and result contract

- Closed fixed query enum and fixed source-reviewed SQL only. Every value is parameterized and every parameter occurrence retains the existing Drizzle column encoder/type; no interpolation/custom quoting. Compile canonical SQL plus ordered placeholder/encoder metadata once only if equivalence is mechanically checked against the existing builder.
- No globally cached prepared object bound to a physical client. If using names, the immutable bounded name contains a version/SQL digest and the standard node-pg client owns its per-connection parsed-statement cache. Name/text conflicts, DDL result-type invalidation or execution errors fail normally; do not silently retry under changed authority.
- Configure node-pg's public query `types` with the pinned Drizzle raw semantics: timestamp, timestamptz, date, interval and OIDs1231/1115/1185/1187/1182 remain raw strings; other OIDs delegate to existing pg parsers. Then use the existing schema decoders exactly once, with explicit null/missing-row mapping. Never replace them with node-pg's default Date parsing (which loses sub-millisecond text and can change timezone handling).
- Prefer the already-raw boolean/one-row fence statements first for correctness feasibility. Extending to SELECT builder results needs explicit aliases and the same nullable-join/Date mapping. A raw `SELECT *` or duplicate-column overwrite is not equivalent.
- Keep instrumentation on the same physical client's query method, ALS labels and configured statement timeout/cancellation. Direct calls bypass Drizzle logger/tracer behavior; verify current logger is no-op and explicitly document any tracing difference rather than claiming identical observability.

## Required proof before an application proposal

Pure SQL+orderedparameter+encoder parity for null/Date/revision bounds and all applicable variants. Native owner/restricted tests must show fresh results under same-client schoolA→RESET→schoolB reuse, different physical clients, transaction rollback and savepoint recovery; stale/escaped/reborrowed token rejection; unawaited query settlement before release; same locks and writer waits; manual/school/license/control/supervision expiry across existing awaited boundaries; same403/409 and SQL errors; query cancellation/timeout/release failure; explicit timestamp/array mapping; prepared-name collision and schema invalidation failure. The current reference helper remains the oracle.

Only after those correctness proofs would one identical resource-bound unprofiled experiment establish whether avoiding construction/wrappers and repeated Parse is material. A microbenchmark of construction alone cannot certify the100rps workload or the reports/worker combined gate. This design deliberately proposes no authority cache, statement combining, pipelining, extra pool, timeout or infrastructure change.
