import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { builders, rawBuilders, factories, directTemplates, orm, repo } from './canonical-capture.mjs';
const require=createRequire(repo+'/package.json');
const {types}=require('pg');
const rawTextOids=new Set([types.builtins.TIMESTAMPTZ,types.builtins.TIMESTAMP,types.builtins.DATE,types.builtins.INTERVAL,1231,1115,1185,1187,1182]);
export const rawTypes=Object.freeze({getTypeParser(oid,format){return rawTextOids.has(oid)?value=>value:types.getTypeParser(oid,format);}});
export const labels=Object.freeze(['locked_school','locked_license','live_binding','screenshot_session','screenshot_control','screenshot_candidate','foreground_fence','final_fence','unlocked_entitlement']);
const allowed=new Set(labels),modes=new Set(['canonical','flat','direct']);
const activeRoots=new WeakSet();
const valueKeys=Object.freeze(['schoolId','studentId','studentSessionId','deviceId','teachingSessionId','controlRevision']);
function snapshotValues(values){const copy={};for(const key of valueKeys){const d=Object.getOwnPropertyDescriptor(values,key);assert.ok(d&&'value'in d,'Own scalar bindings required');const v=d.value;assert.ok(v===null||typeof v==='string'||typeof v==='boolean'||(typeof v==='number'&&Number.isFinite(v)),'Scalar bindings only');copy[key]=v;}return copy;}
export function directConfig(label,values){assert.ok(allowed.has(label),'Closed fixed SELECT enum');const template=directTemplates[label];return {text:template.sql,values:orm.fillPlaceholders(template.params,snapshotValues(values)),types:rawTypes};}

/** External proof only. The function itself owns the actual root transaction;
 * no caller-supplied client/tx pairing, tx.session access or global-pool fallback. */
export async function withOwnedReadTransaction(getOwnedStore,work){
 const store=getOwnedStore();assert.ok(store&&store.client&&store.db&&!store.isSuper,'Owned non-super tenant lease required');
 const client=store.client,database=store.db,schoolId=store.schoolId;
 assert.ok(!activeRoots.has(client),'Nested owned root transaction refused');activeRoots.add(client);
 try{return await database.transaction(async tx=>{
  let active=true,primaryError,readFailure;const pending=new Set();
  const read=(label,values,mode='direct')=>{
   assert.ok(active&&getOwnedStore()===store&&store.client===client&&store.db===database&&store.schoolId===schoolId&&!store.isSuper,'Transaction/store no longer owned');
   assert.ok(modes.has(mode)&&allowed.has(label),'Closed read/mode enum');
   const fresh=snapshotValues(values);assert.equal(fresh.schoolId,schoolId,'Foreign tenant scope refused');let operation;
   try {
    if(mode==='canonical')operation=builders[label](tx,fresh).execute().then(result=>rawBuilders[label]?result.rows:result);
    else if(mode==='flat')operation=tx.execute(factories[label].bind(fresh)).then(result=>factories[label].decode(result.rows));
    else operation=client.query(directConfig(label,fresh)).then(result=>factories[label].decode(result.rows));
   } catch(error){operation=Promise.reject(error);}
   const owned=Promise.resolve(operation);pending.add(owned);
   void owned.then(()=>pending.delete(owned),error=>{readFailure??=error;pending.delete(owned);});
   return owned;
  };
  try{return await work({read,tx,client});}
  catch(error){primaryError=error;throw error;}
  finally{
   active=false;const settling=await Promise.allSettled([...pending]);
   if(!primaryError){const failed=settling.find(r=>r.status==='rejected');if(readFailure)throw readFailure;if(failed)throw failed.reason;}
  }
 });}finally{activeRoots.delete(client);}
}
