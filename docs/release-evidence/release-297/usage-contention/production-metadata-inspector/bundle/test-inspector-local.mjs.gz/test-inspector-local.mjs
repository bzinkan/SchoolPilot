import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
const sourcePath=new URL('./inspect-release-metadata.mjs',import.meta.url);
const original=readFileSync(sourcePath,'utf8');
const source=original.replace(/^import .*;\r?\n/gm,'');
const hash='a'.repeat(64), uuid='11111111-1111-4111-8111-111111111111';
const relation=name=>({schema:'public',name,kind:'r',rls:false,forced:false,partition:false,definitionSha256:hash});
const cases=[];
async function run(options={}){
 const queries=[],output=[],clientOptions=[];let ended=false,connected=false;
 const scopes={...options};
 class Client{
  constructor(value){clientOptions.push(value)}on(){}
  async connect(){connected=true}
  async query(text,parameters){
   queries.push({text,parameters});
   if(text.startsWith('SELECT current_database'))return {rows:[{database:'schoolpilot',read_only:'on',version:160004,superuser:false,bypass_rls:false}]};
   if(text.startsWith('SELECT n.nspname AS schema,c.relname AS name,c.relkind')&&text.includes(' AS rls,'))return {rows:[relation('schools'),{...relation('product_licenses'),rls:!!scopes.rls}]};
   if(text.startsWith('SELECT id,checksum'))return {rows:[{id:'migration-fixture',checksum:scopes.badHash?'invalid':hash,mode:'transactional',status:'complete',application_sha:'synthetic'}]};
   if(text.startsWith('SELECT id,name,status='))return {rows:scopes.missing?[]:Array.from({length:scopes.ambiguous?2:1},()=>({id:uuid,name:'Synthetic school',active_status:true,is_active:true,not_deleted:true,not_disabled:true,plan_not_canceled:true,within_paid_through:true}))};
   if(text.startsWith('SELECT product,status='))return {rows:[{product:'CLASSPILOT',active_status:!scopes.expired,unexpired:true}]};
   if(text.startsWith('SELECT e.extname'))return {rows:[{name:'uuid-ossp',attributesSha256:hash}]};
   if(text.startsWith('SELECT nspname')&&scopes.overflow)return {rows:Array.from({length:33},(_,i)=>({name:'s'+i}))};
   return {rows:[]};
  }
  async end(){ended=true}
 }
 const proc={env:{DATABASE_URL:scopes.url??'[REDACTED_DATABASE_URL]'},stdout:{write:line=>output.push(JSON.parse(line))},exit:()=>{throw new Error('synthetic exit')},exitCode:0};
 const context=vm.createContext({pg:{Client},assert,readFileSync:path=>{assert.equal(path,'/app/rds-ca.pem');return 'SYNTHETIC_CA'},createHash,URL,Buffer,process:proc,setTimeout:()=>0,clearTimeout:()=>{},console:{}});
 await new vm.Script('(async()=>{'+source+'})()').runInContext(context);
 let payload=null;
 if(output[0]&&!output[0].failed){const bytes=Buffer.concat(output.map(part=>Buffer.from(part.data,'base64')));assert.equal(createHash('sha256').update(bytes).digest('hex'),output[0].payloadSha256);payload=JSON.parse(bytes.toString())}
 return {queries,output,payload,clientOptions,ended,connected,exitCode:proc.exitCode};
}
async function check(name,fn){await fn();cases.push({name,passed:true})}
await check('normal read-only inventory; exact TLS fields; bounded fixed-domain pilot',async()=>{
 const r=await run();assert.equal(r.exitCode,0);assert.equal(r.payload.pilot.school.id,uuid);assert.equal(r.payload.pilot.school.classpilotEntitled,true);assert.equal(r.clientOptions[0].ssl.rejectUnauthorized,true);assert.equal(r.clientOptions[0].ssl.ca,'SYNTHETIC_CA');assert.equal(r.clientOptions[0].connectionString,undefined);assert.equal(r.clientOptions[0].host,'schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com');assert.equal(r.queries[0].text,'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');assert.equal(r.queries.at(-1).text,'COMMIT');assert.ok(r.ended);assert.equal(r.queries.find(q=>q.text.startsWith('SELECT id,name')).parameters[0],'desalescincy.org');assert.equal(JSON.stringify(r.output).includes('Synthetic school'),false);
});
await check('absent pilot emits no binding',async()=>{const r=await run({missing:true});assert.equal(r.payload.pilot.matches,0);assert.equal(r.payload.pilot.school,null)});
await check('ambiguous pilot emits no binding and never reads licenses',async()=>{const r=await run({ambiguous:true});assert.equal(r.payload.pilot.matches,2);assert.equal(r.payload.pilot.school,null);assert.equal(r.queries.some(q=>q.text.startsWith('SELECT product')),false)});
await check('inactive license cannot establish entitlement',async()=>{const r=await run({expired:true});assert.equal(r.payload.pilot.school.classpilotEntitled,false)});
for(const [name,options] of [['wrong hostname',{url:'[REDACTED_DATABASE_URL]'}],['wrong database',{url:'[REDACTED_DATABASE_URL]'}],['bad checksum',{badHash:true}],['unexpected global RLS',{rls:true}],['catalog overflow',{overflow:true}]])await check(name+' fails without sensitive output',async()=>{const r=await run(options);assert.equal(r.exitCode,1);assert.deepEqual(r.output,[{version:1,failed:true,code:'RELEASE_METADATA_FAILED'}]);if(r.connected)assert.ok(r.ended);else assert.equal(r.clientOptions.length,0)});
const result={schemaVersion:1,at:new Date().toISOString(),sourceSha256:createHash('sha256').update(original).digest('hex'),status:'passed_local_mock_only',cases,limits:['No AWS calls or production database connection.','VM pg/filesystem/timer adapters do not establish SQL validity or native TLS/image compatibility.']};
writeFileSync(new URL('./local-node-validation.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
writeFileSync(new URL('./synthetic-transport.json',import.meta.url),JSON.stringify((await run()).output.map(part=>({message:JSON.stringify(part)})),null,2)+'\n');
console.log(JSON.stringify({passed:cases.length,failed:0,scope:'local mocked inspector control flow'}));
