import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {readFunctionRetention} from '/function-retention.mjs';
const pg=createRequire('/app/package.json')('pg');
const admin=new pg.Client({connectionString:process.env.ADMIN_DATABASE_URL});
const runtime=new pg.Client({connectionString:process.env.DATABASE_URL});
const result={passed:false,source:process.env.PROBE_SOURCE,scope:'Exact existing fixture role grant only; no install/replacement',capacityAccepted:false,productionMutations:0};
try{
  await admin.connect();await runtime.connect();
  const {grantClasspilotHeartbeatScreenshotEvidence:grant,assertClasspilotHeartbeatScreenshotEvidence:verify}=await import('/app/dist/db/classpilotHeartbeatScreenshotEvidenceInstallation.js');
  const role=(await runtime.query('SELECT current_user AS role,rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user')).rows[0];
  assert.equal(role.rolsuper,false);assert.equal(role.rolbypassrls,false);
  await admin.query('BEGIN');try{await grant(admin,role.role);await admin.query('COMMIT');}catch(error){await admin.query('ROLLBACK');throw error;}
  await verify(runtime);result.function=await readFunctionRetention(runtime);result.passed=true;
}catch(error){result.failure={name:error?.name,code:error?.code};process.exitCode=1;}
finally{
  const closed=await Promise.allSettled([runtime.end(),admin.end()]);result.clientsClosed=closed.every(row=>row.status==='fulfilled');
  if(!result.clientsClosed){result.passed=false;process.exitCode=1;}
  writeFileSync('/proof/grant-result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}
