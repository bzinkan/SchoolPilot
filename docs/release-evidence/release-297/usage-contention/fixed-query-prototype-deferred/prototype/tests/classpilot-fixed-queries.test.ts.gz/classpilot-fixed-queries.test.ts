import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import ts from "typescript";
import { and, eq, sql } from "drizzle-orm";
import { PgDialect } from "drizzle-orm/pg-core";
import * as schema from "../src/schema/index.js";
import { compileFixedScalarQuery } from "../src/lib/fixedScalarQuery.js";
import { currentStudentSessionAuthorityPredicate } from "../src/services/classpilotStudentSessionAuthority.js";

// Run the actual factories and canonical entitlement predicate without importing
// the database pool. Expected SQL comes from the preceding implementation, not
// from the optimized template being tested.
const entitlementSource = readFileSync(new URL("../src/services/classpilotEntitlement.ts", import.meta.url), "utf8");
const entitlementAst = ts.createSourceFile("entitlement.ts", entitlementSource, ts.ScriptTarget.Latest, true);
const entitlement = entitlementAst.statements.find(node => ts.isFunctionDeclaration(node)
  && node.name?.text === "classpilotEntitledSchoolPredicate");
assert.ok(entitlement);
const factories = readFileSync(new URL("../src/services/classpilotFixedQueries.ts", import.meta.url), "utf8");
const factoryAst = ts.createSourceFile("factories.ts", factories, ts.ScriptTarget.Latest, true);
const declarations = factoryAst.statements.filter(node => !ts.isImportDeclaration(node))
  .map(node => node.getText(factoryAst).replace(/^export\s+/, "")).join("\n");
const program = ts.transpileModule(entitlement.getText(entitlementAst).replace(/^export\s+/, "")
  + "\n" + declarations + `\nreturn {
    live_binding: classpilotFixedLiveBindingQuery,
    final_fence: classpilotFixedHeartbeatCurrentQuery,
    foreground_fence: classpilotFixedHeartbeatForegroundQuery,
  };`, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
const names = ["sql", "and", "eq", "compileFixedScalarQuery", "currentStudentSessionAuthorityPredicate", ...Object.keys(schema)];
const values = [sql, and, eq, compileFixedScalarQuery, currentStudentSessionAuthorityPredicate, ...Object.values(schema)];
const queries = new Function(...names, program)(...values);
const expected = JSON.parse(readFileSync(new URL("./fixtures/classpilot-fixed-fence-sql.json", import.meta.url), "utf8"));
const dialect = new PgDialect();

for (const [index, text, revision] of [
  [0, "ordinary", 0],
  [1, "quote' slash\\ dollar$1 ${literal} -- ; /* comment */", 7],
  [2, "Unicode-\u00e9-\u5b66\u6821", Number.MAX_SAFE_INTEGER],
  [3, "", -1],
] as const) {
  for (const name of ["live_binding", "final_fence", "foreground_fence"]) {
    test(`${name} preserves exact SQL, ordered parameters and encoders for case ${index}`, () => {
      const binding = { schoolId: `school:${text}`, studentId: `student:${text}`,
        studentSessionId: `session:${text}`, deviceId: `device:${text}` };
      const focus = { teachingSessionId: `class:${text}`, controlRevision: revision };
      const supplied: Record<string, string | number> = { ...binding, ...focus };
      const actual = dialect.sqlToQuery(queries[name](binding, focus));
      const original = expected.queries[name];
      assert.equal(actual.sql, original.sql);
      assert.deepEqual(actual.params, original.params.map((slot: { binding?: string; value?: unknown }) =>
        slot.binding ? supplied[slot.binding] : slot.value));
      assert.deepEqual(actual.typings, original.typings);
      assert.match(actual.sql, /clock_timestamp\(\)/);
      assert.doesNotMatch(actual.sql, /fixed-scalar|school:|session:/);
    });
  }
}

test("interleaved factory calls never retain another student's bindings or mutable SQL", () => {
  const first = { schoolId: "school-a", studentId: "student-a", studentSessionId: "session-a", deviceId: "device-a" };
  const second = { schoolId: "school-b", studentId: "student-b", studentSessionId: "session-b", deviceId: "device-b" };
  for (const name of ["live_binding", "final_fence", "foreground_fence"]) {
    const queryA = queries[name](first, { teachingSessionId: "class-a", controlRevision: 1 });
    const before = dialect.sqlToQuery(queryA);
    const queryB = queries[name](second, { teachingSessionId: "class-b", controlRevision: 2 });
    queryB.append(sql` AND ${"only-b"}`);
    assert.deepEqual(dialect.sqlToQuery(queryA), before);
    assert.ok(!dialect.sqlToQuery(queryB).params.includes("student-a"));
  }
});
