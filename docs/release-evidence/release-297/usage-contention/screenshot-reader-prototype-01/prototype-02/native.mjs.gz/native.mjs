import assert from 'node:assert/strict';
import test from 'node:test';
import {randomUUID,createHash} from 'node:crypto';
import {writeFileSync,readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import pg from '/app/node_modules/pg/lib/index.js';
import {drizzle} from '/app/node_modules/drizzle-orm/node-postgres/index.js';
import {QueryBuilder} from '/app/node_modules/drizzle-orm/pg-core/index.js';
import {sql} from '/app/node_modules/drizzle-orm/index.js';
import {functionSql,functionHash,statements,sequential,combined,comparableEvidence,dialect} from './queries.mjs';
import {withHeartbeatPreparedReadTransaction} from '/app/dist/services/classpilotHeartbeatPreparedReads.js';
import {db,pool,sessionPool} from '/app/dist/db.js';
import * as storage from '/app/dist/services/storage.js';
import * as context from '/app/dist/middleware/tenantContext.js';
import {waitForTimingRelease,resourceSnapshot} from './timing-gate.mjs';
import {runReviewerCases} from './reviewer-cases.mjs';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const hash=value=>createHash('sha256').update(value).digest('hex');
const scoped=(schoolId,fn)=>context.runWithTenantContext({schoolId},fn);
const root=(schoolId,fn)=>scoped(schoolId,()=>withHeartbeatPreparedReadTransaction(db,schoolId,fn));
const admin=new pg.Client({connectionString:process.env.ADMIN_DATABASE_URL,statement_timeout:15000});
const observer=new pg.Client({connectionString:process.env.ADMIN_DATABASE_URL,statement_timeout:15000});
const results=[];
async function fixture(){
 const key='spi_'+randomUUID().replaceAll('-','');
 const school=await storage.createSchool({name:key,slug:key,domain:key+'.example.invalid'});
 const teacher=await storage.createUser({email:key+'@'+key+'.example.invalid',firstName:'Synthetic',lastName:'SPI'});
 await storage.createMembership({schoolId:school.id,userId:teacher.id,role:'teacher',status:'active'});
 await storage.createProductLicense({schoolId:school.id,product:'CLASSPILOT',status:'active'});
 return scoped(school.id,async()=>{
  const student=await storage.createStudent({schoolId:school.id,firstName:'Synthetic',lastName:'SPI',status:'active'});
  const group=await storage.createGroup({schoolId:school.id,teacherId:teacher.id,name:key,groupType:'teacher_created'});
  await storage.addGroupStudentsDetailed(group.id,[student.id]);
  const deviceId=key;await storage.createDevice({deviceId,schoolId:school.id,classId:'default'});
  const session=await storage.setActiveStudentForDevice(deviceId,student.id);
  const teaching=await storage.createTeachingSession({groupId:group.id,teacherId:teacher.id,startTime:new Date(Date.now()-60000)});
  await db.execute(sql`UPDATE student_sessions SET auth_kind='manual_shared',manual_lease_expires_at=clock_timestamp()+interval '1 hour',session_recovery_token_hash=${randomUUID().replaceAll('-','')+randomUUID().replaceAll('-','')} WHERE id=${session.id}`);
  await db.execute(sql`UPDATE classpilot_student_control_states SET revision=8,hard_expires_at=clock_timestamp()+interval '1 hour',scheduled_end_at=NULL WHERE school_id=${school.id} AND student_id=${student.id}`);
  return{school,student,teacher,group,teaching,options:{schoolId:school.id,studentId:student.id,studentSessionId:session.id,deviceId}};
 });
}
// Run the actual production JS decisions on the collected raw evidence. This
// fake database exists only in the external proof; no authorization API changes.
async function projectionFromEvidence(options,evidence){
 const calls=[];
 const respond=query=>{const text=query.toSQL().sql;if(text.includes('from "student_sessions"')){calls.push('session');return evidence.session?[evidence.session]:[];}if(text.includes('inner join "teaching_sessions"')){calls.push('candidate');return evidence.candidate?[evidence.candidate]:[];}if(text.includes('from "classpilot_student_control_states"')){calls.push('control');return evidence.control?[evidence.control]:[];}throw Error('Unsupported proof branch '+text.slice(0,70));};
 const wrap=query=>new Proxy(query,{get(target,key){if(key==='execute')return async()=>respond(target);if(key==='then')return(resolve,reject)=>Promise.resolve().then(()=>respond(target)).then(resolve,reject);const value=target[key];if(typeof value!=='function')return value;return(...args)=>{const next=value.apply(target,args);return next&&typeof next==='object'&&('getSQL'in next||'from'in next)?wrap(next):next;};}});
 const evidenceDb={select:fields=>wrap(new QueryBuilder().select(fields)),execute:async()=>{calls.push('owner');return{rows:evidence.owners??[]};}};
 const projection=await storage.getClasspilotScreenshotAuthorityProjection(options,evidenceDb);
 return{projection,calls};
}
async function waitBlocked(pid){const end=performance.now()+3000;while(performance.now()<end){const row=(await observer.query('SELECT wait_event_type FROM pg_stat_activity WHERE pid=$1',[pid])).rows[0];if(row?.wait_event_type==='Lock')return;await pause(10);}assert.fail('Expected actual PostgreSQL lock wait');}

test('external sequential snapshot screenshot function',{timeout:900000},async t=>{
 let failures=0;const check=(name,fn)=>t.test(name,async()=>{try{await fn();results.push({name,passed:true});}catch(error){failures++;results.push({name,passed:false,code:error.code??error.cause?.code??null});throw error;}});
 try{
  await admin.connect();await observer.connect();await admin.query(functionSql);
  const fixtureRole=(await pool.query('SELECT current_user AS name')).rows[0].name;
  assert.match(fixtureRole,/^app_[a-f0-9]{12}$/);
  await admin.query('REVOKE ALL ON FUNCTION public.external_screenshot_evidence(text,text,text,text) FROM PUBLIC');
  await admin.query('GRANT EXECUTE ON FUNCTION public.external_screenshot_evidence(text,text,text,text) TO "'+fixtureRole+'"');
  writeFileSync('/evidence/function.sql',functionSql+'\n',{flag:'wx'});
  writeFileSync('/evidence/statements.json',JSON.stringify({functionHash,statements},null,2)+'\n',{flag:'wx'});
  const a=await fixture(),b=await fixture();
  await check('restricted role and actual function invoker/volatility/timeout are enforced',async()=>{
   assert.equal(pool.options.max,16);assert.equal(sessionPool.options.max,2);
   const posture=(await pool.query("SELECT rolsuper,rolbypassrls,current_setting('statement_timeout') timeout FROM pg_roles WHERE rolname=current_user")).rows[0];assert.equal(posture.rolsuper,false);assert.equal(posture.rolbypassrls,false);assert.equal(posture.timeout,'15s');
   const fn=(await admin.query("SELECT provolatile,prosecdef,proparallel,proconfig,proacl::text FROM pg_proc WHERE oid='public.external_screenshot_evidence(text,text,text,text)'::regprocedure")).rows[0];assert.equal(fn.provolatile,'v');assert.equal(fn.prosecdef,false);assert.equal(fn.proparallel,'u');assert.deepEqual(fn.proconfig,['search_path=pg_catalog']);assert.ok(!fn.proacl.includes('{=X')&&!fn.proacl.includes(',=X'));
   const policies=(await admin.query("SELECT relrowsecurity,relforcerowsecurity FROM pg_class WHERE oid=ANY(ARRAY['students'::regclass,'devices'::regclass,'teaching_sessions'::regclass,'classpilot_student_control_states'::regclass])")).rows;assert.equal(policies.length,4);assert.ok(policies.every(x=>x.relrowsecurity&&x.relforcerowsecurity));
  });
  await check('restricted four-query evidence and original JS projection equal the one-call evidence',async()=>root(a.school.id,async tx=>{
   const old=await sequential(tx,a.options),next=await combined(tx,a.options);assert.equal(next.stage,'owner');assert.deepEqual(comparableEvidence(next),comparableEvidence(old));
   const actual=await storage.getClasspilotScreenshotAuthorityProjection(a.options,tx);const projected=await projectionFromEvidence(a.options,next);assert.deepEqual(projected.projection,actual);assert.equal(actual.authority.kind,'teaching_session');assert.deepEqual(projected.calls,['session','control','candidate','owner']);
  }));
  await check('owner role has exact same evidence with explicit school GUC and transaction',async()=>{
   await admin.query('BEGIN');try{await admin.query("SELECT set_config('app.school_id',$1,true),set_config('app.is_super','off',true)",[a.school.id]);const tx=drizzle(admin);assert.deepEqual(comparableEvidence(await combined(tx,a.options)),comparableEvidence(await sequential(tx,a.options)));}finally{await admin.query('ROLLBACK');}
  });
  await check('foreign tenant tuple produces no session under restricted RLS',async()=>root(a.school.id,async tx=>{assert.deepEqual(await combined(tx,b.options),{stage:'session_missing'});assert.deepEqual(await sequential(tx,b.options),{stage:'session_missing'});}));
  await check('supervision control stops at Q2 with raw evidence for the existing JS branch',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore();await assert.rejects(store.db.transaction(async tx=>{
    const id=randomUUID();await tx.execute(sql`INSERT INTO classpilot_supervision_contexts(id,school_id,context_type,name,assigned_staff_id,created_by,ends_at) VALUES(${id},${a.school.id},'coverage','Synthetic',${a.teacher.id},${a.teacher.id},clock_timestamp()+interval '1 hour')`);
    await tx.execute(sql`UPDATE classpilot_student_control_states SET teaching_session_id=NULL,supervision_context_id=${id} WHERE school_id=${a.school.id} AND student_id=${a.student.id}`);
    const old=await sequential(tx,a.options),next=await combined(tx,a.options);assert.equal(next.stage,'control');assert.equal(next.control.supervisionContextId,id);assert.deepEqual(comparableEvidence(next),comparableEvidence(old));throw Error('expected_rollback');
   }),/expected_rollback/);
  }));
  await check('timestamp precision and null evidence remain schema-decoder equivalent',async()=>root(a.school.id,async tx=>{
   await tx.execute(sql`UPDATE student_sessions SET started_at='2026-11-01 01:30:00.123456'::timestamp WHERE id=${a.options.studentSessionId}`);
   await tx.execute(sql`UPDATE classpilot_student_control_states SET updated_at='2026-11-01 01:30:00.999999'::timestamp,scheduled_end_at=NULL WHERE school_id=${a.school.id} AND student_id=${a.student.id}`);
   assert.deepEqual(comparableEvidence(await combined(tx,a.options)),comparableEvidence(await sequential(tx,a.options)));
  }));
  for(const [name,change,expected]of[
   ['missing-control',`DELETE FROM classpilot_student_control_states WHERE school_id=$1 AND student_id=$2`,'control'],
   ['nonteaching-control',`UPDATE classpilot_student_control_states SET teaching_session_id=NULL WHERE school_id=$1 AND student_id=$2`,'control'],
   ['no-hard-expiry',`UPDATE classpilot_student_control_states SET hard_expires_at=NULL WHERE school_id=$1 AND student_id=$2`,'control'],
   ['past-candidate-expiry',`UPDATE classpilot_student_control_states SET hard_expires_at=now()-interval '1 second' WHERE school_id=$1 AND student_id=$2`,'candidate_missing']]){
   await check(name+' stops at matching branch without extra locks',async()=>scoped(a.school.id,async()=>{
    const store=context.getOwnedTenantStore();await assert.rejects(store.db.transaction(async tx=>{await store.client.query(change,[a.school.id,a.student.id]);const old=await sequential(tx,a.options),next=await combined(tx,a.options);assert.equal(next.stage,expected);assert.deepEqual(comparableEvidence(next),comparableEvidence(old));throw Error('expected_rollback');}),/expected_rollback/);
   }));
  }
  await check('manual expiry uses current DB clock even within a long transaction',async()=>root(a.school.id,async tx=>{
   await tx.execute(sql`UPDATE student_sessions SET manual_lease_expires_at=clock_timestamp()+interval '30 milliseconds' WHERE id=${a.options.studentSessionId}`);await pause(50);
   assert.deepEqual(await combined(tx,a.options),{stage:'session_missing'});assert.deepEqual(await sequential(tx,a.options),{stage:'session_missing'});
   await tx.execute(sql`UPDATE student_sessions SET manual_lease_expires_at=clock_timestamp()+interval '1 hour' WHERE id=${a.options.studentSessionId}`);
  }));
  for(const stage of ['session','control'])for(const mode of ['sequential','combined']){
   await check(`${mode} sees commits after blocked ${stage} statement in its later snapshot`,async()=>{
    await admin.query('UPDATE teaching_sessions SET end_time=clock_timestamp() WHERE id=$1',[a.teaching.id]);
    await admin.query('BEGIN');let operation;
    try{
     await admin.query(stage==='session'?'UPDATE student_sessions SET last_seen_at=last_seen_at WHERE id=$1':'UPDATE classpilot_student_control_states SET revision=revision WHERE student_id=$1',[stage==='session'?a.options.studentSessionId:a.student.id]);
     let announce;const started=new Promise(r=>announce=r);let pid;
     operation=root(a.school.id,async tx=>{pid=context.getOwnedTenantStore().client.processID;announce();return(mode==='combined'?combined:sequential)(tx,a.options);});void operation.catch(()=>{});await started;await waitBlocked(pid);
     await admin.query('UPDATE classpilot_student_control_states SET revision=revision+1 WHERE student_id=$1',[a.student.id]);
     await admin.query('UPDATE teaching_sessions SET end_time=NULL WHERE id=$1',[a.teaching.id]);
     const expected=(await admin.query('SELECT revision FROM classpilot_student_control_states WHERE student_id=$1',[a.student.id])).rows[0].revision;
     await admin.query('COMMIT');const evidence=await operation;assert.equal(evidence.stage,'owner');assert.equal(evidence.control.revision,expected);assert.equal(evidence.candidate.controlRevision,expected);
    }finally{await admin.query('ROLLBACK').catch(()=>{});if(operation)await Promise.allSettled([operation]);await admin.query('UPDATE teaching_sessions SET end_time=NULL WHERE id=$1',[a.teaching.id]);}
   });
  }
  await check('caller failure retains pending function ownership through native cancellation and rollback',async()=>{
   await admin.query('BEGIN');let operation,client,completed=false,sqlSettled=false,rollback=false;
   let original;
   try{
    await admin.query('UPDATE student_sessions SET last_seen_at=last_seen_at WHERE id=$1',[a.options.studentSessionId]);
    let announce;const started=new Promise(r=>announce=r);
    operation=root(a.school.id,async tx=>{
     client=context.getOwnedTenantStore().client;original=client.query;
     client.query=function(config,...args){const text=typeof config==='string'?config:config.text;if(/^rollback$/i.test(text)){rollback=true;assert.equal(sqlSettled,true);}return original.call(this,config,...args);};
     const read=combined(tx,a.options);void read.then(()=>sqlSettled=true,()=>sqlSettled=true);announce();throw Error('intentional_caller_failure');
    }).finally(()=>completed=true);void operation.catch(()=>{});
    await started;await waitBlocked(client.processID);assert.equal(completed,false);assert.equal(rollback,false);
    assert.equal((await observer.query('SELECT pg_cancel_backend($1) cancelled',[client.processID])).rows[0].cancelled,true);
    await assert.rejects(operation,/intentional_caller_failure/);assert.equal(sqlSettled,true);assert.equal(rollback,true);assert.equal(client.getTransactionStatus(),'I');
   }finally{await admin.query('ROLLBACK').catch(()=>{});if(operation)await Promise.allSettled([operation]);if(client&&original)client.query=original;}
  });
  await check('outer function retains the unchanged actual fifteen-second statement deadline',async()=>{
   await admin.query('BEGIN');let operation;
   try{
    await admin.query('UPDATE student_sessions SET last_seen_at=last_seen_at WHERE id=$1',[a.options.studentSessionId]);
    const start=performance.now();operation=root(a.school.id,tx=>combined(tx,a.options));void operation.catch(()=>{});
    await assert.rejects(operation,error=>(error.code??error.cause?.code)==='57014');
    const elapsed=performance.now()-start;assert.ok(elapsed>=14000&&elapsed<25000,'actual unchanged statement deadline');
    results.push({name:'actual deadline observation',elapsedMs:elapsed,statementTimeoutMs:15000,passed:true});
   }finally{await admin.query('ROLLBACK').catch(()=>{});if(operation)await Promise.allSettled([operation]);}
  });
  await runReviewerCases({check,a,b,admin,observer,pool,root,storage,context,sql,sequential,combined,comparableEvidence,projectionFromEvidence,waitBlocked});
  assert.equal(failures,0,'Every native subtest must pass before timing readiness');
  writeFileSync('/evidence/correctness.json',JSON.stringify({passed:true,results,functionHash,capacityAccepted:false},null,2)+'\n',{flag:'wx'});
  await waitForTimingRelease();
  const before=resourceSnapshot(),rounds=[];
  await root(a.school.id,async tx=>{
   // The timing comparison holds the same outer student authority lock. It
   // intentionally measures only the four-read boundary, not the full route.
   await storage.lockClasspilotStudentControlAuthorities(a.school.id,[a.student.id],tx);
   for(const mode of ['sequential','combined'])for(let n=0;n<50;n++)await(mode==='combined'?combined:sequential)(tx,a.options);
   for(let round=0;round<4;round++)for(const mode of round%2?['combined','sequential']:['sequential','combined']){
    const cpu=process.cpuUsage(),start=performance.now();for(let n=0;n<1000;n++){const evidence=await(mode==='combined'?combined:sequential)(tx,a.options);assert.equal(evidence.stage,'owner');}
    rounds.push({round,mode,iterations:1000,clientCommands:mode==='combined'?1000:4000,internalStatements:4000,wallMs:performance.now()-start,cpuMicroseconds:process.cpuUsage(cpu)});
   }
  });
  writeFileSync('/evidence/result.json',JSON.stringify({source:'e95a2b56476b1225434c1b0f3907db46c9d84fe3',functionHash,results,rounds,before,after:resourceSnapshot(),timedBoundary:'actual cached sequential reads or function call, including required schema row decoding; final JS projection parity adapter excluded',outerStatementTimeoutMs:15000,stricterCumulativeDeadline:true,capacityAccepted:false,applicationChanges:0},null,2)+'\n',{flag:'wx'});
 }finally{await context.drainTenantContextReleases();await Promise.allSettled([admin.end(),observer.end(),pool.end(),sessionPool.end()]);}
});
