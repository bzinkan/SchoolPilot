$ErrorActionPreference='Stop'
$endpoint='npipe:////./pipe/dockerDesktopLinuxEngine'
$image='sha256:949286506dd548e502aa81e65794a5699e95479d816f60dd057b7a26c17a0de0'
$name='schoolpilot-role-v8-b112-'+[guid]::NewGuid().ToString('N').Substring(0,12)
$out=Join-Path $env:TEMP 'release297-role-b112-v8-smoke-01'
if(Test-Path -LiteralPath $out){throw 'Fresh evidence required'}
New-Item -ItemType Directory -Path $out | Out-Null
$keys=@('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','BUILDX_BUILDER');$saved=@{}
foreach($key in $keys){$saved[$key]=[Environment]::GetEnvironmentVariable($key);[Environment]::SetEnvironmentVariable($key,$null)}
try {
 $id=(& docker --host $endpoint create --name $name --label "codex.role-smoke=$name" --network none --read-only --cpus 1 --memory 2g --memory-swap 2g --cap-drop ALL --security-opt no-new-privileges --user node --env USAGE_RELEASE_ROLE=api --env USAGE_SOURCE_REVISION=b11202fc305198d76e73c5e6d711b7dc9ed2d938 --env USAGE_RELEASE_MODE=diagnostic --env USAGE_RELEASE_PHASE=combined --env USAGE_RELEASE_DIAGNOSTIC=true --env USAGE_RELEASE_CPU_PROFILE=false --entrypoint node $image --import /prototype/runtime-facts.mjs /prototype/runtime-facts.mjs).Trim()
 if($LASTEXITCODE-ne 0){throw 'Create failed'}
 & docker --host $endpoint start --attach $id *> (Join-Path $out 'runtime.log')
 $attach=$LASTEXITCODE
 $i=(& docker --host $endpoint inspect $id | ConvertFrom-Json)[0]
 if($i.Name -cne '/'+$name -or $i.Config.Image -cne $image -or $i.Image -cne $image -or $i.Config.Labels.'codex.role-smoke' -cne $name){throw 'Identity'}
 if($attach-ne 0 -or $i.State.ExitCode-ne 0 -or $i.State.Running){throw 'Runtime proof failed'}
 [ordered]@{source='b11202fc305198d76e73c5e6d711b7dc9ed2d938';id=$id;image=$image;exitCode=$i.State.ExitCode;runtimeSha256=(Get-FileHash (Join-Path $out 'runtime.log')).Hash.ToLower();passed=$true} | ConvertTo-Json | Set-Content (Join-Path $out 'proof.json') -Encoding utf8NoBOM
} finally {
 try {
  $ids=@(& docker --host $endpoint ps -a --filter "name=^/$name`$" --no-trunc --format '{{.ID}}')
  if($LASTEXITCODE-ne 0 -or $ids.Count-gt 1){throw 'Lookup'}
  if($ids.Count-eq 1){$i=(& docker --host $endpoint inspect $ids[0] | ConvertFrom-Json)[0];if($i.Name -cne '/'+$name -or $i.Config.Image -cne $image -or $i.Image -cne $image -or $i.Config.Labels.'codex.role-smoke' -cne $name){throw 'Cleanup identity'};docker --host $endpoint rm --force --volumes $ids[0] | Out-Null;if($LASTEXITCODE-ne 0){throw 'Cleanup'}}
  $remaining=@(& docker --host $endpoint ps -a --filter "name=^/$name`$" --no-trunc --format '{{.ID}}');if($LASTEXITCODE-ne 0 -or $remaining.Count-ne 0){throw 'Absent'}
  [ordered]@{name=$name;cleanupPassed=$true} | ConvertTo-Json | Set-Content (Join-Path $out 'cleanup.json') -Encoding utf8NoBOM
 }finally{foreach($key in $keys){[Environment]::SetEnvironmentVariable($key,$saved[$key])}}
}
