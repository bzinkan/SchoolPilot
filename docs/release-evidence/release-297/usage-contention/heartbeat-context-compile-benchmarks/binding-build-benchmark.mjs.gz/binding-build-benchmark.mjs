import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
const root=process.argv[2]; const require=createRequire(root+'/package.json');
const {drizzle}=require('drizzle-orm/node-postgres'); const {sql,and,eq}=require('drizzle-orm');
const {PgDialect}=require('drizzle-orm/pg-core');
const {studentSessions,devices}=await import(pathToFileURL(root+'/dist/schema/classpilot.js'));
const {students}=await import(pathToFileURL(root+'/dist/schema/students.js'));
const {currentStudentSessionAuthorityPredicate}=await import(pathToFileURL(root+'/dist/services/classpilotStudentSessionAuthority.js'));
const db=drizzle({query:()=>{throw new Error('benchmark must not execute SQL')}});
const o={schoolId:'school',studentId:'student',studentSessionId:'session',deviceId:'device'};
const old=()=>db.select({id:studentSessions.id}).from(studentSessions).innerJoin(students,and(eq(students.id,studentSessions.studentId),eq(students.schoolId,o.schoolId),eq(students.status,'active'))).innerJoin(devices,and(eq(devices.deviceId,studentSessions.deviceId),eq(devices.schoolId,o.schoolId))).where(and(eq(studentSessions.id,o.studentSessionId),eq(studentSessions.studentId,o.studentId),eq(studentSessions.deviceId,o.deviceId),currentStudentSessionAuthorityPredicate())).limit(1).for('share').toSQL();
const dialect=new PgDialect();
const raw=()=>dialect.sqlToQuery(sql`SELECT student_sessions.id FROM student_sessions JOIN students ON students.id = student_sessions.student_id AND students.school_id = ${o.schoolId} AND students.status = 'active' JOIN devices ON devices.device_id = student_sessions.device_id AND devices.school_id = ${o.schoolId} WHERE student_sessions.id = ${o.studentSessionId} AND student_sessions.student_id = ${o.studentId} AND student_sessions.device_id = ${o.deviceId} AND ${currentStudentSessionAuthorityPredicate()} LIMIT 1 FOR SHARE`);
const rounds=[];for(let i=0;i<5;i++){let row={};for(const [name,fn]of[['select',old],['raw',raw]]){const s=performance.now();for(let n=0;n<10000;n++)fn();row[name]=performance.now()-s;}rounds.push(row)}
console.log(JSON.stringify({iterationsPerRound:10000,rounds,oldSQL:old().sql,rawSQL:raw().sql},null,2));
