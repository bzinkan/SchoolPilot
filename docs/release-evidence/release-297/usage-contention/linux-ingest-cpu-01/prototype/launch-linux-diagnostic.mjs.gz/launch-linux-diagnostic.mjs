// EXTERNAL PROTOTYPE. Not run in this preparation task. Docker operations require
// later parent authorization and an exact reviewed diagnostic-image receipt.
import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, createWriteStream } from 'node:fs';
import { resolve } from 'node:path';
import { finished } from 'node:stream/promises';
import { linuxPlan, cleanupOwned } from './prototype-core.mjs';

const [docker, endpoint, bindingFile, run, pgContainerId, output] = process.argv.slice(2);
assert.match(endpoint, /^(?:npipe:\/{2,4}\.\/pipe\/[a-zA-Z0-9_.-]+|unix:\/\/\/[^\s?#]+)$/);
const binding = JSON.parse(readFileSync(bindingFile, 'utf8'));
assert.equal(binding.prototypeValidated, true); assert.equal(binding.diagnosticOnly, true);
const dockerEnv = { ...process.env };
for (const key of ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS']) delete dockerEnv[key];
const invoke = args => execFileSync(docker, ['--host', endpoint, ...args], { env: dockerEnv, encoding: 'utf8', timeout: 30_000, stdio: ['ignore','pipe','pipe'], windowsHide: true });
const image = JSON.parse(invoke(['image', 'inspect', binding.diagnosticImageId]))[0];
const candidate = JSON.parse(invoke(['image', 'inspect', binding.candidateImageId]))[0];
assert.equal(candidate.Id,binding.candidateImageId); assert.equal(candidate.Config.Labels?.['org.opencontainers.image.revision'],binding.applicationSource);
assert.equal(candidate.Os,'linux'); assert.equal(candidate.Architecture,'amd64');
assert.equal(image.Id, binding.diagnosticImageId);
assert.equal(image.Config.Labels?.['org.opencontainers.image.revision'], binding.applicationSource);
assert.equal(image.Config.Labels?.['codex.usage-linux.candidate'], binding.candidateImageId);
const pg = JSON.parse(invoke(['container', 'inspect', pgContainerId]))[0];
assert.equal(pg.Id, pgContainerId); assert.equal(pg.Name, `/schoolpilot-usage-scale-${run}`);
assert.equal(pg.Config.Labels?.['codex.usage-scale'], run); assert.equal(pg.State.Running, true);
assert.equal(pg.HostConfig.NanoCpus, 4_000_000_000); assert.equal(pg.HostConfig.Memory, 4_294_967_296);
const plan = linuxPlan({ run, source: binding.applicationSource, imageId: binding.diagnosticImageId, pgContainerId, evidenceDirectory: output, env: process.env });
Object.assign(dockerEnv, plan.childEnv);
writeFileSync(resolve(output, 'linux-runtime-plan.json'), JSON.stringify(plan.receipt, null, 2) + '\n');
const owner = { run, name: plan.name, imageId: binding.diagnosticImageId, imageIdentities:binding.diagnosticImageIdentities, pgContainerId };
assert.ok(Array.isArray(owner.imageIdentities)&&owner.imageIdentities.includes(owner.imageId));
const inspect = async name => {
  const ids = invoke(['container','ls','--all','--filter',`name=^/${name}$`,'--format','{{.ID}}']).trim().split('\n').filter(Boolean);
  assert.ok(ids.length <= 1);
  if (ids.length === 0) return null;
  return JSON.parse(invoke(['container','inspect',ids[0]]))[0];
};
let exitCode = 1, creationAttempted = false;
try {
  await inspect(plan.name).then(found => assert.equal(found, null));
  creationAttempted = true;
  invoke(plan.args); // Unknown outcome is still reconciled in finally by exact label/name/image/network.
  const log = createWriteStream(resolve(output, 'scale.log'), { flags: 'wx' });
  const attach = spawn(docker, ['--host', endpoint, 'start', '--attach', plan.name], { env: dockerEnv, stdio: ['ignore','pipe','pipe'], windowsHide: true });
  attach.stdout.pipe(log, { end: false }); attach.stderr.pipe(log, { end: false });
  // Outer orphan-prevention deadline only; all request, pool, worker and traffic
  // thresholds stay unchanged. Expiry cannot certify successful diagnostics.
  let expired = false;
  const timer = setTimeout(() => { expired = true; attach.kill('SIGKILL'); }, 900_000);
  let closed;
  try { closed = await new Promise((accept, reject) => { attach.once('error', reject); attach.once('close', code => accept(code)); }); }
  finally { clearTimeout(timer); log.end(); await finished(log); }
  const ended = await inspect(plan.name);
  assert.equal(expired, false); assert.equal(ended?.State.Running, false);
  assert.equal(closed, 0); assert.equal(ended.State.ExitCode, 0);
  const result = JSON.parse(readFileSync(resolve(output, 'usage-scale.json'), 'utf8'));
  assert.equal(result.diagnosticOnly, true); assert.equal(result.capacityAccepted, false);
  assert.equal(result.diagnosticTrafficPassed, true); assert.equal(result.childShutdownClean, true);
  assert.equal(result.cpuProfile?.enabled,true); assert.match(result.cpuProfile?.sha256,/^[a-f0-9]{64}$/);
  assert.ok(result.cpuProfile.samples>0); assert.equal(result.phases?.length,1); assert.equal(result.phases[0].name,'ingest');
  assert.equal(result.phases[0].traffic.heartbeats.expected,6000);
  exitCode = 0;
} catch { writeFileSync(resolve(output, 'linux-launch-failure.json'), JSON.stringify({ code: 'LINUX_DIAGNOSTIC_FAILED', capacityAccepted: false }) + '\n'); }
finally {
  const cleanup = creationAttempted ? await cleanupOwned({ inspect,
    kill: async id => { invoke(['container','kill','--signal','KILL',id]); },
    remove: async id => { invoke(['container','rm','--volumes',id]); } }, owner) : { cleanupPassed: true, creationAttempted: false, noExistingResourceTouched: true };
  writeFileSync(resolve(output, 'linux-container-cleanup.json'), JSON.stringify(cleanup, null, 2) + '\n');
  if (!cleanup.cleanupPassed) exitCode = 1;
}
process.exitCode = exitCode;
