import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {assertRuntime} from '/prototype-tools/verify-runtime.mjs';
import {resourceSnapshot} from './timing-gate.mjs';
const watchdog=setTimeout(()=>{console.error('External native proof bounded watchdog expired');process.exit(124);},1200000);watchdog.unref();
const manifest=JSON.parse(readFileSync('/micro/manifest.json','utf8'));
for(const row of manifest.files)assert.equal(createHash('sha256').update(readFileSync('/micro/'+row.path)).digest('hex'),row.sha256,row.path);
const runtime=assertRuntime('/prototype-tools/base-runtime.json');
const resources=resourceSnapshot();assert.equal(resources['cpu.max'],'100000 100000');assert.equal(resources['memory.max'],'2147483648');assert.equal(resources['memory.swap.max'],'0');assert.ok(process.execArgv.includes('--max-old-space-size=512'));
writeFileSync('/evidence/runtime-before.json',JSON.stringify({runtime,resources,source:'0e427e3ca9b82125e0bb8692176accad21f4f699',prototypeManifestSha256:createHash('sha256').update(readFileSync('/micro/manifest.json')).digest('hex'),applicationChanges:0,capacityAccepted:false},null,2)+'\n',{flag:'wx'});
await import('./native-proof.mjs');
process.once('beforeExit',()=>{
 const runtime=assertRuntime('/prototype-tools/base-runtime.json');
 for(const row of manifest.files)assert.equal(createHash('sha256').update(readFileSync('/micro/'+row.path)).digest('hex'),row.sha256,row.path);
 writeFileSync('/evidence/runtime-after.json',JSON.stringify({runtime,resources:resourceSnapshot(),applicationChanges:0,capacityAccepted:false},null,2)+'\n',{flag:'wx'});
});
