$ErrorActionPreference = 'Stop'
$taskExpected = 'cb66014d70a275405a5469257b37debe8d20ea18'
$taskSource = (git rev-parse HEAD).Trim()
if ($taskSource -cne $taskExpected -or (git status --porcelain)) { throw 'Final candidate checkout must be exact and clean' }
$taskEvidence = $PSScriptRoot
$taskEngine = 'npipe:////./pipe/dockerDesktopLinuxEngine'
$taskTag = 'schoolpilot-candidate-local:cb66014d70a2-' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmss')
$taskScanner = 'aquasec/trivy@sha256:af6acf9a6b85dfe389a1941505c0ce9efef52a4719635e1a962f022a3d855daa'
$taskStarted = [DateTime]::UtcNow.ToString('o')
$taskBuildExit = 99; $taskSaveExit = 99; $taskScanExit = 99; $taskGateExit = 99; $taskError = $null
try {
 docker --host $taskEngine build --pull --platform linux/amd64 --label "org.opencontainers.image.revision=$taskSource" --tag $taskTag --iidfile (Join-Path $taskEvidence 'image-id.txt') --progress plain . *> (Join-Path $taskEvidence 'build.log')
 $taskBuildExit = $LASTEXITCODE
 if ($taskBuildExit -ne 0) { throw 'Exact-source local image build failed' }
 $taskImage = (Get-Content (Join-Path $taskEvidence 'image-id.txt') -Raw).Trim()
 docker --host $taskEngine image inspect $taskImage | Set-Content -LiteralPath (Join-Path $taskEvidence 'image-inspect.json') -Encoding utf8
 if ($LASTEXITCODE -ne 0) { throw 'Local image inspection failed' }
 docker --host $taskEngine image save --output (Join-Path $taskEvidence 'image.tar') $taskTag *> (Join-Path $taskEvidence 'save.log')
 $taskSaveExit = $LASTEXITCODE
 if ($taskSaveExit -ne 0) { throw 'Local image export failed' }
 docker --host $taskEngine run --rm --mount "type=bind,source=$taskEvidence,target=/evidence" $taskScanner image --cache-dir /evidence/trivy-cache --input /evidence/image.tar --scanners vuln --format json --output /evidence/trivy-all.json --exit-code 0 *> (Join-Path $taskEvidence 'trivy-all.log')
 $taskScanExit = $LASTEXITCODE
 if ($taskScanExit -ne 0) { throw 'Local vulnerability scan failed' }
 docker --host $taskEngine run --rm --mount "type=bind,source=$taskEvidence,target=/evidence" $taskScanner image --cache-dir /evidence/trivy-cache --input /evidence/image.tar --scanners vuln --severity HIGH,CRITICAL --ignore-unfixed --format json --output /evidence/trivy-gate.json --exit-code 1 *> (Join-Path $taskEvidence 'trivy-gate.log')
 $taskGateExit = $LASTEXITCODE
 if ($taskGateExit -ne 0) { throw 'Exact local image failed fixed HIGH/CRITICAL gate' }
 if ((git rev-parse HEAD).Trim() -cne $taskSource -or (git status --porcelain)) { throw 'Frozen checkout changed during artifact preparation' }
} catch { $taskError = $_.Exception.Message } finally {
 [ordered]@{ sourceCommit=$taskSource; sourceStatus='clean exact frozen candidate'; dockerEngine=$taskEngine; localTag=$taskTag; scannerImage=$taskScanner; startedAt=$taskStarted; finishedAt=[DateTime]::UtcNow.ToString('o'); buildExit=$taskBuildExit; saveExit=$taskSaveExit; scanExit=$taskScanExit; gateExit=$taskGateExit; failure=$taskError; productionMutations=0; registryPushes=0; taskRegistrations=0; capacityAcceptance='pending separate measured runs'; deploymentApproval=$false } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskEvidence 'preparation.json') -Encoding utf8
 Write-Output ('Evidence: ' + $taskEvidence)
 if ($taskError) { Write-Output $taskError }
}
if ($taskError -or $taskBuildExit -ne 0 -or $taskSaveExit -ne 0 -or $taskScanExit -ne 0 -or $taskGateExit -ne 0) { exit 1 }
