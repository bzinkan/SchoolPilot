$ErrorActionPreference='Stop'
$repo='<WORKTREE>'
$docker='C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$daemon='npipe:////./pipe/dockerDesktopLinuxEngine'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$container='schoolpilot-heartbeat-context-'+$run
$database='heartbeat_context_'+$run
$owner='fixture_'+$run; $app='app_'+$run
$password=[guid]::NewGuid().ToString('N');$appPassword=[guid]::NewGuid().ToString('N')
$out=Join-Path $env:TEMP ('release297-heartbeat-context-plan-'+$run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $repo
$created=$false;$ownerExit=1;$restrictedExit=1
$sourceFiles=@('src/services/storage.ts','src/routes/classpilot/devices.ts','tests/classpilot-heartbeat-persistence-context.integration.test.ts','scripts/run-test-lane.mjs')
function Snapshot { $rows=@();foreach($f in $sourceFiles){$rows += [ordered]@{file=$f;sha256=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower()}};return $rows }
Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-before.json') -Encoding utf8
try {
 $schema=Join-Path $out 'schema.sql'
 Copy-Item -LiteralPath (Join-Path $env:TEMP 'release297-enabled-combined-04/post-convergence-schema.sql') -Destination $schema
 $image=(& $docker --host $daemon inspect schoolpilot-db --format '{{.Image}}').Trim()
 & $docker --host $daemon run --detach --name $container --label "codex.heartbeat-context=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
 if($LASTEXITCODE -ne 0){throw 'Owned fixture creation failed'};$created=$true
 $ready=$false
 for($i=0;$i -lt 40;$i++) { & $docker --host $daemon exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250 }
 if(-not $ready){throw 'Owned fixture not ready'}
 $ports=& $docker --host $daemon inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
 if($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1'){throw 'Fixture must stay loopback only'}
 $port=$ports.'5432/tcp'[0].HostPort
 Get-Content -LiteralPath $schema -Raw | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
 if($LASTEXITCODE -ne 0){throw 'Exact current schema restore failed'}
 "CREATE ROLE $app LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '<REDACTED>'; GRANT USAGE ON SCHEMA public TO $app; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $app;" | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restricted-role.log')
 if($LASTEXITCODE -ne 0){throw 'Restricted role grant failed'}
 $schoolA=[guid]::NewGuid().ToString();$schoolB=[guid]::NewGuid().ToString();$studentA=[guid]::NewGuid().ToString()
 $storage=Get-Content src/services/storage.ts -Raw
 $joinedSql=[regex]::Match($storage,'execute<HeartbeatPersistenceContextRow>\(sql`([\s\S]+?)`\)').Groups[1].Value
 if(-not $joinedSql){throw 'Could not locate exact context query'}
 $joinedSql=$joinedSql.Replace('${studentId}','$1').Replace('${schoolId}','$2')
 if($joinedSql -match '\$\{'){throw 'Unresolved query parameter'}
 $joinedSql | Set-Content -LiteralPath (Join-Path $out 'joined-query.sql') -Encoding utf8
 $planSql=@"
 BEGIN;
 SET LOCAL app.is_super='on';
 INSERT INTO schools(id,name,domain) VALUES('$schoolA','Plan A','a.example.invalid'),('$schoolB','Plan B','b.example.invalid');
 INSERT INTO settings(school_id,school_name,ws_shared_key) VALUES('$schoolA','Plan A','synthetic'),('$schoolB','Plan B','synthetic');
 INSERT INTO students(id,school_id,first_name,last_name,status) VALUES('$studentA','$schoolA','Target','Student','active');
 INSERT INTO students(id,school_id,first_name,last_name,status) SELECT gen_random_uuid(),school_id,'Plan','Student','active' FROM (VALUES('$schoolA'),('$schoolB')) s(school_id) CROSS JOIN generate_series(1,1000);
 INSERT INTO classpilot_student_control_states(school_id,student_id,revision,desired_state) SELECT school_id,id,3,'{"screenLocked":true}'::jsonb FROM students WHERE school_id IN('$schoolA','$schoolB');
 ANALYZE schools; ANALYZE settings; ANALYZE classpilot_student_control_states;
 SET LOCAL app.is_super='off'; SET LOCAL app.school_id='$schoolA';
 PREPARE joined_context(text,text) AS $joinedSql;
 \o /tmp/heartbeat-owner-plan.json
 EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE joined_context('$studentA','$schoolA');
 \o
 SET LOCAL ROLE $app;
 \o /tmp/heartbeat-restricted-plan.json
 EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE joined_context('$studentA','$schoolA');
 \o
 ROLLBACK;
"@
 $planSql | & $docker --host $daemon exec -i $container psql -q -A -t -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'explain-run.log')
 if($LASTEXITCODE -ne 0){throw 'Point-read EXPLAIN failed'}
 foreach($role in @('owner','restricted')) {
  & $docker --host $daemon cp "${container}:/tmp/heartbeat-$role-plan.json" (Join-Path $out "$role-plan.json") *> $null
  if($LASTEXITCODE -ne 0){throw 'Point-read plan copy failed'}
  $plan=Get-Content -LiteralPath (Join-Path $out "$role-plan.json") -Raw | ConvertFrom-Json
  if($plan[0].Plan.'Actual Rows' -ne 1){throw 'Point-read plan did not return exact one row'}
 }
 Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-after.json') -Encoding utf8
 [ordered]@{source=(git rev-parse HEAD).Trim();worktreeDirty=$true;container=$container;database=$database;schemaSource='Combined04 post-convergence';schemaRawSha256=(Get-FileHash -LiteralPath $schema -Algorithm SHA256).Hash.ToLower();studentCount=2001;schoolCount=2;controlRowCount=2001;explain='ANALYZE,BUFFERS,FORMAT JSON';query='exact new helper SQL with only literal placeholders converted to prepared parameters';productionMutations=0;roles=@('owner','restricted nonowner');capacityClaimed=$false;fixtureTransactionRolledBack=$true;sharedModulesUsed=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
 $ownerExit=0;$restrictedExit=0
 Write-Output ([ordered]@{evidence=$out;ownerExecutionMs=(Get-Content (Join-Path $out 'owner-plan.json') -Raw|ConvertFrom-Json)[0].'Execution Time';restrictedExecutionMs=(Get-Content (Join-Path $out 'restricted-plan.json') -Raw|ConvertFrom-Json)[0].'Execution Time'}|ConvertTo-Json -Compress)
} finally {
 if($created){$labels=& $docker --host $daemon inspect $container --format '{{json .Config.Labels}}'|ConvertFrom-Json;if($container -cne ('schoolpilot-heartbeat-context-'+$run) -or $labels.'codex.heartbeat-context' -cne $run){throw 'Ownership mismatch'};& $docker --host $daemon rm -f $container *> (Join-Path $out 'cleanup.log');if($LASTEXITCODE -ne 0){throw 'Cleanup failed'}}
}
if($ownerExit -ne 0 -or $restrictedExit -ne 0){exit 1}

