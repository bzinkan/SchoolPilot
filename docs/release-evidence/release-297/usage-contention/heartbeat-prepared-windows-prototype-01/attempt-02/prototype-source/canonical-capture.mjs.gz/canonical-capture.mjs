import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
const repo='<TEMP>/release297-role-0e427-unprofiled-host-01';
const out=path.join(process.env.TEMP,'release297-owned-pg-native-prototype-01');

const require=createRequire(path.join(repo,'package.json')),ts=require('typescript');
const moduleUrl=relative=>pathToFileURL(path.join(repo,relative)).href;
const orm=await import(moduleUrl('node_modules/drizzle-orm/index.js'));
const core=await import(moduleUrl('node_modules/drizzle-orm/pg-core/index.js'));
const {drizzle}=await import(moduleUrl('node_modules/drizzle-orm/node-postgres/index.js'));
const schema=await import(moduleUrl('dist/schema/index.js'));
const {currentStudentSessionAuthorityPredicate}=await import(moduleUrl('dist/services/classpilotStudentSessionAuthority.js'));
const helperPath=path.join(out,'fixedScalarQuery-source.ts');
const helperSource=fs.readFileSync(helperPath,'utf8');
const helperJs=ts.transpileModule(helperSource,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText
 .replaceAll('from "drizzle-orm"','from '+JSON.stringify(moduleUrl('node_modules/drizzle-orm/index.js')))
 .replaceAll('from "drizzle-orm/pg-core"','from '+JSON.stringify(moduleUrl('node_modules/drizzle-orm/pg-core/index.js')));
if (fs.existsSync(path.join(out,'fixedScalarQuery.mjs'))) assert.equal(fs.readFileSync(path.join(out,'fixedScalarQuery.mjs'),'utf8'),helperJs);
else fs.writeFileSync(path.join(out,'fixedScalarQuery.mjs'),helperJs,{flag:'wx'});
const {compileFixedScalarQuery}=await import(pathToFileURL(path.join(out,'fixedScalarQuery.mjs')).href);
const storage=fs.readFileSync(path.join(repo,'src/services/storage.ts'),'utf8');
const entitlement=fs.readFileSync(path.join(repo,'src/services/classpilotEntitlement.ts'),'utf8');
const screenshot=storage.slice(storage.indexOf('export async function getClasspilotScreenshotAuthorityProjection('),storage.indexOf('function classpilotScreenshotAuthorityMatches('));
const ent=entitlement.slice(entitlement.indexOf('export async function resolveClasspilotEntitlement('),entitlement.indexOf('export async function assertClasspilotEntitled('));
function initializer(source,name,occurrence=0){
 const tree=ts.createSourceFile('capture.ts',source,ts.ScriptTarget.Latest,true);const found=[];
 const visit=node=>{if(ts.isVariableDeclaration(node)&&node.name.getText(tree)===name&&node.initializer)found.push(node.initializer);ts.forEachChild(node,visit);};visit(tree);
 assert.ok(found[occurrence],name);let expression=found[occurrence];if(ts.isAwaitExpression(expression))expression=expression.expression;return expression.getText(tree);
}
const bindings={...orm,...schema,currentStudentSessionAuthorityPredicate,LIVE_TEACHING_SESSION_MODE:'live'};
function capture(expression){
 const plain=ts.transpileModule('const query = '+expression+';',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const capturedNames=Object.keys(bindings),capturedValues=Object.values(bindings);
 const run=new Function(...capturedNames,'dbInstance','options','schoolId','controlState',plain+';return query;');
 return (db,values)=>run(...capturedValues,db,values,values.schoolId,{teachingSessionId:values.teachingSessionId});
}
const builders={
 screenshot_session:capture(initializer(screenshot,'[session]')),
 screenshot_control:capture(initializer(screenshot,'[controlState]')),
 screenshot_candidate:capture(initializer(screenshot,'[candidate]')),
 locked_school:capture(initializer(ent,'schoolQuery')+'.for("share")'),
 locked_license:capture(initializer(ent,'licenseQuery')+'.for("share")'),
 unlocked_entitlement:capture(initializer(ent,'[school]',0)),
};
const {studentSessions:ss,classpilotStudentControlStates:control,teachingSessions:teaching,schools,productLicenses}=schema;
const fields={
 screenshot_session:{id:ss.id,startedAt:ss.startedAt,authKind:ss.authKind,manualLeaseExpiresAt:ss.manualLeaseExpiresAt},
 screenshot_control:{teachingSessionId:control.teachingSessionId,supervisionContextId:control.supervisionContextId,revision:control.revision,scheduledEndAt:control.scheduledEndAt,hardExpiresAt:control.hardExpiresAt,updatedAt:control.updatedAt},
 screenshot_candidate:{teachingSessionId:teaching.id,startTime:teaching.startTime,rosterSnapshotCompletedAt:teaching.rosterSnapshotCompletedAt,teachingScheduledEndAt:teaching.scheduledEndAt,controlRevision:control.revision,controlUpdatedAt:control.updatedAt,controlScheduledEndAt:control.scheduledEndAt,controlHardExpiresAt:control.hardExpiresAt},
 locked_school:{id:schools.id,status:schools.status,isActive:schools.isActive,planStatus:schools.planStatus,activeUntil:schools.activeUntil,disabledAt:schools.disabledAt,deletedAt:schools.deletedAt},
 locked_license:{id:productLicenses.id},
 unlocked_entitlement:{status:schools.status,isActive:schools.isActive,planStatus:schools.planStatus,activeUntil:schools.activeUntil,disabledAt:schools.disabledAt,deletedAt:schools.deletedAt,licensed:null},
};
const dialect=new core.PgDialect();
const placeholders=Object.fromEntries(['schoolId','studentId','studentSessionId','deviceId','teachingSessionId'].map(key=>[key,orm.sql.placeholder(key)]));
const factories={},templates={},fieldSpecs={},directTemplates={};
function functionText(source,name){ const tree=ts.createSourceFile('capture.ts',source,ts.ScriptTarget.Latest,true); let result; const visit=node=>{ if(ts.isFunctionDeclaration(node)&&node.name?.text===name)result=node.getText(tree); ts.forEachChild(node,visit); };visit(tree);assert.ok(result,name);return result; }
function tagged(source, predicate=()=>true){ const tree=ts.createSourceFile('capture.ts',source,ts.ScriptTarget.Latest,true);let result;const visit=node=>{if(result)return;if(ts.isTaggedTemplateExpression(node)&&node.tag.getText(tree)==='sql'&&predicate(node.getText(tree))){result=node.getText(tree);return;}ts.forEachChild(node,visit);};visit(tree);assert.ok(result);return result; }
function makeCanonicalFunction(source,name){const js=ts.transpileModule(functionText(source,name).replace('export function','function'),{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText; return new Function(...Object.keys(bindings),js+';return '+name)(...Object.values(bindings));}
bindings.classpilotEntitledSchoolPredicate=makeCanonicalFunction(entitlement,'classpilotEntitledSchoolPredicate');
bindings.classpilotAuthorityClockSql=makeCanonicalFunction(storage,'classpilotAuthorityClockSql');
const liveSource=functionText(storage,'hasExactClasspilotTelemetryBinding');
const foregroundSource=functionText(storage,'withClasspilotHeartbeatDeliveryAuthority');
const ownerSource=functionText(storage,'getClasspilotTelemetryOwnerProjectionAtClock');
const liveSql=tagged(liveSource,t=>t.includes('SELECT "student_sessions"."id"'));
const finalSql=tagged(functionText(storage,'assertClasspilotHeartbeatDeliveryCurrent'));
const foregroundSql=tagged(foregroundSource,t=>t.includes('SELECT 1 AS allowed'));
const ownerSql=tagged(ownerSource);
function rawBuilder(template,prelude=''){const js=ts.transpileModule(prelude+';const result='+template+';',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;const run=new Function(...Object.keys(bindings),'options','foreground','schoolId','studentId','clock',js+'return result;');return values=>run(...Object.values(bindings),values,values,values.schoolId,values.studentId,values.clock);}
const rawBuilders={live_binding:rawBuilder(liveSql,'const bindingConditions=[eq(studentSessions.id, options.studentSessionId), eq(studentSessions.studentId, options.studentId), eq(studentSessions.deviceId, options.deviceId),currentStudentSessionAuthorityPredicate()]'),final_fence:rawBuilder(finalSql),foreground_fence:rawBuilder(foregroundSql),owner_transaction:rawBuilder(ownerSql),owner_current:rawBuilder(ownerSql)};

for(const [label,build] of Object.entries(builders)){
 const specs=Object.entries(fields[label]).map(([property,column],index)=>Object.freeze({property,alias:'__fixed_'+index,
   decode:column?value=>column.mapFromDriverValue(value):value=>value}));
 Object.freeze(specs);fieldSpecs[label]=specs;
 const sqlOnly={select(selection){
  assert.deepEqual(Object.keys(selection),Object.keys(fields[label]));
  for(const [name,column] of Object.entries(fields[label]))if(column)assert.equal(selection[name],column);
  const aliased=Object.fromEntries(specs.map(spec=>[spec.property,orm.sql`${selection[spec.property]}`.as(spec.alias)]));
  return new core.QueryBuilder().select(aliased);
 }};
 const query=build(sqlOnly,placeholders);
 const bind=compileFixedScalarQuery(query.getSQL());
 const decode=rows=>rows.map(row=>Object.fromEntries(specs.map(spec=>{
   assert.ok(Object.hasOwn(row,spec.alias),'fixed projection alias missing');const value=row[spec.alias];
   return [spec.property,value===null?null:spec.decode(value)];
 })));
 factories[label]={bind,decode};templates[label]=query.toSQL().sql;directTemplates[label]=dialect.sqlToQuery(query.getSQL());
}
for(const [label,raw] of Object.entries(rawBuilders)){
 const clock=label==='owner_current'?'current':'transaction';
 const placeholderValues={...placeholders,controlRevision:orm.sql.placeholder('controlRevision'),clock};
 const template=raw(placeholderValues);factories[label]={bind:compileFixedScalarQuery(template),decode:rows=>rows};templates[label]=dialect.sqlToQuery(template).sql;directTemplates[label]=dialect.sqlToQuery(template);fieldSpecs[label]=[];fields[label]={};
 builders[label]=(db,values)=>({toSQL:()=>dialect.sqlToQuery(raw({...values,clock})),execute:()=>db.execute(raw({...values,clock}))});
}

export { builders, rawBuilders, factories, templates, directTemplates, fieldSpecs, fields, schema, orm, core, drizzle, dialect, placeholders, repo };
