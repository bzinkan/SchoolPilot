#requires -Version 7.5
$ErrorActionPreference='Stop'
$docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe'
$endpoint='npipe:////./pipe/dockerDesktopLinuxEngine'
foreach($key in @('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH')){[Environment]::SetEnvironmentVariable($key,$null,'Process')}
$repo='<TEMP>/release297-role-0e427-unprofiled-host-01'
$prototype='<TEMP>/release297-owned-pg-native-prototype-01'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$out=Join-Path $env:TEMP ('release297-owned-pg-native-'+$run)
New-Item -ItemType Directory -Path $out|Out-Null
$name='schoolpilot-owned-pg-'+$run;$database='owned_pg_'+$run;$owner='owner_'+$run;$role='app_'+$run
$password=[guid]::NewGuid().ToString('N');$rolePassword=[guid]::NewGuid().ToString('N')
$image=(& $docker --host $endpoint inspect schoolpilot-db --format '{{.Image}}').Trim()
if($LASTEXITCODE -ne 0 -or $image -cnotmatch '^sha256:[a-f0-9]{64}$'){throw 'Local PG image binding failed'}
$owned=$false;$containerId=$null;$code=1
$bindings=@('src/services/storage.ts','src/services/classpilotEntitlement.ts','src/middleware/tenantContext.ts','dist/services/storage.js','dist/services/classpilotEntitlement.js','dist/middleware/tenantContext.js','dist/services/classpilotStudentSessionAuthority.js','node_modules/drizzle-orm/package.json')
function Snapshot { @($bindings|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $repo $_) -Algorithm SHA256).Hash.ToLower()}}) }
$before=Snapshot
$before|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $out 'source-before.json') -Encoding utf8
try{
 Copy-Item -LiteralPath '<TEMP>/release297-role-ingest-unprofiled-0e427-01/post-convergence-schema.sql' -Destination (Join-Path $out 'schema.sql')
 & $docker --host $endpoint run --detach --name $name --label "codex.owned-pg=$run" --cpus 4 --memory 4g --memory-swap 4g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'create.log')
 $createExit=$LASTEXITCODE
 $inspect=& $docker --host $endpoint inspect $name 2>$null|ConvertFrom-Json
 if($LASTEXITCODE -eq 0 -and $inspect.Count -eq 1 -and $inspect[0].Config.Labels.'codex.owned-pg' -ceq $run -and $inspect[0].Image -ceq $image -and $inspect[0].Name -ceq ('/'+$name)){$owned=$true;$containerId=$inspect[0].Id}
 if($createExit -ne 0 -or -not $owned){throw 'Owned fixture creation failed'}
 $ready=$false
 for($i=0;$i -lt 40;$i++){& $docker --host $endpoint exec $containerId pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250}
 if(-not $ready){throw 'Owned fixture readiness failed'}
 $inspect=& $docker --host $endpoint inspect $containerId|ConvertFrom-Json
 $port=$inspect[0].NetworkSettings.Ports.'5432/tcp'[0];if($port.HostIp -cne '127.0.0.1'){throw 'Non-local fixture port refused'}
 Get-Content -LiteralPath (Join-Path $out 'schema.sql') -Raw|& $docker --host $endpoint exec -i $containerId psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
 if($LASTEXITCODE -ne 0){throw 'Owned schema restore failed'}
 "CREATE ROLE $role LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$rolePassword'; GRANT USAGE ON SCHEMA public TO $role; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $role; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $role;"|& $docker --host $endpoint exec -i $containerId psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'role.log')
 if($LASTEXITCODE -ne 0){throw 'Restricted role grants failed'}
 $env:DATABASE_URL="<REDACTED_LOCAL_URL>"
 $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL;$env:ADMIN_DATABASE_URL="<REDACTED_LOCAL_URL>"
 $env:JWT_SECRET=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
 $env:NODE_ENV='test';$env:REDIS_URL='';$env:SCHEDULER_ENABLED='false';$env:RLS_GUC_ENABLED='true';$env:DOTENV_CONFIG_PATH=Join-Path $out 'absent.env';$env:DOTENV_CONFIG_QUIET='true'
 $registry=Get-Content -LiteralPath (Join-Path $repo 'src/config/rlsRegistry.json') -Raw|ConvertFrom-Json
 $env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
 $env:OWNED_EXECUTOR_RESULT=Join-Path $out 'native-result.json'
 Push-Location -LiteralPath $repo
 try{node 'scripts/load/usage/bounded-fixture-step.mjs' 240000 (Join-Path $prototype 'native-proof.mjs') *> (Join-Path $out 'native.log');$code=$LASTEXITCODE}finally{Pop-Location}
}finally{
 $after=Snapshot;$after|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $out 'source-after.json') -Encoding utf8
 $unchanged=($before|ConvertTo-Json -Compress) -ceq ($after|ConvertTo-Json -Compress)
 $clean=$false
 if($owned){$final=& $docker --host $endpoint inspect $containerId|ConvertFrom-Json;if($LASTEXITCODE -ne 0 -or $final[0].Id -cne $containerId -or $final[0].Name -cne ('/'+$name) -or $final[0].Config.Labels.'codex.owned-pg' -cne $run -or $final[0].Image -cne $image){throw 'Exact cleanup ownership mismatch'};& $docker --host $endpoint rm -f $containerId *> (Join-Path $out 'cleanup.log');$removeExit=$LASTEXITCODE;& $docker --host $endpoint inspect $containerId *> $null;$clean=$removeExit -eq 0 -and $LASTEXITCODE -ne 0}
 [ordered]@{schemaVersion=1;run=$run;containerId=$containerId;image=$image;source='0e427e3ca9b82125e0bb8692176accad21f4f699';sourceUnchanged=$unchanged;testExit=$code;cleanupPassed=$clean;restrictedRole=$true;capacityAccepted=$false;productionMutations=0;postgresCpu=4;postgresMemoryBytes=4294967296;statementTimeoutUnchanged=$true}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
 Write-Output ([ordered]@{out=$out;testExit=$code;cleanupPassed=$clean;sourceUnchanged=$unchanged}|ConvertTo-Json -Compress)
}
exit $code
