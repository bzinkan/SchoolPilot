import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.argv[2];
const json=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8').replace(/^\uFEFF/,''));
const hash=async p=>{const h=createHash('sha256');for await(const c of fs.createReadStream(p))h.update(c);return h.digest('hex')};
const archive=path.join(root,'image.tar');
const tarJson=p=>JSON.parse(execFileSync('tar',['-xOf',archive,p],{encoding:'utf8',maxBuffer:4*1024*1024}));
const blob=d=>'blobs/sha256/'+d.replace(/^sha256:/,'');
const preparation=json('preparation.json');
assert.equal(preparation.failure,null);for(const x of ['buildExit','saveExit','scanExit','gateExit'])assert.equal(preparation[x],0);
const inspect=json('image-inspect.json')[0];
const index=tarJson('index.json');const indexDigest=index.manifests[0].digest;
const indexed=tarJson(blob(indexDigest));
const platform=indexed.manifests.find(x=>x.platform?.os==='linux'&&x.platform?.architecture==='amd64');assert.ok(platform);
const platformManifest=tarJson(blob(platform.digest));
assert.equal(inspect.Id,indexDigest);assert.equal(inspect.Config.Labels['org.opencontainers.image.revision'],preparation.sourceCommit);
assert.equal(inspect.Os,'linux');assert.equal(inspect.Architecture,'amd64');
const all=json('trivy-all.json'),gate=json('trivy-gate.json');
const counts={UNKNOWN:0,LOW:0,MEDIUM:0,HIGH:0,CRITICAL:0};
for(const r of all.Results??[])for(const v of r.Vulnerabilities??[])counts[v.Severity]=(counts[v.Severity]??0)+1;
const gateFindings=(gate.Results??[]).flatMap(r=>r.Vulnerabilities??[]).length;assert.equal(gateFindings,0);
const compatibility=json('embedded-compatibility.json');assert.equal(compatibility.passed,true);
const database=json('trivy-cache/db/metadata.json');fs.writeFileSync(path.join(root,'trivy-database-metadata.json'),JSON.stringify(database,null,2)+'\n');
const sourceCommit=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();assert.equal(sourceCommit,preparation.sourceCommit);
const sourceStatus=execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim();assert.equal(sourceStatus,'');
const buildSourceTrees={};for(const p of ['src','docs/soc2'])buildSourceTrees[p]=execFileSync('git',['rev-parse',sourceCommit+':'+p],{encoding:'utf8'}).trim();
const files=[];
for(const name of fs.readdirSync(root).sort()){const p=path.join(root,name);if(!fs.statSync(p).isFile()||name==='manifest.json')continue;files.push({file:name,bytes:fs.statSync(p).size,sha256:await hash(p)});}
const manifest={schemaVersion:1,recordedAt:new Date().toISOString(),status:'local_compatible_rollback_ed5599de_prepared',sourceCommit,sourceStatus:'clean',buildSourceTrees,dockerEngine:preparation.dockerEngine,image:{localTag:preparation.localTag,indexDigest,platformManifestDigest:platform.digest,configDigest:platformManifest.config.digest,localRepoDigests:inspect.RepoDigests??[],platform:'linux/amd64',revisionLabel:inspect.Config.Labels['org.opencontainers.image.revision'],apiCommand:['node','dist/index.js'],workerCommand:['node','dist/worker.js'],archive:'image.tar',archiveSha256:files.find(x=>x.file==='image.tar').sha256,registryPublished:false,productionDigestBindingVerified:false},scan:{scannerImage:preparation.scannerImage,gate:'Fixed HIGH/CRITICAL findings fail: --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1',allSeverityCounts:counts,gateFindings,gatePassed:true,databaseMetadata:database},compatibility,preparation,commands:{buildExportScan:'prepare-rollback.ps1',embeddedCheck:'docker --host npipe:////./pipe/dockerDesktopLinuxEngine run --rm --network none --read-only --mount type=bind,source=<artifact-directory>,target=/evidence,readonly --entrypoint node <image-index-digest> /evidence/inspect-compatibility.mjs',manifest:'node write-manifest.mjs <artifact-directory>'},limitations:['Local build/export/scanning and embedded-marker checks only. No API/worker process, migration or database connection was started by this artifact preparation.','Same image supports API default command and worker command override; no cloud task was registered or started.','Source-bound CI, migration/recovery rehearsal, capacity acceptance, production refresh and deployment authorization are separate gates.','Registry publication and live serving/rollback task-definition bindings are not established.'],files};
manifest.productionDependencyPatch={scope:'Six production dependency entries retained from351422d7; later changes are the separately reviewed Stop Focus and classification-barrier correctness backports',versions:compatibility.dependencyVersions}; manifest.usage={rollupMode:'off',digitalUsageMode:'off',reason:'Predates Usage contention correction; both modes must remain off.'}; manifest.syntheticReleaseFloor=json('synthetic-release-floor-proof.json'); assert.equal(manifest.syntheticReleaseFloor.passed,true); manifest.supersedesSource='351422d75a1aefd428e79d0c0d290b2171776f2e'; manifest.ssoCorrection='Narrow bootstrap SSO/shared settings lock ordering backport'; manifest.stopFocusCorrection='Exact V2 cleanup binding preserved when gates/capabilities are off'; manifest.classificationCorrection='Historical producer registered before optional telemetry, current effects wait for foreground completion'; manifest.monitoringCorrection='Fresh matching non-super monitoring authority read reuses only actively owned exact ALS lease'; fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({manifest:path.join(root,'manifest.json'),manifestSha256:await hash(path.join(root,'manifest.json')),image:manifest.image,scan:manifest.scan,sourceClean:true},null,2));




