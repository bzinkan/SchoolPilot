import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const hash=s=>createHash('sha256').update(s).digest('hex');
export function domainMapPrototype(original) {
 const domainStart=original.indexOf("    CASE WHEN observation.active_tab_url ~* '^https?://'");
 const domainEnd=original.indexOf('    END AS domain,',domainStart)+'    END AS domain,'.length;
 assert.ok(domainStart>0&&domainEnd>domainStart);
 const canonical=original.slice(domainStart,domainEnd);
 assert.equal(original.split(canonical).length,2);
 const marker='normalized AS (', join='  LEFT JOIN ai_decision ON ai_decision.heartbeat_id = observation.id';
 assert.equal(original.split(marker).length,2);assert.equal(original.split(join).length,2);
 // DISTINCT ON and the equality key use byte-exact C collation. The selected
 // original column keeps its original collation for the unchanged expression.
 // A null URL's canonical CASE returns ''; the equality join misses null and
 // COALESCE reproduces that result without a quadratic null-safe join.
 const map=`distinct_urls AS MATERIALIZED (\n  SELECT DISTINCT ON (active_tab_url COLLATE "C") active_tab_url\n  FROM deduplicated\n),\nurl_domains AS MATERIALIZED (\n  SELECT observation.active_tab_url,\n${canonical.slice(0,-1)}\n  FROM distinct_urls AS observation\n),\n`;
 const candidate=original.replace(canonical,"    COALESCE(url_domains.domain, '') AS domain,").replace(marker,map+marker).replace(join,join+'\n  LEFT JOIN url_domains ON url_domains.active_tab_url COLLATE "C" = observation.active_tab_url COLLATE "C"');
 const tail=',\ninserted AS (\n  INSERT INTO classpilot_usage_rollups (';
 const index=original.indexOf(tail);assert.ok(index>0);assert.equal(original.split(tail).length,2);
 const grains=sql=>{const i=sql.indexOf(tail);assert.ok(i>0);return sql.slice(0,i)+'\nSELECT $1::text AS school_id, $4::date AS usage_date, grains.* FROM grains';};
 return {original,candidate,originalGrains:grains(original),candidateGrains:grains(candidate),canonicalDomain:canonical,domainMapCtes:map,hashes:{original:hash(original),candidate:hash(candidate),originalGrains:hash(grains(original)),candidateGrains:hash(grains(candidate)),canonicalDomain:hash(canonical)},scope:'Only repeated domain projection moves into a per-student exact-URL map; all source rows, AI, ordering, windows, attribution, grouping and INSERT remain byte-identical.'};
}
