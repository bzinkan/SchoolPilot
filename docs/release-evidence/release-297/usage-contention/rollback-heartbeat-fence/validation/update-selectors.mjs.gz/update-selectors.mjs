import {readFileSync,writeFileSync} from 'node:fs';
const root='<user-home>/.codex/worktrees/release297-compatible-rollback/SchoolPilot/tests/';
for(const file of ['classpilot-control-lock-order-contract.test.ts','classpilot-sso-policy-delivery-contract.test.ts','classpilot-student-session-recovery-contract.test.ts']){
 const path=root+file, text=readFileSync(path,'utf8');
 const before='"export async function withClasspilotStudentControlDeliveryAuthority"';
 if(text.split(before).length!==2) throw new Error('selector count '+file);
 writeFileSync(path,text.replace(before,'"async function withClasspilotStudentControlDeliveryAuthorityCore"'));
}
for(const [file,before,after] of [
 ['classpilot-late-signin-contract.test.ts','/withClasspilotStudentControlDeliveryAuthority\\([\\s\\S]*getClasspilotStudentControlState\\([\\s\\S]*transactionDb[\\s\\S]*\\(_claimed, prepared\\) => \\{[\\s\\S]*return res\\.json','/withClasspilotHeartbeatDeliveryAuthority\\([\\s\\S]*getClasspilotStudentControlState\\([\\s\\S]*transactionDb[\\s\\S]*\\(_claimed, prepared\\) => \\{[\\s\\S]*return res\\.json'],
 ['classpilot-runtime-security-contract.test.ts','/withClasspilotStudentControlDeliveryAuthority\\([\\s\\S]*?buildStudentFabState','/withClasspilotHeartbeatDeliveryAuthority\\([\\s\\S]*?buildStudentFabState']]){
 const path=root+file, text=readFileSync(path,'utf8');
 if(text.split(before).length!==2) throw new Error('wrapper count '+file);
 writeFileSync(path,text.replace(before,after));
}
