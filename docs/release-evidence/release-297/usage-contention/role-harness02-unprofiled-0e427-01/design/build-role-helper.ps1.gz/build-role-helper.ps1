#requires -Version 7.5
param([Parameter(Mandatory=$true)][string]$Context,[Parameter(Mandatory=$true)][string]$OutputDirectory,[Parameter(Mandatory=$true)][string]$CandidateTag)
$ErrorActionPreference='Stop'
$docker=(Get-Command docker -CommandType Application | Select-Object -First 1).Source
$contextName=(& $docker context show).Trim()
if($LASTEXITCODE -ne 0){throw 'Docker context lookup failed.'}
$metadata=@(& $docker context inspect $contextName | ConvertFrom-Json)
if($LASTEXITCODE -ne 0 -or $metadata.Count -ne 1 -or $metadata[0].Name -cne $contextName){throw 'Docker context identity failed.'}
$endpoint=$metadata[0].Endpoints.docker.Host
if($endpoint -cnotmatch '^npipe:/{2,4}\./pipe/[a-zA-Z0-9_.-]+$' -and $endpoint -cnotmatch '^unix:///[^\s?#]+$'){throw 'Local Docker endpoint required.'}
node (Join-Path $PSScriptRoot 'build-role-helper.mjs') $docker $endpoint $Context $OutputDirectory $CandidateTag
if($LASTEXITCODE -ne 0){throw 'Role helper build/runtime proof failed; preserve all logs.'}
