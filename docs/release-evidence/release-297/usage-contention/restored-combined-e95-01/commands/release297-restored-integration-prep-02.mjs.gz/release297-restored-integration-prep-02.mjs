import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync,copyFileSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync,execFileSync} from 'node:child_process';
const main='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot';
const temp=process.env.TEMP,source='e95a2b56476b1225434c1b0f3907db46c9d84fe3';
const clone=join(temp,'release297-linux-e95-candidate-source-01');
const review=join(temp,'release297-restored-role-integration-review-02');
const driver=join(temp,'release297-restored-role-e95-driver-01');
const sha=x=>createHash('sha256').update(x).digest('hex');
const save=(name,x)=>writeFileSync(join(review,name),JSON.stringify(x,null,2)+'\n',{flag:'wx'});
for(const path of[review,driver]){assert.equal(existsSync(path),false);mkdirSync(path);}
const roleNames=readdirSync(join(main,'scripts/load/usage/roles')).sort();
const names=[...roleNames.map(n=>'scripts/load/usage/roles/'+n),'tests/private-load-usage-profiles.test.mjs'];
const inventory=Object.fromEntries(names.map(n=>[n,sha(readFileSync(join(main,n)))]));
save('source-before.json',inventory);
const result=spawnSync(process.execPath,['--test','tests/private-load-usage-profiles.test.mjs'],{cwd:main,encoding:'utf8',maxBuffer:8*1024**2,timeout:120000,windowsHide:true});
writeFileSync(join(review,'aggregate.log'),(result.stdout??'')+(result.stderr??''),{flag:'wx'});
const after=Object.fromEntries(names.map(n=>[n,sha(readFileSync(join(main,n)))]));save('source-after.json',after);assert.deepEqual(after,inventory);assert.equal(result.status,0);
const tap=result.stdout;const count=name=>Number(tap.match(new RegExp('^# '+name+' (\\d+)$','m'))?.[1]);
assert.equal(count('fail'),0);assert.equal(count('skipped'),0);
save('checks.json',{command:'node --test tests/private-load-usage-profiles.test.mjs',files:names.length,passed:count('pass'),failed:count('fail'),skipped:count('skipped'),sourceUnchanged:true,finishedAt:new Date().toISOString(),logSha256:sha(readFileSync(join(review,'aggregate.log'))),capacityAccepted:false});
const git=args=>execFileSync('git',['-C',clone,...args],{encoding:'utf8',windowsHide:true}).trim();assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'');
const canonical=git(['ls-files','-z','scripts/load/usage']).split('\0').filter(Boolean),copied={};
for(const name of canonical){const bytes=readFileSync(join(clone,name)),target=join(driver,name);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});copied[name]=sha(bytes);}
for(const name of roleNames){const relative='scripts/load/usage/roles/'+name,bytes=readFileSync(join(main,relative)),target=join(driver,relative);assert.equal(sha(bytes),inventory[relative]);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});copied[relative]=sha(bytes);}
for(const[name,hash]of Object.entries(copied))assert.equal(sha(readFileSync(join(driver,name))),hash);
assert.deepEqual(Object.fromEntries(names.map(n=>[n,sha(readFileSync(join(main,n)))])),inventory);
save('driver-manifest.json',{source,driver,files:copied,harnessFiles:names.length,canonicalSourceClean:true,capacityAccepted:false});
console.log(JSON.stringify({review,driver,passed:count('pass'),files:names.length,manifestSha256:sha(readFileSync(join(review,'driver-manifest.json')))}));
