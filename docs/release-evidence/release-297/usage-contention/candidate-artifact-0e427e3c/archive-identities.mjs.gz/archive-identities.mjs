import assert from 'node:assert/strict';
import {openSync,readSync,closeSync,fstatSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export function archiveIdentities(filename,imageId,configDigest){
  const fd=openSync(filename,'r'),size=fstatSync(fd).size;
  function entry(wanted){
    for(let position=0;position+512<=size;){
      const header=Buffer.alloc(512);assert.equal(readSync(fd,header,0,512,position),512);
      if(header.every(value=>value===0))break;
      const text=(start,length)=>header.subarray(start,start+length).toString('utf8').replace(/\0.*$/s,'');
      const raw=text(124,12).trim();assert.match(raw,/^[0-7]+$/);const length=Number.parseInt(raw,8);
      const prefix=text(345,155),name=(prefix?prefix+'/':'')+text(0,100);
      assert.ok(Number.isSafeInteger(length)&&length>=0&&position+512+length<=size);
      if(name===wanted){assert.ok(length>0&&length<=8*1024*1024);const bytes=Buffer.alloc(length);assert.equal(readSync(fd,bytes,0,length,position+512),length);return bytes;}
      position+=512+Math.ceil(length/512)*512;
    }
    throw Error('Required OCI archive metadata missing');
  }
  try{
    const root=JSON.parse(entry('index.json')),seen=new Map(),platforms=[];let visited=0;
    function visit(descriptor){
      assert.ok(++visited<=64);assert.match(descriptor.digest,/^sha256:[a-f0-9]{64}$/);
      if(seen.has(descriptor.digest))return;
      const bytes=entry('blobs/sha256/'+descriptor.digest.slice(7));assert.equal('sha256:'+sha(bytes),descriptor.digest);
      const value=JSON.parse(bytes);seen.set(descriptor.digest,{mediaType:descriptor.mediaType,value});
      if(Array.isArray(value.manifests)){for(const child of value.manifests)visit(child);}
      else if(value.config?.digest===configDigest)platforms.push(descriptor.digest);
    }
    assert.ok(Array.isArray(root.manifests));for(const descriptor of root.manifests)visit(descriptor);
    assert.equal(new Set(platforms).size,1,'Require exactly one executable platform manifest for scanned config');
    const local=seen.get(imageId);assert.ok(local||imageId===configDigest,'Saved archive does not contain immutable local image identity');
    return{imageId,imageIdKind:local?.value.manifests?'index':local?'platform-manifest':'config',
      indexDigest:local?.value.manifests?imageId:null,platformManifestDigest:platforms[0],configDigest,
      exportIndexSha256:sha(entry('index.json')),verifiedBlobDigests:[...seen.keys()]};
  }finally{closeSync(fd);}
}
