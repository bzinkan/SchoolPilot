#requires -Version 7.5

[CmdletBinding()]
param(
    [switch]$AtomicJsonRaceOnly,
    [switch]$FailureDiagnosticsOnly,
    [switch]$StartGateCasesOnly,
    [switch]$LiveHarnessLifecycleOnly,
    [switch]$LiveHarnessCasesOnly,
    [ValidateRange(1, 20)]
    [int]$FiveMinuteTelemetryRepeatCount = 1
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$testClock = [Diagnostics.Stopwatch]::StartNew()
$script:AssertionCount = 0
# GitHub's Windows runners can spend more than 15 seconds launching the
# short-lived PowerShell/AWS-mock children used by this suite. Keep one
# test-only startup bounds that match the existing slow-sample allowance.
$script:MonitorStartupDeadlineSeconds = 60
$script:MonitorCompletionWatchdogMilliseconds = 90000
# One supervised mock-AWS sweep can approach the startup bound above, and the
# start-gate barrier holds a second sweep behind the first. Every watchdog or
# staleness budget that spans supervised sweeps must cover both.
$script:SupervisedSampleBudgetSeconds = 2 * $script:MonitorStartupDeadlineSeconds
$previousRolloutTestSentinel = $env:SCHOOLPILOT_ROLLOUT_TEST_MODE
$env:SCHOOLPILOT_ROLLOUT_TEST_MODE = "I_UNDERSTAND_TEST_ONLY"

. (Join-Path $PSScriptRoot "helpers/owned-test-process.ps1")
$ownedTestProcesses = [ordered]@{}

function Assert-Condition {
    param([bool]$Condition, [string]$Message)
    $script:AssertionCount++
    if (-not $Condition) { throw $Message }
}

$script:LiveHarnessLeases = [ordered]@{}

function Start-OwnedLiveHarness {
    param(
        [Parameter(Mandatory = $true)][Collections.IDictionary]$Registry,
        [Parameter(Mandatory = $true)][ValidatePattern('^[a-z0-9-]+$')][string]$Name,
        [Parameter(Mandatory = $true)][string]$Directory
    )
    $resolvedDirectory = [IO.Path]::GetFullPath($Directory)
    $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $resolvedDirectory.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Live harness fixture must remain inside the owned temporary tree.' }
    if ($script:LiveHarnessLeases.Contains($Name)) { throw 'Live harness name is already owned.' }
    $fixtureScript = Join-Path $resolvedDirectory "$Name-live-harness.ps1"
    $readyPath = Join-Path $resolvedDirectory "$Name-harness-lifecycle.json"
    $releasePath = Join-Path $resolvedDirectory "$Name-harness-release.txt"
    foreach ($path in @($fixtureScript, $readyPath, $releasePath)) {
        if (Test-Path -LiteralPath $path) { throw 'Live harness fixture paths must be fresh.' }
    }
    $nonce = [Guid]::NewGuid().ToString('N')
    # Cover the existing fixture/monitor startup and completion budgets. This
    # ceiling only prevents an abandoned test child from living indefinitely.
    $maximumLifetimeSeconds = 2 * $script:MonitorStartupDeadlineSeconds + [math]::Ceiling($script:MonitorCompletionWatchdogMilliseconds / 1000)
    $childSource = @'
param([string]$ReadyPath, [string]$ReleasePath, [string]$Nonce, [int]$MaximumLifetimeSeconds)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$clock = [Diagnostics.Stopwatch]::StartNew()
$self = Get-Process -Id $PID
$ready = [ordered]@{ nonce=$Nonce; id=$PID; startedAtUtc=$self.StartTime.ToUniversalTime().ToString('o'); path=[IO.Path]::GetFullPath([string]$self.Path); maximumLifetimeSeconds=$MaximumLifetimeSeconds }
[IO.File]::WriteAllText("$ReadyPath.pending", ($ready | ConvertTo-Json -Compress), [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath "$ReadyPath.pending" -Destination $ReadyPath
while (-not (Test-Path -LiteralPath $ReleasePath)) {
    if ($clock.Elapsed.TotalSeconds -ge $MaximumLifetimeSeconds) { throw 'Owned live harness reached its test safety ceiling before release.' }
    Start-Sleep -Milliseconds 50
}
if ([IO.File]::ReadAllText($ReleasePath) -cne $Nonce) { throw 'Owned live harness release nonce does not match.' }
'@
    [IO.File]::WriteAllText($fixtureScript, $childSource, [Text.UTF8Encoding]::new($false))
    $lease = [pscustomobject]@{ name=$Name; nonce=$nonce; readyPath=$readyPath; releasePath=$releasePath; identity=$null }
    $script:LiveHarnessLeases.Add($Name, $lease)
    Start-OwnedTestProcess -Registry $Registry -Name $Name `
        -FilePath (Get-Process -Id $PID).Path `
        -ArgumentList @('-NoProfile','-File',$fixtureScript,'-ReadyPath',$readyPath,'-ReleasePath',$releasePath,'-Nonce',$nonce,'-MaximumLifetimeSeconds',[string]$maximumLifetimeSeconds) `
        -StandardOutputPath (Join-Path $resolvedDirectory "$Name.out") `
        -StandardErrorPath (Join-Path $resolvedDirectory "$Name.err")
    $lease.identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
    while (-not (Test-Path -LiteralPath $readyPath) -and [DateTimeOffset]::UtcNow -lt $deadline) {
        if ((Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name).hasExited) { break }
        Start-Sleep -Milliseconds 50
    }
    Assert-Condition (Test-Path -LiteralPath $readyPath) "Owned live harness '$Name' did not publish readiness."
    $ready = Get-Content -LiteralPath $readyPath -Raw | ConvertFrom-Json -DateKind String
    $identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    Assert-Condition (-not $identity.hasExited -and $ready.nonce -ceq $nonce -and $ready.id -eq $identity.id -and
        $ready.startedAtUtc -ceq $identity.startedAtUtc.ToUniversalTime().ToString('o') -and
        [string]::Equals($ready.path, [IO.Path]::GetFullPath($identity.path), [StringComparison]::OrdinalIgnoreCase)) `
        "Owned live harness '$Name' readiness must match its actual PID, start time, path and nonce."
    return $identity
}

function Release-OwnedLiveHarness {
    param([Collections.IDictionary]$Registry, [string]$Name)
    $lease = $script:LiveHarnessLeases[$Name]
    if ($null -eq $lease) { throw 'Live harness release has no owned lease.' }
    if (-not $Registry.Contains($Name)) { $script:LiveHarnessLeases.Remove($Name); return }
    $identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    if ($null -ne $lease.identity -and ($identity.id -ne $lease.identity.id -or
        $identity.startedAtUtc -ne $lease.identity.startedAtUtc -or
        -not [string]::Equals($identity.path, $lease.identity.path, [StringComparison]::OrdinalIgnoreCase))) {
        throw 'Live harness release identity changed.'
    }
    [IO.File]::WriteAllText($lease.releasePath, $lease.nonce, [Text.UTF8Encoding]::new($false))
}

function Complete-OwnedLiveHarness {
    param([Collections.IDictionary]$Registry, [string]$Name)
    Release-OwnedLiveHarness -Registry $Registry -Name $Name
    $result = Complete-OwnedTestProcess -Registry $Registry -Name $Name -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
    Assert-Condition ($result.exitCode -eq 0) "Owned live harness '$Name' must exit successfully after release."
    $script:LiveHarnessLeases.Remove($Name)
}

function Release-AllOwnedLiveHarnesses {
    param([Collections.IDictionary]$Registry)
    $failures = [Collections.Generic.List[Exception]]::new()
    foreach ($name in @($script:LiveHarnessLeases.Keys)) {
        try { Release-OwnedLiveHarness -Registry $Registry -Name $name }
        catch { $failures.Add($_.Exception) }
    }
    if ($failures.Count -gt 0) { throw [AggregateException]::new('Live harness release failed.', $failures.ToArray()) }
}

if ($LiveHarnessLifecycleOnly) {
    $fixtureRoot = Join-Path ([IO.Path]::GetTempPath()) ('rollout-live-harness-proof-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($fixtureRoot)
    try {
        $normal = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'normal-release' -Directory $fixtureRoot
        Start-Sleep -Milliseconds 300
        Assert-Condition (-not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name 'normal-release').hasExited) 'A ready harness must remain alive until its owner releases it.'
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'normal-release'
        Assert-Condition (-not $ownedTestProcesses.Contains('normal-release') -and -not $script:LiveHarnessLeases.Contains('normal-release')) 'Successful release must drain and forget only the owned child.'
        [void](Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'failed-case' -Directory $fixtureRoot)
        try { throw 'synthetic monitor case failure' }
        catch { Assert-Condition ($_.Exception.Message -ceq 'synthetic monitor case failure') 'Cleanup must retain the original case failure.' }
        finally {
            Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses
            Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses
            Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses
        }
        Assert-Condition ($ownedTestProcesses.Count -eq 0 -and $script:LiveHarnessLeases.Count -eq 0) 'Failed case cleanup must leave no owned process or lease.'
        Write-Host "Live harness lifecycle: PASS ($script:AssertionCount assertions)"
    }
    finally {
        try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses }
        finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses }
        $resolvedFixture = [IO.Path]::GetFullPath($fixtureRoot)
        $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if (-not $resolvedFixture.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected live harness proof cleanup path.' }
        Remove-Item -LiteralPath $resolvedFixture -Recurse -Force
        if ($null -ne $previousRolloutTestSentinel) { $env:SCHOOLPILOT_ROLLOUT_TEST_MODE=$previousRolloutTestSentinel } else { Remove-Item Env:SCHOOLPILOT_ROLLOUT_TEST_MODE -ErrorAction SilentlyContinue }
    }
    return
}

function Protect-MockDiagnosticText {
    param([AllowEmptyString()][string]$Text)
    $value = $Text -replace '\x1b\[[0-9;]*[A-Za-z]', ''
    $value = $value -replace '(?i)(?:postgres(?:ql)?|redis|https?)://[^\s"''<>]+', '<redacted-url>'
    $value = $value -replace '(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+', '$1<redacted>'
    $value = $value -replace '(?i)((?:password|secret|token|access[_-]?key|authorization)["'']?\s*[:=]\s*["'']?)[^\s,"''}]+', '$1<redacted>'
    return $value -replace '\b(?:AKIA|ASIA)[A-Z0-9]{16}\b', '<redacted-access-key>'
}

function Save-MockMonitorFailureEvidence {
    param([string]$FixtureRoot, [string]$OutputRoot, [string]$FailureMessage, [string[]]$SourcePaths)
    # Only mock monitor output is copied. Never copy configs, environment,
    # Terraform state, fixture secrets, or encrypted backup material.
    $destination = Join-Path $OutputRoot ('rollout-failure-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($destination)
    $files = @(Get-ChildItem -LiteralPath $FixtureRoot -Recurse -File -ErrorAction Stop |
        Where-Object { $_.Name -match '(?:-aws-monitor\.jsonl|-monitor-result\.json|-harness-lifecycle\.json|\.err)$' } |
        Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 12)
    $records = @()
    foreach ($file in $files) {
        $stream = [IO.File]::Open($file.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            $length = $stream.Length
            $count = [int][Math]::Min(16384, $length)
            [void]$stream.Seek(-$count, [IO.SeekOrigin]::End)
            $bytes = [byte[]]::new($count)
            $offset = 0
            while ($offset -lt $count) {
                $read = $stream.Read($bytes, $offset, $count - $offset)
                if ($read -eq 0) { break }
                $offset += $read
            }
        }
        finally { $stream.Dispose() }
        $records += [ordered]@{
            relativePath = [IO.Path]::GetRelativePath($FixtureRoot, $file.FullName)
            originalBytes = $length
            tailBytes = $offset
            truncated = $length -gt $offset
            text = Protect-MockDiagnosticText ([Text.Encoding]::UTF8.GetString($bytes, 0, $offset))
        }
    }
    $receipt = [ordered]@{
        schemaVersion = 1
        mockOnly = $true
        createdAt = [DateTimeOffset]::UtcNow.ToString('o')
        failure = Protect-MockDiagnosticText $FailureMessage.Substring(0, [Math]::Min(4096, $FailureMessage.Length))
        bounds = @{ maximumFiles = 12; maximumTailBytesPerFile = 16384 }
        sourceHashes = @($SourcePaths | ForEach-Object {
            [ordered]@{ name = [IO.Path]::GetFileName($_); sha256 = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant() }
        })
        files = $records
    }
    $path = Join-Path $destination 'mock-monitor-failure.json'
    [IO.File]::WriteAllText($path, ($receipt | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    return $path
}

if ($FailureDiagnosticsOnly) {
    $probeRoot = Join-Path ([IO.Path]::GetTempPath()) ('rollout-diagnostics-proof-' + [Guid]::NewGuid().ToString('N'))
    $probeFixture = Join-Path $probeRoot 'fixture'
    [void][IO.Directory]::CreateDirectory($probeFixture)
    try {
        [IO.File]::WriteAllText((Join-Path $probeFixture 'case-aws-monitor.jsonl'), '{"error":"The property could not be found.","token":"never-retain-token"}')
        [IO.File]::WriteAllText((Join-Path $probeFixture 'case-monitor-result.json'), '{"failures":["monitor_exception"]}')
        [IO.File]::WriteAllText((Join-Path $probeFixture 'case.err'), ('x' * 20000) + ' Bearer never-retain-bearer')
        [IO.File]::WriteAllText((Join-Path $probeFixture 'config.json'), 'never-copy-config-secret')
        $saved = Save-MockMonitorFailureEvidence -FixtureRoot $probeFixture -OutputRoot $probeRoot -FailureMessage 'original assertion' -SourcePaths @($PSCommandPath)
        $raw = Get-Content -LiteralPath $saved -Raw
        $proof = $raw | ConvertFrom-Json -DateKind String
        Assert-Condition ($proof.mockOnly -and $proof.files.Count -eq 3) 'Only selected mock result/sample/stderr files must be retained.'
        Assert-Condition ($raw -match 'property could not be found' -and $raw -match 'monitor_exception') 'Monitor exception details must survive.'
        Assert-Condition ($raw -notmatch 'never-retain|never-copy') 'Fixture credentials and configs must not be retained.'
        Assert-Condition (@($proof.files | Where-Object tailBytes -gt 16384).Count -eq 0 -and @($proof.files | Where-Object truncated).Count -eq 1) 'Evidence tails must remain bounded and report truncation.'
        Assert-Condition ($proof.sourceHashes[0].sha256 -ceq (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()) 'Evidence must bind the exact tested source.'
        Write-Host "Rollout failure diagnostics: PASS ($script:AssertionCount assertions)"
    }
    finally {
        $resolvedProbe = [IO.Path]::GetFullPath($probeRoot)
        $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if (-not $resolvedProbe.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected diagnostic proof cleanup path.' }
        Remove-Item -LiteralPath $resolvedProbe -Recurse -Force
        if ($null -ne $previousRolloutTestSentinel) { $env:SCHOOLPILOT_ROLLOUT_TEST_MODE = $previousRolloutTestSentinel } else { Remove-Item Env:SCHOOLPILOT_ROLLOUT_TEST_MODE -ErrorAction SilentlyContinue }
    }
    return
}

function Close-OwnedTestProcessForDiagnostics {
    param(
        [Parameter(Mandatory = $true)]
        [Collections.IDictionary]$Registry,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string]$StandardOutputPath,
        [Parameter(Mandatory = $true)]
        [string]$StandardErrorPath,
        [ValidateRange(1, 300000)]
        [int]$TimeoutMilliseconds = 10000
    )

    $state = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    $completion = $null
    $cleanupFailure = $null
    try {
        if ($state.hasExited) {
            $completion = Complete-OwnedTestProcess -Registry $Registry -Name $Name `
                -TimeoutMilliseconds $TimeoutMilliseconds
        }
        else {
            Stop-OwnedTestProcess -Registry $Registry -Name $Name
        }
    }
    catch {
        $cleanupFailure = $_.Exception
    }

    return [pscustomobject]@{
        state = $state
        completion = $completion
        cleanupFailure = $cleanupFailure
        standardOutput = Get-Content -LiteralPath $StandardOutputPath -Raw -ErrorAction SilentlyContinue
        standardError = Get-Content -LiteralPath $StandardErrorPath -Raw -ErrorAction SilentlyContinue
    }
}

function Remove-TestDirectoryWithRetry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [ValidateRange(1, 30000)]
        [int]$TimeoutMilliseconds = 10000
    )
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $lastFailureMessage = $null
    do {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $Path)) { return }
        }
        catch {
            $failure = $_.Exception
            $sharingFailure = $false
            while ($null -ne $failure) {
                if ($failure -is [IO.IOException] -or
                    $failure -is [UnauthorizedAccessException]) {
                    $sharingFailure = $true
                    break
                }
                $failure = $failure.InnerException
            }
            if (-not $sharingFailure) { throw }
            $lastFailureMessage = $_.Exception.Message
        }
        Start-Sleep -Milliseconds 100
    } while ($watch.ElapsedMilliseconds -lt $TimeoutMilliseconds)
    throw "Timed out removing test directory '$Path' after its owned processes were drained. Last failure: $lastFailureMessage"
}

function Get-AtomicJsonFunctionSource {
    param([string]$ScriptPath)
    $tokens = $null
    $errors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($ScriptPath, [ref]$tokens, [ref]$errors)
    Assert-Condition ($errors.Count -eq 0) "$ScriptPath must parse before atomic JSON stress extraction."
    $required = @("Get-AtomicJsonMutexName", "Invoke-WithAtomicJsonMutex", "Write-AtomicJson")
    $definitions = @($ast.FindAll({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in $required
    }, $true))
    foreach ($name in $required) {
        $matches = @($definitions | Where-Object Name -eq $name)
        Assert-Condition ($matches.Count -eq 1) "$ScriptPath must define exactly one $name function."
    }
    return ($required | ForEach-Object { @($definitions | Where-Object Name -eq $_)[0].Extent.Text }) -join [Environment]::NewLine
}

function Invoke-AtomicJsonRaceRegression {
    param([string[]]$ScriptPaths, [string]$Root)
    $iterations = 12
    $readerCount = 3
    foreach ($scriptPath in $ScriptPaths) {
        $caseName = [IO.Path]::GetFileNameWithoutExtension($scriptPath)
        $caseRoot = Join-Path $Root "atomic-json-$caseName"
        [void][IO.Directory]::CreateDirectory($caseRoot)
        $destination = Join-Path $caseRoot "heartbeat.json"
        $auditPath = Join-Path $caseRoot "writer-audit.txt"
        [IO.File]::WriteAllText($destination, '{"sequence":0}', [Text.UTF8Encoding]::new($false))

        $functionSource = Get-AtomicJsonFunctionSource -ScriptPath $scriptPath
        $writerTemplate = @'
param([string]$Path,[string]$CaseRoot,[string]$AuditPath,[int]$Iterations,[int]$ReaderCount)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
__FUNCTIONS__
for($iteration=1;$iteration -le $Iterations;$iteration++){
  for($reader=1;$reader -le $ReaderCount;$reader++){
    $ready=Join-Path $CaseRoot "ready-$reader-$iteration"
    $deadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
    while(-not [IO.File]::Exists($ready)){
      if([DateTimeOffset]::UtcNow -ge $deadline){throw "Reader $reader did not hold iteration $iteration."}
      Start-Sleep -Milliseconds 2
    }
  }
  Write-AtomicJson -Path $Path -Value ([ordered]@{sequence=$iteration;writerProcessId=$PID})
  [IO.File]::AppendAllText($AuditPath,"$iteration$([Environment]::NewLine)",[Text.UTF8Encoding]::new($false))
  for($reader=1;$reader -le $ReaderCount;$reader++){
    [IO.File]::WriteAllText((Join-Path $CaseRoot "ack-$reader-$iteration"),"ok",[Text.UTF8Encoding]::new($false))
  }
}
'@
        $writerSource = $writerTemplate.Replace("__FUNCTIONS__", $functionSource)
        $writerPath = Join-Path $caseRoot "writer.ps1"
        [IO.File]::WriteAllText($writerPath, $writerSource, [Text.UTF8Encoding]::new($false))
        $readerPath = Join-Path $caseRoot "reader.ps1"
        $readerSource = @'
param([string]$Path,[string]$CaseRoot,[int]$ReaderId,[int]$Iterations)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
for($iteration=1;$iteration -le $Iterations;$iteration++){
  $stream=$null
  $deadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
  while($null -eq $stream){
    try{$stream=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)}
    catch [IO.IOException]{
      if([DateTimeOffset]::UtcNow -ge $deadline){throw}
      Start-Sleep -Milliseconds 2
    }
  }
  try{
    $reader=[IO.StreamReader]::new($stream,[Text.UTF8Encoding]::new($false),$true,4096,$true)
    try{$record=$reader.ReadToEnd()|ConvertFrom-Json -Depth 10}
    finally{$reader.Dispose()}
    if($null -eq $record.sequence){throw "Observed incomplete JSON at iteration $iteration."}
    [IO.File]::WriteAllText((Join-Path $CaseRoot "ready-$ReaderId-$iteration"),"held",[Text.UTF8Encoding]::new($false))
    Start-Sleep -Milliseconds 100
  }
  finally{$stream.Dispose()}
  $ack=Join-Path $CaseRoot "ack-$ReaderId-$iteration"
  $deadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
  while(-not [IO.File]::Exists($ack)){
    if([DateTimeOffset]::UtcNow -ge $deadline){throw "Writer did not acknowledge iteration $iteration."}
    Start-Sleep -Milliseconds 2
  }
}
'@
        [IO.File]::WriteAllText($readerPath, $readerSource, [Text.UTF8Encoding]::new($false))

        $pwshPath = (Get-Process -Id $PID).Path
        $readerProcessNames = @()
        for ($readerId=1; $readerId -le $readerCount; $readerId++) {
            $readerProcessName = "atomic-json:$caseName`:reader:$readerId"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $readerProcessName `
                -FilePath $pwshPath `
                -ArgumentList @("-NoProfile","-File",$readerPath,$destination,$caseRoot,[string]$readerId,[string]$iterations) `
                -StandardOutputPath (Join-Path $caseRoot "reader-$readerId.out") `
                -StandardErrorPath (Join-Path $caseRoot "reader-$readerId.err")
            $readerProcessNames += $readerProcessName
        }
        $writerProcessName = "atomic-json:$caseName`:writer"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $writerProcessName `
            -FilePath $pwshPath `
            -ArgumentList @("-NoProfile","-File",$writerPath,$destination,$caseRoot,$auditPath,[string]$iterations,[string]$readerCount) `
            -StandardOutputPath (Join-Path $caseRoot "writer.out") `
            -StandardErrorPath (Join-Path $caseRoot "writer.err")
        $writerResult = Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $writerProcessName -TimeoutMilliseconds 60000
        $readerResults = @()
        foreach ($readerProcessName in $readerProcessNames) {
            $readerResults += Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $readerProcessName -TimeoutMilliseconds 60000
        }
        $writerError = Get-Content -LiteralPath (Join-Path $caseRoot "writer.err") -Raw -ErrorAction SilentlyContinue
        Assert-Condition ($writerResult.exitCode -eq 0) "$caseName atomic writer failed: $writerError"
        for ($readerIndex=0; $readerIndex -lt $readerResults.Count; $readerIndex++) {
            $readerError = Get-Content -LiteralPath (Join-Path $caseRoot "reader-$($readerIndex + 1).err") -Raw -ErrorAction SilentlyContinue
            Assert-Condition ($readerResults[$readerIndex].exitCode -eq 0) "$caseName concurrent atomic reader failed: $readerError"
        }
        $final = Get-Content -LiteralPath $destination -Raw | ConvertFrom-Json -Depth 10
        $audit = @(Get-Content -LiteralPath $auditPath)
        Assert-Condition ([int]$final.sequence -eq $iterations -and $audit.Count -eq $iterations -and [int]$audit[-1] -eq $iterations) "$caseName lost an atomic heartbeat overwrite under concurrent readers."
        Assert-Condition (@(Get-ChildItem -LiteralPath $caseRoot -Filter "*.tmp" -File).Count -eq 0) "$caseName left an atomic JSON temporary file behind."
    }
}

function Get-ArgumentValue {
    param([string[]]$Arguments, [string]$Name)
    $index = [Array]::IndexOf($Arguments, $Name)
    if ($index -lt 0 -or $index + 1 -ge $Arguments.Count) { return $null }
    return $Arguments[$index + 1]
}

$repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$monitorScript = Join-Path $repositoryRoot "scripts\load\aws-rollout-monitor.ps1"
$rollbackScript = Join-Path $repositoryRoot "scripts\load\aws-rollout-rollback.ps1"
$supervisorScript = Join-Path $repositoryRoot "scripts\load\start-aws-rollout-supervisor.ps1"
$albModule = Join-Path $repositoryRoot "infra\modules\alb\main.tf"
$rollbackScriptSource = Get-Content -LiteralPath $rollbackScript -Raw
Assert-Condition ($rollbackScriptSource -match '(?m)^\s*Application\s*=\s*3600\s*$') "Application rollback must retain the approved 3,600-second recovery deadline."
Assert-Condition ($rollbackScriptSource -notmatch 'services-stable') "Rollback automation must not use the fixed AWS ECS services-stable waiter."
Assert-Condition ($rollbackScriptSource -match 'singleton-one-replacement-slot') "Singleton API rollback must declare its bounded availability-preserving replacement mode."
Assert-Condition ($rollbackScriptSource -match [regex]::Escape(
        '$heartbeatStartupSeconds = if ($config.resolvedTestMode) { 60 } else { 10 }'
    )) "Rollback heartbeat startup must keep the 10-second production bound and use 60 seconds only in test mode."
Assert-Condition ((Get-Content -LiteralPath $albModule -Raw) -match '(?m)^\s*deregistration_delay\s*=\s*300\s*$') "The API target group must explicitly declare the current 300-second drain."

$monitorTokens = $null
$monitorParseErrors = $null
$monitorAst = [Management.Automation.Language.Parser]::ParseFile(
    $monitorScript, [ref]$monitorTokens, [ref]$monitorParseErrors
)
Assert-Condition ($monitorParseErrors.Count -eq 0) "The rollout monitor must parse before JSON-boundary regressions."
foreach ($functionName in @("Get-AtomicJsonMutexName", "Invoke-WithAtomicJsonMutex", "Read-AtomicJson")) {
    $definition = $monitorAst.Find({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName
    }, $true)
    Assert-Condition ($null -ne $definition) "The rollout monitor must define $functionName."
    Invoke-Expression $definition.Extent.Text
}
$monitorJsonBoundaryPath = Join-Path ([IO.Path]::GetTempPath()) "schoolpilot-monitor-datekind-$([Guid]::NewGuid().ToString('N')).json"
$topLevelFailure = $null
$topLevelCleanupFailures = [System.Collections.Generic.List[Exception]]::new()
try {
    [IO.File]::WriteAllText($monitorJsonBoundaryPath,
        '{"timestamp":"2026-07-22T15:58:03.1234567Z","nested":{"expiresAtUtc":"2026-07-22T15:58:03.7654321+00:00","operatorOffset":"2026-07-22T11:58:03.1111111-04:00"}}',
        [Text.UTF8Encoding]::new($false))
    $monitorJsonBoundary = Read-AtomicJson -Path $monitorJsonBoundaryPath -Depth 10
    Assert-Condition ($monitorJsonBoundary.timestamp -is [string] -and
        $monitorJsonBoundary.nested.expiresAtUtc -is [string] -and
        $monitorJsonBoundary.nested.operatorOffset -is [string] -and
        $monitorJsonBoundary.timestamp -ceq '2026-07-22T15:58:03.1234567Z' -and
        $monitorJsonBoundary.nested.expiresAtUtc -ceq '2026-07-22T15:58:03.7654321+00:00' -and
        $monitorJsonBoundary.nested.operatorOffset -ceq '2026-07-22T11:58:03.1111111-04:00') `
        "The rollout monitor atomic JSON boundary must preserve timestamp types, offsets, and seven-digit precision."
}
finally {
    Remove-Item -LiteralPath $monitorJsonBoundaryPath -Force -ErrorAction SilentlyContinue
}

foreach ($functionName in @(
        "Get-OptionalValue", "Get-ValidatedLoadSummaryTiming", "Get-BatchSeriesStatus",
        "Get-TelemetryAcceptanceWindow", "Add-SparseAcceptanceSourceCoverage",
        "Test-SparseAcceptanceCoverageReady"
    )) {
    $definition = $monitorAst.Find({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName
    }, $true)
    Assert-Condition ($null -ne $definition) "The rollout monitor must define $functionName."
    Invoke-Expression $definition.Extent.Text
}
$sparseCoverageQueryEnd = [DateTimeOffset]::Parse("2026-08-19T23:33:59Z")
$sparseCoverageSource = "waf_device_blocked"
$script:StartedAt = $sparseCoverageQueryEnd.AddSeconds(-9)
$script:TrafficStartedAtUtc = $null
$script:TrafficStoppedAtUtc = $null
$script:AcceptanceSourceStatuses = @{}
$script:AcceptanceSourceCoverage = @{}
$script:AcceptanceCoverageThroughUtc = $null
$script:AcceptanceSparseCoverageRequired =
    [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$sparseCoverageConfig = [pscustomobject]@{
    TestTelemetryWindow = $false
    LoadProgressPath = $null
    TelemetryExpectedSeconds = 0
}
$sparseCoverageBatch = [pscustomobject]@{
    Status = @{ $sparseCoverageSource = "Complete" }
    QueryStartUtc = $sparseCoverageQueryEnd.AddMinutes(-15)
    QueryEndUtc = $sparseCoverageQueryEnd
    # Simulate an AWS response returning after the next minute has started.
    CollectedThroughUtc = $sparseCoverageQueryEnd.AddSeconds(2)
}
Add-SparseAcceptanceSourceCoverage -MetricBatch $sparseCoverageBatch `
    -Config $sparseCoverageConfig -SourceName $sparseCoverageSource
Assert-Condition ($script:AcceptanceCoverageThroughUtc -eq $sparseCoverageQueryEnd -and
    $script:AcceptanceSourceCoverage[$sparseCoverageSource].Count -eq 1) `
    "Sparse telemetry coverage must stop at the exact CloudWatch query horizon when the response crosses a minute boundary."
Assert-Condition (Test-SparseAcceptanceCoverageReady -Config $sparseCoverageConfig) `
    "Sparse telemetry finalization must not expand beyond the last provider query when wall time advances."
$script:AcceptanceSourceCoverage[$sparseCoverageSource].Clear()
Assert-Condition (-not (Test-SparseAcceptanceCoverageReady -Config $sparseCoverageConfig)) `
    "Sparse telemetry readiness must still reject a genuinely missing covered minute."
$script:StartedAt = [DateTimeOffset]::UtcNow
$script:RequiredWorkloadSchemaVersion = "classpilot-tile-batch-v1"
$script:RequiredWorkloadEndpointShapeSha256 = "8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"
$script:RequiredPollAccountingVersion = "staggered-deadline-v1"
$engineeringSummaryNow = [DateTimeOffset]::UtcNow
$script:TrafficStartedAtUtc = $engineeringSummaryNow.AddSeconds(-1800)
$engineeringSummaryConfig = [pscustomobject]@{
    RunId = "engineering-summary-contract"
    TestMode = $true
    DiagnosticOnly = $false
    EngineeringAcceptance = $true
    Workload = [pscustomobject]@{
        Stage = "500"
        Devices = 510
        DurationSeconds = 1800
        ScreenshotBytes = 40960
        CanaryDevices = 10
        WorkloadSchemaVersion = $script:RequiredWorkloadSchemaVersion
        EndpointShapeSha256 = $script:RequiredWorkloadEndpointShapeSha256
    }
}
$engineeringSummary = [ordered]@{
    runId = $engineeringSummaryConfig.RunId
    stage = "500"
    diagnosticOnly = $false
    engineeringAcceptance = $true
    certificationEligible = $false
    devices = 510
    declaredSecondSchoolCanaryDevices = 10
    workloadSchemaVersion = $script:RequiredWorkloadSchemaVersion
    workloadEndpointShapeSha256 = $script:RequiredWorkloadEndpointShapeSha256
    run = [ordered]@{
        shutdownReason = "duration"
        durationClock = "monotonic-hrtime-v1"
        runtimeTargetTrafficSeconds = 1800
        plannedTrafficMilliseconds = 1800000
        actualTrafficMilliseconds = 1800000
        plannedTrafficSeconds = 1800
        actualTrafficSeconds = 1800
        completedConfiguredDuration = $true
    }
    screenshotFixture = [ordered]@{ decodedBytes = 40960 }
    screenshotRetrieval = [ordered]@{ attempts = 500; successes = 500 }
    tileBatch = [ordered]@{
        configured = $true
        pollAccountingVersion = $script:RequiredPollAccountingVersion
        teacherCohorts = 20
        studentsPerCohort = 25
        teacherTileAssignments = 500
        requestsPerCohortPerPoll = 2
        logicalOperationsPerPoll = 1000
        historyRequestsByCohort = @(1) * 20
        screenshotRequestsByCohort = @(1) * 20
        completeRoundsPerCohort = 1
        maximumRoundsPerCohort = 1
        partialFinalRoundCohorts = 0
        historyRequests = 20
        screenshotRequests = 20
        historyLogicalOperations = 500
        screenshotLogicalOperations = 500
        networkRequests = 40
        logicalOperations = 1000
    }
}
$engineeringProgress = [pscustomobject]@{
    event = [pscustomobject]@{ event = "final"; timestamp = $engineeringSummaryNow.ToString("o") }
    summary = [pscustomobject]$engineeringSummary
}
Assert-Condition ($null -ne (Get-ValidatedLoadSummaryTiming -Config $engineeringSummaryConfig -Progress $engineeringProgress)) `
    "Engineering acceptance must accept the exact monotonic Waf/500 summary with non-certifying identity markers."
$engineeringSummary["engineeringAcceptance"] = $false
$engineeringProgress.summary = [pscustomobject]$engineeringSummary
Assert-Condition ($null -eq (Get-ValidatedLoadSummaryTiming -Config $engineeringSummaryConfig -Progress $engineeringProgress)) `
    "Engineering acceptance must reject a summary missing its exact engineeringAcceptance=true identity."
$engineeringSummary["engineeringAcceptance"] = $true
$engineeringSummary["certificationEligible"] = $true
$engineeringProgress.summary = [pscustomobject]$engineeringSummary
Assert-Condition ($null -eq (Get-ValidatedLoadSummaryTiming -Config $engineeringSummaryConfig -Progress $engineeringProgress)) `
    "Engineering acceptance must reject any summary claiming certification eligibility."

$rollbackTokens = $null
$rollbackParseErrors = $null
$rollbackAst = [Management.Automation.Language.Parser]::ParseFile(
    $rollbackScript, [ref]$rollbackTokens, [ref]$rollbackParseErrors
)
Assert-Condition ($rollbackParseErrors.Count -eq 0) "The rollback controller must parse before JSON-clone regressions."
foreach ($functionName in @("ConvertTo-CanonicalValue", "Get-TaskCloneContractJson")) {
    $definition = $rollbackAst.Find({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName
    }, $true)
    Assert-Condition ($null -ne $definition) "The rollback controller must define $functionName."
    Invoke-Expression $definition.Extent.Text
}
$rollbackCloneSource = [pscustomobject]@{
    taskRoleArn = "arn:aws:iam::135775632425:role/task"
    executionRoleArn = "arn:aws:iam::135775632425:role/execution"
    networkMode = "awsvpc"
    containerDefinitions = @([pscustomobject]@{
        name = "api"
        memory = 2048
        image = "example.invalid/api@sha256:$('a' * 64)"
        environment = @(
            [pscustomobject]@{name="LEASE_EXPIRES_AT";value="2026-07-22T15:58:03.7654321+00:00"},
            [pscustomobject]@{name="OPERATOR_OFFSET";value="2026-07-22T11:58:03.1111111-04:00"}
        )
    })
}
$rollbackCloneContract = Get-TaskCloneContractJson -TaskDefinition $rollbackCloneSource -ApiContainerName "api" |
    ConvertFrom-Json -DateKind String -Depth 30
$rollbackCloneEnvironment = @($rollbackCloneContract.containerDefinitions[0].environment)
Assert-Condition ($rollbackCloneEnvironment[0].value -is [string] -and
    $rollbackCloneEnvironment[1].value -is [string] -and
    $rollbackCloneEnvironment[0].value -ceq '2026-07-22T15:58:03.7654321+00:00' -and
    $rollbackCloneEnvironment[1].value -ceq '2026-07-22T11:58:03.1111111-04:00') `
    "Rollback task-definition deep cloning must not coerce or rewrite timestamp-shaped environment values."

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("schoolpilot-rollout-test-" + [Guid]::NewGuid().ToString("N"))
$evidenceDirectory = Join-Path $tempRoot "evidence"
$global:SchoolPilotTestAwsCalls = [System.Collections.Generic.List[string]]::new()
$global:SchoolPilotTestTerraformCalls = [System.Collections.Generic.List[string]]::new()
$global:SchoolPilotTestWafUpdate = $null
$global:SchoolPilotTestNetworkPayloads = [System.Collections.Generic.List[object]]::new()
$global:SchoolPilotTestDeploymentPayloads = [System.Collections.Generic.List[object]]::new()
$global:SchoolPilotTestAutoscalingPayloads = [System.Collections.Generic.List[object]]::new()
$global:SchoolPilotTestTaskUpdateObservations = [System.Collections.Generic.List[object]]::new()
$global:SchoolPilotTestUpdateServiceCallCount = 0
$global:SchoolPilotTestFailUpdateServiceSelector = $null
$global:SchoolPilotTestForceUnstableService = ""
$global:SchoolPilotTestFailedDeploymentSelector = $null
$global:SchoolPilotTestTransientMixedDeploymentPolls = @{ api = 0; worker = 0 }
$global:SchoolPilotTestTargetDrainingPolls = 0
$global:SchoolPilotTestZeroHealthyTargetPolls = 0
$global:SchoolPilotTestInjectTargetDrainingPollsOnApiUpdate = 0
$global:SchoolPilotTestInjectZeroHealthyTargetPollsOnApiUpdate = 0
$global:SchoolPilotTestInjectDesiredDriftAfterApiPolicyApply = 0
$global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate = 0
$global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath = ""
$global:SchoolPilotTestTargetHealthCallCount = 0
$global:SchoolPilotTestDeregistrationDelaySeconds = 300
$global:SchoolPilotTestServiceState = @{
    api = [ordered]@{ taskDefinition = "api-current"; desired = 1; running = 1; pending = 0; subnets = @("subnet-public-a", "subnet-public-b"); securityGroups = @("sg-ecs"); assignPublicIp = "ENABLED"; deploymentConfiguration = [ordered]@{ deploymentCircuitBreaker = [ordered]@{ enable = $true; rollback = $true }; maximumPercent = 200; minimumHealthyPercent = 100; strategy = "ROLLING" } }
    worker = [ordered]@{ taskDefinition = "worker-current"; desired = 1; running = 1; pending = 0; subnets = @("subnet-public-a", "subnet-public-b"); securityGroups = @("sg-ecs"); assignPublicIp = "ENABLED"; deploymentConfiguration = [ordered]@{ deploymentCircuitBreaker = [ordered]@{ enable = $true; rollback = $true }; maximumPercent = 200; minimumHealthyPercent = 100; strategy = "ROLLING" } }
}
$global:SchoolPilotTestAutoscalingState = [ordered]@{
    resourceId = "service/cluster/api"
    minCapacity = 1
    maxCapacity = 6
    dynamicScalingInSuspended = $false
    dynamicScalingOutSuspended = $false
    scheduledScalingSuspended = $false
}
$global:SchoolPilotTestAutoscalingDescribeCallCount = 0
$global:SchoolPilotTestAutoscalingRegisterCallCount = 0
$global:SchoolPilotTestFailAutoscalingRegisterCalls = @()
$global:SchoolPilotTestAutoscalingPropagationDelayPolls = 0
$global:SchoolPilotTestPendingAutoscalingState = $null
$global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore = 0

function Reset-SchoolPilotTestAutoscalingState {
    $global:SchoolPilotTestAutoscalingState.resourceId = "service/cluster/api"
    $global:SchoolPilotTestAutoscalingState.minCapacity = 1
    $global:SchoolPilotTestAutoscalingState.maxCapacity = 6
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $false
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $false
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $false
    $global:SchoolPilotTestAutoscalingPropagationDelayPolls = 0
    $global:SchoolPilotTestPendingAutoscalingState = $null
    $global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore = 0
}
$global:SchoolPilotTestWafCount = $false
$global:SchoolPilotTestMetricQueryIds = @()
$global:SchoolPilotTestMetricQueryPeriods = @{}
$global:SchoolPilotTestMetricQueryStatistics = @{}
$global:SchoolPilotTestMetricLookbackSeconds = $null
$global:SchoolPilotTestEcsCpuAverage = 20.0
$global:SchoolPilotTestEcsCpuMaximum = 20.0
$global:SchoolPilotTestOmitEcsCpuMaximum = $false
$global:SchoolPilotTestEcsCpuMaximumTimestamp = $null
$global:SchoolPilotTestRouteLatency = $true
$global:SchoolPilotTestRedisNodeType = "cache.t4g.small"
$global:SchoolPilotTestPublicIpv4 = $true
$global:SchoolPilotTestAutomatedSnapshotAfter = $null
$global:SchoolPilotTestTerraformLineage = "test-lineage"
$global:SchoolPilotTestNatAvailable = $true
$global:SchoolPilotTestPlanShapeInvalid = $false
$global:SchoolPilotTestTamperNatPlanBeforeApplyPath = ""
$global:SchoolPilotTestNatPlanTampered = $false
$global:SchoolPilotTestNatForwardPlanPath = ""
$global:SchoolPilotTestStoppedTaskLifecycle = $false
$global:SchoolPilotTestStoppedTaskDescribeCalls = 0

function global:aws {
    $arguments = @($args | ForEach-Object { [string]$_ })
    $global:SchoolPilotTestAwsCalls.Add($arguments -join " ")
    $global:LASTEXITCODE = 0
    $service = $arguments[0]
    $operation = $arguments[1]

    if ($service -eq "ecs" -and $operation -eq "describe-services") {
        $apiTransientMixed = [int]$global:SchoolPilotTestTransientMixedDeploymentPolls.api -gt 0
        if ($apiTransientMixed) { $global:SchoolPilotTestTransientMixedDeploymentPolls.api-- }
        $workerTransientMixed = [int]$global:SchoolPilotTestTransientMixedDeploymentPolls.worker -gt 0
        if ($workerTransientMixed) { $global:SchoolPilotTestTransientMixedDeploymentPolls.worker-- }
        $failedDeploymentSelector = $global:SchoolPilotTestFailedDeploymentSelector
        $apiFailedDeployment = $null -ne $failedDeploymentSelector -and
            [string]$failedDeploymentSelector.service -eq "api" -and
            [string]$failedDeploymentSelector.taskDefinition -eq
                [string]$global:SchoolPilotTestServiceState.api.taskDefinition
        $workerFailedDeployment = $null -ne $failedDeploymentSelector -and
            [string]$failedDeploymentSelector.service -eq "worker" -and
            [string]$failedDeploymentSelector.taskDefinition -eq
                [string]$global:SchoolPilotTestServiceState.worker.taskDefinition
        $apiDeployments = @(
            @{ id = "ecs-svc/api-primary"; status = "PRIMARY"; rolloutState = if ($apiFailedDeployment) { "FAILED" } else { "COMPLETED" }; taskDefinition = $global:SchoolPilotTestServiceState.api.taskDefinition; desiredCount = $global:SchoolPilotTestServiceState.api.desired; runningCount = $global:SchoolPilotTestServiceState.api.running; pendingCount = $global:SchoolPilotTestServiceState.api.pending }
        )
        if ($global:SchoolPilotTestForceUnstableService -eq "api" -or $apiTransientMixed) {
            $apiDeployments += @{ id = "ecs-svc/api-draining"; status = "ACTIVE"; rolloutState = "IN_PROGRESS"; taskDefinition = "api-mixed"; desiredCount = 0; runningCount = 1; pendingCount = 0 }
        }
        $workerDeployments = @(
            @{ id = "ecs-svc/worker-primary"; status = "PRIMARY"; rolloutState = if ($workerFailedDeployment) { "FAILED" } else { "COMPLETED" }; taskDefinition = $global:SchoolPilotTestServiceState.worker.taskDefinition; desiredCount = $global:SchoolPilotTestServiceState.worker.desired; runningCount = $global:SchoolPilotTestServiceState.worker.running; pendingCount = $global:SchoolPilotTestServiceState.worker.pending }
        )
        if ($global:SchoolPilotTestForceUnstableService -eq "worker" -or $workerTransientMixed) {
            $workerDeployments += @{ id = "ecs-svc/worker-draining"; status = "ACTIVE"; rolloutState = "IN_PROGRESS"; taskDefinition = "worker-mixed"; desiredCount = 0; runningCount = 1; pendingCount = 0 }
        }
        return (@{
            services = @(
                @{ serviceName = "api"; desiredCount = $global:SchoolPilotTestServiceState.api.desired; runningCount = $global:SchoolPilotTestServiceState.api.running; pendingCount = $global:SchoolPilotTestServiceState.api.pending; taskDefinition = $global:SchoolPilotTestServiceState.api.taskDefinition; deploymentConfiguration = $global:SchoolPilotTestServiceState.api.deploymentConfiguration; deployments = $apiDeployments; networkConfiguration = @{ awsvpcConfiguration = @{ subnets = $global:SchoolPilotTestServiceState.api.subnets; securityGroups = $global:SchoolPilotTestServiceState.api.securityGroups; assignPublicIp = $global:SchoolPilotTestServiceState.api.assignPublicIp } } },
                @{ serviceName = "worker"; desiredCount = $global:SchoolPilotTestServiceState.worker.desired; runningCount = $global:SchoolPilotTestServiceState.worker.running; pendingCount = $global:SchoolPilotTestServiceState.worker.pending; taskDefinition = $global:SchoolPilotTestServiceState.worker.taskDefinition; deploymentConfiguration = $global:SchoolPilotTestServiceState.worker.deploymentConfiguration; deployments = $workerDeployments; networkConfiguration = @{ awsvpcConfiguration = @{ subnets = $global:SchoolPilotTestServiceState.worker.subnets; securityGroups = $global:SchoolPilotTestServiceState.worker.securityGroups; assignPublicIp = $global:SchoolPilotTestServiceState.worker.assignPublicIp } } }
            )
        } | ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "ecs" -and $operation -eq "list-tasks") {
        $desired = Get-ArgumentValue -Arguments $arguments -Name "--desired-status"
        $serviceName = Get-ArgumentValue -Arguments $arguments -Name "--service-name"
        if ($desired -eq "RUNNING") {
            $runningTasks = @(1..([int]$global:SchoolPilotTestServiceState[$serviceName].desired) | ForEach-Object {
                "arn:aws:ecs:us-east-1:000000000000:task/cluster/$serviceName-running-$_"
            })
            return (@{taskArns=$runningTasks}|ConvertTo-Json -Compress)
        }
        return '{"taskArns":["arn:aws:ecs:us-east-1:000000000000:task/cluster/scale-in-task"]}'
    }
    if ($service -eq "ecs" -and $operation -eq "describe-tasks") {
        if (($arguments -join " ") -match '-running-') {
            $tasks = @($arguments | Where-Object { $_ -match '-running-\d+$' } | ForEach-Object {
                $suffix = ($_ -split '/')[-1]
                $serviceName = if ($suffix -match '^(api|worker)-running-') { $Matches[1] } else { throw "Unexpected running task ARN: $_" }
                @{taskArn=$_;taskDefinitionArn=$global:SchoolPilotTestServiceState[$serviceName].taskDefinition;lastStatus="RUNNING";desiredStatus="RUNNING";attachments=@(@{type="ElasticNetworkInterface";details=@(@{name="networkInterfaceId";value="eni-$suffix"})})}
            })
            return (@{tasks=$tasks}|ConvertTo-Json -Depth 8 -Compress)
        }
        $global:SchoolPilotTestStoppedTaskDescribeCalls++
        $stoppedTask = [ordered]@{
            taskArn = "arn:aws:ecs:us-east-1:123456789012:task/cluster/scale-in-task"
            group = "service:api"
            stopCode = "ServiceSchedulerInitiated"
            stoppedReason = "Scaling activity initiated by deployment ecs-svc/test"
            containers = @(@{ exitCode = 0; reason = "" })
        }
        if (-not $global:SchoolPilotTestStoppedTaskLifecycle -or $global:SchoolPilotTestStoppedTaskDescribeCalls -gt 1) {
            $stoppedTask.stoppedAt = [DateTimeOffset]::UtcNow.ToString("o")
        }
        return (@{ tasks = @($stoppedTask) } | ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "elbv2" -and $operation -eq "describe-target-health") {
        $global:SchoolPilotTestTargetHealthCallCount++
        $targets = @()
        if ($global:SchoolPilotTestZeroHealthyTargetPolls -gt 0) {
            $global:SchoolPilotTestZeroHealthyTargetPolls--
        }
        else {
            $targets = @(1..([int]$global:SchoolPilotTestServiceState.api.desired) | ForEach-Object {
                @{ Target = @{ Id = "10.0.0.$_"; Port = 4000 }; TargetHealth = @{ State = "healthy" } }
            })
        }
        if ($global:SchoolPilotTestTargetDrainingPolls -gt 0) {
            $global:SchoolPilotTestTargetDrainingPolls--
            $targets += @{ Target = @{ Id = "10.0.1.250"; Port = 4000 }; TargetHealth = @{ State = "draining" } }
        }
        return (@{ TargetHealthDescriptions = $targets } | ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "elbv2" -and $operation -eq "describe-target-group-attributes") {
        return (@{ Attributes = @(
            @{ Key = "deregistration_delay.timeout_seconds"; Value = [string]$global:SchoolPilotTestDeregistrationDelaySeconds },
            @{ Key = "stickiness.enabled"; Value = "false" }
        ) } | ConvertTo-Json -Depth 5 -Compress)
    }
    if ($service -eq "application-autoscaling" -and $operation -eq "describe-scalable-targets") {
        $global:SchoolPilotTestAutoscalingDescribeCallCount++
        if ($null -ne $global:SchoolPilotTestPendingAutoscalingState) {
            if ($global:SchoolPilotTestAutoscalingPropagationDelayPolls -gt 0) {
                $global:SchoolPilotTestAutoscalingPropagationDelayPolls--
            }
            else {
                $pending = $global:SchoolPilotTestPendingAutoscalingState
                $global:SchoolPilotTestAutoscalingState.resourceId = $pending.resourceId
                $global:SchoolPilotTestAutoscalingState.minCapacity = $pending.minCapacity
                $global:SchoolPilotTestAutoscalingState.maxCapacity = $pending.maxCapacity
                $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $pending.dynamicScalingInSuspended
                $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $pending.dynamicScalingOutSuspended
                $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $pending.scheduledScalingSuspended
                $global:SchoolPilotTestPendingAutoscalingState = $null
            }
        }
        return (@{ ScalableTargets = @(@{
            ResourceId = $global:SchoolPilotTestAutoscalingState.resourceId
            MinCapacity = $global:SchoolPilotTestAutoscalingState.minCapacity
            MaxCapacity = $global:SchoolPilotTestAutoscalingState.maxCapacity
            SuspendedState = @{
                DynamicScalingInSuspended = $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended
                DynamicScalingOutSuspended = $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended
                ScheduledScalingSuspended = $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
            }
        }) } | ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "application-autoscaling" -and $operation -eq "register-scalable-target") {
        $global:SchoolPilotTestAutoscalingRegisterCallCount++
        if ($global:SchoolPilotTestFailAutoscalingRegisterCalls -contains $global:SchoolPilotTestAutoscalingRegisterCallCount) {
            throw "Mock register-scalable-target failure at call $($global:SchoolPilotTestAutoscalingRegisterCallCount)."
        }
        $stateArgument = Get-ArgumentValue -Arguments $arguments -Name "--suspended-state"
        $state = @{}
        foreach ($entry in @($stateArgument -split ',')) {
            $parts = @($entry -split '=', 2)
            if ($parts.Count -ne 2) { throw "Invalid mocked suspended-state entry '$entry'." }
            $state[$parts[0]] = [bool]::Parse($parts[1])
        }
        $payload = [pscustomobject]@{
            resourceId = Get-ArgumentValue -Arguments $arguments -Name "--resource-id"
            minCapacity = [int](Get-ArgumentValue -Arguments $arguments -Name "--min-capacity")
            maxCapacity = [int](Get-ArgumentValue -Arguments $arguments -Name "--max-capacity")
            dynamicScalingInSuspended = [bool]$state.DynamicScalingInSuspended
            dynamicScalingOutSuspended = [bool]$state.DynamicScalingOutSuspended
            scheduledScalingSuspended = [bool]$state.ScheduledScalingSuspended
        }
        $global:SchoolPilotTestAutoscalingPayloads.Add($payload)
        if ($global:SchoolPilotTestAutoscalingPropagationDelayPolls -gt 0) {
            $global:SchoolPilotTestPendingAutoscalingState = $payload
        }
        else {
            $global:SchoolPilotTestAutoscalingState.resourceId = $payload.resourceId
            $global:SchoolPilotTestAutoscalingState.minCapacity = $payload.minCapacity
            $global:SchoolPilotTestAutoscalingState.maxCapacity = $payload.maxCapacity
            $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $payload.dynamicScalingInSuspended
            $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $payload.dynamicScalingOutSuspended
            $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $payload.scheduledScalingSuspended
        }
        if ($global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore -gt 0 -and
            -not $payload.dynamicScalingInSuspended -and -not $payload.dynamicScalingOutSuspended -and
            -not $payload.scheduledScalingSuspended) {
            $global:SchoolPilotTestServiceState.api.desired = $global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore
            $global:SchoolPilotTestServiceState.api.running = $global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore
            $global:SchoolPilotTestServiceState.api.pending = 0
            $global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore = 0
        }
        return '{}'
    }
    if ($service -eq "rds" -and $operation -eq "describe-db-instances") {
        return '{"DBInstances":[{"DBInstanceStatus":"available","AllocatedStorage":100,"MaxAllocatedStorage":1000,"PendingModifiedValues":{}}]}'
    }
    if ($service -eq "elasticache" -and $operation -eq "describe-replication-groups") {
        return (@{ReplicationGroups=@(@{Status="available";CacheNodeType=$global:SchoolPilotTestRedisNodeType;PendingModifiedValues=@{}})}|ConvertTo-Json -Depth 5 -Compress)
    }
    if ($service -eq "elasticache" -and $operation -eq "describe-snapshots") {
        $snapshots = if ($null -eq $global:SchoolPilotTestAutomatedSnapshotAfter) { @() } else {
            @(@{SnapshotName="automatic-after-resize";SnapshotStatus="available";NodeSnapshots=@(@{SnapshotCreateTime=$global:SchoolPilotTestAutomatedSnapshotAfter})})
        }
        return (@{Snapshots=$snapshots}|ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "elasticache" -and $operation -in @("modify-replication-group", "wait")) { return '{}' }
    if ($service -eq "ec2" -and $operation -eq "describe-nat-gateways") {
        if (-not $global:SchoolPilotTestNatAvailable) { return '{"NatGateways":[]}' }
        return '{"NatGateways":[{"NatGatewayId":"nat-1","State":"available","NatGatewayAddresses":[{"AssociationId":"eipassoc-1"}]},{"NatGatewayId":"nat-2","State":"available","NatGatewayAddresses":[{"AssociationId":"eipassoc-2"}]}]}'
    }
    if ($service -eq "ec2" -and $operation -eq "describe-route-tables") {
        return '{"RouteTables":[{"RouteTableId":"rtb-private-a","Routes":[{"DestinationCidrBlock":"0.0.0.0/0","NatGatewayId":"nat-1","State":"active"}]},{"RouteTableId":"rtb-private-b","Routes":[{"DestinationCidrBlock":"0.0.0.0/0","NatGatewayId":"nat-2","State":"active"}]}]}'
    }
    if ($service -eq "ec2" -and $operation -eq "describe-network-interfaces") {
        $ids = @($arguments | Where-Object { $_ -match '^eni-' })
        return (@{NetworkInterfaces=@($ids|ForEach-Object { @{NetworkInterfaceId=$_;Association=if($global:SchoolPilotTestPublicIpv4){@{PublicIp="198.51.100.10"}}else{@{}}} })}|ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "route53" -and $operation -eq "get-health-check-status") {
        return '{"HealthCheckObservations":[{"StatusReport":{"Status":"Success: HTTP Status Code 200"}}]}'
    }
    if ($service -eq "route53" -and $operation -eq "get-health-check") {
        return (@{ HealthCheck = @{ HealthCheckConfig = @{ Type = "HTTPS"; ResourcePath = "/health"; MeasureLatency = $global:SchoolPilotTestRouteLatency } } } | ConvertTo-Json -Depth 5 -Compress)
    }
    if ($service -eq "cloudwatch" -and $operation -eq "describe-alarms") {
        return '{"MetricAlarms":[{"AlarmName":"route53-alarm","StateValue":"OK"}]}'
    }
    if ($service -eq "cloudwatch" -and $operation -eq "get-metric-data") {
        $metricStartArgument = Get-ArgumentValue -Arguments $arguments -Name "--start-time"
        $metricEndArgument = Get-ArgumentValue -Arguments $arguments -Name "--end-time"
        if ($null -ne $metricStartArgument -and $null -ne $metricEndArgument) {
            $metricStart = [DateTimeOffset]$metricStartArgument
            $metricEnd = [DateTimeOffset]$metricEndArgument
            $global:SchoolPilotTestMetricLookbackSeconds = ($metricEnd - $metricStart).TotalSeconds
        }
        $inputReference = Get-ArgumentValue -Arguments $arguments -Name "--metric-data-queries"
        $inputPath = $inputReference.Substring("file://".Length)
        $queries = @(Get-Content -LiteralPath $inputPath -Raw | ConvertFrom-Json -Depth 20)
        $global:SchoolPilotTestMetricQueryIds = @($queries.Id)
        $global:SchoolPilotTestMetricQueryPeriods = @{}
        $global:SchoolPilotTestMetricQueryStatistics = @{}
        foreach ($query in $queries) {
            if ($null -ne $query.PSObject.Properties["MetricStat"]) {
                $global:SchoolPilotTestMetricQueryPeriods[[string]$query.Id] = [int]$query.MetricStat.Period
                $global:SchoolPilotTestMetricQueryStatistics[[string]$query.Id] = [string]$query.MetricStat.Stat
            }
            else {
                $global:SchoolPilotTestMetricQueryPeriods[[string]$query.Id] = 60
                $global:SchoolPilotTestMetricQueryStatistics[[string]$query.Id] = "Expression"
            }
        }
        $timestamp = [DateTimeOffset]::UtcNow.ToString("o")
        $results = @($queries | ForEach-Object {
            $metricId = [string]$_.Id
            if ($global:SchoolPilotTestOmitEcsCpuMaximum -and $metricId -match '^ecs_.*_cpu_maximum$') {
                @{ Id = $metricId; StatusCode = "Complete"; Timestamps = @(); Values = @() }
            }
            else {
                $value = switch -Regex ($metricId) {
                    '^ecs_.*_cpu_maximum$' { $global:SchoolPilotTestEcsCpuMaximum; break }
                    '^ecs_.*_cpu$' { $global:SchoolPilotTestEcsCpuAverage; break }
                    '^ecs_.*_memory$' { 20; break }
                    '^rds_cpu$' { 10; break }
                    '^rds_connections$' { 20; break }
                    '^rds_free_storage$' { 85899345920; break }
                    '^rds_free_memory$' { 1073741824; break }
                    '^rds_cpu_credit$' { 100; break }
                    '^redis_cpu$' { 10; break }
                    '^redis_memory$' { 20; break }
                    '^redis_free$' { 209715200; break }
                    '^redis_cpu_credit$' { 100; break }
                    default { 0 }
                }
                $metricTimestamp = if ($null -ne $global:SchoolPilotTestEcsCpuMaximumTimestamp -and
                    $metricId -match '^ecs_.*_cpu_maximum$') {
                    [string]$global:SchoolPilotTestEcsCpuMaximumTimestamp
                } else { $timestamp }
                @{ Id = $metricId; StatusCode = "Complete"; Timestamps = @($metricTimestamp); Values = @($value) }
            }
        })
        return (@{ MetricDataResults = $results } | ConvertTo-Json -Depth 8 -Compress)
    }
    if ($service -eq "sns" -and $operation -eq "publish") { return '{"MessageId":"mock-message"}' }
    if ($service -eq "wafv2" -and $operation -eq "list-web-acls") {
        return '{"WebACLs":[{"Name":"acl","Id":"acl-id"}]}'
    }
    if ($service -eq "wafv2" -and $operation -eq "get-web-acl") {
        $rateAction = if ($global:SchoolPilotTestWafCount) { @{ Count = @{} } } else { @{ Block = @{} } }
        return (@{
            LockToken = "mock-lock"
            WebACL = @{
                DefaultAction = @{ Allow = @{} }
                Description = ""
                Rules = @(
                    @{ Name = "Managed"; Priority = 1; OverrideAction = @{ None = @{} }; Statement = @{ ManagedRuleGroupStatement = @{ Name = "Managed"; VendorName = "AWS" } }; VisibilityConfig = @{ SampledRequestsEnabled = $true; CloudWatchMetricsEnabled = $true; MetricName = "managed" } },
                    @{ Name = "DeviceIngestRateLimit"; Priority = 30; Action = $rateAction; Statement = @{ RateBasedStatement = @{ Limit = 100000; AggregateKeyType = "IP" } }; VisibilityConfig = @{ SampledRequestsEnabled = $true; CloudWatchMetricsEnabled = $true; MetricName = "device" } },
                    @{ Name = "ApiRateLimit"; Priority = 40; Action = $rateAction; Statement = @{ RateBasedStatement = @{ Limit = 50000; AggregateKeyType = "IP" } }; VisibilityConfig = @{ SampledRequestsEnabled = $true; CloudWatchMetricsEnabled = $true; MetricName = "api" } }
                )
                VisibilityConfig = @{ SampledRequestsEnabled = $true; CloudWatchMetricsEnabled = $true; MetricName = "acl" }
            }
        } | ConvertTo-Json -Depth 20 -Compress)
    }
    if ($service -eq "wafv2" -and $operation -eq "update-web-acl") {
        $inputReference = Get-ArgumentValue -Arguments $arguments -Name "--cli-input-json"
        $inputPath = $inputReference.Substring("file://".Length)
        $global:SchoolPilotTestWafUpdate = Get-Content -LiteralPath $inputPath -Raw | ConvertFrom-Json -Depth 30
        $global:SchoolPilotTestWafCount = $true
        return '{}'
    }
    if ($service -eq "ecs" -and $operation -eq "update-service") {
        $serviceName = Get-ArgumentValue -Arguments $arguments -Name "--service"
        $taskDefinition = Get-ArgumentValue -Arguments $arguments -Name "--task-definition"
        $global:SchoolPilotTestUpdateServiceCallCount++
        $failureSelector = $global:SchoolPilotTestFailUpdateServiceSelector
        if ($null -ne $failureSelector -and
            [string]$failureSelector.service -ceq [string]$serviceName -and
            [string]$failureSelector.taskDefinition -ceq [string]$taskDefinition) {
            throw "Mock update-service failure for service '$serviceName' and task definition '$taskDefinition'."
        }
        if ($taskDefinition) {
            $desiredCount = [int]$global:SchoolPilotTestServiceState[$serviceName].desired
            $deploymentConfiguration = $global:SchoolPilotTestServiceState[$serviceName].deploymentConfiguration
            $global:SchoolPilotTestTaskUpdateObservations.Add([pscustomobject]@{
                service = $serviceName
                taskDefinition = $taskDefinition
                desired = $desiredCount
                minimumHealthyTasks = [int][Math]::Ceiling(($desiredCount * [int]$deploymentConfiguration.minimumHealthyPercent) / 100.0)
                maximumConcurrentTasks = [int][Math]::Floor(($desiredCount * [int]$deploymentConfiguration.maximumPercent) / 100.0)
                deploymentConfiguration = ($deploymentConfiguration | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20)
            })
            $global:SchoolPilotTestServiceState[$serviceName].taskDefinition = $taskDefinition
            if ($serviceName -eq "api") {
                if ($global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate -gt 0) {
                    $driftDesired = [int]$global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate
                    $global:SchoolPilotTestServiceState.api.desired = $driftDesired
                    $global:SchoolPilotTestServiceState.api.running = $driftDesired
                    $global:SchoolPilotTestServiceState.api.pending = 0
                    $global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate = 0
                }
                if ($global:SchoolPilotTestInjectTargetDrainingPollsOnApiUpdate -gt 0) {
                    $global:SchoolPilotTestTargetDrainingPolls = $global:SchoolPilotTestInjectTargetDrainingPollsOnApiUpdate
                    $global:SchoolPilotTestInjectTargetDrainingPollsOnApiUpdate = 0
                }
                if ($global:SchoolPilotTestInjectZeroHealthyTargetPollsOnApiUpdate -gt 0) {
                    $global:SchoolPilotTestZeroHealthyTargetPolls = $global:SchoolPilotTestInjectZeroHealthyTargetPollsOnApiUpdate
                    $global:SchoolPilotTestInjectZeroHealthyTargetPollsOnApiUpdate = 0
                }
            }
        }
        $deploymentReference = Get-ArgumentValue -Arguments $arguments -Name "--deployment-configuration"
        if ($deploymentReference) {
            $deploymentPath = $deploymentReference.Substring("file://".Length)
            $deploymentPayload = Get-Content -LiteralPath $deploymentPath -Raw | ConvertFrom-Json -Depth 20
            $global:SchoolPilotTestDeploymentPayloads.Add([pscustomobject]@{
                service = $serviceName
                configuration = $deploymentPayload
            })
            $global:SchoolPilotTestServiceState[$serviceName].deploymentConfiguration = $deploymentPayload
            if ($serviceName -eq "api" -and $global:SchoolPilotTestInjectDesiredDriftAfterApiPolicyApply -gt 0) {
                $driftDesired = [int]$global:SchoolPilotTestInjectDesiredDriftAfterApiPolicyApply
                $global:SchoolPilotTestServiceState.api.desired = $driftDesired
                $global:SchoolPilotTestServiceState.api.running = $driftDesired
                $global:SchoolPilotTestServiceState.api.pending = 0
                $global:SchoolPilotTestInjectDesiredDriftAfterApiPolicyApply = 0
            }
            if ($serviceName -eq "api" -and
                -not [string]::IsNullOrWhiteSpace($global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath)) {
                [IO.File]::Delete($global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath)
                $global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath = ""
            }
        }
        $networkReference = Get-ArgumentValue -Arguments $arguments -Name "--network-configuration"
        if ($networkReference) {
            $networkPath = $networkReference.Substring("file://".Length)
            $payload = Get-Content -LiteralPath $networkPath -Raw | ConvertFrom-Json -Depth 10
            $global:SchoolPilotTestNetworkPayloads.Add($payload)
            $global:SchoolPilotTestServiceState[$serviceName].subnets = @($payload.awsvpcConfiguration.subnets)
            $global:SchoolPilotTestServiceState[$serviceName].securityGroups = @($payload.awsvpcConfiguration.securityGroups)
            $global:SchoolPilotTestServiceState[$serviceName].assignPublicIp = [string]$payload.awsvpcConfiguration.assignPublicIp
        }
        return '{}'
    }
    throw "Unexpected mocked AWS call: $($arguments -join ' ')"
}

function global:terraform {
    $arguments = @($args | ForEach-Object { [string]$_ })
    # The saved-plan validator renders plans against the repository infra directory.
    if ($arguments.Count -gt 0 -and $arguments[0] -like "-chdir=*") {
        $arguments = @($arguments | Select-Object -Skip 1)
    }
    $global:SchoolPilotTestTerraformCalls.Add($arguments -join " ")
    $global:LASTEXITCODE = 0
    if (($arguments -join " ") -eq "state pull") {
        if (-not $global:SchoolPilotTestNatPlanTampered -and
            -not [string]::IsNullOrWhiteSpace($global:SchoolPilotTestTamperNatPlanBeforeApplyPath)) {
            [IO.File]::WriteAllBytes($global:SchoolPilotTestTamperNatPlanBeforeApplyPath,[Text.Encoding]::UTF8.GetBytes("tampered-after-initial-validation"))
            $global:SchoolPilotTestNatPlanTampered = $true
        }
        return (@{version=4;terraform_version="1.12.2";serial=1;lineage=$global:SchoolPilotTestTerraformLineage;outputs=@{};resources=@()}|ConvertTo-Json -Depth 5 -Compress)
    }
    if ($arguments.Count -ge 2 -and $arguments[0] -eq "show" -and $arguments[1] -eq "-json") {
        $isForward = [string]$arguments[2] -eq [string]$global:SchoolPilotTestNatForwardPlanPath
        $changes = @()
        foreach ($index in 0..1) {
            $eip = @{domain="vpc";tags=@{Name="nat-$index"};allocation_id="eipalloc-$index";public_ip="198.51.100.$($index+1)"}
            $gateway = @{connectivity_type="public";subnet_id="subnet-a$($index+1)";tags=@{Name="nat-$index"};allocation_id="eipalloc-$index";id="nat-$index"}
            $route = @{destination_cidr_block="0.0.0.0/0";route_table_id="rtb-a$($index+1)";nat_gateway_id="nat-$index"}
            foreach ($entry in @(
                @{address="module.vpc.aws_eip.nat[$index]";value=$eip;unknown=@{}},
                @{address="module.vpc.aws_nat_gateway.main[$index]";value=$gateway;unknown=@{allocation_id=$true}},
                @{address="module.vpc.aws_route.private_nat[$index]";value=$route;unknown=@{nat_gateway_id=$true}}
            )) {
                $changes += @{address=$entry.address;change=@{
                    actions=@($(if($isForward){"delete"}else{"create"}))
                    before=$(if($isForward){$entry.value}else{$null})
                    after=$(if($isForward){$null}else{$entry.value})
                    after_unknown=$(if($isForward){@{}}else{$entry.unknown})
                }}
            }
        }
        $changes += @{address="module.vpc.aws_vpc.main";change=@{actions=@("no-op")}}
        if ($global:SchoolPilotTestPlanShapeInvalid) { $changes += @{address="module.vpc.aws_security_group.unreviewed";change=@{actions=@("update")}} }
        $configuration = @{root_module=@{child_modules=@(@{address="module.vpc";resources=@(
            @{address="aws_nat_gateway.main";expressions=@{allocation_id=@{references=@("aws_eip.nat[count.index].id")}}},
            @{address="aws_route.private_nat";expressions=@{nat_gateway_id=@{references=@("aws_nat_gateway.main[count.index].id")}}}
        )})}}
        return (@{format_version="1.2";errored=$false;complete=$true;applyable=$true;deferred_changes=@();resource_drift=@();checks=@();resource_changes=$changes;configuration=$configuration}|ConvertTo-Json -Depth 15 -Compress)
    }
}

try {
    [void][IO.Directory]::CreateDirectory($evidenceDirectory)
    Invoke-AtomicJsonRaceRegression -ScriptPaths @($monitorScript,$rollbackScript,$supervisorScript) -Root $tempRoot
    if ($AtomicJsonRaceOnly) {
        $testClock.Stop()
        Write-Host ("AWS rollout atomic JSON race tests: PASS ({0} assertions, {1:N1}s)" -f $script:AssertionCount,$testClock.Elapsed.TotalSeconds)
        return
    }

    $monitorConfigPath = Join-Path $tempRoot "monitor.json"
    $monitorConfig = @{
        schemaVersion = 1
        testEnvironmentSentinel = "SCHOOLPILOT_ROLLOUT_TEST_ONLY"
        runId = "monitor-test"
        phase = "PublicEcs"
        evidenceDirectory = $evidenceDirectory
        automaticRollback = $false
        notificationTopicArn = "arn:aws:sns:us-east-1:000000000000:test-alerts"
        pollSeconds = 1
        testMode = $true
        maxIterations = 1
        minimumWallClockSeconds = 0
        deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        resources = @{
            region = "us-east-1"
            cluster = "cluster"
            apiService = "api"
            workerService = "worker"
            targetGroupArn = "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/test/123"
            rdsInstanceId = "db"
            redisCacheClusterId = "redis-001"
            redisReplicationGroupId = "redis"
            vpcId = "vpc-1"
            route53HealthCheckId = "health-1"
            wafWebAclName = "web-acl"
            wafDeviceRuleMetricName = "device"
            wafApiRuleMetricName = "api"
            route53AlarmName = "route53-alarm"
            expectedNatGatewayCount = 2
            expectedRoute53MeasureLatency = $true
            expectedEcsAssignPublicIp = $true
            ecsTaskSubnetIds = @("subnet-public-a", "subnet-public-b")
            expectedRedisNodeType = "cache.t4g.small"
        }
    }
    [IO.File]::WriteAllText($monitorConfigPath, ($monitorConfig | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    & $monitorScript -ConfigPath $monitorConfigPath -Mode Monitor | Out-Null

    $monitorResultPath = Join-Path $evidenceDirectory "monitor-test-monitor-result.json"
    Assert-Condition (Test-Path -LiteralPath $monitorResultPath) "Monitor should write an atomic result."
    $monitorResult = Get-Content -LiteralPath $monitorResultPath -Raw | ConvertFrom-Json
    Assert-Condition ($monitorResult.status -eq "completed") "Healthy mocked telemetry should complete (result: $($monitorResult | ConvertTo-Json -Compress -Depth 10))."
    Assert-Condition (($global:SchoolPilotTestAwsCalls -join "`n").Contains("ecs describe-tasks")) "Healthy monitor test must exercise expected autoscaling/deployment stop classification."
    $monitorCalls = $global:SchoolPilotTestAwsCalls -join "`n"
    foreach ($expected in @("ecs describe-services", "elbv2 describe-target-health", "rds describe-db-instances", "elasticache describe-replication-groups", "cloudwatch get-metric-data", "ec2 describe-nat-gateways", "route53 get-health-check-status", "sns publish")) {
        Assert-Condition ($monitorCalls.Contains($expected)) "Monitor did not poll or notify through '$expected'."
    }
    Assert-Condition ($global:SchoolPilotTestMetricQueryIds -contains "waf_device_blocked" -and $global:SchoolPilotTestMetricQueryIds -contains "waf_api_blocked") "Monitor did not poll both WAF rate-rule metrics."
    Assert-Condition ([double]$global:SchoolPilotTestMetricLookbackSeconds -eq 900) "CloudWatch metric lookback must retain 15 minutes of credit telemetry for three stale confirmations."
    foreach ($fiveMinuteMetric in @("rds_cpu_credit", "rds_surplus_charged", "redis_cpu_credit")) {
        Assert-Condition ([int]$global:SchoolPilotTestMetricQueryPeriods[$fiveMinuteMetric] -eq 300) "Five-minute metric '$fiveMinuteMetric' must use a 300-second CloudWatch period."
    }
    foreach ($oneMinuteMetric in @("ecs_api_cpu", "ecs_api_cpu_maximum", "ecs_worker_cpu", "ecs_worker_cpu_maximum", "waf_device_blocked", "waf_api_blocked")) {
        Assert-Condition ([int]$global:SchoolPilotTestMetricQueryPeriods[$oneMinuteMetric] -eq 60) "One-minute metric '$oneMinuteMetric' must retain a 60-second CloudWatch period."
    }
    Assert-Condition ($global:SchoolPilotTestMetricQueryStatistics["ecs_api_cpu"] -eq "Average" -and
        $global:SchoolPilotTestMetricQueryStatistics["ecs_worker_cpu"] -eq "Average") "ECS CPU gate series must use CloudWatch one-minute Average."
    Assert-Condition ($global:SchoolPilotTestMetricQueryStatistics["ecs_api_cpu_maximum"] -eq "Maximum" -and
        $global:SchoolPilotTestMetricQueryStatistics["ecs_worker_cpu_maximum"] -eq "Maximum") "ECS CPU peak-evidence series must retain CloudWatch one-minute Maximum."

    $global:SchoolPilotTestEcsCpuAverage = 20.0
    $global:SchoolPilotTestEcsCpuMaximum = 99.0
    $ecsCpuEvidenceConfig = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $ecsCpuEvidenceConfig.runId = "ecs-cpu-maximum-evidence-only"
    $ecsCpuEvidenceConfig.maxIterations = 4
    $ecsCpuEvidenceConfig.minimumWallClockSeconds = 3
    $ecsCpuEvidenceConfigPath = Join-Path $tempRoot "ecs-cpu-maximum-evidence-only.json"
    [IO.File]::WriteAllText($ecsCpuEvidenceConfigPath, ($ecsCpuEvidenceConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    & $monitorScript -ConfigPath $ecsCpuEvidenceConfigPath -Mode Monitor | Out-Null
    $ecsCpuEvidenceResult = Get-Content -LiteralPath (Join-Path $evidenceDirectory "ecs-cpu-maximum-evidence-only-monitor-result.json") -Raw | ConvertFrom-Json -Depth 30
    $ecsCpuEvidenceSample = Get-Content -LiteralPath (Join-Path $evidenceDirectory "ecs-cpu-maximum-evidence-only-aws-monitor.jsonl") -Tail 1 | ConvertFrom-Json -Depth 30
    Assert-Condition ($ecsCpuEvidenceResult.status -eq "completed" -and $ecsCpuEvidenceResult.acceptance.passed -and
        -not ($ecsCpuEvidenceResult.acceptance.violations -contains "ecs_api_cpu_steady") -and
        -not ($ecsCpuEvidenceResult.acceptance.violations -contains "ecs_api_cpu_p95")) "A high ECS Maximum with a healthy Average must remain evidence-only and must not trip runtime, steady, or p95 gates."
    Assert-Condition ([double]$ecsCpuEvidenceSample.metrics.ecs.api.cpuPercent -eq 20.0 -and
        [double]$ecsCpuEvidenceSample.metrics.ecs.api.cpuMaximumPercent -eq 99.0) "Per-sample ECS evidence must distinguish Average gate CPU from Maximum peak CPU."
    Assert-Condition ([double]$ecsCpuEvidenceResult.acceptance.metrics.ecs_api_cpu.p95 -eq 20.0 -and
        [double]$ecsCpuEvidenceResult.acceptance.metrics.ecs_api_cpu_maximum.maximum -eq 99.0) "Acceptance evidence must compute p95 from Average while retaining the separate Maximum series."
    $global:SchoolPilotTestEcsCpuMaximum = 20.0

    foreach ($maximumEvidenceCase in @(
        [pscustomobject]@{
            name = "missing"
            omit = $true
            timestamp = $null
        },
        [pscustomobject]@{
            name = "stale"
            omit = $false
            timestamp = [DateTimeOffset]::UtcNow.AddMinutes(-10).ToString("o")
        }
    )) {
        $global:SchoolPilotTestOmitEcsCpuMaximum = [bool]$maximumEvidenceCase.omit
        $global:SchoolPilotTestEcsCpuMaximumTimestamp = $maximumEvidenceCase.timestamp
        $maximumEvidenceConfig = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $maximumEvidenceConfig.runId = "ecs-cpu-maximum-$($maximumEvidenceCase.name)-invalid"
        $maximumEvidenceConfig.maxIterations = 4
        $maximumEvidenceConfig.minimumWallClockSeconds = 3
        $maximumEvidenceConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 120
        $maximumEvidenceConfig | Add-Member -NotePropertyName testTelemetryMetricNames -NotePropertyValue @(
            "ecs_api_cpu_maximum", "ecs_worker_cpu_maximum"
        )
        $maximumEvidenceConfigPath = Join-Path $tempRoot "$($maximumEvidenceConfig.runId).json"
        [IO.File]::WriteAllText($maximumEvidenceConfigPath, ($maximumEvidenceConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        & $monitorScript -ConfigPath $maximumEvidenceConfigPath -Mode Monitor | Out-Null
        $maximumEvidenceExitCode = $LASTEXITCODE
        $global:SchoolPilotTestOmitEcsCpuMaximum = $false
        $global:SchoolPilotTestEcsCpuMaximumTimestamp = $null

        $maximumEvidenceResult = Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($maximumEvidenceConfig.runId)-monitor-result.json") -Raw | ConvertFrom-Json -Depth 30
        Assert-Condition ($maximumEvidenceExitCode -eq 2 -and $maximumEvidenceResult.status -eq "failed" -and
            $maximumEvidenceResult.failures -contains "run_acceptance_failed") "Missing/stale ECS Maximum telemetry must invalidate the completed run."
        foreach ($series in @("ecs_api_cpu_maximum", "ecs_worker_cpu_maximum")) {
            Assert-Condition ($maximumEvidenceResult.acceptance.violations -contains "telemetry_coverage:$series") "Missing/stale ECS Maximum telemetry must fail mandatory coverage for $series."
        }
        Assert-Condition (-not $maximumEvidenceResult.rollback.approved -and -not $maximumEvidenceResult.rollback.attempted -and
            $maximumEvidenceResult.rollback.reason -match "cumulative acceptance") "Missing/stale ECS Maximum evidence must invalidate without guessing at an infrastructure rollback."
    }

    $global:SchoolPilotTestStoppedTaskLifecycle = $true
    $global:SchoolPilotTestStoppedTaskDescribeCalls = 0
    $stoppingTaskConfig = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $stoppingTaskConfig.runId = "stopping-task-lifecycle-test"
    $stoppingTaskConfig.maxIterations = 2
    # Keep completion deliberately out of reach so a slower CI runner cannot
    # satisfy the wall clock after the first sample and skip the lifecycle's
    # second observation. The bounded iteration-limit exit is expected here;
    # this case verifies that the transition itself never triggers a gate.
    $stoppingTaskConfig.minimumWallClockSeconds = 3600
    $stoppingTaskConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddHours(2).ToString("o")
    $stoppingTaskConfigPath = Join-Path $tempRoot "stopping-task-lifecycle.json"
    [IO.File]::WriteAllText($stoppingTaskConfigPath, ($stoppingTaskConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    & $monitorScript -ConfigPath $stoppingTaskConfigPath -Mode Monitor | Out-Null
    $stoppingTaskExitCode = $LASTEXITCODE
    $stoppingTaskResult = Get-Content -LiteralPath (Join-Path $evidenceDirectory "stopping-task-lifecycle-test-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
    $stoppingTaskSamples = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "stopping-task-lifecycle-test-aws-monitor.jsonl") | ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    Assert-Condition ($stoppingTaskExitCode -eq 2 -and $stoppingTaskResult.status -eq "failed" -and
        $stoppingTaskResult.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
        $stoppingTaskSamples.Count -eq 2) "The bounded lifecycle test must end only at its deliberate iteration limit after two samples."
    Assert-Condition (@($stoppingTaskSamples | Where-Object { $_.triggered -or $_.immediateFailures -contains "monitor_exception" }).Count -eq 0) "A DEACTIVATING task without stoppedAt must not crash or trigger a monitoring gate."
    Assert-Condition (@($stoppingTaskSamples[0].stoppedTasks).Count -eq 0) "An incomplete ECS stop transition must remain pending until stoppedAt is published."
    Assert-Condition (@($stoppingTaskSamples[1].stoppedTasks).Count -eq 1 -and $stoppingTaskSamples[1].stoppedTasks[0].expectedScaleOrDeploymentStop) "The completed scale-in must be observed and classified on the next sample."
    $global:SchoolPilotTestStoppedTaskLifecycle = $false
    $global:SchoolPilotTestStoppedTaskDescribeCalls = 0

    $isolatedConfig = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $isolatedConfig.runId = "missing-test-sentinel"
    $isolatedConfig.PSObject.Properties.Remove("testEnvironmentSentinel")
    $isolatedConfigPath = Join-Path $tempRoot "missing-test-sentinel.json"
    [IO.File]::WriteAllText($isolatedConfigPath, ($isolatedConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $testModeBypassRejected = $false
    try { & $monitorScript -ConfigPath $isolatedConfigPath -Mode Validate | Out-Null }
    catch { $testModeBypassRejected = $_.Exception.Message -match "test-only config sentinel" }
    Assert-Condition $testModeBypassRejected "testMode must not bypass production locks without both explicit isolation sentinels."

    $dummyRollbackPath = Join-Path $tempRoot "production-lock-dummy-rollback.json"
    [IO.File]::WriteAllText($dummyRollbackPath, '{}', [Text.UTF8Encoding]::new($false))
    $production800 = @{
        schemaVersion=1;runId="production-800-missing-predecessor";phase="Waf";evidenceDirectory=(Join-Path $tempRoot "production-800-evidence");
        loadProgressPath=(Join-Path $tempRoot "production-800-progress.jsonl");loadSummaryPath=(Join-Path $tempRoot "production-800-summary.json");
        artifactsNotBeforeUtc=[DateTimeOffset]::UtcNow.ToString("o");
        expectedGeneratorPublicIp="203.0.113.10";
        minimumWallClockSeconds=5400;deadlineUtc=[DateTimeOffset]::UtcNow.AddHours(2).ToString("o");
        workload=@{stage="800";devices=810;durationSeconds=5400;screenshotBytes=40960;canaryDevices=10;workloadSchemaVersion="classpilot-tile-batch-v1";endpointShapeSha256="8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"}
    }
    $production800Path = Join-Path $tempRoot "production-800-missing-predecessor.json"
    [IO.File]::WriteAllText($production800Path, ($production800|ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $predecessorRequired = $false
    $predecessorError = ""
    try { & $monitorScript -ConfigPath $production800Path -Mode Validate | Out-Null }
    catch { $predecessorError=$_.Exception.Message;$predecessorRequired = $predecessorError -match "predecessorResultPath" }
    Assert-Condition $predecessorRequired "The immutable Waf500→Waf800 progression must require hashed predecessor acceptance evidence (actual: $predecessorError)."

    $engineering800 = $production800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineering800.runId = "engineering-800-no-predecessor"
    $engineering800 | Add-Member -NotePropertyName engineeringAcceptance -NotePropertyValue $true -Force
    $engineering800Path = Join-Path $tempRoot "engineering-800-no-predecessor.json"
    [IO.File]::WriteAllText($engineering800Path, ($engineering800 | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringAdvancedPastPredecessor = $false
    $engineeringValidationError = ""
    try { & $monitorScript -ConfigPath $engineering800Path -Mode Validate | Out-Null }
    catch {
        $engineeringValidationError = $_.Exception.Message
        $engineeringAdvancedPastPredecessor =
            $engineeringValidationError -notmatch "predecessorResultPath" -and
            $engineeringValidationError -match "property 'resources'|requires 'region'"
    }
    Assert-Condition $engineeringAdvancedPastPredecessor `
        "Exact Waf/800 engineering acceptance must not consume predecessor evidence (actual: $engineeringValidationError)."

    $engineering500 = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineering500.runId = "engineering-500-no-predecessor"
    $engineering500.minimumWallClockSeconds = 1800
    $engineering500.workload.stage = "500"
    $engineering500.workload.devices = 510
    $engineering500.workload.durationSeconds = 1800
    $engineering500Path = Join-Path $tempRoot "engineering-500-no-predecessor.json"
    [IO.File]::WriteAllText($engineering500Path, ($engineering500 | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineering500Accepted = $false
    try { & $monitorScript -ConfigPath $engineering500Path -Mode Validate | Out-Null }
    catch {
        $engineering500Accepted =
            $_.Exception.Message -notmatch "predecessorResultPath" -and
            $_.Exception.Message -match "property 'resources'|requires 'region'"
    }
    Assert-Condition $engineering500Accepted `
        "Exact Waf/500 engineering acceptance must validate without predecessor evidence."

    $engineeringWrongProfile = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineeringWrongProfile.runId = "engineering-profile-rejected"
    $engineeringWrongProfile.workload.stage = "500"
    $engineeringWrongProfilePath = Join-Path $tempRoot "engineering-profile-rejected.json"
    [IO.File]::WriteAllText($engineeringWrongProfilePath, ($engineeringWrongProfile | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringWrongProfileRejected = $false
    try { & $monitorScript -ConfigPath $engineeringWrongProfilePath -Mode Validate | Out-Null }
    catch { $engineeringWrongProfileRejected = $_.Exception.Message -match "permits only exact Waf/500" }
    Assert-Condition $engineeringWrongProfileRejected `
        "Engineering acceptance must reject every workload outside the exact Waf/500 and Waf/800 profiles."

    $engineeringForbiddenBinding = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineeringForbiddenBinding.runId = "engineering-forbidden-binding"
    $engineeringForbiddenBinding | Add-Member -NotePropertyName databaseInsightsLeaseReceiptPath -NotePropertyValue "forbidden" -Force
    $engineeringForbiddenBindingPath = Join-Path $tempRoot "engineering-forbidden-binding.json"
    [IO.File]::WriteAllText($engineeringForbiddenBindingPath, ($engineeringForbiddenBinding | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringForbiddenBindingRejected = $false
    try { & $monitorScript -ConfigPath $engineeringForbiddenBindingPath -Mode Validate | Out-Null }
    catch { $engineeringForbiddenBindingRejected = $_.Exception.Message -match "must not declare certification, predecessor, query-identity, or Database Insights" }
    Assert-Condition $engineeringForbiddenBindingRejected `
        "Engineering acceptance must reject Database Insights, query-identity, predecessor, seal, chain, and attestation bindings."

    $engineeringNestedBinding = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineeringNestedBinding.runId = "engineering-nested-binding"
    $engineeringNestedBinding | Add-Member -NotePropertyName context -NotePropertyValue ([pscustomobject]@{
        certification = [pscustomobject]@{
            chainRoot = [pscustomobject]@{ receiptSha256 = ("a" * 64) }
        }
    }) -Force
    $engineeringNestedBindingPath = Join-Path $tempRoot "engineering-nested-binding.json"
    [IO.File]::WriteAllText(
        $engineeringNestedBindingPath,
        ($engineeringNestedBinding | ConvertTo-Json -Depth 12),
        [Text.UTF8Encoding]::new($false)
    )
    $engineeringNestedBindingRejected = $false
    try { & $monitorScript -ConfigPath $engineeringNestedBindingPath -Mode Validate | Out-Null }
    catch {
        $engineeringNestedBindingRejected =
            $_.Exception.Message -match "must not declare certification, predecessor, query-identity, or Database Insights"
    }
    Assert-Condition $engineeringNestedBindingRejected `
        "Engineering acceptance must recursively reject nested certification, receipt, seal, chain, query, and lease bindings."

    $engineeringMixedMode = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineeringMixedMode.runId = "engineering-diagnostic-mixed-mode"
    $engineeringMixedMode | Add-Member -NotePropertyName diagnosticOnly -NotePropertyValue $true -Force
    $engineeringMixedModePath = Join-Path $tempRoot "engineering-diagnostic-mixed-mode.json"
    [IO.File]::WriteAllText($engineeringMixedModePath, ($engineeringMixedMode | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringMixedModeRejected = $false
    try { & $monitorScript -ConfigPath $engineeringMixedModePath -Mode Validate | Out-Null }
    catch { $engineeringMixedModeRejected = $_.Exception.Message -match "mutually exclusive" }
    Assert-Condition $engineeringMixedModeRejected `
        "Engineering acceptance must remain distinct from diagnostic-only monitoring."

    $engineeringTestMode = $engineering800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $engineeringTestMode.runId = "engineering-test-mode-rejected"
    $engineeringTestMode | Add-Member -NotePropertyName testMode -NotePropertyValue $true -Force
    $engineeringTestModePath = Join-Path $tempRoot "engineering-test-mode-rejected.json"
    [IO.File]::WriteAllText(
        $engineeringTestModePath,
        ($engineeringTestMode | ConvertTo-Json -Depth 12),
        [Text.UTF8Encoding]::new($false)
    )
    $engineeringTestModeRejected = $false
    try { & $monitorScript -ConfigPath $engineeringTestModePath -Mode Validate | Out-Null }
    catch { $engineeringTestModeRejected = $_.Exception.Message -match "cannot use testMode" }
    Assert-Condition $engineeringTestModeRejected `
        "Engineering acceptance must never use testMode's relaxed provider and production gates."

    # The engineering scaling-restoration fail-safe binds the live scheduled
    # minimum it must restore. Only the reviewed 05:45/16:00 minimums (1 ordinary,
    # 3 school-day floor) are valid; the superseded six-task arrival minimum is
    # drift. Read-Configuration runs in an isolated scope with only the two
    # AWS-backed WAF/Redis identity asserts stubbed, so the exact production
    # parser and its minCapacity gate are exercised.
    $script:RepositoryRoot = $repositoryRoot
    $currentProcessPath = [IO.Path]::GetFullPath([string](Get-Process -Id $PID).Path)
    $invokeMonitorReadConfiguration = {
        param($Ast, [string]$ConfigPath)
        $Mode = "Validate"
        foreach ($definition in $Ast.FindAll({
                    param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst]
                }, $false)) {
            if ($definition.Name -in @("Assert-WafMetricIdentity", "Assert-DiagnosticRedisIdentity")) { continue }
            Invoke-Expression $definition.Extent.Text
        }
        function Assert-WafMetricIdentity { param($Resources, [switch]$RequireDiagnosticContract) }
        function Assert-DiagnosticRedisIdentity { param($Resources, [string]$ExpectedNodeType) return $null }
        Assert-Condition ($Mode -ceq "Validate" -and (Test-Path -LiteralPath $ConfigPath)) "Monitor Read-Configuration harness must bind its mode and config path."
        return Read-Configuration
    }
    $engineeringRestorationConfig = [ordered]@{
        schemaVersion = 1
        runId = "engineering-scaling-restoration-floor"
        phase = "Waf"
        engineeringAcceptance = $true
        evidenceDirectory = Join-Path $tempRoot "engineering-restoration-evidence"
        loadProgressPath = Join-Path $tempRoot "engineering-restoration-progress.jsonl"
        loadSummaryPath = Join-Path $tempRoot "engineering-restoration-summary.json"
        expectedGeneratorPublicIp = "203.0.113.10"
        minimumWallClockSeconds = 5400
        deadlineUtc = [DateTimeOffset]::UtcNow.AddHours(3).ToString("o")
        artifactsNotBeforeUtc = [DateTimeOffset]::UtcNow.AddMinutes(-1).ToString("o")
        workload = [ordered]@{
            stage = "800"; devices = 810; durationSeconds = 5400; screenshotBytes = 40960; canaryDevices = 10
            workloadSchemaVersion = $script:RequiredWorkloadSchemaVersion
            endpointShapeSha256 = $script:RequiredWorkloadEndpointShapeSha256
        }
        automaticRollback = $false
        requireLoadAcceptance = $true
        pollSeconds = 60
        notificationTopicArn = "arn:aws:sns:us-east-1:135775632425:schoolpilot-alerts"
        harnessProcessId = $PID
        harnessProcessStartedAtUtc = [DateTimeOffset]::UtcNow.AddMinutes(-5).ToString("o")
        harnessProcessPath = $currentProcessPath
        controllerProcessId = $PID
        controllerProcessStartedAtUtc = [DateTimeOffset]::UtcNow.AddMinutes(-5).ToString("o")
        controllerProcessPath = $currentProcessPath
        engineeringScalingRestoration = [ordered]@{
            apiDesiredCount = 3
            minCapacity = 3
            maxCapacity = 6
            rollbackApiTaskDefinitionArn = "arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-api:100"
            rollbackWorkerTaskDefinitionArn = "arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-scheduler-worker:20"
            scheduledActionsSha256 = ("a" * 64)
            scalingPoliciesSha256 = ("b" * 64)
            suspendedState = [ordered]@{
                DynamicScalingInSuspended = $false
                DynamicScalingOutSuspended = $false
                ScheduledScalingSuspended = $false
            }
        }
        resources = [ordered]@{
            region = "us-east-1"
            cluster = "schoolpilot-production-cluster"
            apiService = "schoolpilot-production-api"
            workerService = "schoolpilot-production-scheduler-worker"
            targetGroupArn = "arn:aws:elasticloadbalancing:us-east-1:135775632425:targetgroup/test/123"
            rdsInstanceId = "schoolpilot-production"
            redisCacheClusterId = "schoolpilot-production-001"
            redisReplicationGroupId = "schoolpilot-production"
            vpcId = "vpc-1"
            wafWebAclName = "schoolpilot-production-web-acl"
            wafDeviceRuleMetricName = "device"
            wafApiRuleMetricName = "api"
            wafDeviceClassifierMetricName = "device-classifier"
            cloudFrontDistributionId = "E1TPPJOD7C2CXR"
            route53HealthCheckId = "health-1"
            route53AlarmName = "route53-alarm"
            expectedNatGatewayCount = 2
            expectedRoute53MeasureLatency = $true
            expectedEcsAssignPublicIp = $false
            ecsTaskSubnetIds = @("subnet-private-a", "subnet-private-b")
            expectedRedisNodeType = "cache.t4g.small"
            expectedRdsInstanceClass = "db.t4g.medium"
            expectedActiveApiTaskDefinitionArn = "arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-api:101"
            expectedActiveWorkerTaskDefinitionArn = "arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-scheduler-worker:21"
        }
    }
    $engineeringFloorPath = Join-Path $tempRoot "engineering-scaling-restoration-floor.json"
    [IO.File]::WriteAllText($engineeringFloorPath, ($engineeringRestorationConfig | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringFloorConfig = & $invokeMonitorReadConfiguration $monitorAst $engineeringFloorPath
    Assert-Condition ($engineeringFloorConfig.EngineeringAcceptance -and
        [int]$engineeringFloorConfig.EngineeringScalingRestoration.MinCapacity -eq 3 -and
        [int]$engineeringFloorConfig.EngineeringScalingRestoration.ApiDesiredCount -eq 3) `
        "Engineering scaling restoration must accept the reviewed three-task school-day floor minimum."
    $engineeringRestorationConfig.engineeringScalingRestoration.minCapacity = 6
    $engineeringRestorationConfig.engineeringScalingRestoration.apiDesiredCount = 6
    $engineeringStaleFloorPath = Join-Path $tempRoot "engineering-scaling-restoration-stale-six.json"
    [IO.File]::WriteAllText($engineeringStaleFloorPath, ($engineeringRestorationConfig | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $engineeringStaleFloorRejected = $false
    $engineeringStaleFloorError = ""
    try { & $invokeMonitorReadConfiguration $monitorAst $engineeringStaleFloorPath | Out-Null }
    catch {
        $engineeringStaleFloorError = $_.Exception.Message
        $engineeringStaleFloorRejected =
            $engineeringStaleFloorError -match "must bind the ordinary unsuspended production posture"
    }
    Assert-Condition $engineeringStaleFloorRejected `
        "Engineering scaling restoration must reject the superseded six-task arrival minimum as drift (actual: $engineeringStaleFloorError)."

    $publicEcsLoadResultPath = Join-Path $tempRoot "public-ecs-800-result.json"
    $publicEcsLoadResult = @{runId="public-800";phase="PublicEcs";status="completed";loadAccepted=$true;postureAccepted=$true;
        minimumWallClockSeconds=5400;workload=@{stage="800"};acceptance=@{passed=$true}}
    [IO.File]::WriteAllText($publicEcsLoadResultPath, ($publicEcsLoadResult|ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $natProgression = $production800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $natProgression.runId = "nat-requires-public-soak"
    $natProgression.phase = "NatRemoved"
    $natProgression | Add-Member -NotePropertyName predecessorResultPath -NotePropertyValue $publicEcsLoadResultPath -Force
    $natProgression | Add-Member -NotePropertyName predecessorResultSha256 -NotePropertyValue ((Get-FileHash $publicEcsLoadResultPath -Algorithm SHA256).Hash.ToLowerInvariant()) -Force
    $natProgressionPath = Join-Path $tempRoot "nat-requires-public-soak.json"
    [IO.File]::WriteAllText($natProgressionPath, ($natProgression|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $natRejectedLoadOnlyPredecessor = $false
    try { & $monitorScript -ConfigPath $natProgressionPath -Mode Validate | Out-Null }
    catch { $natRejectedLoadOnlyPredecessor = $_.Exception.Message -match "PublicEcs no-load posture|supervisor-sealed terminal result" }
    Assert-Condition $natRejectedLoadOnlyPredecessor "NatRemoved 800 must require the accepted 24-hour PublicEcs soak, not merely the earlier PublicEcs 800 load result."

    $productionLoadAcceptance = $production800 | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $productionLoadAcceptance.runId = "production-load-acceptance-lock"
    $productionLoadAcceptance.workload = [pscustomobject]@{stage="500";devices=510;durationSeconds=1800;screenshotBytes=40960;canaryDevices=10;workloadSchemaVersion="classpilot-tile-batch-v1";endpointShapeSha256="8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"}
    $productionLoadAcceptance.minimumWallClockSeconds = 1800
    $productionLoadAcceptance.deadlineUtc = [DateTimeOffset]::UtcNow.AddHours(1).ToString("o")
    $productionLoadAcceptance | Add-Member -NotePropertyName artifactsNotBeforeUtc -NotePropertyValue ([DateTimeOffset]::UtcNow.ToString("o")) -Force
    $productionLoadAcceptance | Add-Member -NotePropertyName automaticRollback -NotePropertyValue $true -Force
    $productionLoadAcceptance | Add-Member -NotePropertyName rollbackConfigPath -NotePropertyValue $dummyRollbackPath -Force
    $productionLoadAcceptance | Add-Member -NotePropertyName requireLoadAcceptance -NotePropertyValue $false -Force
    $productionLoadAcceptancePath = Join-Path $tempRoot "production-load-acceptance-lock.json"
    [IO.File]::WriteAllText($productionLoadAcceptancePath, ($productionLoadAcceptance|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $acceptanceWeakeningRejected = $false
    try { & $monitorScript -ConfigPath $productionLoadAcceptancePath -Mode Validate | Out-Null }
    catch { $acceptanceWeakeningRejected = $_.Exception.Message -match "requireLoadAcceptance=true" }
    Assert-Condition $acceptanceWeakeningRejected "Production load runs must not weaken requireLoadAcceptance=true."

    $productionShortTelemetry = $productionLoadAcceptance | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $productionShortTelemetry.runId = "production-load-duration-lock"
    $productionShortTelemetry.minimumWallClockSeconds = 60
    $productionShortTelemetry.requireLoadAcceptance = $true
    $productionShortTelemetryPath = Join-Path $tempRoot "production-load-duration-lock.json"
    [IO.File]::WriteAllText($productionShortTelemetryPath, ($productionShortTelemetry|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $shortTelemetryRejected = $false
    try { & $monitorScript -ConfigPath $productionShortTelemetryPath -Mode Validate | Out-Null }
    catch { $shortTelemetryRejected = $_.Exception.Message -match "minimumWallClockSeconds to equal workload.durationSeconds" }
    Assert-Condition $shortTelemetryRejected "Production load telemetry must cover the full immutable workload duration."

    $productionThresholdConfig = @{
        schemaVersion=1;runId="production-threshold-lock";phase="Application";evidenceDirectory=(Join-Path $tempRoot "production-threshold-evidence");
        automaticRollback=$true;rollbackConfigPath=$dummyRollbackPath;notificationTopicArn="arn:aws:sns:us-east-1:123456789012:production-alerts";
        minimumWallClockSeconds=60;deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o");pollSeconds=60;maxIterations=0;
        thresholds=@{ecsCpuMaximumPercent=71};resources=@{region="us-east-1";cluster="schoolpilot";apiService="api";workerService="worker";
          targetGroupArn="target";rdsInstanceId="db";redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";
          wafWebAclName="acl";wafDeviceRuleMetricName="device";wafApiRuleMetricName="api";route53HealthCheckId="health";route53AlarmName="route";
          expectedNatGatewayCount=2;expectedRoute53MeasureLatency=$true;expectedEcsAssignPublicIp=$false;ecsTaskSubnetIds=@("private-a","private-b");expectedRedisNodeType="cache.t4g.small"}
    }
    $productionThresholdPath = Join-Path $tempRoot "production-threshold-lock.json"
    [IO.File]::WriteAllText($productionThresholdPath, ($productionThresholdConfig|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $thresholdWeakeningRejected = $false
    try { & $monitorScript -ConfigPath $productionThresholdPath -Mode Validate | Out-Null }
    catch { $thresholdWeakeningRejected = $_.Exception.Message -match "threshold 'ecsCpuMaximumPercent' is immutable" }
    Assert-Condition $thresholdWeakeningRejected "Production reviewed resource/stale/cadence thresholds must be immutable."

    $productionRdsFreshnessConfig = $productionThresholdConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $productionRdsFreshnessConfig.runId = "production-rds-cpu-freshness-lock"
    $productionRdsFreshnessConfig.thresholds = @{rdsCpuMetricFreshnessMaximumSeconds=241}
    $productionRdsFreshnessPath = Join-Path $tempRoot "production-rds-cpu-freshness-lock.json"
    [IO.File]::WriteAllText($productionRdsFreshnessPath, ($productionRdsFreshnessConfig|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $rdsFreshnessWeakeningRejected = $false
    try { & $monitorScript -ConfigPath $productionRdsFreshnessPath -Mode Validate | Out-Null }
    catch { $rdsFreshnessWeakeningRejected = $_.Exception.Message -match "threshold 'rdsCpuMetricFreshnessMaximumSeconds' is immutable" }
    Assert-Condition $rdsFreshnessWeakeningRejected "Production RDS CPU publication-lag allowance must remain immutable."

    $global:SchoolPilotTestRouteLatency = $false
    $routeConfig = $monitorConfig | ConvertTo-Json -Depth 12 | ConvertFrom-Json -Depth 12
    $routeConfig.runId = "route53-three-ok-test"
    $routeConfig.phase = "Route53"
    $routeConfig.maxIterations = 3
    $routeConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
    $routeConfig.resources.expectedRoute53MeasureLatency = $false
    $routeConfigPath = Join-Path $tempRoot "route53-monitor.json"
    [IO.File]::WriteAllText($routeConfigPath, ($routeConfig | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    & $monitorScript -ConfigPath $routeConfigPath -Mode Monitor | Out-Null
    $routeResult = Get-Content -LiteralPath (Join-Path $evidenceDirectory "route53-three-ok-test-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
    Assert-Condition ($routeResult.status -eq "completed" -and $routeResult.iterations -eq 3) "Route53 phase must require three exact HTTP-200/alarm-OK periods."
    $global:SchoolPilotTestRouteLatency = $true

    $global:SchoolPilotTestNatAvailable = $false
    $earlyNatZero = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $earlyNatZero.runId = "early-nat-zero-contract"
    $earlyNatZero.phase = "NatRemoved"
    $earlyNatZero.resources.expectedNatGatewayCount = 0
    $earlyNatZeroPath = Join-Path $tempRoot "early-nat-zero.json"
    [IO.File]::WriteAllText($earlyNatZeroPath, ($earlyNatZero|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    & $monitorScript -ConfigPath $earlyNatZeroPath -Mode Monitor | Out-Null
    $earlyNatResult = Get-Content -LiteralPath (Join-Path $evidenceDirectory "early-nat-zero-contract-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestNatAvailable = $true
    Assert-Condition ($earlyNatResult.status -eq "completed") "Zero-NAT monitor contract failed: $($earlyNatResult|ConvertTo-Json -Compress -Depth 20)."

    $supervisorConfigPath = Join-Path $tempRoot "supervisor.json"
    $supervisorConfig = $monitorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $supervisorConfig.runId = "supervisor-validate"
    $supervisorConfig.evidenceDirectory = Join-Path $tempRoot "supervisor-validate-evidence"
    $supervisorConfig | Add-Member -NotePropertyName loadProgressPath -NotePropertyValue (Join-Path $tempRoot "supervisor-progress.jsonl") -Force
    $supervisorConfig | Add-Member -NotePropertyName loadSummaryPath -NotePropertyValue (Join-Path $tempRoot "supervisor-summary.json") -Force
    $supervisorConfig | Add-Member -NotePropertyName workload -NotePropertyValue ([pscustomobject]@{ stage = "test"; devices = 1; durationSeconds = 1; screenshotBytes = 1024; canaryDevices = 0 }) -Force
    $validateHarness = Join-Path $tempRoot "validate-only-harness.mjs"
    [IO.File]::WriteAllText($validateHarness, 'if(process.env.LOAD_RUN_ID!=="supervisor-validate")process.exit(8);console.log(JSON.stringify({ok:true,trafficStarted:false,runId:process.env.LOAD_RUN_ID,gateProfile:"launch",thresholdsEnforced:true,networkFamily:"IPv4"},null,2));', [Text.UTF8Encoding]::new($false))
    $supervisorConfig | Add-Member -NotePropertyName testRuntimeHarnessScriptPath -NotePropertyValue $validateHarness -Force
    $supervisorConfig | Add-Member -NotePropertyName expectedGeneratorPublicIp -NotePropertyValue "203.0.113.10" -Force
    $supervisorConfig | Add-Member -NotePropertyName testGeneratorPublicIpSequence -NotePropertyValue @("203.0.113.10") -Force
    $supervisorConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddHours(1).ToString("o")
    [IO.File]::WriteAllText($supervisorConfigPath, ($supervisorConfig | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    & $supervisorScript -ConfigPath $supervisorConfigPath -Mode Validate | Out-Null
    Assert-Condition ($LASTEXITCODE -eq 0) "Supervisor validation should accept a unique external long-run contract."

    foreach ($collisionCase in @(
        [pscustomobject]@{ id="progress-monitor-result"; field="loadProgressPath"; generatedSuffix="MONITOR-RESULT.JSON" },
        [pscustomobject]@{ id="summary-rollback-evidence"; field="loadSummaryPath"; generatedSuffix="ROLLBACK.JSONL" }
    )) {
        $collisionConfig = $supervisorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $collisionConfig.runId = "collision-$($collisionCase.id)"
        $collisionConfig.evidenceDirectory = Join-Path $tempRoot "collision-$($collisionCase.id)-evidence"
        $collisionConfig.loadProgressPath = Join-Path $tempRoot "collision-$($collisionCase.id)-progress.jsonl"
        $collisionConfig.loadSummaryPath = Join-Path $tempRoot "collision-$($collisionCase.id)-summary.json"
        $collisionConfig.($collisionCase.field) = Join-Path $collisionConfig.evidenceDirectory `
            "$($collisionConfig.runId.ToUpperInvariant())-$($collisionCase.generatedSuffix)"
        $collisionConfigPath = Join-Path $tempRoot "collision-$($collisionCase.id)-supervisor.json"
        [IO.File]::WriteAllText($collisionConfigPath, ($collisionConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $collisionRejected = $false
        try { & $supervisorScript -ConfigPath $collisionConfigPath -Mode Validate | Out-Null }
        catch { $collisionRejected = $_.Exception.Message -match "must not collide with generated supervisor, monitor, or rollback artifact" }
        Assert-Condition $collisionRejected "Supervisor must reject case-insensitive $($collisionCase.field) collisions with generated evidence artifacts."
    }

    $productionDelayHookConfig = $supervisorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $productionDelayHookConfig.testMode = $false
    $productionDelayHookConfig.PSObject.Properties.Remove("testGeneratorPublicIpSequence")
    $productionDelayHookConfig | Add-Member -NotePropertyName testPreReleaseGeneratorPublicIpDelayMilliseconds -NotePropertyValue 100 -Force
    $productionDelayHookPath = Join-Path $tempRoot "production-delay-hook-supervisor.json"
    [IO.File]::WriteAllText($productionDelayHookPath, ($productionDelayHookConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $productionDelayHookRejected = $false
    try { & $supervisorScript -ConfigPath $productionDelayHookPath -Mode Validate | Out-Null }
    catch { $productionDelayHookRejected = $_.Exception.Message -match "testPreReleaseGeneratorPublicIpDelayMilliseconds is forbidden outside isolated testMode" }
    Assert-Condition $productionDelayHookRejected "The deterministic pre-release IP-delay hook must remain confined to isolated testMode."

    $validPreflightExpression = '{ok:true,trafficStarted:false,runId:process.env.LOAD_RUN_ID,gateProfile:"launch",thresholdsEnforced:true,networkFamily:"IPv4"}'
    foreach ($invalidDocument in @(
        [pscustomobject]@{ id="root-array"; source="console.log(JSON.stringify([$validPreflightExpression]));"; expected="exactly one JSON object" },
        [pscustomobject]@{ id="leading-noise"; source="console.log('noise');console.log(JSON.stringify($validPreflightExpression));"; expected="did not return valid JSON" },
        [pscustomobject]@{ id="two-documents"; source="console.log(JSON.stringify($validPreflightExpression));console.log(JSON.stringify($validPreflightExpression));"; expected="did not return valid JSON" }
    )) {
        $invalidDocumentHarness = Join-Path $tempRoot "$($invalidDocument.id)-document.mjs"
        [IO.File]::WriteAllText($invalidDocumentHarness, $invalidDocument.source, [Text.UTF8Encoding]::new($false))
        $invalidDocumentConfig = $supervisorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $invalidDocumentConfig.runId = "document-$($invalidDocument.id)"
        $invalidDocumentConfig.evidenceDirectory = Join-Path $tempRoot "document-$($invalidDocument.id)-evidence"
        $invalidDocumentConfig.loadProgressPath = Join-Path $tempRoot "document-$($invalidDocument.id)-progress.jsonl"
        $invalidDocumentConfig.loadSummaryPath = Join-Path $tempRoot "document-$($invalidDocument.id)-summary.json"
        $invalidDocumentConfig.testRuntimeHarnessScriptPath = $invalidDocumentHarness
        $invalidDocumentConfigPath = Join-Path $tempRoot "document-$($invalidDocument.id)-supervisor.json"
        [IO.File]::WriteAllText($invalidDocumentConfigPath, ($invalidDocumentConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $invalidDocumentRejected = $false
        try { & $supervisorScript -ConfigPath $invalidDocumentConfigPath -Mode Validate | Out-Null }
        catch { $invalidDocumentRejected = $_.Exception.Message -match [regex]::Escape($invalidDocument.expected) }
        Assert-Condition $invalidDocumentRejected "Supervisor must reject the $($invalidDocument.id) preflight stdout document shape."
    }

    foreach ($invalidPreflight in @(
        [pscustomobject]@{ id="wrong-run-id"; runIdExpression='process.env.LOAD_RUN_ID+"-wrong"'; gateProfile='launch'; thresholds='true'; family='IPv4' },
        [pscustomobject]@{ id="partial-profile"; runIdExpression='process.env.LOAD_RUN_ID'; gateProfile='partial'; thresholds='true'; family='IPv4' },
        [pscustomobject]@{ id="thresholds-disabled"; runIdExpression='process.env.LOAD_RUN_ID'; gateProfile='launch'; thresholds='false'; family='IPv4' },
        [pscustomobject]@{ id="ipv6-family"; runIdExpression='process.env.LOAD_RUN_ID'; gateProfile='launch'; thresholds='true'; family='IPv6' }
    )) {
        $invalidHarnessPath = Join-Path $tempRoot "$($invalidPreflight.id)-preflight.mjs"
        $invalidHarnessSource = 'console.log(JSON.stringify({{ok:true,trafficStarted:false,runId:{0},gateProfile:"{1}",thresholdsEnforced:{2},networkFamily:"{3}"}}));' -f `
            $invalidPreflight.runIdExpression,$invalidPreflight.gateProfile,$invalidPreflight.thresholds,$invalidPreflight.family
        [IO.File]::WriteAllText($invalidHarnessPath, $invalidHarnessSource, [Text.UTF8Encoding]::new($false))
        $invalidPreflightConfig = $supervisorConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $invalidPreflightConfig.runId = "preflight-$($invalidPreflight.id)"
        $invalidPreflightConfig.evidenceDirectory = Join-Path $tempRoot "preflight-$($invalidPreflight.id)-evidence"
        $invalidPreflightConfig.loadProgressPath = Join-Path $tempRoot "preflight-$($invalidPreflight.id)-progress.jsonl"
        $invalidPreflightConfig.loadSummaryPath = Join-Path $tempRoot "preflight-$($invalidPreflight.id)-summary.json"
        $invalidPreflightConfig.testRuntimeHarnessScriptPath = $invalidHarnessPath
        $invalidPreflightConfigPath = Join-Path $tempRoot "preflight-$($invalidPreflight.id)-supervisor.json"
        [IO.File]::WriteAllText($invalidPreflightConfigPath, ($invalidPreflightConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $invalidPreflightRejected = $false
        try { & $supervisorScript -ConfigPath $invalidPreflightConfigPath -Mode Validate | Out-Null }
        catch { $invalidPreflightRejected = $_.Exception.Message -match "did not prove the bound runId, launch profile" }
        Assert-Condition $invalidPreflightRejected "Supervisor must reject the $($invalidPreflight.id) harness preflight contract."
    }

    # A test-only runtime monitor simulates a rollback that outlives the
    # monitor heartbeat. The supervisor must honor the fresh bounded rollback
    # heartbeat instead of applying its stale-monitor watchdog.
    $fakeHarnessOk = Join-Path $tempRoot "fake-harness-ok.mjs"
    $fakeHarnessFail = Join-Path $tempRoot "fake-harness-fail.mjs"
    $fakeHarnessPreflightFail = Join-Path $tempRoot "fake-harness-preflight-fail.mjs"
    $fakeSlowRollbackMonitor = Join-Path $tempRoot "fake-slow-rollback-monitor.ps1"
    $fakeLostHeartbeatMonitor = Join-Path $tempRoot "fake-lost-heartbeat-monitor.ps1"
    $fakeHealthyMonitor = Join-Path $tempRoot "fake-healthy-monitor.ps1"
    $fakeExitBeforeReleaseMonitor = Join-Path $tempRoot "fake-exit-before-release-monitor.ps1"
    $fakeHarnessPreamble = @'
import fs from "node:fs";
if(!process.env.LOAD_RUN_ID)process.exit(8);
if(process.argv.includes("--validate-config")){
  console.log(JSON.stringify({ok:true,trafficStarted:false,runId:process.env.LOAD_RUN_ID,gateProfile:"launch",thresholdsEnforced:true,networkFamily:"IPv4"}));
  process.exit(0);
}
const readyPath=process.env.LOAD_SUPERVISOR_READY_PATH;
const gatePath=process.env.LOAD_SUPERVISOR_START_GATE_PATH;
if(!readyPath||!gatePath)process.exit(9);
fs.writeFileSync(readyPath,JSON.stringify({schemaVersion:1,type:"load_supervisor_ready",runId:process.env.LOAD_RUN_ID,stage:process.env.LOAD_STAGE,harnessProcessId:process.pid,readyAt:new Date().toISOString(),trafficStarted:false}));
while(!fs.existsSync(gatePath))await new Promise(resolve=>setTimeout(resolve,25));
'@
    [IO.File]::WriteAllText($fakeHarnessOk, $fakeHarnessPreamble + "`nsetTimeout(() => process.exit(0), 4500);", [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($fakeHarnessFail, $fakeHarnessPreamble + "`nsetTimeout(() => process.exit(7), 1000);", [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($fakeHarnessPreflightFail, 'if(process.argv.includes("--validate-config")){process.exit(9)}setTimeout(() => process.exit(0), 5000);', [Text.UTF8Encoding]::new($false))
    $fakeMonitorPreamble = @'
param([string]$ConfigPath,[string]$ExpectedConfigSha256,[string]$Mode)
$c=Get-Content -LiteralPath $ConfigPath -Raw|ConvertFrom-Json -Depth 30
function W([string]$p,$v){
  $temporary="$p.$([Guid]::NewGuid().ToString('N')).tmp"
  try {
    [IO.File]::WriteAllText($temporary,($v|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
    [IO.File]::Move($temporary,$p,$true)
  }
  finally {if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
}
$mh=Join-Path $c.evidenceDirectory "$($c.runId)-monitor-heartbeat.json"
$rh=Join-Path $c.evidenceDirectory "$($c.runId)-rollback-heartbeat.json"
$mr=Join-Path $c.evidenceDirectory "$($c.runId)-monitor-result.json"
'@
    [IO.File]::WriteAllText($fakeSlowRollbackMonitor, $fakeMonitorPreamble + "`n" + @'
# Prove child startup may exceed the deliberately short five-second ongoing
# watchdog without releasing the traffic gate before the first heartbeat.
Start-Sleep -Seconds 6
$gate=Join-Path $c.evidenceDirectory "$($c.runId)-harness-start.json"
$gateDeadline=[DateTimeOffset]::UtcNow.AddSeconds(30)
$iteration=0
do {
  $iteration++
  W $mh @{runId=$c.runId;phase=$c.phase;timestamp=[DateTimeOffset]::UtcNow.ToString("o");iteration=$iteration;triggered=$false}
  if(Test-Path -LiteralPath $gate -PathType Leaf){break}
  Start-Sleep -Milliseconds 100
} while([DateTimeOffset]::UtcNow -lt $gateDeadline)
if(-not (Test-Path -LiteralPath $gate -PathType Leaf)){exit 91}
W $rh @{runId=$c.runId;action="NatRemoved";status="running";step="slow-test";timestamp=[DateTimeOffset]::UtcNow.ToString("o");deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o")}
Start-Sleep -Seconds 4
W $mr @{runId=$c.runId;phase=$c.phase;status="completed";postureAccepted=$true;acceptance=@{passed=$true}}
exit 0
'@, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($fakeLostHeartbeatMonitor, $fakeMonitorPreamble + "`nW `$mh @{runId=`$c.runId;phase=`$c.phase;timestamp=[DateTimeOffset]::UtcNow.ToString(`"o`");iteration=1;triggered=`$false}`nStart-Sleep -Seconds 8`nexit 0`n", [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($fakeHealthyMonitor, $fakeMonitorPreamble + "`n" + @'
for($i=0;$i-lt 12;$i++){W $mh @{runId=$c.runId;phase=$c.phase;timestamp=[DateTimeOffset]::UtcNow.ToString("o");iteration=($i+1);triggered=$false};Start-Sleep -Milliseconds 500}
exit 0
'@, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($fakeExitBeforeReleaseMonitor, $fakeMonitorPreamble + "`n" + @'
W $mh @{runId=$c.runId;phase=$c.phase;timestamp=[DateTimeOffset]::UtcNow.ToString("o");iteration=1;triggered=$false}
Start-Sleep -Milliseconds 500
exit 42
'@, [Text.UTF8Encoding]::new($false))

    function New-SupervisorRuntimeConfig {
        param([string]$RunId,[string]$MonitorPath,[string]$HarnessPath)
        $runtime = $supervisorConfig | ConvertTo-Json -Depth 30 | ConvertFrom-Json -Depth 30
        $runtime.runId = $RunId
        $runtime.evidenceDirectory = Join-Path $tempRoot "$RunId-evidence"
        $runtime.loadProgressPath = Join-Path $tempRoot "$RunId-progress.jsonl"
        $runtime.loadSummaryPath = Join-Path $tempRoot "$RunId-summary.json"
        $runtime | Add-Member -NotePropertyName supervisorWatchdog -NotePropertyValue ([pscustomobject]@{monitorHeartbeatStaleSeconds=5;rollbackHeartbeatStaleSeconds=10;pollSeconds=1;generatorIpCheckSeconds=1}) -Force
        $runtime | Add-Member -NotePropertyName testRuntimeMonitorScriptPath -NotePropertyValue $MonitorPath -Force
        $runtime | Add-Member -NotePropertyName testRuntimeHarnessScriptPath -NotePropertyValue $HarnessPath -Force
        $runtime.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(2).ToString("o")
        $path = Join-Path $tempRoot "$RunId-supervisor.json"
        [IO.File]::WriteAllText($path, ($runtime|ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
        return $path
    }

    $slowSupervisorPath = New-SupervisorRuntimeConfig "slow-rollback-watchdog" $fakeSlowRollbackMonitor $fakeHarnessOk
    try { & $supervisorScript -ConfigPath $slowSupervisorPath -Mode Run | Out-Null }
    catch {
        $slowDebug = @(
            "supervisor=$($_.Exception.Message)",
            "monitor.stderr=$((Get-Content -LiteralPath (Join-Path $tempRoot 'slow-rollback-watchdog-evidence\slow-rollback-watchdog-monitor.stderr.log') -Raw -ErrorAction SilentlyContinue))",
            "monitor.heartbeat=$((Get-Content -LiteralPath (Join-Path $tempRoot 'slow-rollback-watchdog-evidence\slow-rollback-watchdog-monitor-heartbeat.json') -Raw -ErrorAction SilentlyContinue))",
            "rollback.heartbeat=$((Get-Content -LiteralPath (Join-Path $tempRoot 'slow-rollback-watchdog-evidence\slow-rollback-watchdog-rollback-heartbeat.json') -Raw -ErrorAction SilentlyContinue))",
            "artifacts=$((Get-ChildItem -LiteralPath (Join-Path $tempRoot 'slow-rollback-watchdog-evidence') -ErrorAction SilentlyContinue).Name -join ',')"
        ) -join " | "
        throw $slowDebug
    }
    $slowSupervisorResult = Get-Content -LiteralPath (Join-Path $tempRoot "slow-rollback-watchdog-evidence\slow-rollback-watchdog-supervisor-result.json") -Raw | ConvertFrom-Json
    Assert-Condition ($slowSupervisorResult.status -eq "completed") "A fresh bounded rollback heartbeat must protect a slow rollback from the stale-monitor watchdog."

    $changedIpSupervisorPath = New-SupervisorRuntimeConfig "generator-ip-changed" $fakeHealthyMonitor $fakeHarnessOk
    $changedIpConfig = Get-Content -LiteralPath $changedIpSupervisorPath -Raw | ConvertFrom-Json -Depth 30
    $changedIpConfig.testGeneratorPublicIpSequence = @("203.0.113.10","203.0.113.11")
    [IO.File]::WriteAllText($changedIpSupervisorPath, ($changedIpConfig|ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $changedIpRejected = $false
    $changedIpError = ""
    try { & $supervisorScript -ConfigPath $changedIpSupervisorPath -Mode Run | Out-Null }
    catch { $changedIpError=$_.Exception.Message;$changedIpRejected = $changedIpError -match "changed during" }
    Assert-Condition $changedIpRejected "Supervisor must stop traffic without an infrastructure mutation if the generator public IPv4 changes (actual: $changedIpError)."

    $exitBeforeReleaseSupervisorPath = New-SupervisorRuntimeConfig "monitor-exit-before-release" $fakeExitBeforeReleaseMonitor $fakeHarnessOk
    $exitBeforeReleaseConfig = Get-Content -LiteralPath $exitBeforeReleaseSupervisorPath -Raw | ConvertFrom-Json -Depth 30
    $exitBeforeReleaseConfig | Add-Member -NotePropertyName testPreReleaseGeneratorPublicIpDelayMilliseconds -NotePropertyValue 1500 -Force
    [IO.File]::WriteAllText($exitBeforeReleaseSupervisorPath, ($exitBeforeReleaseConfig|ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $exitBeforeReleaseRejected = $false
    $exitBeforeReleaseError = ""
    try { & $supervisorScript -ConfigPath $exitBeforeReleaseSupervisorPath -Mode Run | Out-Null }
    catch {
        $exitBeforeReleaseError = $_.Exception.Message
        $exitBeforeReleaseRejected = $exitBeforeReleaseError -match "AWS monitor exited before releasing the load harness"
    }
    $exitBeforeReleaseGate = Join-Path $tempRoot "monitor-exit-before-release-evidence\monitor-exit-before-release-harness-start.json"
    Assert-Condition ($exitBeforeReleaseRejected -and -not (Test-Path -LiteralPath $exitBeforeReleaseGate)) "Supervisor must recheck monitor liveness after the generator-IP lookup and keep the traffic gate closed (actual: $exitBeforeReleaseError)."

    $lostSupervisorPath = New-SupervisorRuntimeConfig "lost-monitor-heartbeat" $fakeLostHeartbeatMonitor $fakeHarnessOk
    $lostRejected = $false
    try { & $supervisorScript -ConfigPath $lostSupervisorPath -Mode Run | Out-Null }
    catch { $lostRejected = $_.Exception.Message -match "no fresh, bounded rollback heartbeat" }
    Assert-Condition $lostRejected "Supervisor must fail closed and terminate traffic when monitor and rollback heartbeats are both lost."

    $badHarnessSupervisorPath = New-SupervisorRuntimeConfig "bad-harness-exit" $fakeHealthyMonitor $fakeHarnessFail
    $badHarnessRejected = $false
    $badHarnessError = ""
    try { & $supervisorScript -ConfigPath $badHarnessSupervisorPath -Mode Run | Out-Null }
    catch { $badHarnessError=$_.Exception.Message;$badHarnessRejected = $badHarnessError -match "load harness exited with code 7" }
    Assert-Condition $badHarnessRejected "Supervisor success must require harness exit code zero (actual: $badHarnessError)."

    $preflightFailSupervisorPath = New-SupervisorRuntimeConfig "harness-preflight-fail" $fakeHealthyMonitor $fakeHarnessPreflightFail
    $preflightFailureRejected = $false
    try { & $supervisorScript -ConfigPath $preflightFailSupervisorPath -Mode Run | Out-Null }
    catch { $preflightFailureRejected = $_.Exception.Message -match "--validate-config preflight failed" }
    Assert-Condition ($preflightFailureRejected -and -not (Test-Path -LiteralPath (Join-Path $tempRoot "harness-preflight-fail-evidence\harness-preflight-fail-harness.stdout.log"))) "Harness --validate-config must pass before sleep prevention or any traffic process starts."
    $monitorOnlyProductionPath = Join-Path $tempRoot "monitor-only-production.json"
    $monitorOnlyProduction = @{
        schemaVersion=1;runId="public-ecs-24h-soak";phase="PublicEcs";evidenceDirectory=(Join-Path $tempRoot "monitor-only-production-evidence");
        automaticRollback=$false;notificationTopicArn="arn:aws:sns:us-east-1:123456789012:test";pollSeconds=60;testMode=$false;maxIterations=0;
        minimumWallClockSeconds=86400;deadlineUtc=[DateTimeOffset]::UtcNow.AddHours(25).ToString("o");
        predecessorResultPath=$publicEcsLoadResultPath;predecessorResultSha256=(Get-FileHash $publicEcsLoadResultPath -Algorithm SHA256).Hash.ToLowerInvariant();
        thresholds=@{requireNatSixHourAcceptance=$true};resources=@{region="us-east-1";cluster="cluster";apiService="api";workerService="worker";
          targetGroupArn="target";rdsInstanceId="db";redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";
          wafWebAclName="acl";wafDeviceRuleMetricName="device";wafApiRuleMetricName="api";route53HealthCheckId="health";
          route53AlarmName="route";expectedNatGatewayCount=2;expectedRoute53MeasureLatency=$true}
    }
    [IO.File]::WriteAllText($monitorOnlyProductionPath, ($monitorOnlyProduction|ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $productionRollbackLockRejected = $false
    try { & $supervisorScript -ConfigPath $monitorOnlyProductionPath -Mode Validate -SupervisionKind MonitorOnly 2>$null | Out-Null }
    catch { $productionRollbackLockRejected = $_.Exception.Message -match "static AWS monitor/rollback" }
    Assert-Condition $productionRollbackLockRejected "Production monitoring must reject automaticRollback=false even for an exact 24-hour soak."
    $invalidMonitorOnly = $monitorOnlyProduction | ConvertTo-Json -Depth 10 | ConvertFrom-Json -Depth 10
    $invalidMonitorOnly.runId = "invalid-short-public-soak"
    $invalidMonitorOnly.minimumWallClockSeconds = 3600
    $invalidMonitorOnlyPath = Join-Path $tempRoot "invalid-monitor-only.json"
    [IO.File]::WriteAllText($invalidMonitorOnlyPath, ($invalidMonitorOnly|ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $invalidMonitorOnlyRejected = $false
    try { & $supervisorScript -ConfigPath $invalidMonitorOnlyPath -Mode Validate -SupervisionKind MonitorOnly | Out-Null }
    catch { $invalidMonitorOnlyRejected = $_.Exception.Message -match "exactly 24 hours" }
    Assert-Condition $invalidMonitorOnlyRejected "MonitorOnly must reject shortened production PublicEcs soaks."

    $reparseTarget = Join-Path $tempRoot "reparse-target"
    $reparseEvidence = Join-Path $tempRoot "reparse-evidence"
    [void][IO.Directory]::CreateDirectory($reparseTarget)
    New-Item -ItemType Junction -Path $reparseEvidence -Target $reparseTarget | Out-Null
    $reparseConfig = $supervisorConfig | ConvertTo-Json -Depth 10 | ConvertFrom-Json -Depth 10
    $reparseConfig.runId = "reparse-rejected"
    $reparseConfig.evidenceDirectory = $reparseEvidence
    $reparseConfigPath = Join-Path $tempRoot "reparse-supervisor.json"
    [IO.File]::WriteAllText($reparseConfigPath, ($reparseConfig|ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $reparseRejected = $false
    try { & $supervisorScript -ConfigPath $reparseConfigPath -Mode Validate | Out-Null }
    catch { $reparseRejected = $_.Exception.Message -match "reparse point" }
    Assert-Condition $reparseRejected "Supervisor must reject evidence paths traversing a junction/reparse point before writing artifacts."

    foreach ($phaseUnderTest in @("PublicEcs", "Final")) {
        $preflightRunId = "preflight-$($phaseUnderTest.ToLowerInvariant())-missing-waf"
        $preflightRollbackPath = Join-Path $tempRoot "$preflightRunId-rollback.json"
        $preflightRollback = @{
            schemaVersion=1;testMode=$true;testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";testAccountId="000000000000";
            runId=$preflightRunId;region="us-east-1";cluster="cluster";apiService="api";workerService="worker";
            evidenceDirectory=$evidenceDirectory;previousApiTaskDefinition="api-prev";previousWorkerTaskDefinition="worker-prev";
            emergencyApiTaskDefinition="arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1";
            emergencyApiTaskDefinitionFamily="test-emergency";emergencyApiContainerName="api";targetGroupArn="target";
            privateSubnetIds=@("private-a","private-b");ecsSecurityGroupIds=@("sg-1");privateRouteTableIds=@("rtb-a","rtb-b");
            vpcId="vpc";expectedNatGatewayCount=2;redisReplicationGroupId="redis";
            emergencyTaskDefinitionEvidence=@{
              currentTaskDefinition=@{cpu="1024";memory="2048";executionRoleArn="exec";taskRoleArn="task";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");containerDefinitions=@(@{name="api";image="repo@sha256:$('a'*64)"})};
              emergencyTaskDefinition=@{status="ACTIVE";family="test-emergency";taskDefinitionArn="arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1";
                cpu="1024";memory="2048";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");executionRoleArn="exec";taskRoleArn="task";
                containerDefinitions=@(@{name="api";image="repo@sha256:$('a'*64)";memory=2048})}
            }
        }
        [IO.File]::WriteAllText($preflightRollbackPath, ($preflightRollback|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $preflightConfigPath = Join-Path $tempRoot "$preflightRunId-monitor.json"
        $preflightExpectedNat = if ($phaseUnderTest -eq "PublicEcs") { 2 } else { 0 }
        $preflightConfig = @{
            schemaVersion=1;runId=$preflightRunId;phase=$phaseUnderTest;evidenceDirectory=$evidenceDirectory;testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";
            loadProgressPath=(Join-Path $tempRoot "$preflightRunId-progress.jsonl");loadSummaryPath=(Join-Path $tempRoot "$preflightRunId-summary.json");
            artifactsNotBeforeUtc=[DateTimeOffset]::UtcNow.AddSeconds(-1).ToString("o");automaticRollback=$true;rollbackConfigPath=$preflightRollbackPath;
            notificationTopicArn="arn:aws:sns:us-east-1:000000000000:test";pollSeconds=1;testMode=$true;maxIterations=1;minimumWallClockSeconds=0;
            deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o");harnessProcessId=$PID;
            harnessProcessStartedAtUtc=([DateTimeOffset](Get-Process -Id $PID).StartTime).ToUniversalTime().ToString("o");
            harnessProcessPath=(Get-Process -Id $PID).Path;workload=@{stage="preflight";devices=1;durationSeconds=1;screenshotBytes=1024;canaryDevices=0};
            resources=@{region="us-east-1";cluster="cluster";apiService="api";workerService="worker";targetGroupArn="target";rdsInstanceId="db";
              redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";wafWebAclName="acl";wafDeviceRuleMetricName="device";
              wafApiRuleMetricName="api";route53HealthCheckId="health";route53AlarmName="route";
              expectedNatGatewayCount=$preflightExpectedNat;expectedRoute53MeasureLatency=$true;expectedEcsAssignPublicIp=$true;
              ecsTaskSubnetIds=@("subnet-public-a","subnet-public-b");expectedRedisNodeType="cache.t4g.small"}
        }
        if ($phaseUnderTest -eq "Final") {
            $preflightConfig.redisResizeCompletedAtUtc = [DateTimeOffset]::UtcNow.AddHours(-1).ToString("o")
        }
        [IO.File]::WriteAllText($preflightConfigPath, ($preflightConfig|ConvertTo-Json -Depth 15), [Text.UTF8Encoding]::new($false))
        $preflightFailed = $false
        $preflightError = ""
        try { & $monitorScript -ConfigPath $preflightConfigPath -Mode Validate 2>$null | Out-Null }
        catch { $preflightError = $_.Exception.Message; $preflightFailed = $preflightError -match "preflight failed for action Waf" }
        Assert-Condition $preflightFailed "$phaseUnderTest load validation must preflight correlated WAF rollback even outside phase=Waf (actual: $preflightError)."
    }

    # Exercise a hard gate in a child pwsh so the monitor's required nonzero
    # exit cannot terminate this test host. The PATH-scoped aws.ps1 mock also
    # proves fatal-final reason propagation and typed WAF rollback dispatch.
    $childRoot = Join-Path $tempRoot "child-fatal"
    $childEvidence = Join-Path $childRoot "evidence"
    [void][IO.Directory]::CreateDirectory($childEvidence)
    $childAws = Join-Path $childRoot "aws.ps1"
    $wafFlag = Join-Path $childRoot "waf-count.flag"
    $childAwsSource = @'
$arguments = @($args | ForEach-Object { [string]$_ })
$service = $arguments[0]
$operation = $arguments[1]
function Arg([string]$name) { $index = [Array]::IndexOf($arguments, $name); if ($index -ge 0) { return $arguments[$index + 1] }; return $null }
if ($service -eq "ecs" -and $operation -eq "describe-services") {
  if ($env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM -and $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY -and
      $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE -and $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED -and
      (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM) -and
      -not (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED)) {
    [IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED,"1")
    [IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY,"1")
    $barrierDeadline=[DateTimeOffset]::UtcNow.AddSeconds(20)
    while(-not (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE)){
      if([DateTimeOffset]::UtcNow -ge $barrierDeadline){throw "Timed out waiting for the test sample barrier release."}
      Start-Sleep -Milliseconds 10
    }
  }
  $apiTask=if($env:SCHOOLPILOT_TEST_API_TASK_FLAG -and (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_API_TASK_FLAG)){Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_API_TASK_FLAG -Raw}else{"api-current"}
  $workerTask=if($env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG -and (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG)){Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG -Raw}else{"worker-current"}
  @{ services = @(
    @{ serviceName="api"; desiredCount=1; runningCount=1; pendingCount=0; taskDefinition=$apiTask; deploymentConfiguration=@{deploymentCircuitBreaker=@{enable=$true;rollback=$true};maximumPercent=200;minimumHealthyPercent=100;strategy="ROLLING"};deployments=@(@{id="ecs-svc/api-primary";status="PRIMARY";rolloutState="COMPLETED";taskDefinition=$apiTask;desiredCount=1;runningCount=1;pendingCount=0}); networkConfiguration=@{awsvpcConfiguration=@{subnets=@("private-a","private-b");securityGroups=@("sg-1");assignPublicIp="DISABLED"}} },
    @{ serviceName="worker"; desiredCount=1; runningCount=1; pendingCount=0; taskDefinition=$workerTask; deploymentConfiguration=@{deploymentCircuitBreaker=@{enable=$true;rollback=$true};maximumPercent=200;minimumHealthyPercent=100;strategy="ROLLING"};deployments=@(@{id="ecs-svc/worker-primary";status="PRIMARY";rolloutState="COMPLETED";taskDefinition=$workerTask;desiredCount=1;runningCount=1;pendingCount=0}); networkConfiguration=@{awsvpcConfiguration=@{subnets=@("private-a","private-b");securityGroups=@("sg-1");assignPublicIp="DISABLED"}} }
  )} | ConvertTo-Json -Depth 12 -Compress; exit 0
}
if ($service -eq "ecs" -and $operation -eq "update-service") { $td=Arg "--task-definition";$name=Arg "--service";if($env:SCHOOLPILOT_TEST_UPDATE_LOG){[IO.File]::AppendAllText($env:SCHOOLPILOT_TEST_UPDATE_LOG,($arguments -join " ")+[Environment]::NewLine)};if($td){$flag=if($name -eq "worker"){$env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG}else{$env:SCHOOLPILOT_TEST_API_TASK_FLAG};[IO.File]::WriteAllText($flag,$td)};'{}';exit 0 }
if ($service -eq "ecs" -and $operation -eq "list-tasks") {
  if ((Arg "--desired-status") -eq "RUNNING") { $name=Arg "--service-name"; @{taskArns=@("arn:aws:ecs:us-east-1:000000000000:task/cluster/$name-running")}|ConvertTo-Json -Compress; exit 0 }
  if ($env:SCHOOLPILOT_TEST_OOM_FLAG -and (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_OOM_FLAG)) { '{"taskArns":["arn:aws:ecs:us-east-1:000000000000:task/cluster/api-oom"]}';exit 0 }
  '{"taskArns":[]}'; exit 0
}
if ($service -eq "ecs" -and $operation -eq "describe-tasks") {
  if (($arguments -join " ") -match 'api-oom') {@{tasks=@(@{taskArn="arn:aws:ecs:us-east-1:000000000000:task/cluster/api-oom";group="service:api";stoppedAt=[DateTimeOffset]::UtcNow.ToString("o");stopCode="EssentialContainerExited";stoppedReason="OutOfMemoryError";containers=@(@{exitCode=137;reason="OutOfMemoryError"})})}|ConvertTo-Json -Depth 8 -Compress;exit 0}
  $running=@($arguments|Where-Object {$_ -match '-running$'});$tasks=@($running|ForEach-Object {$suffix=($_ -split '/')[-1];$name=if($suffix -match '^worker-'){'worker'}else{'api'};$flag=if($name -eq 'worker'){$env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG}else{$env:SCHOOLPILOT_TEST_API_TASK_FLAG};$taskDefinition=if($flag -and (Test-Path -LiteralPath $flag)){Get-Content -LiteralPath $flag -Raw}else{"$name-current"};@{taskArn=$_;taskDefinitionArn=$taskDefinition;lastStatus="RUNNING";desiredStatus="RUNNING";attachments=@(@{type="ElasticNetworkInterface";details=@(@{name="networkInterfaceId";value="eni-$suffix"})})}})
  @{tasks=$tasks}|ConvertTo-Json -Depth 8 -Compress;exit 0
}
if ($service -eq "elbv2" -and $operation -eq "describe-target-health") { '{"TargetHealthDescriptions":[{"TargetHealth":{"State":"healthy"}}]}'; exit 0 }
if ($service -eq "elbv2" -and $operation -eq "describe-target-group-attributes") { '{"Attributes":[{"Key":"deregistration_delay.timeout_seconds","Value":"300"},{"Key":"stickiness.enabled","Value":"false"}]}'; exit 0 }
if ($service -eq "application-autoscaling" -and $operation -eq "describe-scalable-targets") {
  $suspended=Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_AUTOSCALING_FLAG
  @{ScalableTargets=@(@{ResourceId="service/cluster/api";MinCapacity=1;MaxCapacity=6;SuspendedState=@{DynamicScalingInSuspended=$suspended;DynamicScalingOutSuspended=$suspended;ScheduledScalingSuspended=$suspended}})}|ConvertTo-Json -Depth 8 -Compress;exit 0
}
if ($service -eq "application-autoscaling" -and $operation -eq "register-scalable-target") {
  $state=Arg "--suspended-state"
  $hold=$state -match 'DynamicScalingInSuspended=true' -and $state -match 'DynamicScalingOutSuspended=true' -and $state -match 'ScheduledScalingSuspended=true'
  if($hold){[IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_AUTOSCALING_FLAG,"held")}elseif(Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_AUTOSCALING_FLAG){[IO.File]::Delete($env:SCHOOLPILOT_TEST_AUTOSCALING_FLAG)}
  '{}';exit 0
}
if ($service -eq "rds") { $pending=if($env:SCHOOLPILOT_TEST_PENDING){@{DBInstanceClass="db.t4g.small"}}else{@{}};@{DBInstances=@(@{DBInstanceStatus="available";AllocatedStorage=100;MaxAllocatedStorage=1000;PendingModifiedValues=$pending})}|ConvertTo-Json -Depth 6 -Compress; exit 0 }
if ($service -eq "elasticache" -and $operation -eq "describe-snapshots") {
  $snapshotTime=$env:SCHOOLPILOT_TEST_SNAPSHOT_TIME
  if($env:SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE -and (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE)){$snapshotTime=(Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE -Raw).Trim()}
  $snapshots=if($snapshotTime){@(@{SnapshotName="auto-test";SnapshotStatus="available";NodeSnapshots=@(@{SnapshotCreateTime=$snapshotTime})})}else{@()}
  @{Snapshots=$snapshots}|ConvertTo-Json -Depth 8 -Compress;exit 0
}
if ($service -eq "elasticache") { $node=if($env:SCHOOLPILOT_TEST_REDIS_TYPE){$env:SCHOOLPILOT_TEST_REDIS_TYPE}else{"cache.t4g.small"};$pending=if($env:SCHOOLPILOT_TEST_PENDING){@{CacheNodeType="cache.t4g.micro"}}else{@{}};@{ReplicationGroups=@(@{Status="available";CacheNodeType=$node;PendingModifiedValues=$pending})}|ConvertTo-Json -Depth 5 -Compress;exit 0 }
if ($service -eq "ec2" -and $operation -eq "describe-nat-gateways") {
  if($env:SCHOOLPILOT_TEST_NAT_ZERO -eq "1"){'{"NatGateways":[]}';exit 0}
  $gateways=@(
    @{NatGatewayId="nat-1";State="available";NatGatewayAddresses=@(@{AssociationId="eipassoc-1"})},
    @{NatGatewayId="nat-2";State="available";NatGatewayAddresses=@(@{AssociationId="eipassoc-2"})}
  )
  @{NatGateways=$gateways}|ConvertTo-Json -Depth 5 -Compress;exit 0
}
if ($service -eq "ec2" -and $operation -eq "describe-route-tables") {
  @{RouteTables=@(
    @{RouteTableId="rtb-private-a";Routes=@(@{DestinationCidrBlock="0.0.0.0/0";NatGatewayId="nat-1";State="active"})},
    @{RouteTableId="rtb-private-b";Routes=@(@{DestinationCidrBlock="0.0.0.0/0";NatGatewayId="nat-2";State="active"})}
  )}|ConvertTo-Json -Depth 8 -Compress;exit 0
}
if ($service -eq "ec2" -and $operation -eq "describe-network-interfaces") { $ids=@($arguments|Where-Object {$_ -match '^eni-'});@{NetworkInterfaces=@($ids|ForEach-Object {$association=if($env:SCHOOLPILOT_TEST_PUBLIC_IP -eq "1"){@{PublicIp="198.51.100.20"}}else{@{}};@{NetworkInterfaceId=$_;Association=$association}})}|ConvertTo-Json -Depth 6 -Compress;exit 0 }
if ($service -eq "route53" -and $operation -eq "get-health-check-status") { '{"HealthCheckObservations":[{"StatusReport":{"Status":"Success: HTTP Status Code 200"}}]}'; exit 0 }
if ($service -eq "route53" -and $operation -eq "get-health-check") { '{"HealthCheck":{"HealthCheckConfig":{"Type":"HTTPS","ResourcePath":"/health","MeasureLatency":true}}}'; exit 0 }
if ($service -eq "cloudwatch" -and $operation -eq "describe-alarms") { '{"MetricAlarms":[{"StateValue":"OK"}]}'; exit 0 }
if ($service -eq "cloudwatch" -and $operation -eq "get-metric-data") {
  $path = (Arg "--metric-data-queries").Substring(7)
  $queries = @(Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -Depth 20)
  $timestamp = if($env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP){$env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP}elseif($env:SCHOOLPILOT_TEST_METRIC_STEP_FILE){$n=if(Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_METRIC_STEP_FILE){[int](Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_METRIC_STEP_FILE -Raw)}else{0};$n++;[IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_METRIC_STEP_FILE,[string]$n);$stepIndex=[Math]::Min($n,2);([DateTimeOffset]$env:SCHOOLPILOT_TEST_METRIC_STEP_START).AddSeconds($stepIndex*[int]$env:SCHOOLPILOT_TEST_METRIC_STEP_SECONDS).ToString("o")}else{[DateTimeOffset]::UtcNow.ToString("o")}
  $swapValue=0
  if($env:SCHOOLPILOT_TEST_SWAP_COUNTER){$n=if(Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_SWAP_COUNTER){[int](Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_SWAP_COUNTER -Raw)}else{0};$n++;[IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_SWAP_COUNTER,[string]$n);$swapValue=$n*20971520}
  $results = @($queries | ForEach-Object {
    $metricId = [string]$_.Id
    if (($env:SCHOOLPILOT_TEST_WAF_SPARSE_ZERO -or $env:SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY) -and
        $metricId -in @("waf_device_blocked", "waf_api_blocked")) {
      $status = if ($env:SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY) { "PartialData" } else { "Complete" }
      @{Id=$metricId;StatusCode=$status;Timestamps=@();Values=@()}
    }
    else {
      $metricTimestamp = if ($env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS -and
          $metricId -in @("rds_cpu_credit", "rds_surplus_charged", "redis_cpu_credit")) {
        [DateTimeOffset]::UtcNow.AddSeconds(-[int]$env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS).ToString("o")
      } elseif ($env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS -and $metricId -eq "rds_cpu") {
        [DateTimeOffset]::UtcNow.AddSeconds(-[int]$env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS).ToString("o")
      } elseif ($env:SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS -and
          $metricId -notin @("rds_cpu_credit", "rds_surplus_charged", "redis_cpu_credit")) {
        [DateTimeOffset]::UtcNow.AddSeconds(-[int]$env:SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS).ToString("o")
      } elseif ($env:SCHOOLPILOT_TEST_METRIC_STEP_FILE -and
          $metricId -notin @("rds_cpu_credit", "rds_surplus_charged", "redis_cpu_credit")) {
        [DateTimeOffset]::UtcNow.ToString("o")
      } else { $timestamp }
      $value = switch -Regex ($metricId) {
        '^waf_device_blocked$' { if($env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK -or ($env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK_FILE -and (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK_FILE))){1}else{0}; break }
        '^waf_api_blocked$' { if($env:SCHOOLPILOT_TEST_WAF_API_BLOCK){1}else{0}; break }
        '^ecs_.*_(cpu_maximum|cpu|memory)$' { 10; break }
        '^rds_cpu$' { 10; break }
        '^rds_connections$' { 20; break }
        '^rds_free_storage$' { 85899345920; break }
        '^rds_free_memory$' { if($env:SCHOOLPILOT_TEST_AUX_BREACH){1}else{1073741824}; break }
        '^rds_swap$' { $swapValue; break }
        '^rds_cpu_credit$' { if($env:SCHOOLPILOT_TEST_AUX_BREACH){0}else{100}; break }
        '^rds_surplus_charged$' { if($env:SCHOOLPILOT_TEST_AUX_BREACH){1}else{0}; break }
        '^redis_cpu$' { 10; break }
        '^redis_memory$' { 20; break }
        '^redis_free$' { 209715200; break }
        '^redis_cpu_credit$' { if($env:SCHOOLPILOT_TEST_AUX_BREACH){0}else{100}; break }
        default { 0 }
      }
      if($metricId -eq "rds_cpu" -and $env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE){
        $boundaryStep=if(Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE){[int](Get-Content -LiteralPath $env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE -Raw)}else{0}
        $boundaryStep++;[IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE,[string]$boundaryStep)
        $base=[DateTimeOffset]$env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE
        $boundaryTimes=@($base.AddMinutes(-1).ToString("o"),$base.ToString("o"),$base.AddMinutes(1).ToString("o"),$base.AddMinutes(2).ToString("o"))
        $boundaryCount=[Math]::Min($boundaryStep,4)
        @{Id=$metricId;StatusCode="Complete";Timestamps=@($boundaryTimes[0..($boundaryCount-1)]);Values=@(1..$boundaryCount|ForEach-Object{70})}
      } elseif($metricId -eq "rds_cpu" -and $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN){
        $base=[DateTimeOffset]$env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE
        if($env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN -eq "gapped"){
          $runtimeTimes=@($base.ToString("o"),$base.AddMinutes(1).ToString("o"),$base.AddMinutes(3).ToString("o"));$runtimeValues=@(70,70,70)
        } else {
          $runtimeTimes=@($base.ToString("o"),$base.AddMinutes(1).ToString("o"),$base.AddMinutes(2).ToString("o"),$base.AddMinutes(3).ToString("o"))
          $runtimeValues=if($env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN -eq "three"){@(10,70,70,70)}elseif($env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN -eq "historical"){@(70,70,70,10)}else{@(10,70,10,10)}
        }
        @{Id=$metricId;StatusCode="Complete";Timestamps=$runtimeTimes;Values=$runtimeValues}
      } elseif($metricId -eq "rds_cpu" -and $env:SCHOOLPILOT_TEST_RDS_CPU_LOAD_WINDOW_START){
        $base=[DateTimeOffset]$env:SCHOOLPILOT_TEST_RDS_CPU_LOAD_WINDOW_START
        @{Id=$metricId;StatusCode="Complete";Timestamps=@($base.AddMinutes(-1).ToString("o"),$base.ToString("o"),$base.AddMinutes(1).ToString("o"),$base.AddMinutes(2).ToString("o"),$base.AddMinutes(3).ToString("o"),$base.AddMinutes(4).ToString("o"),[DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o"));Values=@(99,10,70,10,11,98,97)}
      } elseif($metricId -eq "rds_cpu" -and $env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL){
        $pointTime=[DateTimeOffset]$metricTimestamp
        $earlier=$pointTime.AddMilliseconds(-10).ToString("o")
        $beforeWindow=$pointTime.AddMinutes(-3).ToString("o")
        $afterCollection=$pointTime.AddMinutes(3).ToString("o")
        $backfillValue=if($env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL_SPIKE){70}else{12}
        @{Id=$metricId;StatusCode="Complete";Timestamps=@($metricTimestamp,$earlier,$beforeWindow,$afterCollection);Values=@($value,$backfillValue,99,98)}
      } else {
        @{Id=$metricId;StatusCode="Complete";Timestamps=@($metricTimestamp);Values=@($value)}
      }
    }
  })
  @{MetricDataResults=$results}|ConvertTo-Json -Depth 8 -Compress; exit 0
}
if ($service -eq "sns") { '{"MessageId":"test"}'; exit 0 }
if ($service -eq "wafv2" -and $operation -eq "get-web-acl") {
  $count = Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_WAF_FLAG
  $action = if ($count) { @{Count=@{}} } else { @{Block=@{}} }
  @{LockToken="lock";WebACL=@{Description="";DefaultAction=@{Allow=@{}};Rules=@(
    @{Name="Managed";Priority=1;OverrideAction=@{None=@{}};Statement=@{ManagedRuleGroupStatement=@{Name="Managed";VendorName="AWS"}};VisibilityConfig=@{SampledRequestsEnabled=$true;CloudWatchMetricsEnabled=$true;MetricName="managed"}},
    @{Name="DeviceIngestRateLimit";Priority=30;Action=$action;Statement=@{RateBasedStatement=@{Limit=100000;AggregateKeyType="IP"}};VisibilityConfig=@{SampledRequestsEnabled=$true;CloudWatchMetricsEnabled=$true;MetricName="device"}},
    @{Name="ApiRateLimit";Priority=40;Action=$action;Statement=@{RateBasedStatement=@{Limit=50000;AggregateKeyType="IP"}};VisibilityConfig=@{SampledRequestsEnabled=$true;CloudWatchMetricsEnabled=$true;MetricName="api"}}
  );VisibilityConfig=@{SampledRequestsEnabled=$true;CloudWatchMetricsEnabled=$true;MetricName="acl"}}}|ConvertTo-Json -Depth 20 -Compress; exit 0
}
if ($service -eq "wafv2" -and $operation -eq "update-web-acl") {
  if($env:SCHOOLPILOT_TEST_WAF_READY_PATH){[IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_WAF_READY_PATH,"ready")}
  if($env:SCHOOLPILOT_TEST_WAF_RELEASE_PATH){
    $releaseDeadline=[DateTimeOffset]::UtcNow.AddSeconds(20)
    while(-not (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_WAF_RELEASE_PATH) -and [DateTimeOffset]::UtcNow -lt $releaseDeadline){Start-Sleep -Milliseconds 50}
    if(-not (Test-Path -LiteralPath $env:SCHOOLPILOT_TEST_WAF_RELEASE_PATH)){throw "Timed out waiting for the test-only WAF release barrier."}
  } elseif($env:SCHOOLPILOT_TEST_WAF_DELAY){
    Start-Sleep -Seconds ([int]$env:SCHOOLPILOT_TEST_WAF_DELAY)
  }
  [IO.File]::WriteAllText($env:SCHOOLPILOT_TEST_WAF_FLAG,"count"); '{}'; exit 0
}
throw "Unexpected child AWS call: $($arguments -join ' ')"
'@
    [IO.File]::WriteAllText($childAws, $childAwsSource, [Text.UTF8Encoding]::new($false))
    $immediateFatalHarness = Join-Path $childRoot "immediate-fatal-after-start-gate.mjs"
    $immediateFatalHarnessSource = @'
import fs from "node:fs";
import path from "node:path";
if(process.argv.includes("--validate-config")){
  console.log(JSON.stringify({ok:true,trafficStarted:false,runId:process.env.LOAD_RUN_ID,gateProfile:"launch",thresholdsEnforced:true,networkFamily:"IPv4"}));
  process.exit(0);
}
const runId=process.env.LOAD_RUN_ID;
const stage=process.env.LOAD_STAGE;
const readyPath=process.env.LOAD_SUPERVISOR_READY_PATH;
const gatePath=process.env.LOAD_SUPERVISOR_START_GATE_PATH;
const progressPath=process.env.LOAD_EXTERNAL_PROGRESS_PATH;
const summaryPath=process.env.LOAD_EXTERNAL_SUMMARY_PATH;
const reason=process.env.SCHOOLPILOT_TEST_FATAL_REASON;
if(!runId||!stage||!readyPath||!gatePath||!progressPath||!summaryPath||!reason)process.exit(10);
fs.writeFileSync(readyPath,JSON.stringify({schemaVersion:1,type:"load_supervisor_ready",runId,stage,harnessProcessId:process.pid,readyAt:new Date().toISOString(),trafficStarted:false}));
while(!fs.existsSync(gatePath))await new Promise(resolve=>setTimeout(resolve,10));
const gate=JSON.parse(fs.readFileSync(gatePath,"utf8"));
const monitorHeartbeatPath=path.join(path.dirname(gatePath),`${runId}-monitor-heartbeat.json`);
if(!fs.existsSync(monitorHeartbeatPath))process.exit(11);
const monitorHeartbeat=JSON.parse(fs.readFileSync(monitorHeartbeatPath,"utf8"));
fs.writeFileSync(progressPath,JSON.stringify({schemaVersion:1,type:"progress",event:"start",runId,stage,timestamp:new Date().toISOString()})+"\n");
if(process.env.SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH){
  fs.writeFileSync(process.env.SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH,JSON.stringify({runId,reason,gate,monitorHeartbeat,observedAt:new Date().toISOString()}));
}
const fatalGate={reasonCodes:[reason],observedAt:new Date().toISOString(),kind:"tenant-isolation-probe"};
fs.appendFileSync(progressPath,JSON.stringify({schemaVersion:1,type:"fatal_gate",event:"fatal",runId,stage,timestamp:new Date().toISOString(),fatalGate})+"\n");
const summary={runId,stage,devices:1,declaredSecondSchoolCanaryDevices:0,run:{plannedTrafficSeconds:1,actualTrafficSeconds:1,completedConfiguredDuration:true},screenshotFixture:{decodedBytes:1024},thresholds:{passed:false},fatalGate};
fs.appendFileSync(progressPath,JSON.stringify({schemaVersion:1,type:"progress",event:"final",runId,stage,timestamp:new Date().toISOString(),fatalGate})+"\n");
const summaryReleasePath=process.env.SCHOOLPILOT_TEST_SUMMARY_RELEASE_PATH;
const summaryBlockedPath=process.env.SCHOOLPILOT_TEST_SUMMARY_BLOCKED_PATH;
const summaryTimeoutPath=process.env.SCHOOLPILOT_TEST_SUMMARY_TIMEOUT_PATH;
const summaryWaitMilliseconds=Number.parseInt(process.env.SCHOOLPILOT_TEST_SUMMARY_WAIT_MS||"0",10);
if(summaryReleasePath){
  if(!summaryBlockedPath||!summaryTimeoutPath||!Number.isSafeInteger(summaryWaitMilliseconds)||summaryWaitMilliseconds<=0)process.exit(12);
  fs.writeFileSync(summaryBlockedPath,JSON.stringify({runId,harnessProcessId:process.pid}));
}
if(process.env.SCHOOLPILOT_TEST_FINAL_WRITTEN_PATH)fs.writeFileSync(process.env.SCHOOLPILOT_TEST_FINAL_WRITTEN_PATH,"1");
if(summaryReleasePath){
  const summaryDeadline=performance.now()+summaryWaitMilliseconds;
  while(!fs.existsSync(summaryReleasePath)){
    if(performance.now()>=summaryDeadline){
      fs.writeFileSync(summaryTimeoutPath,JSON.stringify({runId,harnessProcessId:process.pid}));
      process.exit(13);
    }
    await new Promise(resolve=>setTimeout(resolve,10));
  }
}
fs.writeFileSync(summaryPath,JSON.stringify(summary));
process.exit(1);
'@
    [IO.File]::WriteAllText($immediateFatalHarness, $immediateFatalHarnessSource, [Text.UTF8Encoding]::new($false))
    $sampleBarrierCoordinator = Join-Path $childRoot "sample-barrier-coordinator.ps1"
    $sampleBarrierCoordinatorSource = @'
param(
  [string]$MonitorHeartbeatPath,
  [string]$ArmPath,
  [string]$ReadyPath,
  [string]$ReleasePath,
  [string]$TerminalProgressPath,
  [string]$CompletedPath,
  [int]$TimeoutSeconds = 30
)
$ErrorActionPreference="Stop"
function Wait-ForPath([string]$Path,[string]$Label){
  $deadline=[DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
  while(-not (Test-Path -LiteralPath $Path)){
    if([DateTimeOffset]::UtcNow -ge $deadline){throw "Timed out waiting for $Label."}
    Start-Sleep -Milliseconds 10
  }
}
Wait-ForPath $MonitorHeartbeatPath "the first monitor heartbeat"
[IO.File]::WriteAllText($ArmPath,"1")
Wait-ForPath $ReadyPath "the monitor to enter mocked AWS collection"
$blockedHeartbeat=Get-Content -LiteralPath $MonitorHeartbeatPath -Raw | ConvertFrom-Json
Wait-ForPath $TerminalProgressPath "the harness to commit terminal progress"
[IO.File]::WriteAllText($ReleasePath,"1")
[IO.File]::WriteAllText($CompletedPath,(@{
  runId=$blockedHeartbeat.runId
  lastCompletedIteration=$blockedHeartbeat.iteration
}|ConvertTo-Json -Compress))
'@
    [IO.File]::WriteAllText($sampleBarrierCoordinator, $sampleBarrierCoordinatorSource, [Text.UTF8Encoding]::new($false))
    $childProgress = Join-Path $childRoot "progress.jsonl"
    $childSummary = Join-Path $childRoot "summary.json"
    $childRollbackConfigPath = Join-Path $childRoot "rollback.json"
    $childRunId = "fatal-waf-test"
    $sleepProcess = "sleep-harness"
    Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $sleepProcess `
        -FilePath (Get-Process -Id $PID).Path `
        -ArgumentList @("-NoProfile", "-Command", "Start-Sleep -Seconds 60")
    Start-Sleep -Milliseconds 200
    $sleepProcessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $sleepProcess
    $childRollback = @{
        schemaVersion=1;testMode=$true;testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";testAccountId="000000000000";
        runId=$childRunId;region="us-east-1";cluster="cluster";apiService="api";workerService="worker";
        evidenceDirectory=$childEvidence;previousApiTaskDefinition="api-prev";previousWorkerTaskDefinition="worker-prev";
        emergencyApiTaskDefinition="arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1";
        emergencyApiTaskDefinitionFamily="test-emergency";emergencyApiContainerName="api";targetGroupArn="target";wafName="acl";wafId="id";wafScope="CLOUDFRONT";
        wafDeviceMetricName="device";wafApiMetricName="api";wafDeviceLimit=100000;wafApiLimit=50000;
        rollbackHeartbeatIntervalSeconds=1;emergencyTaskDefinitionEvidence=@{
          currentTaskDefinition=@{cpu="1024";memory="2048";executionRoleArn="exec";taskRoleArn="task";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");containerDefinitions=@(@{name="api";image="repo@sha256:$('b'*64)"})};
          emergencyTaskDefinition=@{status="ACTIVE";family="test-emergency";taskDefinitionArn="arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1";
            cpu="1024";memory="2048";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");executionRoleArn="exec";taskRoleArn="task";
            containerDefinitions=@(@{name="api";image="repo@sha256:$('b'*64)";memory=2048})}
        }
    }
    [IO.File]::WriteAllText($childRollbackConfigPath, ($childRollback|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    $childConfigPath = Join-Path $childRoot "monitor.json"
    $childStartedAt = [DateTimeOffset]::UtcNow.AddSeconds(-1)
    $childConfig = @{
        schemaVersion=1;runId=$childRunId;phase="Waf";evidenceDirectory=$childEvidence;testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";
        loadProgressPath=$childProgress;loadSummaryPath=$childSummary;
        artifactsNotBeforeUtc=$childStartedAt.ToString("o");automaticRollback=$true;rollbackConfigPath=$childRollbackConfigPath;
        notificationTopicArn="arn:aws:sns:us-east-1:000000000000:test";pollSeconds=1;testMode=$true;maxIterations=10;
        minimumWallClockSeconds=0;deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o");harnessProcessId=$sleepProcessIdentity.id;
        harnessProcessStartedAtUtc=([DateTimeOffset]$sleepProcessIdentity.startedAtUtc).ToUniversalTime().ToString("o");harnessProcessPath=$sleepProcessIdentity.path;
        requireLoadAcceptance=$true;workload=@{stage="fatal-stage";devices=1;durationSeconds=1;screenshotBytes=1024;canaryDevices=0};
        resources=@{region="us-east-1";cluster="cluster";apiService="api";workerService="worker";targetGroupArn="target";rdsInstanceId="db";
          redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";wafWebAclName="acl";wafDeviceRuleMetricName="device";
          wafApiRuleMetricName="api";route53HealthCheckId="health";route53AlarmName="route-alarm";expectedNatGatewayCount=2;expectedRoute53MeasureLatency=$true;
          expectedEcsAssignPublicIp=$false;ecsTaskSubnetIds=@("private-a","private-b");expectedRedisNodeType="cache.t4g.small"}
    }
    [IO.File]::WriteAllText($childConfigPath, ($childConfig|ConvertTo-Json -Depth 15), [Text.UTF8Encoding]::new($false))
    $childEnvironmentNames = @(
        "PATH",
        "SCHOOLPILOT_TEST_API_TASK_FLAG",
        "SCHOOLPILOT_TEST_AUTOSCALING_FLAG",
        "SCHOOLPILOT_TEST_AUX_BREACH",
        "SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS",
        "SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH",
        "SCHOOLPILOT_TEST_FATAL_REASON",
        "SCHOOLPILOT_TEST_FINAL_WRITTEN_PATH",
        "SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS",
        "SCHOOLPILOT_TEST_METRIC_STEP_FILE",
        "SCHOOLPILOT_TEST_METRIC_STEP_SECONDS",
        "SCHOOLPILOT_TEST_METRIC_STEP_START",
        "SCHOOLPILOT_TEST_METRIC_TIMESTAMP",
        "SCHOOLPILOT_TEST_NAT_ZERO",
        "SCHOOLPILOT_TEST_OOM_FLAG",
        "SCHOOLPILOT_TEST_PENDING",
        "SCHOOLPILOT_TEST_PUBLIC_IP",
        "SCHOOLPILOT_TEST_RDS_CPU_BACKFILL",
        "SCHOOLPILOT_TEST_RDS_CPU_BACKFILL_SPIKE",
        "SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE",
        "SCHOOLPILOT_TEST_RDS_CPU_LOAD_WINDOW_START",
        "SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS",
        "SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE",
        "SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN",
        "SCHOOLPILOT_TEST_REDIS_TYPE",
        "SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM",
        "SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED",
        "SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY",
        "SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE",
        "SCHOOLPILOT_TEST_SNAPSHOT_TIME",
        "SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE",
        "SCHOOLPILOT_TEST_SUMMARY_RELEASE_PATH",
        "SCHOOLPILOT_TEST_SUMMARY_BLOCKED_PATH",
        "SCHOOLPILOT_TEST_SUMMARY_TIMEOUT_PATH",
        "SCHOOLPILOT_TEST_SUMMARY_WAIT_MS",
        "SCHOOLPILOT_TEST_SWAP_COUNTER",
        "SCHOOLPILOT_TEST_UPDATE_LOG",
        "SCHOOLPILOT_TEST_WAF_API_BLOCK",
        "SCHOOLPILOT_TEST_WAF_DELAY",
        "SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK",
        "SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK_FILE",
        "SCHOOLPILOT_TEST_WAF_FLAG",
        "SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY",
        "SCHOOLPILOT_TEST_WAF_READY_PATH",
        "SCHOOLPILOT_TEST_WAF_RELEASE_PATH",
        "SCHOOLPILOT_TEST_WAF_SPARSE_ZERO",
        "SCHOOLPILOT_TEST_WAF_ZERO",
        "SCHOOLPILOT_TEST_WORKER_TASK_FLAG"
    )
    $childEnvironmentSnapshot = [ordered]@{}
    foreach ($childEnvironmentName in $childEnvironmentNames) {
        $childEnvironmentSnapshot[$childEnvironmentName] =
            [Environment]::GetEnvironmentVariable($childEnvironmentName, "Process")
    }
    $oldPath = [string]$childEnvironmentSnapshot["PATH"]
    $oomFlag = Join-Path $childRoot "oom.flag"
    $apiTaskFlag = Join-Path $childRoot "api-task.flag"
    $workerTaskFlag = Join-Path $childRoot "worker-task.flag"
    $updateLog = Join-Path $childRoot "ecs-update.log"
    $autoscalingFlag = Join-Path $childRoot "autoscaling-held.flag"
    $env:PATH = "$childRoot$([IO.Path]::PathSeparator)$oldPath"
    $env:SCHOOLPILOT_TEST_WAF_FLAG = $wafFlag
    $env:SCHOOLPILOT_TEST_OOM_FLAG = $oomFlag
    $env:SCHOOLPILOT_TEST_API_TASK_FLAG = $apiTaskFlag
    $env:SCHOOLPILOT_TEST_WORKER_TASK_FLAG = $workerTaskFlag
    $env:SCHOOLPILOT_TEST_UPDATE_LOG = $updateLog
    $env:SCHOOLPILOT_TEST_AUTOSCALING_FLAG = $autoscalingFlag
    $childMonitor = $null
    $oomOnlyMonitor = $null
    $oomOnlyHarness = $null
    $limitMonitor = $null
    $loadWindowMonitor = $null
    $loadWindowHarness = $null
    $futureFinalMonitor = $null
    $futureFinalHarness = $null
    $completedWaitMonitor = $null
    $completedWaitHarness = $null
    $slowRollbackProcess = $null
    $childBlockFailure = $null
    $childBlockCleanupFailures = [System.Collections.Generic.List[Exception]]::new()
    try {
        $childMonitor = "child-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $childMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$childConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "monitor.out") `
            -StandardErrorPath (Join-Path $childRoot "monitor.err")
        $evidencePath = Join-Path $childEvidence "$childRunId-aws-monitor.jsonl"
        $waitDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
        while (-not (Test-Path -LiteralPath $evidencePath) -and [DateTimeOffset]::UtcNow -lt $waitDeadline) { Start-Sleep -Milliseconds 100 }
        if (-not (Test-Path -LiteralPath $evidencePath)) {
            $childStartupState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $childMonitor
            $childStartupCompletion = $null
            $childStartupCleanupFailure = $null
            try {
                if ($childStartupState.hasExited) {
                    $childStartupCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
                        -Name $childMonitor -TimeoutMilliseconds 10000
                }
                else {
                    Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $childMonitor
                }
            }
            catch {
                $childStartupCleanupFailure = $_
            }
            if (-not $ownedTestProcesses.Contains($childMonitor)) { $childMonitor = $null }
            $childStartupOutput = Get-Content -LiteralPath (Join-Path $childRoot "monitor.out") -Raw -ErrorAction SilentlyContinue
            $childStartupError = Get-Content -LiteralPath (Join-Path $childRoot "monitor.err") -Raw -ErrorAction SilentlyContinue
            $childStartupCleanupMessage = if ($null -eq $childStartupCleanupFailure) {
                "<none>"
            }
            else {
                $childStartupCleanupFailure.Exception.Message
            }
            throw (
                "Child monitor did not begin sampling. state=$($childStartupState|ConvertTo-Json -Compress); " +
                "completion=$($childStartupCompletion|ConvertTo-Json -Compress); " +
                "cleanup=$childStartupCleanupMessage; " +
                "stdout=$childStartupOutput; stderr=$childStartupError"
            )
        }
        $fatal = @{reasonCodes=@("valid-http-403","cross-school-http-response","tenant-isolation-probe-unavailable","command-target-scope","invalid-teacher-response");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        $summary = @{runId=$childRunId;stage="fatal-stage";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};
          thresholds=@{passed=$false};fatalGate=$fatal}
        [IO.File]::WriteAllText($childSummary, ($summary|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $progress = @{schemaVersion=1;type="progress";event="final";runId=$childRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o");fatalGate=$fatal}
        [IO.File]::WriteAllText($childProgress, ($progress|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText($oomFlag, "oom")
        $childMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
            -Name $childMonitor -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $childMonitor = $null
        $childErrorText = Get-Content -LiteralPath (Join-Path $childRoot "monitor.err") -Raw -ErrorAction SilentlyContinue
        $childResult = Get-Content -LiteralPath (Join-Path $childEvidence "$childRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($childMonitorCompletion.exitCode -eq 2) "Hard-gate monitor should exit 2 after a successful rollback (exit=$($childMonitorCompletion.exitCode), stderr=$childErrorText, result=$($childResult|ConvertTo-Json -Compress -Depth 20))."
        $childEvidenceTail = Get-Content -LiteralPath $evidencePath -Tail 1 -ErrorAction SilentlyContinue
        Assert-Condition ($childResult.failures -contains "load:valid-http-403" -and $childResult.failures -contains "load:cross-school-http-response" -and $childResult.failures -contains "load:tenant-isolation-probe-unavailable" -and $childResult.failures -contains "load:command-target-scope" -and $childResult.failures -contains "load:invalid-teacher-response") "Final summary fatal reason codes must be preserved (actual: $($childResult|ConvertTo-Json -Compress -Depth 20); sample: $childEvidenceTail; stderr: $childErrorText)."
        Assert-Condition (@($childResult.failures | Where-Object { $_ -like "ecs_api_oom:*" }).Count -gt 0) "Priority test must observe the simultaneous API OOM."
        Assert-Condition ($childResult.rollback.attempted -and $childResult.rollback.action -eq "Application" -and $childResult.rollback.exitCode -eq 0) "Tenant-isolation regression must outrank a simultaneous OOM and restore the previous API/worker revisions."
        $sleepProcessState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $sleepProcess
        Assert-Condition $sleepProcessState.hasExited "Hard gate must terminate the bound harness process."
        [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $sleepProcess -TimeoutMilliseconds 10000)
        $sleepProcess = $null

        $oomOnlyRunId = "oom-already-emergency-monitor"
        $oomOnlyEvidence = Join-Path $childRoot "$oomOnlyRunId-evidence"
        [void][IO.Directory]::CreateDirectory($oomOnlyEvidence)
        $oomOnlyProgress = Join-Path $childRoot "$oomOnlyRunId-progress.jsonl"
        $oomOnlySummary = Join-Path $childRoot "$oomOnlyRunId-summary.json"
        $oomOnlyRollbackPath = Join-Path $childRoot "$oomOnlyRunId-rollback.json"
        $oomOnlyRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $oomOnlyRollback.runId = $oomOnlyRunId
        $oomOnlyRollback.evidenceDirectory = $oomOnlyEvidence
        [IO.File]::WriteAllText($oomOnlyRollbackPath, ($oomOnlyRollback | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $oomOnlyHarness = "oom-only-harness"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $oomOnlyHarness `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile", "-Command", "Start-Sleep -Seconds 60")
        Start-Sleep -Milliseconds 200
        $oomOnlyHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $oomOnlyHarness
        $oomOnlyConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $oomOnlyConfig.runId = $oomOnlyRunId
        $oomOnlyConfig.evidenceDirectory = $oomOnlyEvidence
        $oomOnlyConfig.loadProgressPath = $oomOnlyProgress
        $oomOnlyConfig.loadSummaryPath = $oomOnlySummary
        $oomOnlyConfig.rollbackConfigPath = $oomOnlyRollbackPath
        $oomOnlyConfig.artifactsNotBeforeUtc = [DateTimeOffset]::UtcNow.AddSeconds(-1).ToString("o")
        $oomOnlyConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o")
        $oomOnlyConfig.harnessProcessId = $oomOnlyHarnessIdentity.id
        $oomOnlyConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$oomOnlyHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $oomOnlyConfig.harnessProcessPath = $oomOnlyHarnessIdentity.path
        $oomOnlyConfigPath = Join-Path $childRoot "$oomOnlyRunId-monitor.json"
        [IO.File]::WriteAllText($oomOnlyConfigPath, ($oomOnlyConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText($apiTaskFlag, [string]$childRollback.emergencyApiTaskDefinition, [Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText($oomFlag, "oom", [Text.UTF8Encoding]::new($false))
        $updatesBeforeOomOnly = @(Get-Content -LiteralPath $updateLog -ErrorAction SilentlyContinue).Count
        $oomOnlyMonitor = "oom-only-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $oomOnlyMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$oomOnlyConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "$oomOnlyRunId.out") `
            -StandardErrorPath (Join-Path $childRoot "$oomOnlyRunId.err")
        $oomOnlyMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
            -Name $oomOnlyMonitor -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $oomOnlyMonitor = $null
        $oomOnlyResult = Get-Content -LiteralPath (Join-Path $oomOnlyEvidence "$oomOnlyRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        $updatesAfterOomOnly = @(Get-Content -LiteralPath $updateLog -ErrorAction SilentlyContinue).Count
        $oomOnlyHarnessState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $oomOnlyHarness
        Assert-Condition ($oomOnlyMonitorCompletion.exitCode -eq 3) `
            "An OOM on the active emergency revision must return monitor exit code 3 (actual=$($oomOnlyMonitorCompletion.exitCode))."
        Assert-Condition ($oomOnlyResult.status -eq "failed" -and
            @($oomOnlyResult.failures | Where-Object { $_ -like "ecs_api_oom:*" }).Count -gt 0) `
            "The emergency-active OOM result must preserve the OOM failure evidence (actual=$($oomOnlyResult|ConvertTo-Json -Compress -Depth 20))."
        Assert-Condition ($oomOnlyResult.rollback.attempted -and
            $oomOnlyResult.rollback.action -eq "Oom" -and
            $oomOnlyResult.rollback.exitCode -eq 1 -and
            $oomOnlyResult.rollback.error -match "already uses the reviewed emergency revision") `
            "The emergency-active OOM rollback result must explain why no replacement revision was selected (actual=$($oomOnlyResult.rollback|ConvertTo-Json -Compress -Depth 20))."
        Assert-Condition ($updatesAfterOomOnly -eq $updatesBeforeOomOnly) `
            "An emergency-active OOM must not issue an ECS service update (before=$updatesBeforeOomOnly, after=$updatesAfterOomOnly)."
        Assert-Condition $oomOnlyHarnessState.hasExited `
            "An emergency-active OOM must stop its bound traffic harness."
        [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $oomOnlyHarness -TimeoutMilliseconds 10000)
        $oomOnlyHarness = $null

        # The supervisor must arm the real monitor before releasing even the
        # first synthetic request. Exercise both immediate tenant exposure and
        # immediate probe availability failure through the full start-gate path.
        Remove-Item -LiteralPath $oomFlag -ErrorAction SilentlyContinue
        $oldImmediateFatalReason = $env:SCHOOLPILOT_TEST_FATAL_REASON
        $oldImmediateObservedPath = $env:SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH
        try {
            foreach ($startGateCase in @(
                [pscustomobject]@{ label="cross-school"; reason="cross-school-http-response"; expectApplicationRollback=$true },
                [pscustomobject]@{ label="probe-unavailable"; reason="tenant-isolation-probe-unavailable"; expectApplicationRollback=$false }
            )) {
                Remove-Item -LiteralPath $apiTaskFlag,$workerTaskFlag -ErrorAction SilentlyContinue
                $caseRunId = "start-gate-$($startGateCase.label)"
                $caseEvidence = Join-Path $childRoot "$caseRunId-evidence"
                [void][IO.Directory]::CreateDirectory($caseEvidence)
                $caseProgress = Join-Path $childRoot "$caseRunId-progress.jsonl"
                $caseSummary = Join-Path $childRoot "$caseRunId-summary.json"
                $caseObserved = Join-Path $childRoot "$caseRunId-observed.json"
                $caseRollbackPath = Join-Path $childRoot "$caseRunId-rollback.json"

                $caseRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
                $caseRollback.runId = $caseRunId
                $caseRollback.evidenceDirectory = $caseEvidence
                [IO.File]::WriteAllText($caseRollbackPath, ($caseRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))

                $caseConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
                $caseConfig.runId = $caseRunId
                $caseConfig.evidenceDirectory = $caseEvidence
                $caseConfig.loadProgressPath = $caseProgress
                $caseConfig.loadSummaryPath = $caseSummary
                $caseConfig.rollbackConfigPath = $caseRollbackPath
                $caseConfig.maxIterations = 10
                $caseConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(3).ToString("o")
                $caseConfig | Add-Member -NotePropertyName expectedGeneratorPublicIp -NotePropertyValue "203.0.113.10" -Force
                $caseConfig | Add-Member -NotePropertyName testGeneratorPublicIpSequence -NotePropertyValue @("203.0.113.10") -Force
                $caseConfig | Add-Member -NotePropertyName testRuntimeHarnessScriptPath -NotePropertyValue $immediateFatalHarness -Force
                if ($startGateCase.label -eq "cross-school") {
                    # Release traffic while the next monitor sample is inside its
                    # mocked AWS calls. The final progress refresh must still retain
                    # the immediate tenant-isolation reason and rollback priority.
                    # The next sample starts right after the arming heartbeat, so this
                    # delay only has to outlast one mock-AWS child launch; use the
                    # supervisor's maximum so a slow runner cannot commit terminal
                    # progress before the barrier engages.
                    $caseConfig | Add-Member -NotePropertyName testPreReleaseGeneratorPublicIpDelayMilliseconds -NotePropertyValue 5000 -Force
                }
                # The monitor heartbeat is written once per completed sweep, and the
                # cross-school barrier holds the post-release sweep inside mocked AWS,
                # so the stale bound must cover two slow sweeps. The same bound sets
                # the supervisor's harness-ready and monitor-arming deadlines.
                $caseConfig | Add-Member -NotePropertyName supervisorWatchdog -NotePropertyValue ([pscustomobject]@{
                    monitorHeartbeatStaleSeconds=$script:SupervisedSampleBudgetSeconds;rollbackHeartbeatStaleSeconds=10;pollSeconds=1;generatorIpCheckSeconds=1
                }) -Force
                $caseConfigPath = Join-Path $childRoot "$caseRunId-supervisor.json"
                [IO.File]::WriteAllText($caseConfigPath, ($caseConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))

                $env:SCHOOLPILOT_TEST_FATAL_REASON = $startGateCase.reason
                $env:SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH = $caseObserved
                $barrierCoordinatorProcess = $null
                $barrierCoordinatorExitCode = $null
                $barrierCompleted = $null
                $barrierReady = $null
                $barrierConsumed = $null
                $barrierEnvironment = [ordered]@{}
                if ($startGateCase.label -eq "cross-school") {
                    $barrierArm = Join-Path $childRoot "$caseRunId-sample-barrier-arm.flag"
                    $barrierReady = Join-Path $childRoot "$caseRunId-sample-barrier-ready.flag"
                    $barrierRelease = Join-Path $childRoot "$caseRunId-sample-barrier-release.flag"
                    $barrierConsumed = Join-Path $childRoot "$caseRunId-sample-barrier-consumed.flag"
                    $barrierCompleted = Join-Path $childRoot "$caseRunId-sample-barrier-completed.flag"
                    $terminalProgressWritten = Join-Path $childRoot "$caseRunId-terminal-progress-written.flag"
                    $summaryRelease = Join-Path $childRoot "$caseRunId-summary-release.flag"
                    $summaryBlocked = Join-Path $childRoot "$caseRunId-summary-blocked.json"
                    $summaryTimeout = Join-Path $childRoot "$caseRunId-summary-timeout.json"
                    $caseMonitorHeartbeat = Join-Path $caseEvidence "$caseRunId-monitor-heartbeat.json"
                    $barrierPaths = [ordered]@{
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM = $barrierArm
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY = $barrierReady
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE = $barrierRelease
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED = $barrierConsumed
                        SCHOOLPILOT_TEST_FINAL_WRITTEN_PATH = $terminalProgressWritten
                        # Hold the summary until the monitor stops the bound harness.
                        # The marker is deliberately never released in this fatal case;
                        # timing out fails the test instead of publishing a summary.
                        SCHOOLPILOT_TEST_SUMMARY_RELEASE_PATH = $summaryRelease
                        SCHOOLPILOT_TEST_SUMMARY_BLOCKED_PATH = $summaryBlocked
                        SCHOOLPILOT_TEST_SUMMARY_TIMEOUT_PATH = $summaryTimeout
                        SCHOOLPILOT_TEST_SUMMARY_WAIT_MS = [string]($script:SupervisedSampleBudgetSeconds * 1000)
                    }
                    foreach ($entry in $barrierPaths.GetEnumerator()) {
                        $barrierEnvironment[$entry.Key] = [Environment]::GetEnvironmentVariable($entry.Key, "Process")
                        [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
                    }
                    $barrierCoordinatorProcess = "barrier-coordinator:$caseRunId"
                    Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $barrierCoordinatorProcess `
                        -FilePath (Get-Process -Id $PID).Path `
                        -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$sampleBarrierCoordinator,
                            "-MonitorHeartbeatPath",$caseMonitorHeartbeat,"-ArmPath",$barrierArm,"-ReadyPath",$barrierReady,
                            "-ReleasePath",$barrierRelease,"-TerminalProgressPath",$terminalProgressWritten,"-CompletedPath",$barrierCompleted,"-TimeoutSeconds",$script:SupervisedSampleBudgetSeconds) `
                        -StandardOutputPath (Join-Path $childRoot "$caseRunId-barrier.out") `
                        -StandardErrorPath (Join-Path $childRoot "$caseRunId-barrier.err")
                }
                $supervisorRejected = $false
                $supervisorFailure = ""
                $supervisorError = $null
                $barrierCoordinatorCleanupFailures = [System.Collections.Generic.List[Exception]]::new()
                try { & $supervisorScript -ConfigPath $caseConfigPath -Mode Run | Out-Null }
                catch {
                    $supervisorError = $_
                    $supervisorFailure = $_.Exception.Message
                    $supervisorRejected = $supervisorFailure -match "AWS monitor exited with code 2"
                }
                finally {
                    if ($null -ne $barrierCoordinatorProcess) {
                        try {
                            $barrierCoordinatorCompletion = Complete-OwnedTestProcess `
                                -Registry $ownedTestProcesses -Name $barrierCoordinatorProcess `
                                -TimeoutMilliseconds 10000
                            $barrierCoordinatorExitCode = $barrierCoordinatorCompletion.exitCode
                        }
                        catch {
                            $barrierCoordinatorCleanupFailures.Add([InvalidOperationException]::new(
                                "$caseRunId barrier coordinator cleanup failed.",
                                $_.Exception
                            ))
                        }
                        if (-not $ownedTestProcesses.Contains($barrierCoordinatorProcess)) {
                            $barrierCoordinatorProcess = $null
                        }
                    }
                    try {
                        foreach ($entry in $barrierEnvironment.GetEnumerator()) {
                            [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
                        }
                    }
                    catch {
                        $barrierCoordinatorCleanupFailures.Add([InvalidOperationException]::new(
                            "$caseRunId barrier environment restoration failed.",
                            $_.Exception
                        ))
                    }
                }
                if ($barrierCoordinatorCleanupFailures.Count -gt 0) {
                    if ($null -ne $supervisorError -and -not $supervisorRejected) {
                        Add-OwnedTestProcessCleanupFailures -Exception $supervisorError.Exception `
                            -CleanupFailures ([Exception[]]$barrierCoordinatorCleanupFailures.ToArray())
                        throw $supervisorError
                    }
                    throw [AggregateException]::new(
                        "$caseRunId barrier coordinator cleanup failed.",
                        [Exception[]]$barrierCoordinatorCleanupFailures.ToArray()
                    )
                }
                Assert-Condition $supervisorRejected "$caseRunId must fail through the armed monitor, not before monitor startup (actual: $supervisorFailure)."
                Assert-Condition (Test-Path -LiteralPath $caseObserved) "$caseRunId harness never observed the released start gate."
                if ($startGateCase.label -eq "cross-school") {
                    $barrierError = Get-Content -LiteralPath (Join-Path $childRoot "$caseRunId-barrier.err") -Raw -ErrorAction SilentlyContinue
                    Assert-Condition ($barrierCoordinatorExitCode -eq 0 -and (Test-Path -LiteralPath $barrierCompleted) -and
                        (Test-Path -LiteralPath $barrierReady) -and (Test-Path -LiteralPath $barrierConsumed) -and
                        (Test-Path -LiteralPath $terminalProgressWritten)) `
                        "$caseRunId did not exercise the deterministic in-sample AWS barrier (exit=$barrierCoordinatorExitCode; stderr=$barrierError)."
                    Assert-Condition ((Get-Item -LiteralPath $barrierReady).LastWriteTimeUtc -le (Get-Item -LiteralPath $terminalProgressWritten).LastWriteTimeUtc) `
                        "$caseRunId terminal evidence must be committed while the monitor is inside mocked AWS collection."
                    Assert-Condition ((Test-Path -LiteralPath $summaryBlocked) -and
                        -not (Test-Path -LiteralPath $summaryRelease) -and -not (Test-Path -LiteralPath $summaryTimeout)) `
                        "$caseRunId must stop the harness while its summary is blocked, without a release or wait timeout."
                    Assert-Condition (-not (Test-Path -LiteralPath $caseSummary)) `
                        "$caseRunId must preserve and act on terminal fatal evidence before the atomic summary exists."
                    $barrierReceipt = Get-Content -LiteralPath $barrierCompleted -Raw | ConvertFrom-Json
                    $terminalHeartbeat = Get-Content -LiteralPath $caseMonitorHeartbeat -Raw | ConvertFrom-Json
                    Assert-Condition ($barrierReceipt.runId -eq $caseRunId -and $terminalHeartbeat.runId -eq $caseRunId -and
                        $terminalHeartbeat.triggered -and [int]$terminalHeartbeat.iteration -eq ([int]$barrierReceipt.lastCompletedIteration + 1)) `
                        "$caseRunId must act on fatal evidence in the AWS sample held by the barrier, not a later sweep."
                    $boundMonitorConfig = Get-Content -LiteralPath (Join-Path $caseEvidence "$caseRunId-bound-monitor-config.json") -Raw | ConvertFrom-Json
                    $remainingHarness = Get-Process -Id ([int]$boundMonitorConfig.harnessProcessId) -ErrorAction SilentlyContinue
                    $sameHarness = $null -ne $remainingHarness -and
                        [string]::Equals([string]$remainingHarness.Path, [string]$boundMonitorConfig.harnessProcessPath, [StringComparison]::OrdinalIgnoreCase) -and
                        [math]::Abs((([DateTimeOffset]$remainingHarness.StartTime).ToUniversalTime() - [DateTimeOffset]$boundMonitorConfig.harnessProcessStartedAtUtc).TotalSeconds) -le 2
                    Assert-Condition (-not $sameHarness) "$caseRunId must terminate the exact bound harness before its summary can be released."
                }

                $caseObservation = Get-Content -LiteralPath $caseObserved -Raw | ConvertFrom-Json -Depth 20
                Assert-Condition ($caseObservation.reason -eq $startGateCase.reason) "$caseRunId observed the wrong immediate fatal reason."
                Assert-Condition ($caseObservation.gate.runId -eq $caseRunId -and $caseObservation.monitorHeartbeat.runId -eq $caseRunId) "$caseRunId gate and monitor heartbeat identities must match."
                Assert-Condition ([DateTimeOffset]$caseObservation.gate.releasedAt -ge [DateTimeOffset]$caseObservation.monitorHeartbeat.timestamp) "$caseRunId traffic gate opened before the first monitor heartbeat."

                $caseMonitorResultPath = Join-Path $caseEvidence "$caseRunId-monitor-result.json"
                Assert-Condition (Test-Path -LiteralPath $caseMonitorResultPath) "$caseRunId monitor did not write its failure result."
                $caseMonitorResult = Get-Content -LiteralPath $caseMonitorResultPath -Raw | ConvertFrom-Json -Depth 20
                Assert-Condition ($caseMonitorResult.failures -contains "load:$($startGateCase.reason)") "$caseRunId monitor did not preserve the immediate fatal reason (result=$($caseMonitorResult|ConvertTo-Json -Compress -Depth 20))."
                if ($startGateCase.expectApplicationRollback) {
                    Assert-Condition ($caseMonitorResult.rollback.attempted -and $caseMonitorResult.rollback.action -eq "Application" -and $caseMonitorResult.rollback.exitCode -eq 0) "$caseRunId must invoke the pre-approved Application rollback."
                }
                else {
                    Assert-Condition (-not $caseMonitorResult.rollback.attempted) "$caseRunId availability-indeterminate failure must stop without guessing at an infrastructure mutation."
                }
            }
        }
        finally {
            if ($null -eq $oldImmediateFatalReason) { Remove-Item Env:SCHOOLPILOT_TEST_FATAL_REASON -ErrorAction SilentlyContinue }
            else { $env:SCHOOLPILOT_TEST_FATAL_REASON = $oldImmediateFatalReason }
            if ($null -eq $oldImmediateObservedPath) { Remove-Item Env:SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH -ErrorAction SilentlyContinue }
            else { $env:SCHOOLPILOT_TEST_FATAL_OBSERVED_PATH = $oldImmediateObservedPath }
        }

        if ($StartGateCasesOnly) {
            Write-Host ("Rollout startup prerequisites and start-gate cases: PASS ({0} assertions, {1:N1}s)" -f $script:AssertionCount,$testClock.Elapsed.TotalSeconds)
            return
        }

        $slowRollbackConfig = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $slowRollbackConfig.runId = "slow-waf-rollback-heartbeat"
        $slowEvidence = Join-Path $childRoot "slow-heartbeat-evidence"
        [void][IO.Directory]::CreateDirectory($slowEvidence)
        $slowRollbackConfig.evidenceDirectory = $slowEvidence
        [IO.File]::WriteAllText($childRollbackConfigPath, ($slowRollbackConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        Remove-Item -LiteralPath $wafFlag -ErrorAction SilentlyContinue
        $slowWafReadyPath = Join-Path $childRoot "slow-waf.ready"
        $slowWafReleasePath = Join-Path $childRoot "slow-waf.release"
        Remove-Item -LiteralPath $slowWafReadyPath,$slowWafReleasePath -ErrorAction SilentlyContinue
        $env:SCHOOLPILOT_TEST_WAF_READY_PATH = $slowWafReadyPath
        $env:SCHOOLPILOT_TEST_WAF_RELEASE_PATH = $slowWafReleasePath
        $slowRollbackExitCode = $null
        $slowRollbackFailure = $null
        $slowRollbackCleanupFailures = [System.Collections.Generic.List[Exception]]::new()
        try {
            $slowRollbackProcess = "slow-waf-rollback"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $slowRollbackProcess `
                -FilePath (Get-Process -Id $PID).Path `
                -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$rollbackScript,"-ConfigPath",$childRollbackConfigPath,"-Action","Waf","-Mode","Execute") `
                -StandardOutputPath (Join-Path $childRoot "slow-rollback.out") `
                -StandardErrorPath (Join-Path $childRoot "slow-rollback.err")
            $slowWafReadyDeadline = [DateTimeOffset]::UtcNow.AddSeconds(30)
            while (-not (Test-Path -LiteralPath $slowWafReadyPath) -and [DateTimeOffset]::UtcNow -lt $slowWafReadyDeadline) {
                Start-Sleep -Milliseconds 100
                if ((Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $slowRollbackProcess).hasExited) { break }
            }
            $slowHeartbeatPath = Join-Path $slowEvidence "slow-waf-rollback-heartbeat-rollback-heartbeat.json"
            $slowHeartbeatDeadline = [DateTimeOffset]::UtcNow.AddSeconds(10)
            while (-not (Test-Path -LiteralPath $slowHeartbeatPath) -and [DateTimeOffset]::UtcNow -lt $slowHeartbeatDeadline) {
                Start-Sleep -Milliseconds 100
                if ((Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $slowRollbackProcess).hasExited) { break }
            }
            $slowStateDebugPath = Join-Path $slowEvidence "slow-waf-rollback-heartbeat-rollback-state.json"
            $slowStateDebug = Get-Content -LiteralPath $slowStateDebugPath -Raw -ErrorAction SilentlyContinue
            if (-not (Test-Path -LiteralPath $slowWafReadyPath) -or
                -not (Test-Path -LiteralPath $slowHeartbeatPath)) {
                $slowFailureDiagnostics = Close-OwnedTestProcessForDiagnostics `
                    -Registry $ownedTestProcesses `
                    -Name $slowRollbackProcess `
                    -StandardOutputPath (Join-Path $childRoot "slow-rollback.out") `
                    -StandardErrorPath (Join-Path $childRoot "slow-rollback.err")
                if (-not $ownedTestProcesses.Contains($slowRollbackProcess)) { $slowRollbackProcess = $null }
                $missingSlowArtifact = if (-not (Test-Path -LiteralPath $slowWafReadyPath)) {
                    "the deterministic WAF mutation barrier"
                }
                else {
                    "its independent heartbeat"
                }
                throw (
                    "Slow rollback did not reach $missingSlowArtifact " +
                    "(state=$($slowFailureDiagnostics.state|ConvertTo-Json -Compress); " +
                    "rollbackState=$slowStateDebug; cleanup=$($slowFailureDiagnostics.cleanupFailure); " +
                    "stdout=$($slowFailureDiagnostics.standardOutput); stderr=$($slowFailureDiagnostics.standardError))."
                )
            }
            $firstSlowHeartbeatWrite = (Get-Item -LiteralPath $slowHeartbeatPath).LastWriteTimeUtc
            $secondSlowHeartbeatWrite = $firstSlowHeartbeatWrite
            $slowHeartbeatAdvanceDeadline = [DateTimeOffset]::UtcNow.AddSeconds(10)
            while ($secondSlowHeartbeatWrite -le $firstSlowHeartbeatWrite -and
                [DateTimeOffset]::UtcNow -lt $slowHeartbeatAdvanceDeadline) {
                Start-Sleep -Milliseconds 100
                $secondSlowHeartbeatWrite = (Get-Item -LiteralPath $slowHeartbeatPath).LastWriteTimeUtc
                if ((Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $slowRollbackProcess).hasExited) { break }
            }
            Assert-Condition ($secondSlowHeartbeatWrite -gt $firstSlowHeartbeatWrite) "Rollback heartbeat must keep advancing while a slow AWS mutation blocks the monitor process."
            [IO.File]::WriteAllText($slowWafReleasePath, "release", [Text.UTF8Encoding]::new($false))
            $slowRollbackCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
                -Name $slowRollbackProcess -TimeoutMilliseconds 15000
            $slowRollbackExitCode = $slowRollbackCompletion.exitCode
            $slowRollbackProcess = $null
            Assert-Condition ($slowRollbackExitCode -eq 0) "Slow WAF rollback must complete within its bounded action deadline."
        }
        catch {
            $slowRollbackFailure = $_
        }
        finally {
            if (-not (Test-Path -LiteralPath $slowWafReleasePath)) {
                try {
                    [IO.File]::WriteAllText($slowWafReleasePath, "release", [Text.UTF8Encoding]::new($false))
                }
                catch {
                    $slowRollbackCleanupFailures.Add([InvalidOperationException]::new(
                        "Slow WAF rollback release-barrier cleanup failed.",
                        $_.Exception
                    ))
                }
            }
            if ($null -ne $slowRollbackProcess) {
                try {
                    Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $slowRollbackProcess
                }
                catch {
                    $slowRollbackCleanupFailures.Add([InvalidOperationException]::new(
                        "Slow WAF rollback owned-process cleanup failed.",
                        $_.Exception
                    ))
                }
                if (-not $ownedTestProcesses.Contains($slowRollbackProcess)) { $slowRollbackProcess = $null }
            }
            try {
                foreach ($slowEnvironmentName in @(
                    "SCHOOLPILOT_TEST_WAF_READY_PATH",
                    "SCHOOLPILOT_TEST_WAF_RELEASE_PATH"
                )) {
                    [Environment]::SetEnvironmentVariable(
                        $slowEnvironmentName,
                        $childEnvironmentSnapshot[$slowEnvironmentName],
                        "Process"
                    )
                }
            }
            catch {
                $slowRollbackCleanupFailures.Add([InvalidOperationException]::new(
                    "Slow WAF rollback environment restoration failed.",
                    $_.Exception
                ))
            }
        }
        if ($null -ne $slowRollbackFailure -and $slowRollbackCleanupFailures.Count -gt 0) {
            Add-OwnedTestProcessCleanupFailures -Exception $slowRollbackFailure.Exception `
                -CleanupFailures ([Exception[]]$slowRollbackCleanupFailures.ToArray())
            throw $slowRollbackFailure
        }
        if ($null -ne $slowRollbackFailure) { throw $slowRollbackFailure }
        if ($slowRollbackCleanupFailures.Count -gt 0) {
            throw [AggregateException]::new(
                "Slow WAF rollback cleanup failed.",
                [Exception[]]$slowRollbackCleanupFailures.ToArray()
            )
        }
        foreach ($redirectedPath in @(
            (Join-Path $childRoot "slow-rollback.out"),
            (Join-Path $childRoot "slow-rollback.err")
        )) {
            $redirectProbe = [IO.File]::Open(
                $redirectedPath,
                [IO.FileMode]::Open,
                [IO.FileAccess]::ReadWrite,
                [IO.FileShare]::None
            )
            $redirectProbe.Dispose()
        }
        $slowState = Get-Content -LiteralPath (Join-Path $slowEvidence "slow-waf-rollback-heartbeat-rollback-state.json") -Raw | ConvertFrom-Json
        Assert-Condition ($slowState.status -eq "completed") "Rollback progress state must end in completed after the slow action."
        foreach ($slowEvidenceFile in @(Get-ChildItem -LiteralPath $slowEvidence -File -Force)) {
            $slowEvidenceProbe = [IO.File]::Open(
                $slowEvidenceFile.FullName,
                [IO.FileMode]::Open,
                [IO.FileAccess]::ReadWrite,
                [IO.FileShare]::None
            )
            $slowEvidenceProbe.Dispose()
        }
        Remove-TestDirectoryWithRetry -Path $slowEvidence
        Assert-Condition (-not (Test-Path -LiteralPath $slowEvidence)) "Rollback parent exit must release every heartbeat descendant evidence handle."

        Remove-Item -LiteralPath $oomFlag -ErrorAction SilentlyContinue
        $uncorrelatedRunId = "uncorrelated-valid-403"
        $uncorrelatedHarness = "uncorrelated-harness"
        $uncorrelatedHarnessIdentity = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name $uncorrelatedHarness -Directory $childRoot
        $uncorrelatedRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $uncorrelatedRollback.runId = $uncorrelatedRunId
        [IO.File]::WriteAllText($childRollbackConfigPath, ($uncorrelatedRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $uncorrelatedProgress = Join-Path $childRoot "uncorrelated-progress.jsonl"
        $uncorrelatedSummary = Join-Path $childRoot "uncorrelated-summary.json"
        $uncorrelatedStarted = [DateTimeOffset]::UtcNow.AddSeconds(-1)
        $uncorrelatedConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $uncorrelatedConfig.runId = $uncorrelatedRunId
        $uncorrelatedConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $uncorrelatedConfig.loadProgressPath = $uncorrelatedProgress
        $uncorrelatedConfig.loadSummaryPath = $uncorrelatedSummary
        $uncorrelatedConfig.rollbackConfigPath = $childRollbackConfigPath
        $uncorrelatedConfig.artifactsNotBeforeUtc = $uncorrelatedStarted.ToString("o")
        $uncorrelatedConfig.harnessProcessId = $uncorrelatedHarnessIdentity.id
        $uncorrelatedConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$uncorrelatedHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $uncorrelatedConfig.harnessProcessPath = $uncorrelatedHarnessIdentity.path
        $uncorrelatedConfigPath = Join-Path $childRoot "uncorrelated-monitor.json"
        [IO.File]::WriteAllText($uncorrelatedConfigPath, ($uncorrelatedConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $uncorrelatedMonitor = "uncorrelated-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $uncorrelatedMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$uncorrelatedConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "uncorrelated.out") `
            -StandardErrorPath (Join-Path $childRoot "uncorrelated.err")
        $uncorrelatedEvidencePath = Join-Path $childEvidence "$uncorrelatedRunId-aws-monitor.jsonl"
        $uncorrelatedStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
        while (-not (Test-Path -LiteralPath $uncorrelatedEvidencePath) -and [DateTimeOffset]::UtcNow -lt $uncorrelatedStartDeadline) { Start-Sleep -Milliseconds 100 }
        Assert-Condition (Test-Path -LiteralPath $uncorrelatedEvidencePath) "Uncorrelated valid-403 monitor did not start."
        $uncorrelatedFatal = @{reasonCodes=@("uncorrelated-valid-http-403");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        $uncorrelatedSummaryValue = @{runId=$uncorrelatedRunId;stage="fatal-stage";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};thresholds=@{passed=$false};fatalGate=$uncorrelatedFatal}
        [IO.File]::WriteAllText($uncorrelatedSummary, ($uncorrelatedSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $uncorrelatedProgressValue = @{schemaVersion=1;type="progress";event="final";runId=$uncorrelatedRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o");fatalGate=$uncorrelatedFatal}
        [IO.File]::WriteAllText($uncorrelatedProgress, ($uncorrelatedProgressValue|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $uncorrelatedMonitor `
            -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds)
        $uncorrelatedMonitor = $null
        $uncorrelatedResult = Get-Content -LiteralPath (Join-Path $childEvidence "$uncorrelatedRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($uncorrelatedResult.rollback.action -eq "Application" -and $uncorrelatedResult.rollback.exitCode -eq 0) "A valid synthetic 403 without a fresh rate-rule BlockedRequests datapoint must restore the application, not weaken WAF."
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name $uncorrelatedHarness
        $uncorrelatedHarness = $null

        $genericRejectedRunId = "generic-valid-401"
        $genericRejectedHarness = "generic-rejected-harness"
        $genericRejectedHarnessIdentity = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name $genericRejectedHarness -Directory $childRoot
        $genericRejectedRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $genericRejectedRollback.runId = $genericRejectedRunId
        [IO.File]::WriteAllText($childRollbackConfigPath, ($genericRejectedRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $genericRejectedProgress = Join-Path $childRoot "generic-rejected-progress.jsonl"
        $genericRejectedSummary = Join-Path $childRoot "generic-rejected-summary.json"
        $genericRejectedStarted = [DateTimeOffset]::UtcNow.AddSeconds(-1)
        $genericRejectedConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $genericRejectedConfig.runId = $genericRejectedRunId
        $genericRejectedConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $genericRejectedConfig.loadProgressPath = $genericRejectedProgress
        $genericRejectedConfig.loadSummaryPath = $genericRejectedSummary
        $genericRejectedConfig.rollbackConfigPath = $childRollbackConfigPath
        $genericRejectedConfig.artifactsNotBeforeUtc = $genericRejectedStarted.ToString("o")
        $genericRejectedConfig.harnessProcessId = $genericRejectedHarnessIdentity.id
        $genericRejectedConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$genericRejectedHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $genericRejectedConfig.harnessProcessPath = $genericRejectedHarnessIdentity.path
        $genericRejectedConfigPath = Join-Path $childRoot "generic-rejected-monitor.json"
        [IO.File]::WriteAllText($genericRejectedConfigPath, ($genericRejectedConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $genericRejectedMonitor = "generic-rejected-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $genericRejectedMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$genericRejectedConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "generic-rejected.out") `
            -StandardErrorPath (Join-Path $childRoot "generic-rejected.err")
        $genericRejectedEvidencePath = Join-Path $childEvidence "$genericRejectedRunId-aws-monitor.jsonl"
        $genericRejectedStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
        while (-not (Test-Path -LiteralPath $genericRejectedEvidencePath) -and [DateTimeOffset]::UtcNow -lt $genericRejectedStartDeadline) { Start-Sleep -Milliseconds 100 }
        Assert-Condition (Test-Path -LiteralPath $genericRejectedEvidencePath) "Generic valid-401 monitor did not start."
        $genericRejectedFatal = @{reasonCodes=@("valid-http-401");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        $genericRejectedSummaryValue = @{runId=$genericRejectedRunId;stage="fatal-stage";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};thresholds=@{passed=$false};fatalGate=$genericRejectedFatal}
        [IO.File]::WriteAllText($genericRejectedSummary, ($genericRejectedSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $genericRejectedProgressValue = @{schemaVersion=1;type="progress";event="final";runId=$genericRejectedRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o");fatalGate=$genericRejectedFatal}
        [IO.File]::WriteAllText($genericRejectedProgress, ($genericRejectedProgressValue|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $genericRejectedMonitor `
            -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds)
        $genericRejectedMonitor = $null
        $genericRejectedResult = Get-Content -LiteralPath (Join-Path $childEvidence "$genericRejectedRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($genericRejectedResult.rollback.action -eq "Application" -and $genericRejectedResult.rollback.exitCode -eq 0) "Any valid workload 401 must invoke the reviewed application rollback."
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name $genericRejectedHarness
        $genericRejectedHarness = $null

        $combinedRunId = "combined-valid-401-rds-cpu"
        $combinedHarness = "combined-valid-401-rds-harness"
        $combinedHarnessIdentity = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name $combinedHarness -Directory $childRoot
        $combinedRollbackPath = Join-Path $childRoot "combined-valid-401-rds-rollback.json"
        $combinedRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $combinedRollback.runId = $combinedRunId
        $combinedRollback | Add-Member -NotePropertyName privateSubnetIds -NotePropertyValue @("private-a","private-b") -Force
        $combinedRollback | Add-Member -NotePropertyName ecsSecurityGroupIds -NotePropertyValue @("sg-1") -Force
        $combinedRollback | Add-Member -NotePropertyName privateRouteTableIds -NotePropertyValue @("rtb-private-a","rtb-private-b") -Force
        $combinedRollback | Add-Member -NotePropertyName vpcId -NotePropertyValue "vpc" -Force
        $combinedRollback | Add-Member -NotePropertyName expectedNatGatewayCount -NotePropertyValue 2 -Force
        [IO.File]::WriteAllText($combinedRollbackPath, ($combinedRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $combinedProgress = Join-Path $childRoot "combined-valid-401-rds-progress.jsonl"
        $combinedSummary = Join-Path $childRoot "combined-valid-401-rds-summary.json"
        $combinedStarted = [DateTimeOffset]::UtcNow.AddSeconds(-1)
        $combinedConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $combinedConfig.runId = $combinedRunId
        $combinedConfig.phase = "PublicEcs"
        $combinedConfig.loadProgressPath = $combinedProgress
        $combinedConfig.loadSummaryPath = $combinedSummary
        $combinedConfig.rollbackConfigPath = $combinedRollbackPath
        $combinedConfig.artifactsNotBeforeUtc = $combinedStarted.ToString("o")
        $combinedConfig.harnessProcessId = $combinedHarnessIdentity.id
        $combinedConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$combinedHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $combinedConfig.harnessProcessPath = $combinedHarnessIdentity.path
        $combinedConfig.maxIterations = 1
        $combinedConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $combinedNow = [DateTimeOffset]::UtcNow.ToUniversalTime()
        $combinedMinuteTicks = [TimeSpan]::TicksPerMinute
        $combinedRuntimeBase = [DateTimeOffset]::new(
            $combinedNow.Ticks - ($combinedNow.Ticks % $combinedMinuteTicks),
            [TimeSpan]::Zero
        ).AddMinutes(-3)
        $combinedConfig | Add-Member -NotePropertyName testRuntimeSeriesNotBeforeUtc -NotePropertyValue $combinedRuntimeBase.ToString("o") -Force
        $combinedConfigPath = Join-Path $childRoot "combined-valid-401-rds-monitor.json"
        [IO.File]::WriteAllText($combinedConfigPath, ($combinedConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $combinedFatal = @{reasonCodes=@("valid-http-401");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        # Commit terminal progress before monitor startup, but deliberately leave
        # the atomic summary absent. This models the real fatal-gate commit
        # window while allowing config validation to require a unique summary.
        $combinedProgressValue = @{schemaVersion=1;type="progress";event="final";runId=$combinedRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o");fatalGate=$combinedFatal}
        [IO.File]::WriteAllText($combinedProgress, ($combinedProgressValue|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        $oldCombinedRuntimeBase = $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE
        $oldCombinedRuntimePattern = $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE = $combinedRuntimeBase.ToString("o")
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = "three"
        try {
            $combinedMonitor = "combined-valid-401-rds-monitor"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $combinedMonitor `
                -FilePath (Get-Process -Id $PID).Path `
                -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$combinedConfigPath,"-Mode","Monitor") `
                -StandardOutputPath (Join-Path $childRoot "combined-valid-401-rds.out") `
                -StandardErrorPath (Join-Path $childRoot "combined-valid-401-rds.err")
            [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $combinedMonitor `
                -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds)
            $combinedMonitor = $null
        }
        finally {
            if ($null -eq $oldCombinedRuntimeBase) { Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE -ErrorAction SilentlyContinue }
            else { $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE = $oldCombinedRuntimeBase }
            if ($null -eq $oldCombinedRuntimePattern) { Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN -ErrorAction SilentlyContinue }
            else { $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = $oldCombinedRuntimePattern }
        }
        $combinedResultPath = Join-Path $childEvidence "$combinedRunId-monitor-result.json"
        $combinedError = Get-Content -LiteralPath (Join-Path $childRoot "combined-valid-401-rds.err") -Raw -ErrorAction SilentlyContinue
        Assert-Condition (Test-Path -LiteralPath $combinedResultPath) "Combined valid-401/RDS monitor did not write a result (stderr=$combinedError)."
        $combinedResult = Get-Content -LiteralPath $combinedResultPath -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($combinedResult.failures -contains "load:valid-http-401" -and $combinedResult.failures -contains "rds_cpu") "Combined regression must observe both the valid workload 401 and three consecutive RDS CPU breaches."
        Assert-Condition ($combinedResult.rollback.attempted -and $combinedResult.rollback.action -eq "Application" -and $combinedResult.rollback.exitCode -eq 0) "RDS capacity evidence must not select an unrelated PublicEcs mutation; the simultaneous valid-traffic 401 may invoke only its corresponding Application recovery (actual=$($combinedResult.rollback|ConvertTo-Json -Compress -Depth 20); stderr=$combinedError)."
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name $combinedHarness
        $combinedHarness = $null

        $correlatedWafBlockFlag = Join-Path $childRoot "correlated-waf-block.flag"
        $env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK_FILE = $correlatedWafBlockFlag
        $correlatedRunId = "correlated-valid-403"
        $correlatedHarness = "correlated-valid-403-harness"
        $correlatedHarnessIdentity = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name $correlatedHarness -Directory $childRoot
        $correlatedRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $correlatedRollback.runId = $correlatedRunId
        [IO.File]::WriteAllText($childRollbackConfigPath, ($correlatedRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $correlatedProgress = Join-Path $childRoot "correlated-progress.jsonl"
        $correlatedSummary = Join-Path $childRoot "correlated-summary.json"
        $correlatedConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $correlatedConfig.runId = $correlatedRunId
        $correlatedConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $correlatedConfig.loadProgressPath = $correlatedProgress
        $correlatedConfig.loadSummaryPath = $correlatedSummary
        $correlatedConfig.rollbackConfigPath = $childRollbackConfigPath
        $correlatedConfig.artifactsNotBeforeUtc = [DateTimeOffset]::UtcNow.AddSeconds(-1).ToString("o")
        $correlatedConfig.harnessProcessId = $correlatedHarnessIdentity.id
        $correlatedConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$correlatedHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $correlatedConfig.harnessProcessPath = $correlatedHarnessIdentity.path
        $correlatedConfigPath = Join-Path $childRoot "correlated-monitor.json"
        [IO.File]::WriteAllText($correlatedConfigPath, ($correlatedConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $correlatedMonitor = "correlated-valid-403-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $correlatedMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$correlatedConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "correlated.out") `
            -StandardErrorPath (Join-Path $childRoot "correlated.err")
        $correlatedEvidencePath = Join-Path $childEvidence "$correlatedRunId-aws-monitor.jsonl"
        $correlatedStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
        while (-not (Test-Path -LiteralPath $correlatedEvidencePath) -and [DateTimeOffset]::UtcNow -lt $correlatedStartDeadline) { Start-Sleep -Milliseconds 100 }
        Assert-Condition (Test-Path -LiteralPath $correlatedEvidencePath) "Correlated valid-403 monitor did not start."
        [IO.File]::WriteAllText($correlatedWafBlockFlag, "blocked")
        $correlatedFatal = @{reasonCodes=@("valid-http-403");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        $correlatedSummaryValue = @{runId=$correlatedRunId;stage="fatal-stage";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};thresholds=@{passed=$false};fatalGate=$correlatedFatal}
        [IO.File]::WriteAllText($correlatedSummary, ($correlatedSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $correlatedProgressValue = @{schemaVersion=1;type="progress";event="final";runId=$correlatedRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o");fatalGate=$correlatedFatal}
        [IO.File]::WriteAllText($correlatedProgress, ($correlatedProgressValue|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $correlatedMonitor `
            -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds)
        $correlatedMonitor = $null
        $correlatedResult = Get-Content -LiteralPath (Join-Path $childEvidence "$correlatedRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($correlatedResult.rollback.action -eq "Waf" -and $correlatedResult.rollback.exitCode -eq 0) "A valid synthetic 403 corroborated by fresh device-rate BlockedRequests must switch only the reviewed WAF rate rules to COUNT."
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name $correlatedHarness
        $correlatedHarness = $null
        if ($LiveHarnessCasesOnly) {
            Write-Host "Rollout live harness cases: PASS ($script:AssertionCount assertions)"
            return
        }
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK_FILE -ErrorAction SilentlyContinue

        foreach ($raceKind in @("summary-pending", "partial-tail")) {
            $raceRunId = "load-$raceKind-race"
            $raceHarness = "race-harness:$raceKind"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $raceHarness `
                -FilePath (Get-Process -Id $PID).Path `
                -ArgumentList @("-NoProfile","-Command","Start-Sleep -Seconds 60")
            Start-Sleep -Milliseconds 200
            $raceHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $raceHarness
            $raceConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
            $raceConfig.runId = $raceRunId
            $raceConfig.automaticRollback = $false
            $raceConfig.PSObject.Properties.Remove("rollbackConfigPath")
            $raceConfig.maxIterations = 2
            $raceConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
            $raceConfig.loadProgressPath = Join-Path $childRoot "$raceRunId-progress.jsonl"
            $raceConfig.loadSummaryPath = Join-Path $childRoot "$raceRunId-summary.json"
            $raceConfig.artifactsNotBeforeUtc = [DateTimeOffset]::UtcNow.AddSeconds(-1).ToString("o")
            $raceConfig.harnessProcessId = $raceHarnessIdentity.id
            $raceConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$raceHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
            $raceConfig.harnessProcessPath = (Get-Process -Id $PID).Path
            $raceConfigPath = Join-Path $childRoot "$raceRunId-monitor.json"
            [IO.File]::WriteAllText($raceConfigPath, ($raceConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
            $raceMonitor = "race-monitor:$raceKind"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $raceMonitor `
                -FilePath (Get-Process -Id $PID).Path `
                -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$raceConfigPath,"-Mode","Monitor") `
                -StandardOutputPath (Join-Path $childRoot "$raceRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$raceRunId.err")
            $raceEvidencePath = Join-Path $childEvidence "$raceRunId-aws-monitor.jsonl"
            $raceStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
            while (-not (Test-Path -LiteralPath $raceEvidencePath) -and [DateTimeOffset]::UtcNow -lt $raceStartDeadline) { Start-Sleep -Milliseconds 100 }
            if (-not (Test-Path -LiteralPath $raceEvidencePath)) {
                $raceStartDiagnostics = Close-OwnedTestProcessForDiagnostics `
                    -Registry $ownedTestProcesses `
                    -Name $raceMonitor `
                    -StandardOutputPath (Join-Path $childRoot "$raceRunId.out") `
                    -StandardErrorPath (Join-Path $childRoot "$raceRunId.err")
                if (-not $ownedTestProcesses.Contains($raceMonitor)) { $raceMonitor = $null }
                throw (
                    "$raceKind race monitor did not start " +
                    "(state=$($raceStartDiagnostics.state|ConvertTo-Json -Compress); " +
                    "cleanup=$($raceStartDiagnostics.cleanupFailure); stderr=$($raceStartDiagnostics.standardError))."
                )
            }
            if ($raceKind -eq "summary-pending") {
                $raceEvent = @{schemaVersion=1;type="progress";event="final";runId=$raceRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o")}
                [IO.File]::WriteAllText($raceConfig.loadProgressPath, ($raceEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
            }
            else {
                $completeEvent = @{schemaVersion=1;type="progress";event="progress";runId=$raceRunId;stage="fatal-stage";timestamp=[DateTimeOffset]::UtcNow.ToString("o")}
                [IO.File]::WriteAllText($raceConfig.loadProgressPath, ($completeEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine+'{"event":"final"', [Text.UTF8Encoding]::new($false))
            }
            [void](Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $raceMonitor `
                -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds)
            $raceMonitor = $null
            $raceResult = Get-Content -LiteralPath (Join-Path $childEvidence "$raceRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
            Assert-Condition ($raceResult.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
                $raceResult.failures -notcontains "load_progress_parse_error" -and $raceResult.failures -notcontains "load_summary_invalid" -and
                $raceResult.failures -notcontains "load_generator_process_lost") "$raceKind commit window must be retried within grace instead of invalidating the run."
            Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $raceHarness
            $raceHarness = $null
        }

        $limitRunId = "limit-fail-test"
        $limitConfigPath = Join-Path $childRoot "limit-monitor.json"
        $limitConfig = @{
            schemaVersion=1;runId=$limitRunId;phase="Application";evidenceDirectory=$childEvidence;automaticRollback=$false;
            testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";notificationTopicArn="arn:aws:sns:us-east-1:000000000000:test";pollSeconds=1;testMode=$true;maxIterations=1;
            minimumWallClockSeconds=10;deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o");
            resources=@{region="us-east-1";cluster="cluster";apiService="api";workerService="worker";targetGroupArn="target";rdsInstanceId="db";
              redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";wafWebAclName="acl";wafDeviceRuleMetricName="device";
              wafApiRuleMetricName="api";route53HealthCheckId="health";route53AlarmName="route-alarm";expectedNatGatewayCount=2;expectedRoute53MeasureLatency=$true;
              expectedEcsAssignPublicIp=$false;ecsTaskSubnetIds=@("private-a","private-b");expectedRedisNodeType="cache.t4g.small"}
        }
        [IO.File]::WriteAllText($limitConfigPath, ($limitConfig|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $limitMonitor = "iteration-limit-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $limitMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$limitConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "limit.out") `
            -StandardErrorPath (Join-Path $childRoot "limit.err")
        $limitMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses -Name $limitMonitor `
            -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $limitMonitor = $null
        $limitResult = Get-Content -LiteralPath (Join-Path $childEvidence "$limitRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($limitMonitorCompletion.exitCode -eq 2 -and $limitResult.failures -contains "monitor_iteration_limit_reached_before_acceptance") "maxIterations must be a fail-closed ceiling, never a success condition."
        Assert-Condition (-not $limitResult.rollback.attempted) "Monitoring completeness failures must not mutate infrastructure."

        function Invoke-ChildMonitorCase {
            param([string]$CaseId, $CaseConfig)
            $CaseConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
            $casePath = Join-Path $childRoot "$CaseId.json"
            [IO.File]::WriteAllText($casePath, ($CaseConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
            $resultPath = Join-Path $childEvidence "$CaseId-monitor-result.json"
            $caseEvidencePath = Join-Path $childEvidence "$CaseId-aws-monitor.jsonl"
            $caseOutputPath = Join-Path $childRoot "$CaseId.out"
            $caseErrorPath = Join-Path $childRoot "$CaseId.err"
            $processName = "child-monitor:$CaseId"
            $ownedResult = $null
            $primaryFailure = $null
            try {
                $ownedResult = Invoke-OwnedTestProcessWithResult `
                    -Registry $ownedTestProcesses `
                    -Name $processName `
                    -FilePath (Get-Process -Id $PID).Path `
                    -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$casePath,"-Mode","Monitor") `
                    -StandardOutputPath $caseOutputPath `
                    -StandardErrorPath $caseErrorPath `
                    -ResultPath $resultPath `
                    -WatchdogMilliseconds $script:MonitorCompletionWatchdogMilliseconds
            }
            catch {
                $primaryFailure = $_
            }
            $caseError = Get-Content -LiteralPath $caseErrorPath -Raw -ErrorAction SilentlyContinue
            $caseOutput = Get-Content -LiteralPath $caseOutputPath -Raw -ErrorAction SilentlyContinue
            $lastEvidence = Get-Content -LiteralPath $caseEvidencePath -Tail 1 -ErrorAction SilentlyContinue
            $partialResult = Get-Content -LiteralPath $resultPath -Raw -ErrorAction SilentlyContinue
            if ($null -ne $primaryFailure) {
                $primaryFailure.Exception.Data["MonitorCaseId"] = $CaseId
                $primaryFailure.Exception.Data["StandardOutput"] = $caseOutput
                $primaryFailure.Exception.Data["StandardError"] = $caseError
                $primaryFailure.Exception.Data["LastEvidence"] = $lastEvidence
                $primaryFailure.Exception.Data["PartialResult"] = $partialResult
                throw $primaryFailure
            }
            $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json -Depth 30
            return [pscustomobject]@{
                exitCode = [int]$ownedResult.exitCode
                result = $result
                lastEvidence = $lastEvidence
                durationMs = [long]$ownedResult.durationMs
            }
        }

        function New-StrictDurationSummary {
            param(
                [string]$RunId,
                [double]$ActualTrafficSeconds,
                [double]$ActualTrafficMilliseconds,
                [bool]$CompletedConfiguredDuration,
                [double]$PlannedTrafficSeconds = 1,
                [string]$ShutdownReason = "duration",
                [switch]$LegacyTiming,
                $FatalGate = $null
            )
            $run = [ordered]@{
                shutdownReason = $ShutdownReason
                plannedTrafficSeconds = $PlannedTrafficSeconds
                actualTrafficSeconds = $ActualTrafficSeconds
                completedConfiguredDuration = $CompletedConfiguredDuration
            }
            if (-not $LegacyTiming) {
                $run.durationClock = "monotonic-hrtime-v1"
                $run.runtimeTargetTrafficSeconds = 1
                $run.plannedTrafficMilliseconds = 1000
                $run.actualTrafficMilliseconds = $ActualTrafficMilliseconds
            }
            return [ordered]@{
                runId = $RunId
                stage = "800"
                devices = 810
                declaredSecondSchoolCanaryDevices = 10
                workloadSchemaVersion = "classpilot-tile-batch-v1"
                workloadEndpointShapeSha256 = "8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"
                run = $run
                screenshotFixture = [ordered]@{decodedBytes=40960}
                thresholds = [ordered]@{passed=($null -eq $FatalGate)}
                fatalGate = $FatalGate
                screenshotRetrieval = [ordered]@{attempts=800;successes=800;successPercent=100}
                tileBatch = [ordered]@{
                    configured=$true;pollAccountingVersion="staggered-deadline-v1";teacherCohorts=20;studentsPerCohort=40;teacherTileAssignments=800
                    requestsPerCohortPerPoll=2;logicalOperationsPerPoll=1600
                    historyRequestsByCohort=@(1)*20;screenshotRequestsByCohort=@(1)*20
                    completeRoundsPerCohort=1;maximumRoundsPerCohort=1;partialFinalRoundCohorts=0
                    historyRequests=20;screenshotRequests=20;historyLogicalOperations=800;screenshotLogicalOperations=800
                    networkRequests=40;logicalOperations=1600
                }
            }
        }

        $strictDurationHarnessScript = Join-Path $childRoot "strict-duration-harness.ps1"
        $strictDurationHarnessSource = @'
param(
    [Parameter(Mandatory = $true)][string]$SignalPath,
    [Parameter(Mandatory = $true)][int]$ParentProcessId,
    [Parameter(Mandatory = $true)][long]$ParentProcessStartedAtUtcTicks
)
while (-not (Test-Path -LiteralPath $SignalPath)) {
    $parent = Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue
    if ($null -eq $parent) { exit 10 }
    try {
        if ($parent.StartTime.ToUniversalTime().Ticks -ne $ParentProcessStartedAtUtcTicks) { exit 11 }
    }
    finally {
        $parent.Dispose()
    }
    Start-Sleep -Milliseconds 50
}
exit 0
'@
        [IO.File]::WriteAllText(
            $strictDurationHarnessScript,
            $strictDurationHarnessSource,
            [Text.UTF8Encoding]::new($false)
        )

        function Invoke-StrictDurationSummaryCase {
            param([string]$CaseId, $Summary, [double]$FinalWallClockOffsetSeconds = 0, [switch]$StopHarnessAfterFinal)
            $caseProgress = Join-Path $childRoot "$CaseId-progress.jsonl"
            $caseSummary = Join-Path $childRoot "$CaseId-summary.json"
            $caseHarnessSignal = Join-Path $childRoot "$CaseId-harness-release"
            Remove-Item -LiteralPath $caseProgress,$caseSummary,$caseHarnessSignal -ErrorAction SilentlyContinue
            $caseHarnessStartInfo = [Diagnostics.ProcessStartInfo]::new()
            $caseHarnessStartInfo.UseShellExecute = $false
            $caseHarnessStartInfo.CreateNoWindow = $true
            $testHostProcess = [Diagnostics.Process]::GetCurrentProcess()
            try {
                $caseHarnessStartInfo.FileName = $testHostProcess.Path
                $testHostStartedAtUtcTicks = $testHostProcess.StartTime.ToUniversalTime().Ticks
            }
            finally {
                $testHostProcess.Dispose()
            }
            foreach ($argument in @(
                "-NoProfile",
                "-File",
                $strictDurationHarnessScript,
                "-SignalPath",
                $caseHarnessSignal,
                "-ParentProcessId",
                $PID,
                "-ParentProcessStartedAtUtcTicks",
                $testHostStartedAtUtcTicks
            )) {
                [void]$caseHarnessStartInfo.ArgumentList.Add([string]$argument)
            }
            $caseHarnessProcessName = "strict-duration-harness:$CaseId"
            $caseMonitorProcessName = "strict-duration-monitor:$CaseId"
            Start-OwnedTestProcessFromStartInfo -Registry $ownedTestProcesses `
                -Name $caseHarnessProcessName -StartInfo $caseHarnessStartInfo
            $caseHarness = $caseHarnessProcessName
            $caseHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $caseHarness
            $caseMonitor = $null
            $caseMonitorExitCode = $null
            $caseMonitorDurationMs = $null
            $caseBarrierRelease = $null
            $caseResultValue = $null
            $caseFailure = $null
            $caseCleanupFailures = [System.Collections.Generic.List[Exception]]::new()
            try {
                Start-Sleep -Milliseconds 200
                $caseStartedAt = [DateTimeOffset]::UtcNow
                $startEvent = @{schemaVersion=1;type="progress";event="start";runId=$CaseId;stage="800";timestamp=$caseStartedAt.ToString("o")}
                [IO.File]::WriteAllText($caseProgress, ($startEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))

                $caseConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
                $caseConfig.runId = $CaseId
                $caseConfig.phase = "Waf"
                $caseConfig.minimumWallClockSeconds = 0
                $caseConfig.maxIterations = 10
                # $limitConfig freezes a deadlineUtc one minute after that config
                # was built, and every other consumer restamps it before use
                # (Invoke-ChildMonitorCase and the explicit callers below). These
                # cases run well past that minute on a loaded runner, and an
                # expired deadline makes the monitor exit 2 carrying only
                # "monitor_deadline_reached_before_acceptance" -- silently
                # replacing the load findings each case asserts on. Stamp a
                # per-case deadline covering the monitor startup bound, the
                # completion watchdog and one supervised sweep.
                $caseConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddSeconds(
                    $script:MonitorStartupDeadlineSeconds +
                    ($script:MonitorCompletionWatchdogMilliseconds / 1000) +
                    $script:SupervisedSampleBudgetSeconds).ToString("o")
                $caseConfig | Add-Member -NotePropertyName loadProgressPath -NotePropertyValue $caseProgress -Force
                $caseConfig | Add-Member -NotePropertyName loadSummaryPath -NotePropertyValue $caseSummary -Force
                $caseConfig | Add-Member -NotePropertyName artifactsNotBeforeUtc -NotePropertyValue $caseStartedAt.AddSeconds(-1).ToString("o") -Force
                $caseConfig | Add-Member -NotePropertyName harnessProcessId -NotePropertyValue $caseHarnessIdentity.id -Force
                $caseConfig | Add-Member -NotePropertyName harnessProcessStartedAtUtc -NotePropertyValue ([DateTimeOffset]$caseHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o") -Force
                $caseConfig | Add-Member -NotePropertyName harnessProcessPath -NotePropertyValue $caseHarnessIdentity.path -Force
                $caseConfig | Add-Member -NotePropertyName requireLoadAcceptance -NotePropertyValue $true -Force
                $caseConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 1 -Force
                $caseConfig | Add-Member -NotePropertyName workload -NotePropertyValue @{
                    stage="800";devices=810;durationSeconds=1;screenshotBytes=40960;canaryDevices=10
                    workloadSchemaVersion="classpilot-tile-batch-v1"
                    endpointShapeSha256="8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"
                } -Force
                $casePath = Join-Path $childRoot "$CaseId-monitor.json"
                [IO.File]::WriteAllText($casePath, ($caseConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
                # Keep the synthetic CloudWatch sample inside the logical traffic
                # minute even when this test deliberately moves the final wall
                # clock backward or the host crosses a minute boundary.
                $oldCaseMetricTimestamp = $env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP
                $caseBarrierEnvironment = [ordered]@{}
                $caseBarrierReady = $null
                if ($StopHarnessAfterFinal) {
                    $caseBarrierArm = Join-Path $childRoot "$CaseId-sample-barrier-arm.flag"
                    $caseBarrierReady = Join-Path $childRoot "$CaseId-sample-barrier-ready.flag"
                    $caseBarrierRelease = Join-Path $childRoot "$CaseId-sample-barrier-release.flag"
                    $caseBarrierConsumed = Join-Path $childRoot "$CaseId-sample-barrier-consumed.flag"
                    Remove-Item -LiteralPath $caseBarrierArm,$caseBarrierReady,$caseBarrierRelease,$caseBarrierConsumed -ErrorAction SilentlyContinue
                    [IO.File]::WriteAllText($caseBarrierArm, "1", [Text.UTF8Encoding]::new($false))
                    foreach ($entry in ([ordered]@{
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM = $caseBarrierArm
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY = $caseBarrierReady
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE = $caseBarrierRelease
                        SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED = $caseBarrierConsumed
                    }).GetEnumerator()) {
                        $caseBarrierEnvironment[$entry.Key] = [Environment]::GetEnvironmentVariable($entry.Key, "Process")
                        [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
                    }
                }
                $env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP = $caseStartedAt.ToString("o")
                try {
                    Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $caseMonitorProcessName `
                        -FilePath $caseHarnessStartInfo.FileName `
                        -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$casePath,"-Mode","Monitor") `
                        -StandardOutputPath (Join-Path $childRoot "$CaseId.out") `
                        -StandardErrorPath (Join-Path $childRoot "$CaseId.err")
                    $caseMonitor = $caseMonitorProcessName
                }
                finally {
                    if ($null -eq $oldCaseMetricTimestamp) {
                        Remove-Item Env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP -ErrorAction SilentlyContinue
                    }
                    else {
                        $env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP = $oldCaseMetricTimestamp
                    }
                    foreach ($entry in $caseBarrierEnvironment.GetEnumerator()) {
                        [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
                    }
                }
                $evidencePath = Join-Path $childEvidence "$CaseId-aws-monitor.jsonl"
                $startDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
                if ($StopHarnessAfterFinal) {
                    while (-not (Test-Path -LiteralPath $caseBarrierReady) -and
                        -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $caseMonitor).hasExited -and
                        [DateTimeOffset]::UtcNow -lt $startDeadline) {
                        Start-Sleep -Milliseconds 100
                    }
                    if (-not (Test-Path -LiteralPath $caseBarrierReady)) {
                        $caseStartDiagnostics = Close-OwnedTestProcessForDiagnostics `
                            -Registry $ownedTestProcesses `
                            -Name $caseMonitor `
                            -StandardOutputPath (Join-Path $childRoot "$CaseId.out") `
                            -StandardErrorPath (Join-Path $childRoot "$CaseId.err")
                        if (-not $ownedTestProcesses.Contains($caseMonitor)) { $caseMonitor = $null }
                        throw (
                            "$CaseId strict duration monitor did not reach its first sample barrier " +
                            "(state=$($caseStartDiagnostics.state|ConvertTo-Json -Compress); " +
                            "cleanup=$($caseStartDiagnostics.cleanupFailure); stderr=$($caseStartDiagnostics.standardError))."
                        )
                    }
                }
                else {
                    while (-not (Test-Path -LiteralPath $evidencePath) -and
                        -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $caseMonitor).hasExited -and
                        [DateTimeOffset]::UtcNow -lt $startDeadline) {
                        Start-Sleep -Milliseconds 100
                    }
                    if (-not (Test-Path -LiteralPath $evidencePath)) {
                        $caseStartDiagnostics = Close-OwnedTestProcessForDiagnostics `
                            -Registry $ownedTestProcesses `
                            -Name $caseMonitor `
                            -StandardOutputPath (Join-Path $childRoot "$CaseId.out") `
                            -StandardErrorPath (Join-Path $childRoot "$CaseId.err")
                        if (-not $ownedTestProcesses.Contains($caseMonitor)) { $caseMonitor = $null }
                        throw (
                            "$CaseId strict duration monitor did not start " +
                            "(state=$($caseStartDiagnostics.state|ConvertTo-Json -Compress); " +
                            "cleanup=$($caseStartDiagnostics.cleanupFailure); stderr=$($caseStartDiagnostics.standardError))."
                        )
                    }
                }
                [IO.File]::WriteAllText($caseSummary, ($Summary|ConvertTo-Json -Depth 15), [Text.UTF8Encoding]::new($false))
                $finalEvent = @{schemaVersion=1;type="progress";event="final";runId=$CaseId;stage="800";timestamp=[DateTimeOffset]::UtcNow.AddSeconds($FinalWallClockOffsetSeconds).ToString("o")}
                if ($null -ne $Summary.fatalGate) { $finalEvent.fatalGate = $Summary.fatalGate }
                [IO.File]::AppendAllText($caseProgress, ($finalEvent|ConvertTo-Json -Compress -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
                if ($StopHarnessAfterFinal) {
                    $release = Release-OwnedTestProcess `
                        -Registry $ownedTestProcesses `
                        -Name $caseHarness `
                        -SignalPath $caseHarnessSignal `
                        -TimeoutMilliseconds 10000
                    $caseHarness = $null
                    Assert-Condition ($release.wasRunningBeforeSignal -and
                        $release.exitedAfterSignal -and $release.exitCode -eq 0) `
                        "$CaseId strict-duration harness did not exit normally after coherent terminal evidence."
                    [IO.File]::WriteAllText($caseBarrierRelease, "1", [Text.UTF8Encoding]::new($false))
                }
                $caseResultPath = Join-Path $childEvidence "$CaseId-monitor-result.json"
                $caseCompletionWatch = [Diagnostics.Stopwatch]::StartNew()
                while ($caseCompletionWatch.ElapsedMilliseconds -lt $script:MonitorCompletionWatchdogMilliseconds) {
                    $caseMonitorState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $caseMonitor
                    if ($caseMonitorState.hasExited -and (Test-Path -LiteralPath $caseResultPath -PathType Leaf)) { break }
                    Start-Sleep -Milliseconds 100
                }
                $caseMonitorState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $caseMonitor
                Assert-Condition ($caseMonitorState.hasExited -and (Test-Path -LiteralPath $caseResultPath -PathType Leaf)) `
                    "$CaseId strict duration monitor did not publish a result and exit inside the 90-second watchdog."
                $caseDrainBudgetMilliseconds = $script:MonitorCompletionWatchdogMilliseconds - [int]$caseCompletionWatch.ElapsedMilliseconds
                Assert-Condition ($caseDrainBudgetMilliseconds -gt 0) `
                    "$CaseId strict duration monitor exhausted its 90-second budget before redirect drain."
                $caseMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
                    -Name $caseMonitor -TimeoutMilliseconds $caseDrainBudgetMilliseconds
                $caseMonitorExitCode = $caseMonitorCompletion.exitCode
                $caseCompletionWatch.Stop()
                $caseMonitorDurationMs = [long]$caseCompletionWatch.ElapsedMilliseconds
                $caseMonitor = $null
                Assert-Condition (Test-Path -LiteralPath $evidencePath) `
                    "$CaseId strict duration monitor produced no evidence."
                $result = Get-Content -LiteralPath $caseResultPath -Raw | ConvertFrom-Json -Depth 30
                $lastEvidence = Get-Content -LiteralPath $evidencePath -Tail 1 -ErrorAction SilentlyContinue
                $caseResultValue = [pscustomobject]@{
                    exitCode = [int]$caseMonitorExitCode
                    result = $result
                    lastEvidence = $lastEvidence
                    durationMs = [long]$caseMonitorDurationMs
                }
            }
            catch {
                $caseFailure = $_
            }
            finally {
                if ($StopHarnessAfterFinal -and
                    $null -ne $caseBarrierRelease -and
                    -not (Test-Path -LiteralPath $caseBarrierRelease)) {
                    try {
                        [IO.File]::WriteAllText($caseBarrierRelease, "1", [Text.UTF8Encoding]::new($false))
                    }
                    catch {
                        $caseCleanupFailures.Add([InvalidOperationException]::new(
                            "$CaseId sample-barrier release cleanup failed.",
                            $_.Exception
                        ))
                    }
                }
                if ($null -ne $caseMonitor) {
                    try {
                        Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $caseMonitor
                    }
                    catch {
                        $caseCleanupFailures.Add([InvalidOperationException]::new(
                            "$CaseId strict-duration monitor cleanup failed.",
                            $_.Exception
                        ))
                    }
                    if (-not $ownedTestProcesses.Contains($caseMonitor)) { $caseMonitor = $null }
                }
                if ($null -ne $caseHarness) {
                    try {
                        [void](Release-OwnedTestProcess `
                            -Registry $ownedTestProcesses `
                            -Name $caseHarness `
                            -SignalPath $caseHarnessSignal `
                            -TimeoutMilliseconds 10000)
                    }
                    catch {
                        $caseCleanupFailures.Add([InvalidOperationException]::new(
                            "$CaseId strict-duration harness cleanup failed.",
                            $_.Exception
                        ))
                    }
                    if (-not $ownedTestProcesses.Contains($caseHarness)) { $caseHarness = $null }
                }
                try {
                    Remove-Item -LiteralPath $caseHarnessSignal -ErrorAction SilentlyContinue
                }
                catch {
                    $caseCleanupFailures.Add([InvalidOperationException]::new(
                        "$CaseId strict-duration signal cleanup failed.",
                        $_.Exception
                    ))
                }
            }
            if ($null -ne $caseFailure -and $caseCleanupFailures.Count -gt 0) {
                Add-OwnedTestProcessCleanupFailures -Exception $caseFailure.Exception `
                    -CleanupFailures ([Exception[]]$caseCleanupFailures.ToArray())
                throw $caseFailure
            }
            if ($null -ne $caseFailure) { throw $caseFailure }
            if ($caseCleanupFailures.Count -gt 0) {
                throw [AggregateException]::new(
                    "$CaseId strict-duration cleanup failed.",
                    [Exception[]]$caseCleanupFailures.ToArray()
                )
            }
            return $caseResultValue
        }

        $durationExactId = "duration-monotonic-exact"
        $durationExact = Invoke-StrictDurationSummaryCase $durationExactId `
            (New-StrictDurationSummary -RunId $durationExactId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true) -FinalWallClockOffsetSeconds -30
        Assert-Condition ($durationExact.exitCode -eq 0 -and $durationExact.result.status -eq "completed") `
            "An exact monotonic millisecond duration must satisfy the reviewed tile-batch contract even when the final wall-clock label moves backward (actual: $($durationExact.result|ConvertTo-Json -Compress -Depth 30))."

        $durationRoundedShortId = "duration-rounded-seconds-short-ms"
        $durationRoundedShort = Invoke-StrictDurationSummaryCase $durationRoundedShortId `
            (New-StrictDurationSummary -RunId $durationRoundedShortId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 999 -CompletedConfiguredDuration $true)
        Assert-Condition ($durationRoundedShort.exitCode -eq 2 -and
            $durationRoundedShort.result.failures -contains "load_workload_contract_mismatch") `
            "Rounded display seconds must not hide a raw monotonic duration below the configured target."

        $durationCommittedRejectId = "duration-committed-rejected-final"
        $durationCommittedReject = Invoke-StrictDurationSummaryCase $durationCommittedRejectId `
            (New-StrictDurationSummary -RunId $durationCommittedRejectId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 999 -CompletedConfiguredDuration $true) `
            -StopHarnessAfterFinal
        $durationCommittedRejectEvidence = $durationCommittedReject.lastEvidence | ConvertFrom-Json -Depth 30
        Assert-Condition ($durationCommittedReject.exitCode -eq 2 -and
            $durationCommittedReject.result.failures -contains "load_workload_contract_mismatch" -and
            $durationCommittedReject.result.failures -notcontains "load_generator_process_lost" -and
            $durationCommittedRejectEvidence.terminalEvidenceCommitted -eq $true) `
            "A coherent rejected final must preserve its contract failure without adding a derivative process-loss finding."

        $durationActualMismatchId = "duration-actual-seconds-ms-mismatch"
        $durationActualMismatch = Invoke-StrictDurationSummaryCase $durationActualMismatchId `
            (New-StrictDurationSummary -RunId $durationActualMismatchId -ActualTrafficSeconds 1.001 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true)
        Assert-Condition ($durationActualMismatch.exitCode -eq 2 -and
            $durationActualMismatch.result.failures -contains "load_workload_contract_mismatch") `
            "Displayed actual seconds must equal the three-decimal value derived from raw monotonic milliseconds."

        $durationPlannedMismatchId = "duration-planned-seconds-ms-mismatch"
        $durationPlannedMismatch = Invoke-StrictDurationSummaryCase $durationPlannedMismatchId `
            (New-StrictDurationSummary -RunId $durationPlannedMismatchId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true -PlannedTrafficSeconds 1.001)
        Assert-Condition ($durationPlannedMismatch.exitCode -eq 2 -and
            $durationPlannedMismatch.result.failures -contains "load_workload_contract_mismatch") `
            "Displayed planned seconds must equal the value derived from planned monotonic milliseconds."

        $durationFractionalMillisecondsId = "duration-fractional-actual-ms"
        $fractionalMilliseconds = 1000.5
        $durationFractionalMilliseconds = Invoke-StrictDurationSummaryCase $durationFractionalMillisecondsId `
            (New-StrictDurationSummary -RunId $durationFractionalMillisecondsId -ActualTrafficSeconds ([math]::Round($fractionalMilliseconds / 1000, 3)) -ActualTrafficMilliseconds $fractionalMilliseconds -CompletedConfiguredDuration $true)
        Assert-Condition ($durationFractionalMilliseconds.exitCode -eq 2 -and
            $durationFractionalMilliseconds.result.failures -contains "load_workload_contract_mismatch") `
            "Raw actual traffic milliseconds must be an integer produced by the monotonic harness clock."

        $durationShutdownMismatchId = "duration-nonduration-shutdown-completed"
        $durationShutdownMismatch = Invoke-StrictDurationSummaryCase $durationShutdownMismatchId `
            (New-StrictDurationSummary -RunId $durationShutdownMismatchId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true -ShutdownReason "SIGTERM")
        Assert-Condition ($durationShutdownMismatch.exitCode -eq 2 -and
            $durationShutdownMismatch.result.failures -contains "load_workload_contract_mismatch") `
            "completedConfiguredDuration=true must not make a non-duration shutdown certification-eligible."

        $durationLegacyId = "duration-missing-monotonic-fields"
        $durationLegacy = Invoke-StrictDurationSummaryCase $durationLegacyId `
            (New-StrictDurationSummary -RunId $durationLegacyId -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true -LegacyTiming)
        Assert-Condition ($durationLegacy.exitCode -eq 2 -and
            $durationLegacy.result.failures -contains "load_workload_contract_mismatch") `
            "A tile-batch diagnostic/certification summary missing the monotonic clock fields must fail closed."

        $durationStringTimingId = "duration-string-encoded-timing"
        $durationStringTimingSummary = New-StrictDurationSummary -RunId $durationStringTimingId `
            -ActualTrafficSeconds 1 -ActualTrafficMilliseconds 1000 -CompletedConfiguredDuration $true
        $durationStringTimingSummary.run.plannedTrafficSeconds = "1"
        $durationStringTimingSummary.run.actualTrafficSeconds = "1"
        $durationStringTimingSummary.run.runtimeTargetTrafficSeconds = "1"
        $durationStringTimingSummary.run.plannedTrafficMilliseconds = "1000"
        $durationStringTimingSummary.run.actualTrafficMilliseconds = "1000"
        $durationStringTiming = Invoke-StrictDurationSummaryCase $durationStringTimingId $durationStringTimingSummary
        Assert-Condition ($durationStringTiming.exitCode -eq 2 -and
            $durationStringTiming.result.failures -contains "load_workload_contract_mismatch") `
            "String-encoded timing fields must not satisfy the strict JSON numeric timing contract."

        $durationFatalId = "duration-monotonic-early-fatal"
        $durationFatalGate = @{reasonCodes=@("tenant-isolation-probe-unavailable");observedAt=[DateTimeOffset]::UtcNow.ToString("o")}
        $durationFatal = Invoke-StrictDurationSummaryCase $durationFatalId `
            (New-StrictDurationSummary -RunId $durationFatalId -ActualTrafficSeconds 0.25 -ActualTrafficMilliseconds 250 -CompletedConfiguredDuration $false -ShutdownReason "fatal-tenant-isolation-probe-unavailable" -FatalGate $durationFatalGate)
        Assert-Condition ($durationFatal.exitCode -eq 2 -and
            $durationFatal.result.failures -contains "load_workload_contract_mismatch" -and
            $durationFatal.result.failures -contains "load:tenant-isolation-probe-unavailable") `
            "An early fatal run must retain its fatal reason while remaining ineligible for duration acceptance."

        $sparseWafConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $sparseWafConfig.runId = "sparse-waf-zero"
        $sparseWafConfig.minimumWallClockSeconds = 3
        $sparseWafConfig.maxIterations = 5
        $env:SCHOOLPILOT_TEST_WAF_SPARSE_ZERO = "1"
        $sparseWafCase = Invoke-ChildMonitorCase "sparse-waf-zero" $sparseWafConfig
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_SPARSE_ZERO -ErrorAction SilentlyContinue
        $sparseWafSample = $sparseWafCase.lastEvidence | ConvertFrom-Json -Depth 30
        Assert-Condition ($sparseWafCase.exitCode -eq 0 -and $sparseWafCase.result.status -eq "completed") "Sparse zero-event WAF counters must not invalidate a healthy monitor sample."
        Assert-Condition ($sparseWafSample.waf.deviceBlockedSparseZero -eq $true -and $sparseWafSample.waf.apiBlockedSparseZero -eq $true) "Sparse WAF zero substitution must remain explicit in monitor evidence."

        $partialWafConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $partialWafConfig.runId = "partial-waf-unavailable"
        $partialWafConfig.minimumWallClockSeconds = 10
        $partialWafConfig.maxIterations = 4
        $env:SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY = "1"
        $partialWafCase = Invoke-ChildMonitorCase "partial-waf-unavailable" $partialWafConfig
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY -ErrorAction SilentlyContinue
        Assert-Condition ($partialWafCase.exitCode -eq 2 -and
            $partialWafCase.result.failures -contains "missing_metric:waf_device_blocked" -and
            $partialWafCase.result.failures -contains "missing_metric:waf_api_blocked") "Partial WAF telemetry must remain fail-closed instead of being converted to a sparse zero."

        $slowFreshConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $slowFreshConfig.runId = "five-minute-runtime-freshness"
        $slowFreshConfig.minimumWallClockSeconds = 3
        $slowFreshConfig.maxIterations = 5
        $env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS = "600"
        $slowFreshCase = Invoke-ChildMonitorCase "five-minute-runtime-freshness" $slowFreshConfig
        Remove-Item Env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        Assert-Condition ($slowFreshCase.exitCode -eq 0 -and $slowFreshCase.result.status -eq "completed") "A healthy five-minute credit datapoint 600 seconds old must remain fresh while one-minute metrics stay current."

        $slowStaleConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $slowStaleConfig.runId = "five-minute-runtime-stale"
        $slowStaleConfig.minimumWallClockSeconds = 10
        $slowStaleConfig.maxIterations = 4
        $env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS = "720"
        $slowStaleCase = Invoke-ChildMonitorCase "five-minute-runtime-stale" $slowStaleConfig
        Remove-Item Env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        foreach ($slowMetric in @("rds_cpu_credit", "rds_surplus_credits_charged", "redis_cpu_credit")) {
            Assert-Condition ($slowStaleCase.result.failures -contains "stale_metric:$slowMetric") "Five-minute metric '$slowMetric' older than 660 seconds must fail closed after three checks."
        }

        $rdsCpuLagConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $rdsCpuLagConfig.runId = "rds-cpu-publication-lag"
        # These runtime cases must reach their iteration/staleness gates before
        # cumulative acceptance, even when Windows mock sweeps exceed ten seconds.
        # The owned-child watchdog bounds runtime; this adds no wait or threshold change.
        $rdsCpuLagConfig.minimumWallClockSeconds = [int][Math]::Ceiling(
            $script:MonitorCompletionWatchdogMilliseconds / 1000.0
        )
        $rdsCpuLagConfig.maxIterations = 3
        $env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS = "210"
        $rdsCpuLagCase = Invoke-ChildMonitorCase "rds-cpu-publication-lag" $rdsCpuLagConfig
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        Assert-Condition ($rdsCpuLagCase.exitCode -eq 2 -and
            $rdsCpuLagCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
            $rdsCpuLagCase.result.failures -notcontains "stale_metric:rds_cpu") (
            "A live RDS CPU series with one additional period of publication lag must remain runtime-valid without padding cumulative in-run evidence. " +
            "Result: $($rdsCpuLagCase.result | ConvertTo-Json -Compress -Depth 30)"
        )

        $rdsCpuLagAcceptanceConfig = $rdsCpuLagConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $rdsCpuLagAcceptanceConfig.runId = "rds-cpu-publication-lag-acceptance"
        $rdsCpuLagAcceptanceConfig.minimumWallClockSeconds = 0
        $rdsCpuLagAcceptanceConfig.maxIterations = 1
        $rdsCpuLagAcceptanceConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 60 -Force
        $env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS = "210"
        $rdsCpuLagAcceptanceCase = Invoke-ChildMonitorCase "rds-cpu-publication-lag-acceptance" $rdsCpuLagAcceptanceConfig
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        Assert-Condition ($rdsCpuLagAcceptanceCase.exitCode -eq 2 -and
            $rdsCpuLagAcceptanceCase.result.failures -contains "run_acceptance_failed" -and
            $rdsCpuLagAcceptanceCase.result.failures -contains "telemetry_coverage:rds_cpu" -and
            $rdsCpuLagAcceptanceCase.result.failures -contains "missing_acceptance_metric:rds" -and
            $rdsCpuLagAcceptanceCase.result.failures -notcontains "stale_metric:rds_cpu" -and
            $null -eq $rdsCpuLagAcceptanceCase.result.acceptance.metrics.PSObject.Properties["rds_cpu"] -and
            -not $rdsCpuLagAcceptanceCase.result.rollback.attempted) "Runtime-fresh RDS CPU from before this run must not pad cumulative coverage or permit acceptance or infrastructure rollback."

        $rdsCpuStaleConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $rdsCpuStaleConfig.runId = "rds-cpu-truly-stale"
        $rdsCpuStaleConfig.minimumWallClockSeconds = $rdsCpuLagConfig.minimumWallClockSeconds
        $rdsCpuStaleConfig.maxIterations = 4
        $env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS = "300"
        $rdsCpuStaleCase = Invoke-ChildMonitorCase "rds-cpu-truly-stale" $rdsCpuStaleConfig
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        $rdsCpuStaleFailures = @($rdsCpuStaleCase.result.failures | Where-Object { $_ -like "stale_metric:*" })
        Assert-Condition ($rdsCpuStaleCase.exitCode -eq 2 -and
            $rdsCpuStaleFailures.Count -eq 1 -and
            $rdsCpuStaleFailures[0] -eq "stale_metric:rds_cpu") "An RDS CPU series older than four raw minutes must still fail closed without implicating current metrics."

        $fastStaleConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $fastStaleConfig.runId = "one-minute-runtime-stale"
        $fastStaleConfig.minimumWallClockSeconds = 10
        $fastStaleConfig.maxIterations = 4
        $env:SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS = "330"
        $fastStaleCase = Invoke-ChildMonitorCase "one-minute-runtime-stale" $fastStaleConfig
        Remove-Item Env:SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        Assert-Condition (@($fastStaleCase.result.failures | Where-Object { $_ -like "stale_metric:ecs_*" }).Count -gt 0) "One-minute metrics must retain the 180-second fail-closed freshness gate."

        foreach ($wafSignal in @(
            [pscustomobject]@{ id="device-blocked-no-valid403"; env="SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK"; failure="waf_device_blocked" },
            [pscustomobject]@{ id="api-blocked-no-valid403"; env="SCHOOLPILOT_TEST_WAF_API_BLOCK"; failure="waf_api_blocked" }
        )) {
            $signalRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
            $signalRollback.runId = $wafSignal.id
            [IO.File]::WriteAllText($childRollbackConfigPath, ($signalRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
            $signalConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
            $signalConfig.runId = $wafSignal.id
            $signalConfig.phase = "Waf"
            $signalConfig.minimumWallClockSeconds = 0
            $signalConfig.automaticRollback = $true
            $signalConfig | Add-Member -NotePropertyName rollbackConfigPath -NotePropertyValue $childRollbackConfigPath -Force
            [Environment]::SetEnvironmentVariable($wafSignal.env, "1", "Process")
            $signalCase = Invoke-ChildMonitorCase $wafSignal.id $signalConfig
            [Environment]::SetEnvironmentVariable($wafSignal.env, $null, "Process")
            Assert-Condition ($signalCase.result.failures -contains $wafSignal.failure -and -not $signalCase.result.rollback.attempted) "Fresh $($wafSignal.failure) without a valid synthetic 403 must stop/alert for manual triage without weakening WAF."
        }

        $wafResourceRunId = "waf-resource-regression"
        $wafResourceRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $wafResourceRollback.runId = $wafResourceRunId
        [IO.File]::WriteAllText($childRollbackConfigPath, ($wafResourceRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $wafResourceConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $wafResourceConfig.runId = $wafResourceRunId
        $wafResourceConfig.phase = "Waf"
        $wafResourceConfig.minimumWallClockSeconds = 0
        $wafResourceConfig.automaticRollback = $true
        $wafResourceConfig | Add-Member -NotePropertyName rollbackConfigPath -NotePropertyValue $childRollbackConfigPath -Force
        $env:SCHOOLPILOT_TEST_PENDING = "1"
        $wafResourceCase = Invoke-ChildMonitorCase $wafResourceRunId $wafResourceConfig
        Remove-Item Env:SCHOOLPILOT_TEST_PENDING -ErrorAction SilentlyContinue
        Assert-Condition (-not $wafResourceCase.result.rollback.attempted -and $null -eq $wafResourceCase.result.rollback.action) "RDS/Redis posture failures without proven application cause must hard-stop instead of guessing an Application or WAF mutation."

        $publicContract = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $publicContract.runId = "public-ip-contract"
        $publicContract.phase = "PublicEcs"
        $publicContract.minimumWallClockSeconds = 0
        $publicContract.resources.expectedEcsAssignPublicIp = $true
        $publicIpCase = Invoke-ChildMonitorCase "public-ip-contract" $publicContract
        Assert-Condition ($publicIpCase.exitCode -eq 2 -and $publicIpCase.result.failures -contains "ecs_network_contract_mismatch") "Public-ECS gate must reject services/tasks without the expected public IPv4 contract."

        $pendingConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $pendingConfig.runId = "pending-modification-gate"
        $pendingConfig.minimumWallClockSeconds = 0
        $env:SCHOOLPILOT_TEST_PENDING = "1"
        $pendingCase = Invoke-ChildMonitorCase "pending-modification-gate" $pendingConfig
        Assert-Condition ($pendingCase.result.failures -contains "rds_pending_modifications" -and $pendingCase.result.failures -contains "redis_pending_modifications") "Load/soak posture must fail closed on non-empty RDS or Redis pending modifications."
        Remove-Item Env:SCHOOLPILOT_TEST_PENDING -ErrorAction SilentlyContinue

        $env:SCHOOLPILOT_TEST_NAT_ZERO = "1"
        $natZero = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $natZero.runId = "nat-zero-contract"
        $natZero.phase = "NatRemoved"
        $natZero.minimumWallClockSeconds = 0
        $natZero.resources.expectedNatGatewayCount = 0
        $natZeroCase = Invoke-ChildMonitorCase "nat-zero-contract" $natZero
        $natZeroEvidence = Get-Content -LiteralPath (Join-Path $childEvidence "nat-zero-contract-aws-monitor.jsonl") -Tail 1 -ErrorAction SilentlyContinue
        Assert-Condition ($natZeroCase.exitCode -eq 0 -and $natZeroCase.result.status -eq "completed") "Post-removal gate must accept exactly zero NAT gateways (actual: $($natZeroCase.result|ConvertTo-Json -Compress -Depth 20); sample: $natZeroEvidence)."
        Remove-Item Env:SCHOOLPILOT_TEST_NAT_ZERO -ErrorAction SilentlyContinue

        $cadenceConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $cadenceConfig.runId = "telemetry-cadence-contract"
        $cadenceConfig.minimumWallClockSeconds = 0
        $cadenceConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 180 -Force
        $cadenceCase = Invoke-ChildMonitorCase "telemetry-cadence-contract" $cadenceConfig
        Assert-Condition ($cadenceCase.exitCode -eq 2 -and $cadenceCase.result.acceptance.violations -contains "telemetry_coverage:ecs_api_cpu" -and
            $cadenceCase.result.acceptance.violations -contains "telemetry_cadence:ecs_api_cpu") "Acceptance must reject sparse/repeated telemetry that lacks unique 60-second coverage and span."

        $rdsBackfillConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $rdsBackfillConfig.runId = "rds-cpu-publication-backfill"
        $rdsBackfillConfig.minimumWallClockSeconds = 0
        $rdsBackfillConfig.maxIterations = 1
        $rdsBackfillConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 120 -Force
        $rdsBackfillConfig | Add-Member -NotePropertyName testTelemetryMetricNames -NotePropertyValue @("rds_cpu") -Force
        $env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL = "1"
        $rdsBackfillCase = Invoke-ChildMonitorCase "rds-cpu-publication-backfill" $rdsBackfillConfig
        Assert-Condition ($rdsBackfillCase.exitCode -eq 0 -and $rdsBackfillCase.result.status -eq "completed" -and
            $rdsBackfillCase.result.acceptance.metrics.rds_cpu.count -eq 2 -and
            $rdsBackfillCase.result.acceptance.metrics.rds_cpu.maximum -eq 12) (
                "Delayed RDS CPU datapoints returned in one poll must backfill strict one-minute acceptance coverage. " +
                "Result: $($rdsBackfillCase.result | ConvertTo-Json -Compress -Depth 30)"
            )

        $rdsSpikeConfig = $rdsBackfillConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $rdsSpikeConfig.runId = "rds-cpu-publication-backfill-spike"
        $env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL_SPIKE = "1"
        $rdsSpikeCase = Invoke-ChildMonitorCase "rds-cpu-publication-backfill-spike" $rdsSpikeConfig
        $rdsSpikeSample = $rdsSpikeCase.lastEvidence | ConvertFrom-Json -Depth 30
        Assert-Condition ($rdsSpikeCase.exitCode -eq 2 -and
            $rdsSpikeCase.result.acceptance.violations -contains "rds_cpu_peak" -and
            $rdsSpikeCase.result.acceptance.metrics.rds_cpu.maximum -eq 70 -and
            $rdsSpikeSample.metrics.rdsCpuPercent -eq 10 -and
            $rdsSpikeCase.result.failures -notcontains "rds_cpu") "A delayed RDS CPU spike must remain visible to cumulative acceptance without replacing the latest-only runtime sample."
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL,Env:SCHOOLPILOT_TEST_RDS_CPU_BACKFILL_SPIKE -ErrorAction SilentlyContinue

        function Set-RdsRuntimeSeriesFixtureClock {
            param($CaseConfig, [int]$BaseMinutesAgo = 3, [int]$BoundaryMinutesAfterBase = 0)
            # Keep exact 60-second spacing without losing up to 59 seconds of
            # freshness to minute rounding before a slow owned child starts.
            $base = [DateTimeOffset]::UtcNow.ToUniversalTime().AddMinutes(-$BaseMinutesAgo)
            $CaseConfig | Add-Member -NotePropertyName testRuntimeSeriesNotBeforeUtc `
                -NotePropertyValue $base.AddMinutes($BoundaryMinutesAfterBase).ToString("o") -Force
            $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE = $base.ToString("o")
        }

        $runtimeMinuteTicks = [TimeSpan]::TicksPerMinute
        $runtimeSeriesConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        # These cases exercise runtime breaches and the iteration ceiling, not
        # cumulative acceptance. Slow mock sweeps must not reach acceptance first.
        # maxIterations still ends each case; this adds no wait and leaves the
        # production three-breach and 240-second RDS freshness thresholds intact.
        $runtimeSeriesConfig.minimumWallClockSeconds = [int][Math]::Ceiling(
            $script:MonitorCompletionWatchdogMilliseconds / 1000.0
        )
        $runtimeSeriesConfig.maxIterations = 1

        $runtimeSeriesConfig.runId = "rds-cpu-delayed-single-runtime"
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = "one"
        Set-RdsRuntimeSeriesFixtureClock $runtimeSeriesConfig
        $singleRuntimeCase = Invoke-ChildMonitorCase "rds-cpu-delayed-single-runtime" $runtimeSeriesConfig
        Assert-Condition ($singleRuntimeCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
            $singleRuntimeCase.result.failures -notcontains "rds_cpu") "One delayed RDS CPU spike must not trigger the three-consecutive-minute runtime gate."

        $runtimeSeriesConfig.runId = "rds-cpu-delayed-three-runtime"
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = "three"
        Set-RdsRuntimeSeriesFixtureClock $runtimeSeriesConfig
        $threeRuntimeCase = Invoke-ChildMonitorCase "rds-cpu-delayed-three-runtime" $runtimeSeriesConfig
        Assert-Condition ($threeRuntimeCase.exitCode -eq 2 -and
            $threeRuntimeCase.result.failures -contains "rds_cpu") "Three consecutive delayed RDS CPU breach datapoints returned together must trigger the runtime gate."

        $runtimeSeriesConfig.runId = "rds-cpu-delayed-gap-runtime"
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = "gapped"
        Set-RdsRuntimeSeriesFixtureClock $runtimeSeriesConfig
        $gappedRuntimeCase = Invoke-ChildMonitorCase "rds-cpu-delayed-gap-runtime" $runtimeSeriesConfig
        Assert-Condition ($gappedRuntimeCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
            $gappedRuntimeCase.result.failures -notcontains "rds_cpu") "A missing one-minute RDS datapoint must reset the consecutive runtime breach counter."

        $historicalRuntimeConfig = $runtimeSeriesConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $historicalRuntimeConfig.runId = "rds-cpu-pre-monitor-history"
        $env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN = "historical"
        Set-RdsRuntimeSeriesFixtureClock $historicalRuntimeConfig -BoundaryMinutesAfterBase 3
        $historicalRuntimeCase = Invoke-ChildMonitorCase "rds-cpu-pre-monitor-history" $historicalRuntimeConfig
        $historicalRuntimeSample = $historicalRuntimeCase.lastEvidence | ConvertFrom-Json -Depth 30
        Assert-Condition ($historicalRuntimeCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
            $historicalRuntimeCase.result.failures -notcontains "rds_cpu" -and
            $historicalRuntimeSample.metrics.rdsCpuPercent -eq 10) "Pre-monitor RDS breach history must not trigger the active phase rollback when the current datapoint is healthy."

        $boundaryStepFile = Join-Path $childRoot "rds-cpu-boundary-step.txt"
        $boundaryRuntimeConfig = $runtimeSeriesConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $boundaryRuntimeConfig.maxIterations = 3
        $boundaryRuntimeConfig | Add-Member -NotePropertyName testMinimumIterationsBeforeAcceptance -NotePropertyValue 3 -Force
        $env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE = $boundaryStepFile
        Remove-Item -LiteralPath $boundaryStepFile -ErrorAction SilentlyContinue
        $boundaryRuntimeConfig.runId = "rds-cpu-boundary-two-post-start"
        Set-RdsRuntimeSeriesFixtureClock $boundaryRuntimeConfig -BaseMinutesAgo 2
        $boundaryTwoCase = Invoke-ChildMonitorCase "rds-cpu-boundary-two-post-start" $boundaryRuntimeConfig
        Assert-Condition ($boundaryTwoCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance" -and
            $boundaryTwoCase.result.failures -notcontains "rds_cpu") "A pre-monitor RDS breach plus only two post-start breaches must not trigger rollback."

        Remove-Item -LiteralPath $boundaryStepFile -ErrorAction SilentlyContinue
        $boundaryRuntimeConfig.runId = "rds-cpu-boundary-three-post-start"
        $boundaryRuntimeConfig.maxIterations = 4
        $boundaryRuntimeConfig.testMinimumIterationsBeforeAcceptance = 4
        Set-RdsRuntimeSeriesFixtureClock $boundaryRuntimeConfig -BaseMinutesAgo 2
        $boundaryThreeCase = Invoke-ChildMonitorCase "rds-cpu-boundary-three-post-start" $boundaryRuntimeConfig
        $boundaryThreeSample = $boundaryThreeCase.lastEvidence | ConvertFrom-Json -DateKind String -Depth 30
        $boundaryThreeContext = [ordered]@{
            exitCode = $boundaryThreeCase.exitCode
            status = $boundaryThreeCase.result.status
            failures = if ($boundaryThreeCase.result.PSObject.Properties["failures"]) { @($boundaryThreeCase.result.failures) } else { @() }
            sampleCount = @(Get-Content -LiteralPath (Join-Path $childEvidence "rds-cpu-boundary-three-post-start-aws-monitor.jsonl")).Count
            lastSampleUtc = $boundaryThreeSample.timestamp
            lastRdsCpuPercent = $boundaryThreeSample.metrics.rdsCpuPercent
        }
        Assert-Condition ($boundaryThreeCase.exitCode -eq 2 -and
            $boundaryThreeCase.result.failures -contains "rds_cpu") (
                "The third consecutive post-start RDS breach must trigger even when an earlier pre-monitor breach was ignored. " +
                "Context: $($boundaryThreeContext | ConvertTo-Json -Compress -Depth 5)"
            )
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_BOUNDARY_STEP_FILE -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $boundaryStepFile -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_BASE,Env:SCHOOLPILOT_TEST_RDS_CPU_RUNTIME_PATTERN -ErrorAction SilentlyContinue

        $loadWindowRunId = "rds-cpu-load-window-boundaries"
        $loadWindowProgress = Join-Path $childRoot "$loadWindowRunId-progress.jsonl"
        $loadWindowSummary = Join-Path $childRoot "$loadWindowRunId-summary.json"
        $loadWindowNow = [DateTimeOffset]::UtcNow.ToUniversalTime()
        $loadWindowStart = [DateTimeOffset]::new(
            $loadWindowNow.Ticks - ($loadWindowNow.Ticks % $runtimeMinuteTicks),
            [TimeSpan]::Zero
        ).AddMinutes(-4)
        $loadWindowStartEvent = @{schemaVersion=1;type="progress";event="start";runId=$loadWindowRunId;stage="window";timestamp=$loadWindowStart.ToString("o")}
        [IO.File]::WriteAllText($loadWindowProgress, ($loadWindowStartEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        Remove-Item -LiteralPath $loadWindowSummary -ErrorAction SilentlyContinue
        $loadWindowHarness = "load-window-harness"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $loadWindowHarness `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-Command","Start-Sleep -Seconds 60")
        Start-Sleep -Milliseconds 200
        $loadWindowHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $loadWindowHarness
        $loadWindowConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $loadWindowConfig.runId = $loadWindowRunId
        $loadWindowConfig.phase = "Waf"
        $loadWindowConfig.minimumWallClockSeconds = 2
        $loadWindowConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $loadWindowConfig.maxIterations = 10
        $loadWindowConfig | Add-Member -NotePropertyName loadProgressPath -NotePropertyValue $loadWindowProgress -Force
        $loadWindowConfig | Add-Member -NotePropertyName loadSummaryPath -NotePropertyValue $loadWindowSummary -Force
        $loadWindowConfig | Add-Member -NotePropertyName artifactsNotBeforeUtc -NotePropertyValue $loadWindowStart.AddSeconds(-1).ToString("o") -Force
        $loadWindowConfig | Add-Member -NotePropertyName harnessProcessId -NotePropertyValue $loadWindowHarnessIdentity.id -Force
        $loadWindowConfig | Add-Member -NotePropertyName harnessProcessStartedAtUtc -NotePropertyValue ([DateTimeOffset]$loadWindowHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o") -Force
        $loadWindowConfig | Add-Member -NotePropertyName harnessProcessPath -NotePropertyValue $loadWindowHarnessIdentity.path -Force
        $loadWindowConfig | Add-Member -NotePropertyName requireLoadAcceptance -NotePropertyValue $true -Force
        $loadWindowConfig | Add-Member -NotePropertyName workload -NotePropertyValue @{stage="window";devices=1;durationSeconds=180;screenshotBytes=1024;canaryDevices=0} -Force
        $loadWindowConfig | Add-Member -NotePropertyName testTelemetryMetricNames -NotePropertyValue @("rds_cpu") -Force
        $loadWindowConfigPath = Join-Path $childRoot "$loadWindowRunId-monitor.json"
        [IO.File]::WriteAllText($loadWindowConfigPath, ($loadWindowConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $env:SCHOOLPILOT_TEST_RDS_CPU_LOAD_WINDOW_START = $loadWindowStart.ToString("o")
        $loadWindowMonitor = "load-window-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $loadWindowMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$loadWindowConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "$loadWindowRunId.out") `
            -StandardErrorPath (Join-Path $childRoot "$loadWindowRunId.err")
        $loadWindowEvidencePath = Join-Path $childEvidence "$loadWindowRunId-aws-monitor.jsonl"
        $loadWindowStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while (-not (Test-Path -LiteralPath $loadWindowEvidencePath) -and
            -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $loadWindowMonitor).hasExited -and
            [DateTimeOffset]::UtcNow -lt $loadWindowStartDeadline) { Start-Sleep -Milliseconds 100 }
        if (-not (Test-Path -LiteralPath $loadWindowEvidencePath)) {
            $loadWindowDiagnostic = Close-OwnedTestProcessForDiagnostics `
                -Registry $ownedTestProcesses -Name $loadWindowMonitor `
                -StandardOutputPath (Join-Path $childRoot "$loadWindowRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$loadWindowRunId.err")
            if (-not $ownedTestProcesses.Contains($loadWindowMonitor)) { $loadWindowMonitor = $null }
            throw "Load-window boundary monitor did not start (exited=$($loadWindowDiagnostic.state.hasExited); cleanup=$($loadWindowDiagnostic.cleanupFailure); stdout=$($loadWindowDiagnostic.standardOutput); stderr=$($loadWindowDiagnostic.standardError))."
        }
        $loadWindowSummaryValue = @{runId=$loadWindowRunId;stage="window";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=180;actualTrafficSeconds=181;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};thresholds=@{passed=$true};fatalGate=$null}
        [IO.File]::WriteAllText($loadWindowSummary, ($loadWindowSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $loadWindowFinalEvent = @{schemaVersion=1;type="progress";event="final";runId=$loadWindowRunId;stage="window";timestamp=[DateTimeOffset]::UtcNow.ToString("o")}
        [IO.File]::AppendAllText($loadWindowProgress, ($loadWindowFinalEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        $loadWindowMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
            -Name $loadWindowMonitor -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $loadWindowMonitor = $null
        $loadWindowResult = Get-Content -LiteralPath (Join-Path $childEvidence "$loadWindowRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 30
        Assert-Condition ($loadWindowMonitorCompletion.exitCode -eq 2 -and
            $loadWindowResult.failures -contains "run_acceptance_failed" -and
            $loadWindowResult.failures -notcontains "rds_cpu" -and
            $loadWindowResult.acceptance.violations -contains "rds_cpu_peak" -and
            $loadWindowResult.acceptance.metrics.rds_cpu.count -eq 4 -and
            $loadWindowResult.acceptance.metrics.rds_cpu.maximum -eq 70) "Load telemetry must use the full actual traffic window, retain its delayed tail spike, and exclude pre-start, post-stop, and future RDS points across later polls."
        Remove-Item Env:SCHOOLPILOT_TEST_RDS_CPU_LOAD_WINDOW_START -ErrorAction SilentlyContinue
        Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $loadWindowHarness
        $loadWindowHarness = $null

        $futureFinalRunId = "load-future-final-rejected"
        $futureFinalProgress = Join-Path $childRoot "$futureFinalRunId-progress.jsonl"
        $futureFinalSummary = Join-Path $childRoot "$futureFinalRunId-summary.json"
        $futureFinalStartedAt = [DateTimeOffset]::UtcNow
        $futureFinalStartEvent = @{schemaVersion=1;type="progress";event="start";runId=$futureFinalRunId;stage="future";timestamp=$futureFinalStartedAt.ToString("o")}
        [IO.File]::WriteAllText($futureFinalProgress, ($futureFinalStartEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        Remove-Item -LiteralPath $futureFinalSummary -ErrorAction SilentlyContinue
        $futureFinalHarness = "future-final-harness"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $futureFinalHarness `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-Command","Start-Sleep -Seconds 60")
        Start-Sleep -Milliseconds 200
        $futureFinalHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $futureFinalHarness
        $futureFinalConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $futureFinalConfig.runId = $futureFinalRunId
        $futureFinalConfig.phase = "Waf"
        $futureFinalConfig.minimumWallClockSeconds = 0
        $futureFinalConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $futureFinalConfig.maxIterations = 10
        $futureFinalConfig | Add-Member -NotePropertyName loadProgressPath -NotePropertyValue $futureFinalProgress -Force
        $futureFinalConfig | Add-Member -NotePropertyName loadSummaryPath -NotePropertyValue $futureFinalSummary -Force
        $futureFinalConfig | Add-Member -NotePropertyName artifactsNotBeforeUtc -NotePropertyValue $futureFinalStartedAt.AddSeconds(-1).ToString("o") -Force
        $futureFinalConfig | Add-Member -NotePropertyName harnessProcessId -NotePropertyValue $futureFinalHarnessIdentity.id -Force
        $futureFinalConfig | Add-Member -NotePropertyName harnessProcessStartedAtUtc -NotePropertyValue ([DateTimeOffset]$futureFinalHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o") -Force
        $futureFinalConfig | Add-Member -NotePropertyName harnessProcessPath -NotePropertyValue $futureFinalHarnessIdentity.path -Force
        $futureFinalConfig | Add-Member -NotePropertyName requireLoadAcceptance -NotePropertyValue $true -Force
        $futureFinalConfig | Add-Member -NotePropertyName workload -NotePropertyValue @{stage="future";devices=1;durationSeconds=1;screenshotBytes=1024;canaryDevices=0} -Force
        $futureFinalConfigPath = Join-Path $childRoot "$futureFinalRunId-monitor.json"
        [IO.File]::WriteAllText($futureFinalConfigPath, ($futureFinalConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $futureFinalMonitor = "future-final-monitor"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $futureFinalMonitor `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$futureFinalConfigPath,"-Mode","Monitor") `
            -StandardOutputPath (Join-Path $childRoot "$futureFinalRunId.out") `
            -StandardErrorPath (Join-Path $childRoot "$futureFinalRunId.err")
        $futureFinalEvidencePath = Join-Path $childEvidence "$futureFinalRunId-aws-monitor.jsonl"
        $futureFinalStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while (-not (Test-Path -LiteralPath $futureFinalEvidencePath) -and
            -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $futureFinalMonitor).hasExited -and
            [DateTimeOffset]::UtcNow -lt $futureFinalStartDeadline) { Start-Sleep -Milliseconds 100 }
        if (-not (Test-Path -LiteralPath $futureFinalEvidencePath)) {
            $futureFinalDiagnostic = Close-OwnedTestProcessForDiagnostics `
                -Registry $ownedTestProcesses -Name $futureFinalMonitor `
                -StandardOutputPath (Join-Path $childRoot "$futureFinalRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$futureFinalRunId.err")
            if (-not $ownedTestProcesses.Contains($futureFinalMonitor)) { $futureFinalMonitor = $null }
            throw "Future-final rejection monitor did not start (exited=$($futureFinalDiagnostic.state.hasExited); cleanup=$($futureFinalDiagnostic.cleanupFailure); stdout=$($futureFinalDiagnostic.standardOutput); stderr=$($futureFinalDiagnostic.standardError))."
        }
        $futureFinalSummaryValue = @{runId=$futureFinalRunId;stage="future";devices=1;declaredSecondSchoolCanaryDevices=0;
          run=@{plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true};screenshotFixture=@{decodedBytes=1024};thresholds=@{passed=$true};fatalGate=$null}
        [IO.File]::WriteAllText($futureFinalSummary, ($futureFinalSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        $futureFinalEvent = @{schemaVersion=1;type="progress";event="final";runId=$futureFinalRunId;stage="future";timestamp=[DateTimeOffset]::UtcNow.AddMinutes(10).ToString("o")}
        [IO.File]::AppendAllText($futureFinalProgress, ($futureFinalEvent|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        $futureFinalMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
            -Name $futureFinalMonitor -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $futureFinalMonitor = $null
        $futureFinalResult = Get-Content -LiteralPath (Join-Path $childEvidence "$futureFinalRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 30
        Assert-Condition ($futureFinalMonitorCompletion.exitCode -eq 2 -and
            $futureFinalResult.failures -contains "load_workload_contract_mismatch" -and
            -not $futureFinalResult.rollback.attempted) "A future-dated final progress record must fail closed without extending telemetry or guessing at rollback."
        Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $futureFinalHarness
        $futureFinalHarness = $null

        for ($fiveMinuteIteration = 1; $fiveMinuteIteration -le $FiveMinuteTelemetryRepeatCount; $fiveMinuteIteration++) {
            $fiveMinuteSuffix = if ($FiveMinuteTelemetryRepeatCount -eq 1) { "" } else { "-$fiveMinuteIteration" }
            $fiveMinuteCompleteCaseId = "five-minute-telemetry-complete$fiveMinuteSuffix"
            $fiveMinuteGappedCaseId = "five-minute-telemetry-gapped$fiveMinuteSuffix"
            $fiveMinuteConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
            $fiveMinuteConfig.runId = $fiveMinuteCompleteCaseId
            $fiveMinuteConfig.minimumWallClockSeconds = 2
            $fiveMinuteConfig.maxIterations = 5
            $fiveMinuteConfig | Add-Member -NotePropertyName testMinimumIterationsBeforeAcceptance -NotePropertyValue 2 -Force
            $fiveMinuteConfig | Add-Member -NotePropertyName testTelemetryExpectedSeconds -NotePropertyValue 600 -Force
            $fiveMinuteConfig | Add-Member -NotePropertyName testTelemetryMetricNames -NotePropertyValue @("rds_cpu_credit","rds_surplus_charged","redis_cpu_credit") -Force
            $env:SCHOOLPILOT_TEST_METRIC_STEP_FILE = Join-Path $childRoot "$fiveMinuteCompleteCaseId-counter.txt"
            $env:SCHOOLPILOT_TEST_METRIC_STEP_START = [DateTimeOffset]::UtcNow.AddSeconds(-600).ToString("o")
            $env:SCHOOLPILOT_TEST_METRIC_STEP_SECONDS = "300"
            $fiveMinuteCase = Invoke-ChildMonitorCase $fiveMinuteCompleteCaseId $fiveMinuteConfig
            Assert-Condition ($fiveMinuteCase.exitCode -eq 0) "Healthy five-minute credit/surplus telemetry must use proportional coverage and a bounded 360-second gap (iteration=$fiveMinuteIteration, actual: $($fiveMinuteCase.result|ConvertTo-Json -Compress -Depth 30))."

            $gappedFiveMinute = $fiveMinuteConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
            $gappedFiveMinute.runId = $fiveMinuteGappedCaseId
            $env:SCHOOLPILOT_TEST_METRIC_STEP_FILE = Join-Path $childRoot "$fiveMinuteGappedCaseId-counter.txt"
            $env:SCHOOLPILOT_TEST_METRIC_STEP_START = [DateTimeOffset]::UtcNow.AddSeconds(-800).ToString("o")
            $env:SCHOOLPILOT_TEST_METRIC_STEP_SECONDS = "400"
            $gappedFiveMinuteCase = Invoke-ChildMonitorCase $fiveMinuteGappedCaseId $gappedFiveMinute
            Assert-Condition ($gappedFiveMinuteCase.result.acceptance.violations -contains "telemetry_cadence:rds_cpu_credit") "A >360-second gap in five-minute credit telemetry must fail acceptance (iteration=$fiveMinuteIteration)."
        }
        Remove-Item Env:SCHOOLPILOT_TEST_METRIC_STEP_FILE,Env:SCHOOLPILOT_TEST_METRIC_STEP_START,Env:SCHOOLPILOT_TEST_METRIC_STEP_SECONDS -ErrorAction SilentlyContinue

        $auxConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $auxConfig.runId = "auxiliary-resource-gates"
        $auxConfig.minimumWallClockSeconds = 10
        $auxConfig.maxIterations = 5
        $env:SCHOOLPILOT_TEST_AUX_BREACH = "1"
        $auxCase = Invoke-ChildMonitorCase "auxiliary-resource-gates" $auxConfig
        foreach ($expectedGate in @("rds_free_memory", "rds_cpu_credit", "rds_surplus_credits_charged", "redis_cpu_credit")) {
            Assert-Condition ($auxCase.result.failures -contains $expectedGate) "Runtime monitoring must enforce three consecutive minutes for $expectedGate."
        }
        Remove-Item Env:SCHOOLPILOT_TEST_AUX_BREACH -ErrorAction SilentlyContinue

        $swapConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $swapConfig.runId = "rds-swap-growth-gate"
        $swapConfig.minimumWallClockSeconds = 10
        $swapConfig.maxIterations = 5
        $env:SCHOOLPILOT_TEST_SWAP_COUNTER = Join-Path $childRoot "swap-counter.txt"
        $swapCase = Invoke-ChildMonitorCase "rds-swap-growth-gate" $swapConfig
        Assert-Condition ($swapCase.result.failures -contains "rds_swap_growing") "RDS SwapUsage growth must be a three-consecutive-datapoint runtime gate."
        Remove-Item Env:SCHOOLPILOT_TEST_SWAP_COUNTER -ErrorAction SilentlyContinue

        $freshnessConfig = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $freshnessConfig.runId = "metric-freshness-gate"
        $freshnessConfig.minimumWallClockSeconds = 10
        $freshnessConfig.maxIterations = 4
        $env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP = [DateTimeOffset]::UtcNow.AddMinutes(-10).ToString("o")
        $freshnessCase = Invoke-ChildMonitorCase "metric-freshness-gate" $freshnessConfig
        Assert-Condition (@($freshnessCase.result.failures | Where-Object { $_ -like "stale_metric:*" }).Count -gt 0) "Runtime telemetry must fail closed after three stale one-minute checks."
        Remove-Item Env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_SPARSE_ZERO,Env:SCHOOLPILOT_TEST_WAF_PARTIAL_EMPTY,Env:SCHOOLPILOT_TEST_FIVE_MINUTE_METRIC_AGE_SECONDS,Env:SCHOOLPILOT_TEST_FAST_METRIC_AGE_SECONDS,Env:SCHOOLPILOT_TEST_RDS_CPU_METRIC_AGE_SECONDS -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_DELAY -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_ZERO -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_WAF_DEVICE_BLOCK,Env:SCHOOLPILOT_TEST_WAF_API_BLOCK -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_METRIC_STEP_FILE,Env:SCHOOLPILOT_TEST_METRIC_STEP_START,Env:SCHOOLPILOT_TEST_METRIC_STEP_SECONDS -ErrorAction SilentlyContinue
        # All earlier cases should have released their entries. Drain any
        # unexpected survivor before final-stage fixtures reuse rollback state.
        try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses } finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses }

        $env:SCHOOLPILOT_TEST_REDIS_TYPE = "cache.t4g.micro"
        $env:SCHOOLPILOT_TEST_SNAPSHOT_TIME = [DateTimeOffset]::UtcNow.ToString("o")
        $finalSnapshot = $limitConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $finalSnapshot.runId = "final-automated-snapshot"
        $finalSnapshot.phase = "Final"
        $finalSnapshot.minimumWallClockSeconds = 0
        $finalSnapshot.resources.expectedRedisNodeType = "cache.t4g.micro"
        $finalSnapshot | Add-Member -NotePropertyName redisResizeCompletedAtUtc -NotePropertyValue ([DateTimeOffset]::UtcNow.AddHours(-1).ToString("o")) -Force
        $finalSnapshotCase = Invoke-ChildMonitorCase "final-automated-snapshot" $finalSnapshot
        Assert-Condition ($finalSnapshotCase.exitCode -eq 0 -and $finalSnapshotCase.result.automatedRedisSnapshot.accepted) "Final gate must verify cache.t4g.micro and a later available automated snapshot."

        Remove-Item Env:SCHOOLPILOT_TEST_SNAPSHOT_TIME -ErrorAction SilentlyContinue
        $missingSnapshot = $finalSnapshot | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $missingSnapshot.runId = "final-missing-snapshot"
        $missingSnapshotCase = Invoke-ChildMonitorCase "final-missing-snapshot" $missingSnapshot
        Assert-Condition ($missingSnapshotCase.exitCode -eq 2 -and $missingSnapshotCase.result.failures -contains "monitor_iteration_limit_reached_before_acceptance") "Final acceptance must wait for an available automated snapshot created after resize (actual: $($missingSnapshotCase.result|ConvertTo-Json -Compress -Depth 30); evidence: $($missingSnapshotCase.lastEvidence))."

        $completedWaitRunId = "final-completed-awaits-snapshot"
        $completedWaitProgress = Join-Path $childRoot "$completedWaitRunId-progress.jsonl"
        $completedWaitSummary = Join-Path $childRoot "$completedWaitRunId-summary.json"
        $completedWaitSnapshotFile = Join-Path $childRoot "$completedWaitRunId-snapshot-time.txt"
        $completedWaitRollbackEvidence = Join-Path $childEvidence "$completedWaitRunId-rollback.jsonl"
        Remove-Item -LiteralPath $completedWaitSummary,$completedWaitSnapshotFile,$completedWaitRollbackEvidence -ErrorAction SilentlyContinue
        # Keep the bound dummy generator alive beyond every observation wait;
        # the test stops it explicitly after snapshot acceptance.
        $completedWaitHarness = "completed-wait-harness"
        Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $completedWaitHarness `
            -FilePath (Get-Process -Id $PID).Path `
            -ArgumentList @("-NoProfile","-Command","Start-Sleep -Seconds 180")
        Start-Sleep -Milliseconds 200
        $completedWaitHarnessIdentity = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $completedWaitHarness
        $completedWaitStarted = [DateTimeOffset]::UtcNow.AddSeconds(-1)
        $completedWaitMetricTimestamp = [DateTimeOffset]::UtcNow
        $initialCompletedWaitProgress = @{schemaVersion=1;type="progress";event="start";runId=$completedWaitRunId;stage="endurance";timestamp=$completedWaitMetricTimestamp.ToString("o")}
        [IO.File]::WriteAllText($completedWaitProgress, ($initialCompletedWaitProgress|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))

        $completedWaitRollback = $childRollback | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $completedWaitRollback.runId = $completedWaitRunId
        $completedWaitRollback | Add-Member -NotePropertyName redisReplicationGroupId -NotePropertyValue "redis" -Force
        [IO.File]::WriteAllText($childRollbackConfigPath, ($completedWaitRollback|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $completedWaitConfig = $childConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $completedWaitConfig.runId = $completedWaitRunId
        $completedWaitConfig.phase = "Final"
        $completedWaitConfig.loadProgressPath = $completedWaitProgress
        $completedWaitConfig.loadSummaryPath = $completedWaitSummary
        $completedWaitConfig.artifactsNotBeforeUtc = $completedWaitStarted.ToString("o")
        $completedWaitConfig.rollbackConfigPath = $childRollbackConfigPath
        $completedWaitConfig.minimumWallClockSeconds = 0
        $completedWaitConfig.maxIterations = 15
        $completedWaitConfig.deadlineUtc = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("o")
        $completedWaitConfig.harnessProcessId = $completedWaitHarnessIdentity.id
        $completedWaitConfig.harnessProcessStartedAtUtc = ([DateTimeOffset]$completedWaitHarnessIdentity.startedAtUtc).ToUniversalTime().ToString("o")
        $completedWaitConfig.harnessProcessPath = $completedWaitHarnessIdentity.path
        $completedWaitConfig.workload = @{
            stage="endurance";devices=810;durationSeconds=1;screenshotBytes=40960;canaryDevices=10
            workloadSchemaVersion="classpilot-tile-batch-v1"
            endpointShapeSha256="8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"
        }
        $completedWaitConfig.resources.expectedRedisNodeType = "cache.t4g.micro"
        $completedWaitConfig | Add-Member -NotePropertyName redisResizeCompletedAtUtc -NotePropertyValue ([DateTimeOffset]::UtcNow.AddHours(-1).ToString("o")) -Force
        # The first sample reads progress before its mocked AWS calls, so the
        # stale bound must cover slow monitor startup. It stays far below the
        # ten-minute mtime skew applied below, which still exercises the gate.
        $completedWaitConfig | Add-Member -NotePropertyName thresholds -NotePropertyValue @{progressStaleSeconds=$script:SupervisedSampleBudgetSeconds} -Force
        $completedWaitConfigPath = Join-Path $childRoot "$completedWaitRunId-monitor.json"
        [IO.File]::WriteAllText($completedWaitConfigPath, ($completedWaitConfig|ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $completedWaitBarrierArm = Join-Path $childRoot "$completedWaitRunId-sample-barrier-arm.flag"
        $completedWaitBarrierReady = Join-Path $childRoot "$completedWaitRunId-sample-barrier-ready.flag"
        $completedWaitBarrierRelease = Join-Path $childRoot "$completedWaitRunId-sample-barrier-release.flag"
        $completedWaitBarrierConsumed = Join-Path $childRoot "$completedWaitRunId-sample-barrier-consumed.flag"
        [IO.File]::WriteAllText($completedWaitBarrierArm, "1", [Text.UTF8Encoding]::new($false))
        $completedWaitBarrierEnvironment = [ordered]@{}
        foreach ($entry in ([ordered]@{
            SCHOOLPILOT_TEST_SAMPLE_BARRIER_ARM = $completedWaitBarrierArm
            SCHOOLPILOT_TEST_SAMPLE_BARRIER_READY = $completedWaitBarrierReady
            SCHOOLPILOT_TEST_SAMPLE_BARRIER_RELEASE = $completedWaitBarrierRelease
            SCHOOLPILOT_TEST_SAMPLE_BARRIER_CONSUMED = $completedWaitBarrierConsumed
        }).GetEnumerator()) {
            $completedWaitBarrierEnvironment[$entry.Key] = [Environment]::GetEnvironmentVariable($entry.Key, "Process")
            [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
        }
        # Bind this one-second synthetic workload to a datapoint inside its
        # acceptance window. Otherwise a minute rollover between progress
        # completion and the mock CloudWatch poll can exclude only RDS CPU.
        $env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP = $completedWaitMetricTimestamp.ToString("o")
        $env:SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE = $completedWaitSnapshotFile
        try {
            $completedWaitMonitor = "completed-wait-monitor"
            Start-OwnedTestProcess -Registry $ownedTestProcesses -Name $completedWaitMonitor `
                -FilePath (Get-Process -Id $PID).Path `
                -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$monitorScript,"-ConfigPath",$completedWaitConfigPath,"-Mode","Monitor") `
                -StandardOutputPath (Join-Path $childRoot "$completedWaitRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$completedWaitRunId.err")
            Remove-Item Env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP -ErrorAction SilentlyContinue
            $completedWaitBarrierDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
            while (-not (Test-Path -LiteralPath $completedWaitBarrierReady) -and
                -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $completedWaitMonitor).hasExited -and
                [DateTimeOffset]::UtcNow -lt $completedWaitBarrierDeadline) {
                Start-Sleep -Milliseconds 100
            }
            if (-not (Test-Path -LiteralPath $completedWaitBarrierReady)) {
                $completedWaitBarrierDiagnostic = Close-OwnedTestProcessForDiagnostics `
                    -Registry $ownedTestProcesses -Name $completedWaitMonitor `
                    -StandardOutputPath (Join-Path $childRoot "$completedWaitRunId.out") `
                    -StandardErrorPath (Join-Path $childRoot "$completedWaitRunId.err")
                if (-not $ownedTestProcesses.Contains($completedWaitMonitor)) { $completedWaitMonitor = $null }
                throw "Completed-final snapshot-wait monitor did not reach its first sample barrier (exited=$($completedWaitBarrierDiagnostic.state.hasExited); cleanup=$($completedWaitBarrierDiagnostic.cleanupFailure); stdout=$($completedWaitBarrierDiagnostic.standardOutput); stderr=$($completedWaitBarrierDiagnostic.standardError))."
            }

            $completedWaitSummaryValue = @{
              runId=$completedWaitRunId;stage="endurance";devices=810;declaredSecondSchoolCanaryDevices=10
              workloadSchemaVersion="classpilot-tile-batch-v1"
              workloadEndpointShapeSha256="8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2"
              run=@{
                shutdownReason="duration";durationClock="monotonic-hrtime-v1";runtimeTargetTrafficSeconds=1
                plannedTrafficMilliseconds=1000;actualTrafficMilliseconds=1000
                plannedTrafficSeconds=1;actualTrafficSeconds=1;completedConfiguredDuration=$true
              }
              screenshotFixture=@{decodedBytes=40960};thresholds=@{passed=$true};fatalGate=$null
              screenshotRetrieval=@{attempts=800;successes=800;successPercent=100}
              tileBatch=@{
                configured=$true;pollAccountingVersion="staggered-deadline-v1";teacherCohorts=20;studentsPerCohort=40;teacherTileAssignments=800
                requestsPerCohortPerPoll=2;logicalOperationsPerPoll=1600
                historyRequestsByCohort=@(1)*20;screenshotRequestsByCohort=@(1)*20
                completeRoundsPerCohort=1;maximumRoundsPerCohort=1;partialFinalRoundCohorts=0
                historyRequests=20;screenshotRequests=20;historyLogicalOperations=800;screenshotLogicalOperations=800
                networkRequests=40;logicalOperations=1600
              }
            }
            [IO.File]::WriteAllText($completedWaitSummary, ($completedWaitSummaryValue|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
            $completedWaitFinalProgress = @{schemaVersion=1;type="progress";event="final";runId=$completedWaitRunId;stage="endurance";timestamp=[DateTimeOffset]::UtcNow.ToString("o")}
            [IO.File]::AppendAllText($completedWaitProgress, ($completedWaitFinalProgress|ConvertTo-Json -Compress -Depth 10)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
            (Get-Item -LiteralPath $completedWaitProgress).LastWriteTimeUtc = [DateTime]::UtcNow.AddMinutes(-10)
            [IO.File]::WriteAllText($completedWaitBarrierRelease, "1", [Text.UTF8Encoding]::new($false))
        }
        finally {
            Remove-Item Env:SCHOOLPILOT_TEST_METRIC_TIMESTAMP -ErrorAction SilentlyContinue
            if (-not (Test-Path -LiteralPath $completedWaitBarrierRelease)) {
                [IO.File]::WriteAllText($completedWaitBarrierRelease, "1", [Text.UTF8Encoding]::new($false))
            }
            foreach ($entry in $completedWaitBarrierEnvironment.GetEnumerator()) {
                [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, "Process")
            }
        }

        $completedWaitEvidencePath = Join-Path $childEvidence "$completedWaitRunId-aws-monitor.jsonl"
        $completedWaitStartDeadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
        while (-not (Test-Path -LiteralPath $completedWaitEvidencePath) -and [DateTimeOffset]::UtcNow -lt $completedWaitStartDeadline) { Start-Sleep -Milliseconds 100 }
        if (-not (Test-Path -LiteralPath $completedWaitEvidencePath)) {
            $completedWaitStartDiagnostic = Close-OwnedTestProcessForDiagnostics `
                -Registry $ownedTestProcesses -Name $completedWaitMonitor `
                -StandardOutputPath (Join-Path $childRoot "$completedWaitRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$completedWaitRunId.err")
            if (-not $ownedTestProcesses.Contains($completedWaitMonitor)) { $completedWaitMonitor = $null }
            throw "Completed-final snapshot-wait monitor did not start (exited=$($completedWaitStartDiagnostic.state.hasExited); cleanup=$($completedWaitStartDiagnostic.cleanupFailure); stdout=$($completedWaitStartDiagnostic.standardOutput); stderr=$($completedWaitStartDiagnostic.standardError))."
        }

        $completedWaitSample = $null
        # A Windows mock-AWS sweep launches enough short-lived pwsh processes
        # that the semantic sample after the progress->final transition can
        # legitimately take longer than 15 seconds on a busy runner.
        $completedWaitSampleDeadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while (
            $null -eq $completedWaitSample -and
            -not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $completedWaitMonitor).hasExited -and
            [DateTimeOffset]::UtcNow -lt $completedWaitSampleDeadline
        ) {
            foreach ($line in @(Get-Content -LiteralPath $completedWaitEvidencePath -ErrorAction SilentlyContinue)) {
                try { $candidate = $line | ConvertFrom-Json -Depth 30 }
                catch { continue }
                if ($candidate.type -eq "aws_rollout_sample" -and $candidate.loadCompleted -eq $true -and $candidate.automatedRedisSnapshot.accepted -eq $false) {
                    $completedWaitSample = $candidate
                }
            }
            if ($null -eq $completedWaitSample) { Start-Sleep -Milliseconds 100 }
        }
        $completedWaitMonitorState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $completedWaitMonitor
        $completedWaitExitCode = $completedWaitMonitorState.exitCode
        $completedWaitDiagnosticResult = Get-Content -LiteralPath (Join-Path $childEvidence "$completedWaitRunId-monitor-result.json") -Raw -ErrorAction SilentlyContinue
        $completedWaitDiagnosticEvidence = @(Get-Content -LiteralPath $completedWaitEvidencePath -Tail 3 -ErrorAction SilentlyContinue)
        if ($null -eq $completedWaitSample -or
            $completedWaitSample.immediateFailures -contains "load_progress_stale") {
            $completedWaitSampleDiagnostic = Close-OwnedTestProcessForDiagnostics `
                -Registry $ownedTestProcesses -Name $completedWaitMonitor `
                -StandardOutputPath (Join-Path $childRoot "$completedWaitRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$completedWaitRunId.err")
            if (-not $ownedTestProcesses.Contains($completedWaitMonitor)) { $completedWaitMonitor = $null }
            throw "A valid completed final workload must remain accepted after its progress artifact becomes old while the automated snapshot is pending (monitorExited=$($completedWaitMonitorState.hasExited); exitCode=$completedWaitExitCode; sample=$($completedWaitSample|ConvertTo-Json -Compress -Depth 20); result=$completedWaitDiagnosticResult; cleanup=$($completedWaitSampleDiagnostic.cleanupFailure); stdout=$($completedWaitSampleDiagnostic.standardOutput); stderr=$($completedWaitSampleDiagnostic.standardError); evidence=$($completedWaitDiagnosticEvidence -join ' || '))."
        }
        Start-Sleep -Milliseconds 1200
        $completedWaitMonitorState = Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name $completedWaitMonitor
        $earlyCompletedWaitResult = Get-Content -LiteralPath (Join-Path $childEvidence "$completedWaitRunId-monitor-result.json") -Raw -ErrorAction SilentlyContinue
        if ($completedWaitMonitorState.hasExited -or (Test-Path -LiteralPath $completedWaitRollbackEvidence)) {
            $completedWaitEarlyExitDiagnostic = Close-OwnedTestProcessForDiagnostics `
                -Registry $ownedTestProcesses -Name $completedWaitMonitor `
                -StandardOutputPath (Join-Path $childRoot "$completedWaitRunId.out") `
                -StandardErrorPath (Join-Path $childRoot "$completedWaitRunId.err")
            if (-not $ownedTestProcesses.Contains($completedWaitMonitor)) { $completedWaitMonitor = $null }
            throw "The final monitor must keep waiting without Redis rollback after traffic completes and before the post-resize automated snapshot appears (result=$earlyCompletedWaitResult; cleanup=$($completedWaitEarlyExitDiagnostic.cleanupFailure); stdout=$($completedWaitEarlyExitDiagnostic.standardOutput); stderr=$($completedWaitEarlyExitDiagnostic.standardError))."
        }

        [IO.File]::WriteAllText($completedWaitSnapshotFile, [DateTimeOffset]::UtcNow.ToString("o"), [Text.UTF8Encoding]::new($false))
        $completedWaitMonitorCompletion = Complete-OwnedTestProcess -Registry $ownedTestProcesses `
            -Name $completedWaitMonitor -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
        $completedWaitFinalExitCode = $completedWaitMonitorCompletion.exitCode
        $completedWaitMonitor = $null
        $completedWaitResult = Get-Content -LiteralPath (Join-Path $childEvidence "$completedWaitRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 30
        $completedWaitDiagnosticError = Get-Content -LiteralPath (Join-Path $childRoot "$completedWaitRunId.err") -Raw -ErrorAction SilentlyContinue
        Assert-Condition ($completedWaitFinalExitCode -eq 0 -and $completedWaitResult.status -eq "completed" -and $completedWaitResult.automatedRedisSnapshot.accepted -and
            -not (Test-Path -LiteralPath $completedWaitRollbackEvidence)) "An old, valid completed progress artifact must remain accepted until a qualifying post-resize automated snapshot arrives, with no Redis rollback (exit=$completedWaitFinalExitCode; result=$($completedWaitResult|ConvertTo-Json -Compress -Depth 30); stderr=$completedWaitDiagnosticError)."
        Assert-Condition (
            $completedWaitResult.workload.workloadSchemaVersion -eq "classpilot-tile-batch-v1" -and
            $completedWaitResult.workload.endpointShapeSha256 -eq "8e9f1942e4b3a27de7dd0571a9f60ffeb276c089e4baae96a885dba69e3233b2" -and
            $completedWaitResult.workload.tileBatch.teacherCohorts -eq 20 -and
            $completedWaitResult.workload.tileBatch.pollAccountingVersion -eq "staggered-deadline-v1" -and
            $completedWaitResult.workload.tileBatch.studentsPerCohort -eq 40 -and
            $completedWaitResult.workload.tileBatch.requestsPerCohortPerPoll -eq 2 -and
            $completedWaitResult.workload.tileBatch.historyLogicalOperations -eq 800 -and
            $completedWaitResult.workload.tileBatch.screenshotLogicalOperations -eq 800 -and
            $completedWaitResult.workload.tileBatch.screenshotAttempts -eq 800
        ) "The actual monitor writer must seal the schema, endpoint shape, 20x40 cohort contract, and per-tile logical accounting for supervisor continuity."
        Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $completedWaitHarness
        $completedWaitHarness = $null
        Remove-Item Env:SCHOOLPILOT_TEST_SNAPSHOT_TIME_FILE -ErrorAction SilentlyContinue
        Remove-Item Env:SCHOOLPILOT_TEST_REDIS_TYPE -ErrorAction SilentlyContinue

        $monitorOnlyRunId = "monitor-only-lifecycle"
        $monitorOnlyEvidence = Join-Path $childRoot "monitor-only-evidence"
        $monitorOnlyConfigPath = Join-Path $childRoot "monitor-only-lifecycle.json"
        $monitorOnlyConfig = @{
            schemaVersion=1;runId=$monitorOnlyRunId;phase="PublicEcs";evidenceDirectory=$monitorOnlyEvidence;automaticRollback=$false;
            testEnvironmentSentinel="SCHOOLPILOT_ROLLOUT_TEST_ONLY";notificationTopicArn="arn:aws:sns:us-east-1:000000000000:test";pollSeconds=1;testMode=$true;maxIterations=1;
            minimumWallClockSeconds=0;deadlineUtc=[DateTimeOffset]::UtcNow.AddMinutes(1).ToString("o");
            resources=@{region="us-east-1";cluster="cluster";apiService="api";workerService="worker";targetGroupArn="target";rdsInstanceId="db";
              redisCacheClusterId="redis-001";redisReplicationGroupId="redis";vpcId="vpc";wafWebAclName="acl";wafDeviceRuleMetricName="device";
              wafApiRuleMetricName="api";route53HealthCheckId="health";route53AlarmName="route-alarm";expectedNatGatewayCount=2;expectedRoute53MeasureLatency=$true;
              expectedEcsAssignPublicIp=$false;ecsTaskSubnetIds=@("private-a","private-b");expectedRedisNodeType="cache.t4g.small"}
        }
        [IO.File]::WriteAllText($monitorOnlyConfigPath, ($monitorOnlyConfig|ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
        & $supervisorScript -ConfigPath $monitorOnlyConfigPath -Mode Run -SupervisionKind MonitorOnly | Out-Null
        $monitorOnlySupervisorResult = Get-Content -LiteralPath (Join-Path $monitorOnlyEvidence "$monitorOnlyRunId-supervisor-result.json") -Raw | ConvertFrom-Json -Depth 10
        $monitorOnlyMonitorResult = Get-Content -LiteralPath (Join-Path $monitorOnlyEvidence "$monitorOnlyRunId-monitor-result.json") -Raw | ConvertFrom-Json -Depth 20
        Assert-Condition ($monitorOnlySupervisorResult.status -eq "completed" -and $monitorOnlySupervisorResult.supervisionKind -eq "MonitorOnly") "MonitorOnly supervisor lifecycle must complete with watcher evidence."
        Assert-Condition ($monitorOnlyMonitorResult.status -eq "completed") "MonitorOnly lifecycle must supervise the AWS monitor to completion."
        Assert-Condition (-not (Test-Path -LiteralPath (Join-Path $monitorOnlyEvidence "$monitorOnlyRunId-harness.stdout.log"))) "MonitorOnly lifecycle must never launch or create artifacts for load traffic."
    }
    catch {
        $childBlockFailure = $_
    }
    finally {
        if ($ownedTestProcesses.Count -gt 0) {
            try {
                try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses } finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses }
            }
            catch {
                $childBlockCleanupFailures.Add([InvalidOperationException]::new(
                    "Owned process drain failed in the child rollout block.",
                    $_.Exception
                ))
            }
        }
        try {
            foreach ($childEnvironmentName in $childEnvironmentNames) {
                [Environment]::SetEnvironmentVariable(
                    $childEnvironmentName,
                    $childEnvironmentSnapshot[$childEnvironmentName],
                    "Process"
                )
            }
        }
        catch {
            $childBlockCleanupFailures.Add([InvalidOperationException]::new(
                "Environment restore failed in the child rollout block.",
                $_.Exception
            ))
        }
        if ($null -ne $childBlockFailure -and $childBlockCleanupFailures.Count -gt 0) {
            Add-OwnedTestProcessCleanupFailures -Exception $childBlockFailure.Exception `
                -CleanupFailures ([Exception[]]$childBlockCleanupFailures.ToArray())
            throw $childBlockFailure
        }
        if ($null -ne $childBlockFailure) { throw $childBlockFailure }
        if ($childBlockCleanupFailures.Count -gt 0) {
            throw [AggregateException]::new(
                "Child rollout regression cleanup failed.",
                [Exception[]]$childBlockCleanupFailures.ToArray()
            )
        }
    }

    $exactGitSha = ([string](@(& git -C $repositoryRoot rev-parse --verify HEAD) | Select-Object -First 1)).Trim().ToLowerInvariant()
    $natPlanPath = Join-Path $tempRoot "20260711T120000Z-$exactGitSha-nat-restore.tfplan"
    [IO.File]::WriteAllBytes($natPlanPath, [Text.Encoding]::UTF8.GetBytes("reviewed-nat-plan"))
    $natForwardPlanPath = Join-Path $tempRoot "20260711T110000Z-$exactGitSha-nat-remove.tfplan"
    [IO.File]::WriteAllBytes($natForwardPlanPath, [Text.Encoding]::UTF8.GetBytes("reviewed-nat-forward-plan"))
    $global:SchoolPilotTestNatForwardPlanPath = $natForwardPlanPath
    $terraformStatePath = Join-Path $tempRoot "terraform.tfstate"
    [IO.File]::WriteAllText($terraformStatePath, '{"version":4,"serial":1,"lineage":"test-lineage","outputs":{},"resources":[]}', [Text.UTF8Encoding]::new($false))
    $stateBackupDirectory = Join-Path $tempRoot "state-backups"
    $oldOneDrive = $env:OneDrive
    $env:OneDrive = Join-Path $tempRoot "onedrive"
    $stateRecoveryDirectory = Join-Path $env:OneDrive "SchoolPilot-Recovery"
    [void][IO.Directory]::CreateDirectory($stateRecoveryDirectory)
    $credentialPath = Join-Path $tempRoot "recovery-credential.dpapi.txt"
    $testRecoveryPassphrase = ConvertTo-SecureString "test-only-recovery-passphrase-123" -AsPlainText -Force
    [IO.File]::WriteAllText($credentialPath, (ConvertFrom-SecureString $testRecoveryPassphrase), [Text.UTF8Encoding]::new($false))
    $testRecoveryPassphrase.Dispose()
    $rollbackConfigPath = Join-Path $tempRoot "rollback.json"
    $rollbackConfig = @{
        schemaVersion = 1
        testMode = $true
        testEnvironmentSentinel = "SCHOOLPILOT_ROLLOUT_TEST_ONLY"
        testAccountId = "000000000000"
        runId = "rollback-test"
        region = "us-east-1"
        cluster = "cluster"
        apiService = "api"
        workerService = "worker"
        evidenceDirectory = $evidenceDirectory
        previousApiTaskDefinition = "api-previous"
        previousWorkerTaskDefinition = "worker-previous"
        emergencyApiTaskDefinition = "arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1"
        emergencyApiTaskDefinitionFamily = "test-emergency"
        emergencyApiContainerName = "api"
        targetGroupArn = "arn:aws:elasticloadbalancing:us-east-1:000000000000:targetgroup/test/123"
        wafName = "acl"
        wafId = "acl-id"
        wafScope = "CLOUDFRONT"
        wafDeviceMetricName = "device"
        wafApiMetricName = "api"
        wafDeviceLimit = 100000
        wafApiLimit = 50000
        privateSubnetIds = @("subnet-private-a", "subnet-private-b")
        ecsSecurityGroupIds = @("sg-ecs")
        natRollbackPlanPath = $natPlanPath
        natRollbackPlanPhase = "nat-restore"
        natRollbackPlanSha256 = (Get-FileHash -LiteralPath $natPlanPath -Algorithm SHA256).Hash.ToLowerInvariant()
        natForwardPlanPath = $natForwardPlanPath
        natForwardPlanPhase = "nat-remove"
        natForwardPlanSha256 = (Get-FileHash -LiteralPath $natForwardPlanPath -Algorithm SHA256).Hash.ToLowerInvariant()
        vpcId = "vpc-1"
        expectedNatGatewayCount = 2
        privateRouteTableIds = @("rtb-private-a", "rtb-private-b")
        terraformStatePath = $terraformStatePath
        terraformStateLineage = "test-lineage"
        stateBackupOutputDirectory = $stateBackupDirectory
        stateRecoveryDirectory = $stateRecoveryDirectory
        recoveryCredentialPath = $credentialPath
        recoveryCredentialSha256 = (Get-FileHash -LiteralPath $credentialPath -Algorithm SHA256).Hash.ToLowerInvariant()
        recoveryCredentialPreparedInteractively = $true
        redisReplicationGroupId = "redis"
        rollbackHeartbeatIntervalSeconds = 1
        emergencyTaskDefinitionEvidence = @{
            currentTaskDefinition = @{cpu="1024";memory="2048";executionRoleArn="exec";taskRoleArn="task";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");containerDefinitions=@(@{name="api";image="repo@sha256:$('c'*64)"})}
            emergencyTaskDefinition = @{status="ACTIVE";family="test-emergency";taskDefinitionArn="arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1";
                cpu="1024";memory="2048";networkMode="awsvpc";requiresCompatibilities=@("FARGATE");executionRoleArn="exec";taskRoleArn="task";
                containerDefinitions=@(@{name="api";image="repo@sha256:$('c'*64)";memory=2048})}
        }
    }
    $applicationRecoveryCheckpointPath = Join-Path $evidenceDirectory "application-recovery-checkpoint.json"
    $rollbackEvidencePaths = @()
    $publicPreconditionConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $publicPreconditionConfig.runId = "public-ecs-missing-nat-precondition"
    [IO.File]::WriteAllText($rollbackConfigPath, ($publicPreconditionConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $networkCallsBeforePrecondition = $global:SchoolPilotTestNetworkPayloads.Count
    $global:SchoolPilotTestNatAvailable = $false
    $publicPreconditionRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action PublicEcs -Mode Execute | Out-Null }
    catch { $publicPreconditionRejected = $_.Exception.Message -match "expected available gateways" }
    $global:SchoolPilotTestNatAvailable = $true
    Assert-Condition ($publicPreconditionRejected -and $global:SchoolPilotTestNetworkPayloads.Count -eq $networkCallsBeforePrecondition) "Public-ECS rollback must verify retained NAT gateways/private default routes before any ECS network mutation."

    $wrongDrainConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $wrongDrainConfig.runId = "application-wrong-alb-drain"
    [IO.File]::WriteAllText($rollbackConfigPath, ($wrongDrainConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $wrongDrainUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $global:SchoolPilotTestDeregistrationDelaySeconds = 60
    $wrongDrainError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $wrongDrainError = $_ }
    finally { $global:SchoolPilotTestDeregistrationDelaySeconds = 300 }
    Assert-Condition (
        $null -ne $wrongDrainError -and
        $wrongDrainError.Exception.Message -match "reviewed 300-second ALB deregistration delay" -and
        $global:SchoolPilotTestUpdateServiceCallCount -eq $wrongDrainUpdateStart
    ) "Application rollback must verify the live 300-second ALB drain before any service mutation."

    $checkpointNormalApi = $global:SchoolPilotTestServiceState.api.deploymentConfiguration | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $checkpointNormalWorker = $global:SchoolPilotTestServiceState.worker.deploymentConfiguration | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $invalidCheckpointBase = [ordered]@{
        schemaVersion = 1
        status = "active"
        action = "Application"
        cluster = "cluster"
        apiService = "api"
        workerService = "worker"
        initialRunId = "invalid-checkpoint-source"
        resumeCount = 0
        expectedTaskDefinitions = [ordered]@{ api = "api-previous"; worker = "worker-previous" }
        normalApiDeploymentConfiguration = $checkpointNormalApi
        normalWorkerDeploymentConfiguration = $checkpointNormalWorker
        originalApiAutoscalingTarget = [ordered]@{
            resourceId = "service/other-cluster/api"
            minCapacity = 1
            maxCapacity = 6
            suspendedState = [ordered]@{
                dynamicScalingInSuspended = $false
                dynamicScalingOutSuspended = $false
                scheduledScalingSuspended = $false
            }
        }
        recoveryState = [ordered]@{
            rollbackMutationBegan = $false
            availability = [ordered]@{
                apiInitialHealthyTargets = 1
                apiMinimumObservedHealthyTargets = 1
                apiZeroHealthyObserved = $false
                apiAvailabilityViolation = $false
            }
            apiPolicy = [ordered]@{
                apiInitialDesired = 1
                apiDesired = 1
                apiDesiredDriftObserved = $false
                apiPolicyApplyCount = 0
                apiPolicyHistory = @()
            }
        }
    }
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($invalidCheckpointBase | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $wrongCheckpointConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $wrongCheckpointConfig.runId = "application-wrong-recovery-checkpoint-target"
    [IO.File]::WriteAllText($rollbackConfigPath, ($wrongCheckpointConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $wrongCheckpointUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $wrongCheckpointRegisterStart = $global:SchoolPilotTestAutoscalingRegisterCallCount
    $wrongCheckpointError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $wrongCheckpointError = $_ }
    $wrongCheckpointDiagnostic = [ordered]@{
        error = if ($null -eq $wrongCheckpointError) { "<none>" } else { [string]$wrongCheckpointError.Exception.Message }
        updateServiceCallsBefore = $wrongCheckpointUpdateStart
        updateServiceCallsAfter = $global:SchoolPilotTestUpdateServiceCallCount
        registerTargetCallsBefore = $wrongCheckpointRegisterStart
        registerTargetCallsAfter = $global:SchoolPilotTestAutoscalingRegisterCallCount
        expectedResourceId = "service/cluster/api"
        checkpointResourceId = [string]$invalidCheckpointBase.originalApiAutoscalingTarget.resourceId
    } | ConvertTo-Json -Compress -Depth 10
    Assert-Condition (
        $null -ne $wrongCheckpointError -and
        $wrongCheckpointError.Exception.Message -match "invalid API scalable target" -and
        $global:SchoolPilotTestUpdateServiceCallCount -eq $wrongCheckpointUpdateStart -and
        $global:SchoolPilotTestAutoscalingRegisterCallCount -eq $wrongCheckpointRegisterStart
    ) "A recovery checkpoint bound to another scalable target must fail closed before any autoscaling or ECS mutation. Observed: $wrongCheckpointDiagnostic"
    [IO.File]::Delete($applicationRecoveryCheckpointPath)

    $invalidCheckpointBase.originalApiAutoscalingTarget.resourceId = "service/cluster/api"
    $invalidCheckpointBase.normalApiDeploymentConfiguration.maximumPercent = 100
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($invalidCheckpointBase | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $wrongCheckpointPolicyConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $wrongCheckpointPolicyConfig.runId = "application-wrong-recovery-checkpoint-policy"
    [IO.File]::WriteAllText($rollbackConfigPath, ($wrongCheckpointPolicyConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $wrongCheckpointPolicyUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $wrongCheckpointPolicyRegisterStart = $global:SchoolPilotTestAutoscalingRegisterCallCount
    $wrongCheckpointPolicyError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $wrongCheckpointPolicyError = $_ }
    Assert-Condition (
        $null -ne $wrongCheckpointPolicyError -and
        $wrongCheckpointPolicyError.Exception.Message -match "non-normal deployment configuration" -and
        $global:SchoolPilotTestUpdateServiceCallCount -eq $wrongCheckpointPolicyUpdateStart -and
        $global:SchoolPilotTestAutoscalingRegisterCallCount -eq $wrongCheckpointPolicyRegisterStart
    ) "A recovery checkpoint with a non-normal deployment policy must fail closed before any autoscaling or ECS mutation."
    [IO.File]::Delete($applicationRecoveryCheckpointPath)

    $singletonConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $singletonConfig.runId = "availability-safe-application-singleton"
    [IO.File]::WriteAllText($rollbackConfigPath, ($singletonConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = [ordered]@{
        deploymentCircuitBreaker = [ordered]@{ enable = $true; rollback = $true }
        maximumPercent = 200
        minimumHealthyPercent = 100
        strategy = "ROLLING"
    }
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.desired = 1
    $global:SchoolPilotTestServiceState.worker.running = 1
    $global:SchoolPilotTestServiceState.worker.pending = 0
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = [ordered]@{
        deploymentCircuitBreaker = [ordered]@{ enable = $true; rollback = $true }
        maximumPercent = 200
        minimumHealthyPercent = 100
        strategy = "ROLLING"
    }
    $singletonCapturedApiJson = $global:SchoolPilotTestServiceState.api.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20
    $singletonPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $singletonTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $singletonTargetPollStart = $global:SchoolPilotTestTargetHealthCallCount
    $singletonAutoscalingStart = $global:SchoolPilotTestAutoscalingPayloads.Count
    $singletonAutoscalingDescribeStart = $global:SchoolPilotTestAutoscalingDescribeCallCount
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingPropagationDelayPolls = 2
    $global:SchoolPilotTestInjectTargetDrainingPollsOnApiUpdate = 3
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null

    $singletonPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $singletonPayloadStart)
    $singletonTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $singletonTaskStart)
    $singletonAutoscalingPayloads = @($global:SchoolPilotTestAutoscalingPayloads | Select-Object -Skip $singletonAutoscalingStart)
    Assert-Condition (
        $singletonAutoscalingPayloads.Count -eq 2 -and
        $singletonAutoscalingPayloads[0].dynamicScalingInSuspended -and
        $singletonAutoscalingPayloads[0].dynamicScalingOutSuspended -and
        $singletonAutoscalingPayloads[0].scheduledScalingSuspended -and
        -not $singletonAutoscalingPayloads[1].dynamicScalingInSuspended -and
        -not $singletonAutoscalingPayloads[1].dynamicScalingOutSuspended -and
        -not $singletonAutoscalingPayloads[1].scheduledScalingSuspended -and
        ($global:SchoolPilotTestAutoscalingDescribeCallCount - $singletonAutoscalingDescribeStart) -ge 5
    ) "Singleton Application rollback must tolerate delayed autoscaling propagation, hold all scaling sources before mutation, and restore the exact captured state."
    Assert-Condition (
        $singletonPayloads.Count -eq 4 -and
        $singletonPayloads[0].service -eq "api" -and
        [int]$singletonPayloads[0].configuration.maximumPercent -eq 200 -and
        [int]$singletonPayloads[0].configuration.minimumHealthyPercent -eq 100
    ) "Singleton Application rollback must reserve exactly one replacement slot and keep one API task healthy."
    Assert-Condition (
        $singletonTaskUpdates.Count -eq 2 -and
        $singletonTaskUpdates[0].service -eq "api" -and
        [int]$singletonTaskUpdates[0].desired -eq 1 -and
        [int]$singletonTaskUpdates[0].minimumHealthyTasks -eq 1 -and
        [int]$singletonTaskUpdates[0].maximumConcurrentTasks -eq 2 -and
        $singletonTaskUpdates[1].service -eq "worker"
    ) "Singleton Application rollback must stay API-first with a one-healthy/two-maximum task envelope."
    Assert-Condition (
        $global:SchoolPilotTestTargetDrainingPolls -eq 0 -and
        ($global:SchoolPilotTestTargetHealthCallCount - $singletonTargetPollStart) -ge 6
    ) "Singleton Application rollback must retain one healthy target while waiting out the old target's 300-second drain."
    Assert-Condition (
        ($singletonPayloads[2].configuration | ConvertTo-Json -Compress -Depth 20) -ceq $singletonCapturedApiJson -and
        [int]$global:SchoolPilotTestServiceState.api.desired -eq 1 -and
        [int]$global:SchoolPilotTestServiceState.api.running -eq 1
    ) "Singleton Application rollback must restore its captured deployment policy and original desired capacity."
    $singletonEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($singletonConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $singletonCompleted = @($singletonEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $singletonCompleted.Count -eq 1 -and
        $singletonCompleted[0].details.postcondition.apiAvailabilityMode -eq "singleton-one-replacement-slot" -and
        [int]$singletonCompleted[0].details.postcondition.apiMinimumHealthyTasks -eq 1 -and
        [int]$singletonCompleted[0].details.postcondition.apiMaximumConcurrentTasks -eq 2 -and
        [int]$singletonCompleted[0].details.postcondition.apiSingletonReplacementSlots -eq 1 -and
        [int]$singletonCompleted[0].details.postcondition.apiMinimumObservedHealthyTargets -eq 1 -and
        $singletonCompleted[0].details.postcondition.apiAvailabilityViolation -eq $false -and
        $singletonCompleted[0].details.postcondition.apiAutoscalingHoldApplied -eq $true -and
        $singletonCompleted[0].details.postcondition.apiAutoscalingHoldRetained -eq $false -and
        $singletonCompleted[0].details.postcondition.apiAutoscalingRestoration.success -eq $true -and
        [int]$singletonCompleted[0].details.postcondition.targetGroupDrain.deregistrationDelaySeconds -eq 300
    ) "Singleton completion evidence must prove the one-target availability floor and bounded replacement slot."

    $scaleResumeConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $scaleResumeConfig.runId = "availability-safe-autoscaling-resume"
    [IO.File]::WriteAllText($rollbackConfigPath, ($scaleResumeConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestInjectDesiredAfterAutoscalingRestore = 6
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $scaleResumeEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($scaleResumeConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $scaleResumeCompleted = @($scaleResumeEvidence | Where-Object status -eq "completed")
    $scaleResumeFinalApi = @($scaleResumeCompleted[0].details.postcondition.finalServices | Where-Object serviceName -eq "api")
    Assert-Condition (
        $scaleResumeCompleted.Count -eq 1 -and
        [int]$scaleResumeCompleted[0].details.postcondition.postAutoscalingApiConvergence.observation.desired -eq 6 -and
        [int]$scaleResumeCompleted[0].details.postcondition.postAutoscalingApiConvergence.consecutiveStablePolls -eq 2 -and
        $scaleResumeFinalApi.Count -eq 1 -and [int]$scaleResumeFinalApi[0].desired -eq 6 -and
        [int]$scaleResumeFinalApi[0].running -eq 6 -and [int]$scaleResumeFinalApi[0].pending -eq 0 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 100 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "Autoscaling restoration must be followed by two fresh exact API/target polls and final evidence that includes an immediate desired-capacity change."

    $zeroHealthyConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $zeroHealthyConfig.runId = "availability-floor-zero-healthy-hard-stop"
    [IO.File]::WriteAllText($rollbackConfigPath, ($zeroHealthyConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $zeroHealthyPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $zeroHealthyTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestInjectZeroHealthyTargetPollsOnApiUpdate = 1
    $zeroHealthyError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $zeroHealthyError = $_ }
    $zeroHealthyPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $zeroHealthyPayloadStart)
    $zeroHealthyTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $zeroHealthyTaskStart)
    Assert-Condition (
        $null -ne $zeroHealthyError -and
        $zeroHealthyError.Exception.Message -match "restored the exact API and worker revisions" -and
        $zeroHealthyTaskUpdates.Count -eq 2 -and
        $zeroHealthyTaskUpdates[0].service -eq "api" -and
        $zeroHealthyTaskUpdates[1].service -eq "worker" -and
        $global:SchoolPilotTestServiceState.api.taskDefinition -eq "api-previous" -and
        $global:SchoolPilotTestServiceState.worker.taskDefinition -eq "worker-previous" -and
        $zeroHealthyPayloads.Count -eq 4 -and
        ($global:SchoolPilotTestServiceState.api.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20) -ceq $singletonCapturedApiJson
    ) "A controller-time zero-healthy singleton observation must finish exact API/worker recovery, restore configuration, and then fail closed."
    $zeroHealthyEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($zeroHealthyConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $zeroHealthyFailed = @($zeroHealthyEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $zeroHealthyFailed.Count -eq 1 -and
        $zeroHealthyFailed[0].details.recoveryRequired -eq $false -and
        $zeroHealthyFailed[0].details.recoveryStatus -eq "completed_with_availability_violation" -and
        $zeroHealthyFailed[0].details.failedStep -eq "verify-api-availability-floor" -and
        [int]$zeroHealthyFailed[0].details.apiInitialHealthyTargets -eq 1 -and
        $zeroHealthyFailed[0].details.apiAvailabilityPreExistingOutage -eq $false -and
        $zeroHealthyFailed[0].details.apiZeroHealthyObserved -eq $true -and
        $zeroHealthyFailed[0].details.apiAvailabilityViolation -eq $true -and
        $zeroHealthyFailed[0].details.apiAvailabilityRecovered -eq $true -and
        [int]$zeroHealthyFailed[0].details.apiMinimumObservedHealthyTargets -eq 0 -and
        $zeroHealthyFailed[0].details.safetyPolicyRetained -eq $false -and
        [int]$zeroHealthyFailed[0].details.temporaryApiDeploymentConfiguration.maximumPercent -eq 200 -and
        [int]$zeroHealthyFailed[0].details.temporaryApiDeploymentConfiguration.minimumHealthyPercent -eq 100
    ) "Controller-time availability failure evidence must prove exact recovery while blocking progression."
    [IO.File]::Delete($applicationRecoveryCheckpointPath)

    $preExistingOutageConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $preExistingOutageConfig.runId = "availability-floor-pre-existing-outage-recovery"
    [IO.File]::WriteAllText($rollbackConfigPath, ($preExistingOutageConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestZeroHealthyTargetPolls = 1
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $preExistingOutageEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($preExistingOutageConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $preExistingOutageCompleted = @($preExistingOutageEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $preExistingOutageCompleted.Count -eq 1 -and
        [int]$preExistingOutageCompleted[0].details.postcondition.apiInitialHealthyTargets -eq 0 -and
        [int]$preExistingOutageCompleted[0].details.postcondition.apiMinimumObservedHealthyTargets -eq 0 -and
        $preExistingOutageCompleted[0].details.postcondition.apiAvailabilityPreExistingOutage -eq $true -and
        $preExistingOutageCompleted[0].details.postcondition.apiZeroHealthyObserved -eq $true -and
        $preExistingOutageCompleted[0].details.postcondition.apiAvailabilityViolation -eq $false -and
        $preExistingOutageCompleted[0].details.postcondition.apiAvailabilityRecovered -eq $true -and
        $preExistingOutageCompleted[0].details.postcondition.recoveryRequired -eq $false -and
        $global:SchoolPilotTestServiceState.api.taskDefinition -eq "api-previous" -and
        $global:SchoolPilotTestServiceState.worker.taskDefinition -eq "worker-previous"
    ) "A pre-existing zero-target outage must not abort rollback; evidence must distinguish it and prove recovery."

    $driftOneToSixConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $driftOneToSixConfig.runId = "availability-policy-desired-drift-one-to-six"
    [IO.File]::WriteAllText($rollbackConfigPath, ($driftOneToSixConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $oneToSixPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $oneToSixTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate = 6
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $oneToSixPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $oneToSixPayloadStart)
    $oneToSixTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $oneToSixTaskStart)
    Assert-Condition (
        $oneToSixPayloads.Count -eq 5 -and
        $oneToSixPayloads[0].service -eq "api" -and
        [int]$oneToSixPayloads[0].configuration.maximumPercent -eq 200 -and
        [int]$oneToSixPayloads[0].configuration.minimumHealthyPercent -eq 100 -and
        $oneToSixPayloads[1].service -eq "api" -and
        [int]$oneToSixPayloads[1].configuration.maximumPercent -eq 100 -and
        [int]$oneToSixPayloads[1].configuration.minimumHealthyPercent -eq 83 -and
        $oneToSixTaskUpdates.Count -eq 2 -and
        $oneToSixTaskUpdates[0].service -eq "api" -and
        [int]$oneToSixTaskUpdates[0].desired -eq 1 -and
        [int]$oneToSixTaskUpdates[0].maximumConcurrentTasks -eq 2 -and
        [int]$oneToSixTaskUpdates[0].minimumHealthyTasks -eq 1
    ) "A 1-to-6 desired drift at task dispatch must start under the held singleton envelope and replace it with the six-task policy on the first poll."
    $oneToSixEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($driftOneToSixConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $oneToSixCompleted = @($oneToSixEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $oneToSixCompleted.Count -eq 1 -and
        [int]$oneToSixCompleted[0].details.postcondition.apiInitialDesired -eq 1 -and
        [int]$oneToSixCompleted[0].details.postcondition.apiDesired -eq 6 -and
        $oneToSixCompleted[0].details.postcondition.apiDesiredDriftObserved -eq $true -and
        [int]$oneToSixCompleted[0].details.postcondition.apiPolicyApplyCount -eq 2 -and
        @($oneToSixCompleted[0].details.postcondition.apiPolicyHistory).Count -eq 2 -and
        [int]$oneToSixCompleted[0].details.postcondition.apiPolicyHistory[0].maximumConcurrentTasks -eq 2 -and
        [int]$oneToSixCompleted[0].details.postcondition.apiPolicyHistory[1].maximumConcurrentTasks -eq 6 -and
        $oneToSixCompleted[0].details.postcondition.apiAutoscalingHoldApplied -eq $true -and
        $oneToSixCompleted[0].details.postcondition.apiAutoscalingRestoration.success -eq $true -and
        $oneToSixCompleted[0].details.postcondition.recoveryRequired -eq $false -and
        [int]$global:SchoolPilotTestServiceState.api.desired -eq 6
    ) "A 1-to-6 drift must bind both policies in evidence and complete without retaining the stale 200% recovery policy."

    $driftSixToOneConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $driftSixToOneConfig.runId = "availability-policy-desired-drift-six-to-one"
    [IO.File]::WriteAllText($rollbackConfigPath, ($driftSixToOneConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 6
    $global:SchoolPilotTestServiceState.api.running = 6
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $singletonCapturedApiJson | ConvertFrom-Json -Depth 20
    $sixToOnePayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $sixToOneTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestInjectDesiredDriftOnApiTaskUpdate = 1
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $sixToOnePayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $sixToOnePayloadStart)
    $sixToOneTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $sixToOneTaskStart)
    Assert-Condition (
        $sixToOnePayloads.Count -eq 5 -and
        $sixToOnePayloads[0].service -eq "api" -and
        [int]$sixToOnePayloads[0].configuration.maximumPercent -eq 100 -and
        [int]$sixToOnePayloads[0].configuration.minimumHealthyPercent -eq 83 -and
        $sixToOnePayloads[1].service -eq "api" -and
        [int]$sixToOnePayloads[1].configuration.maximumPercent -eq 200 -and
        [int]$sixToOnePayloads[1].configuration.minimumHealthyPercent -eq 100 -and
        $sixToOneTaskUpdates.Count -eq 2 -and
        $sixToOneTaskUpdates[0].service -eq "api" -and
        [int]$sixToOneTaskUpdates[0].desired -eq 6 -and
        [int]$sixToOneTaskUpdates[0].maximumConcurrentTasks -eq 6
    ) "A 6-to-1 desired drift must replace the non-overlap policy with a one-healthy/two-maximum singleton policy on the first convergence poll."
    $sixToOneEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($driftSixToOneConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $sixToOneCompleted = @($sixToOneEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $sixToOneCompleted.Count -eq 1 -and
        [int]$sixToOneCompleted[0].details.postcondition.apiInitialDesired -eq 6 -and
        [int]$sixToOneCompleted[0].details.postcondition.apiDesired -eq 1 -and
        $sixToOneCompleted[0].details.postcondition.apiDesiredDriftObserved -eq $true -and
        [int]$sixToOneCompleted[0].details.postcondition.apiPolicyApplyCount -eq 2 -and
        @($sixToOneCompleted[0].details.postcondition.apiPolicyHistory).Count -eq 2 -and
        [int]$sixToOneCompleted[0].details.postcondition.apiPolicyHistory[0].maximumConcurrentTasks -eq 6 -and
        [int]$sixToOneCompleted[0].details.postcondition.apiPolicyHistory[1].maximumConcurrentTasks -eq 2 -and
        $sixToOneCompleted[0].details.postcondition.recoveryRequired -eq $false -and
        [int]$global:SchoolPilotTestServiceState.api.desired -eq 1
    ) "A 6-to-1 drift must bind the replacement policy in evidence and complete without retaining stale 100% singleton capacity."

    $connectionSafeConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $connectionSafeConfig.runId = "connection-safe-application-six"
    [IO.File]::WriteAllText($rollbackConfigPath, ($connectionSafeConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 6
    $global:SchoolPilotTestServiceState.api.running = 6
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.desired = 1
    $global:SchoolPilotTestServiceState.worker.running = 1
    $global:SchoolPilotTestServiceState.worker.pending = 0
    $capturedApiDeploymentJson = $global:SchoolPilotTestServiceState.api.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20
    $capturedWorkerDeploymentJson = $global:SchoolPilotTestServiceState.worker.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20
    $deploymentPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $taskObservationStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null

    $connectionSafePayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $deploymentPayloadStart)
    Assert-Condition ($connectionSafePayloads.Count -eq 4) "Six-task Application rollback must install and then restore captured API/worker deployment configurations."
    Assert-Condition (
        $connectionSafePayloads[0].service -eq "api" -and
        [int]$connectionSafePayloads[0].configuration.maximumPercent -eq 100 -and
        [int]$connectionSafePayloads[0].configuration.minimumHealthyPercent -eq 83
    ) "Six-task Application rollback must cap API replacement capacity at desired count while keeping five tasks available."
    Assert-Condition (
        $connectionSafePayloads[1].service -eq "worker" -and
        [int]$connectionSafePayloads[1].configuration.maximumPercent -eq 100 -and
        [int]$connectionSafePayloads[1].configuration.minimumHealthyPercent -eq 0
    ) "Six-task Application rollback must prevent the singleton worker from overlapping its replacement."
    Assert-Condition (
        ($connectionSafePayloads[2].configuration | ConvertTo-Json -Compress -Depth 20) -ceq $capturedApiDeploymentJson -and
        ($connectionSafePayloads[3].configuration | ConvertTo-Json -Compress -Depth 20) -ceq $capturedWorkerDeploymentJson
    ) "Six-task Application rollback must restore the exact captured deployment configurations."

    $connectionSafeTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $taskObservationStart)
    Assert-Condition (
        $connectionSafeTaskUpdates.Count -eq 2 -and
        $connectionSafeTaskUpdates[0].service -eq "api" -and
        [int]$connectionSafeTaskUpdates[0].minimumHealthyTasks -eq 5 -and
        [int]$connectionSafeTaskUpdates[0].maximumConcurrentTasks -eq 6 -and
        $connectionSafeTaskUpdates[1].service -eq "worker"
    ) "Connection-safe Application rollback must stabilize the API revision before replacing the worker revision."
    Assert-Condition (@($connectionSafeTaskUpdates | Where-Object {
        [int]$_.deploymentConfiguration.maximumPercent -ne 100
    }).Count -eq 0) "No six-task Application task-definition update may use an overlapping deployment maximum."
    Assert-Condition (
        ($global:SchoolPilotTestServiceState.api.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20) -ceq $capturedApiDeploymentJson -and
        ($global:SchoolPilotTestServiceState.worker.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20) -ceq $capturedWorkerDeploymentJson -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 100 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.minimumHealthyPercent -eq 100
    ) "Application rollback postconditions must verify both captured deployment configurations were restored."
    $connectionSafeEvidencePath = Join-Path $evidenceDirectory "$($connectionSafeConfig.runId)-rollback.jsonl"
    $connectionSafeEvidence = @(Get-Content -LiteralPath $connectionSafeEvidencePath | ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $connectionSafeCompleted = @($connectionSafeEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $connectionSafeCompleted.Count -eq 1 -and
        $connectionSafeCompleted[0].details.postcondition.connectionSafeDeployment -eq $true -and
        [int]$connectionSafeCompleted[0].details.postcondition.apiDesired -eq 6 -and
        $connectionSafeCompleted[0].details.postcondition.apiAvailabilityMode -eq "non-overlap-one-at-a-time" -and
        [int]$connectionSafeCompleted[0].details.postcondition.apiMinimumHealthyTasks -eq 5 -and
        [int]$connectionSafeCompleted[0].details.postcondition.apiMaximumConcurrentTasks -eq 6 -and
        [int]$connectionSafeCompleted[0].details.postcondition.apiSingletonReplacementSlots -eq 0 -and
        $connectionSafeCompleted[0].details.postcondition.apiAvailabilityViolation -eq $false -and
        $connectionSafeCompleted[0].details.postcondition.recoveryRequired -eq $false -and
        [int]$connectionSafeCompleted[0].details.postcondition.targetGroupDrain.deregistrationDelaySeconds -eq 300 -and
        $connectionSafeCompleted[0].details.postcondition.targetGroupDrain.verified -eq $true -and
        [int]$connectionSafeCompleted[0].details.postcondition.apiConvergence.consecutiveStablePolls -eq 2 -and
        [int]$connectionSafeCompleted[0].details.postcondition.workerConvergence.consecutiveStablePolls -eq 2 -and
        [int]$connectionSafeCompleted[0].details.postcondition.postAutoscalingApiConvergence.consecutiveStablePolls -eq 2 -and
        [int]$connectionSafeCompleted[0].details.postcondition.postAutoscalingWorkerConvergence.consecutiveStablePolls -eq 2
    ) "Completed rollback evidence must prove exact two-poll API/worker convergence for the connection-safe six-task path."

    $overCapacityConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $overCapacityConfig.runId = "connection-safe-application-over-capacity"
    [IO.File]::WriteAllText($rollbackConfigPath, ($overCapacityConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 8
    $global:SchoolPilotTestServiceState.api.running = 8
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $overCapacityRejected = $false
    try {
        & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    }
    catch {
        $overCapacityRejected = $_.Exception.Message -match "above the reviewed six-task ceiling"
    }
    Assert-Condition $overCapacityRejected "Application rollback must reject an API posture above the six-task ceiling."

    $longDrainConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $longDrainConfig.runId = "connection-safe-long-draining-target"
    [IO.File]::WriteAllText($rollbackConfigPath, ($longDrainConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 6
    $global:SchoolPilotTestServiceState.api.running = 6
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $targetPollStart = $global:SchoolPilotTestTargetHealthCallCount
    $global:SchoolPilotTestTargetDrainingPolls = 3
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    Assert-Condition (
        $global:SchoolPilotTestTargetDrainingPolls -eq 0 -and
        ($global:SchoolPilotTestTargetHealthCallCount - $targetPollStart) -ge 5
    ) "Application rollback must wait through long target draining and then observe two consecutive exact API polls."

    $singletonRestartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $singletonRestartConfig.runId = "availability-safe-singleton-controller-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($singletonRestartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestTransientMixedDeploymentPolls.api = 3
    $global:SchoolPilotTestTargetDrainingPolls = 4
    $singletonRestartPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $singletonRestartTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $singletonRestartPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $singletonRestartPayloadStart)
    $singletonRestartTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $singletonRestartTaskStart)
    Assert-Condition (
        $singletonRestartTaskUpdates.Count -eq 1 -and
        $singletonRestartTaskUpdates[0].service -eq "worker" -and
        $singletonRestartPayloads.Count -eq 4 -and
        $singletonRestartPayloads[0].service -eq "api" -and
        [int]$singletonRestartPayloads[0].configuration.maximumPercent -eq 200 -and
        [int]$singletonRestartPayloads[0].configuration.minimumHealthyPercent -eq 100 -and
        $global:SchoolPilotTestTransientMixedDeploymentPolls.api -eq 0 -and
        $global:SchoolPilotTestTargetDrainingPolls -eq 0
    ) "A restarted singleton controller must reassert the availability policy and fully drain the mixed API deployment before touching the worker."
    $singletonRestartEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($singletonRestartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $singletonRestartCompleted = @($singletonRestartEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $singletonRestartCompleted.Count -eq 1 -and
        $singletonRestartCompleted[0].details.postcondition.apiRevisionAlreadySelected -eq $true -and
        $singletonRestartCompleted[0].details.postcondition.apiInitiallyConverged -eq $false -and
        $singletonRestartCompleted[0].details.postcondition.apiSafetyPolicyTouched -eq $true -and
        $singletonRestartCompleted[0].details.postcondition.apiRollbackDispatched -eq $false -and
        $singletonRestartCompleted[0].details.postcondition.apiAvailabilityMode -eq "singleton-one-replacement-slot" -and
        [int]$singletonRestartCompleted[0].details.postcondition.apiMinimumObservedHealthyTargets -eq 1 -and
        $singletonRestartCompleted[0].details.postcondition.workerRollbackDispatched -eq $true
    ) "Singleton restart evidence must prove availability-safe recovery without duplicate API dispatch."

    $global:SchoolPilotTestServiceState.api.desired = 6
    $global:SchoolPilotTestServiceState.api.running = 6
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20

    $restartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $restartConfig.runId = "connection-safe-controller-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($restartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent = 83
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $true
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $restartCheckpoint = [ordered]@{
        schemaVersion = 1
        status = "active"
        action = "Application"
        cluster = "cluster"
        apiService = "api"
        workerService = "worker"
        createdAt = [DateTimeOffset]::UtcNow.AddMinutes(-5).ToString("o")
        initialRunId = "simulated-crashed-controller"
        resumeCount = 0
        expectedTaskDefinitions = [ordered]@{ api = "api-previous"; worker = "worker-previous" }
        normalApiDeploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
        normalWorkerDeploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
        originalApiAutoscalingTarget = [ordered]@{
            resourceId = "service/cluster/api"
            minCapacity = 1
            maxCapacity = 6
            suspendedState = [ordered]@{
                dynamicScalingInSuspended = $false
                dynamicScalingOutSuspended = $false
                scheduledScalingSuspended = $false
            }
        }
        recoveryState = [ordered]@{
            rollbackMutationBegan = $true
            availability = [ordered]@{
                apiInitialHealthyTargets = 6
                apiMinimumObservedHealthyTargets = 6
                apiZeroHealthyObserved = $false
                apiAvailabilityViolation = $false
            }
            apiPolicy = [ordered]@{
                apiInitialDesired = 6
                apiDesired = 6
                apiDesiredDriftObserved = $false
                apiPolicyApplyCount = 1
                apiPolicyHistory = @([ordered]@{
                    reason = "simulated-prior-controller"
                    desired = 6
                    mode = "non-overlap-one-at-a-time"
                    minimumHealthyTasks = 5
                    maximumConcurrentTasks = 6
                    configuration = $global:SchoolPilotTestServiceState.api.deploymentConfiguration
                })
            }
        }
    }
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($restartCheckpoint | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestTransientMixedDeploymentPolls.api = 3
    $restartPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $restartTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $restartPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $restartPayloadStart)
    $restartTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $restartTaskStart)
    Assert-Condition (
        $restartTaskUpdates.Count -eq 1 -and $restartTaskUpdates[0].service -eq "worker" -and
        $restartPayloads.Count -eq 4 -and @($restartPayloads | Where-Object service -eq "api").Count -eq 2 -and
        $restartPayloads[0].service -eq "api" -and
        [int]$restartPayloads[0].configuration.maximumPercent -eq 100 -and
        [int]$restartPayloads[0].configuration.minimumHealthyPercent -eq 83 -and
        $global:SchoolPilotTestTransientMixedDeploymentPolls.api -eq 0 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 100 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "A restarted controller must resume the durable pre-mutation capture, safely converge the mixed API revision, and restore normal policy/scaling without redeploying API."
    $restartEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($restartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $restartCompleted = @($restartEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $restartCompleted.Count -eq 1 -and
        $restartCompleted[0].details.postcondition.apiRevisionAlreadySelected -eq $true -and
        $restartCompleted[0].details.postcondition.apiInitiallyConverged -eq $false -and
        [int]$restartCompleted[0].details.postcondition.initialApiConvergence.deploymentCount -eq 2 -and
        $restartCompleted[0].details.postcondition.apiSafetyPolicyTouched -eq $true -and
        $restartCompleted[0].details.postcondition.apiRollbackDispatched -eq $false -and
        $restartCompleted[0].details.postcondition.workerRollbackDispatched -eq $true -and
        $restartCompleted[0].details.postcondition.recoveryCheckpointResumed -eq $true -and
        $restartCompleted[0].details.postcondition.recoveryCheckpointInitialRunId -eq "simulated-crashed-controller" -and
        [int]$restartCompleted[0].details.postcondition.recoveryCheckpointResumeCount -eq 1 -and
        $restartCompleted[0].details.postcondition.recoveryCheckpointStatus -eq "completed" -and
        $restartCompleted[0].details.postcondition.recoveryRequired -eq $false
    ) "Controller-restart evidence must prove the mixed API revision was safely converged before the worker rollback was dispatched."
    $completedRestartCheckpoint = Get-Content -LiteralPath $applicationRecoveryCheckpointPath -Raw | ConvertFrom-Json -Depth 30
    Assert-Condition (
        $completedRestartCheckpoint.status -eq "completed" -and
        $completedRestartCheckpoint.initialRunId -eq "simulated-crashed-controller" -and
        [int]$completedRestartCheckpoint.resumeCount -eq 1 -and
        $completedRestartCheckpoint.completedByRunId -eq $restartConfig.runId
    ) "Stateful controller restart must durably close the original checkpoint only after exact service/config/scaling recovery."

    $apiStableRestartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $apiStableRestartConfig.runId = "connection-safe-api-stable-policy-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($apiStableRestartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $apiStableCheckpoint = $restartCheckpoint | ConvertTo-Json -Depth 30 | ConvertFrom-Json -Depth 30
    $apiStableCheckpoint.initialRunId = "simulated-api-stable-crash"
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($apiStableCheckpoint | ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent = 83
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $true
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $apiStableTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $apiStableTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $apiStableTaskStart)
    $apiStableEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($apiStableRestartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $apiStableCompleted = @($apiStableEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $apiStableTaskUpdates.Count -eq 1 -and $apiStableTaskUpdates[0].service -eq "worker" -and
        $apiStableCompleted.Count -eq 1 -and
        $apiStableCompleted[0].details.postcondition.apiInitiallyConverged -eq $true -and
        $apiStableCompleted[0].details.postcondition.apiConfigurationNeedsRestoration -eq $true -and
        $apiStableCompleted[0].details.postcondition.apiRollbackDispatched -eq $false -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 100 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended
    ) "A restart after exact API convergence must still restore its temporary API policy and original scaling state without duplicate API dispatch."

    $bothStableRestartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $bothStableRestartConfig.runId = "connection-safe-both-stable-policy-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($bothStableRestartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $bothStableCheckpoint = $restartCheckpoint | ConvertTo-Json -Depth 30 | ConvertFrom-Json -Depth 30
    $bothStableCheckpoint.initialRunId = "simulated-both-stable-crash"
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($bothStableCheckpoint | ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent = 83
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-previous"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.minimumHealthyPercent = 0
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $true
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $bothStableTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $bothStableTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $bothStableTaskStart)
    $bothStableEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($bothStableRestartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $bothStableCompleted = @($bothStableEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $bothStableTaskUpdates.Count -eq 0 -and $bothStableCompleted.Count -eq 1 -and
        $bothStableCompleted[0].details.postcondition.apiInitiallyConverged -eq $true -and
        $bothStableCompleted[0].details.postcondition.workerInitiallyConverged -eq $true -and
        $bothStableCompleted[0].details.postcondition.apiConfigurationNeedsRestoration -eq $true -and
        $bothStableCompleted[0].details.postcondition.workerConfigurationNeedsRestoration -eq $true -and
        $bothStableCompleted[0].details.postcondition.apiRollbackDispatched -eq $false -and
        $bothStableCompleted[0].details.postcondition.workerRollbackDispatched -eq $false -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent -eq 200 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended
    ) "A restart after both revisions converge must restore both temporary policies and original scaling without duplicate deployments."

    $violationRestartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $violationRestartConfig.runId = "availability-violation-stateful-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($violationRestartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $violationCheckpoint = $restartCheckpoint | ConvertTo-Json -Depth 30 | ConvertFrom-Json -Depth 30
    $violationCheckpoint.initialRunId = "simulated-availability-violation-crash"
    $violationCheckpoint.recoveryState.availability.apiMinimumObservedHealthyTargets = 0
    $violationCheckpoint.recoveryState.availability.apiZeroHealthyObserved = $true
    $violationCheckpoint.recoveryState.availability.apiAvailabilityViolation = $true
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($violationCheckpoint | ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent = 83
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-previous"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.minimumHealthyPercent = 0
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $true
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $violationRestartTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $violationRestartError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $violationRestartError = $_ }
    $violationRestartTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $violationRestartTaskStart)
    $violationRestartEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($violationRestartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $violationRestartFailed = @($violationRestartEvidence | Where-Object status -eq "failed")
    $terminalViolationCheckpoint = Get-Content -LiteralPath $applicationRecoveryCheckpointPath -Raw | ConvertFrom-Json -Depth 30
    Assert-Condition (
        $null -ne $violationRestartError -and $violationRestartError.Exception.Message -match "availability-floor violation" -and
        $violationRestartTaskUpdates.Count -eq 0 -and $violationRestartFailed.Count -eq 1 -and
        $violationRestartFailed[0].details.recoveryRequired -eq $false -and
        $violationRestartFailed[0].details.recoveryStatus -eq "completed_with_availability_violation" -and
        $violationRestartFailed[0].details.apiAvailabilityViolation -eq $true -and
        [int]$violationRestartFailed[0].details.apiMinimumObservedHealthyTargets -eq 0 -and
        $violationRestartFailed[0].details.recoveryCheckpointStatus -eq "completed_with_availability_violation" -and
        $terminalViolationCheckpoint.status -eq "completed_with_availability_violation" -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent -eq 200 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended
    ) "A restarted controller must preserve a prior availability violation, finish exact recovery, and durably block progression."

    $terminalReuseConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $terminalReuseConfig.runId = "availability-violation-terminal-reuse-rejected"
    [IO.File]::WriteAllText($rollbackConfigPath, ($terminalReuseConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $terminalReuseCheckpointHashBefore = (Get-FileHash -LiteralPath $applicationRecoveryCheckpointPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $terminalReuseStatePath = Join-Path $evidenceDirectory "$($terminalReuseConfig.runId)-rollback-state.json"
    $terminalReuseHeartbeatPath = Join-Path $evidenceDirectory "$($terminalReuseConfig.runId)-rollback-heartbeat.json"
    $terminalReuseEvidencePath = Join-Path $evidenceDirectory "$($terminalReuseConfig.runId)-rollback.jsonl"
    $terminalReuseAwsStart = $global:SchoolPilotTestAwsCalls.Count
    $terminalReuseUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $terminalReuseRegisterStart = $global:SchoolPilotTestAutoscalingRegisterCallCount
    $terminalReuseError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $terminalReuseError = $_ }
    $terminalReuseCheckpointExistsAfter = Test-Path -LiteralPath $applicationRecoveryCheckpointPath -PathType Leaf
    $terminalReuseCheckpointHashAfter = if ($terminalReuseCheckpointExistsAfter) {
        (Get-FileHash -LiteralPath $applicationRecoveryCheckpointPath -Algorithm SHA256).Hash.ToLowerInvariant()
    } else { "" }
    $terminalReuseCheckpointAfter = if ($terminalReuseCheckpointExistsAfter) {
        Get-Content -LiteralPath $applicationRecoveryCheckpointPath -Raw | ConvertFrom-Json -DateKind String -Depth 30
    } else { $null }
    $terminalReuseStateExists = Test-Path -LiteralPath $terminalReuseStatePath -PathType Leaf
    $terminalReuseState = if ($terminalReuseStateExists) {
        Get-Content -LiteralPath $terminalReuseStatePath -Raw | ConvertFrom-Json -DateKind String -Depth 20
    } else { $null }
    $terminalReuseEvidenceExists = Test-Path -LiteralPath $terminalReuseEvidencePath -PathType Leaf
    $terminalReuseEvidence = if ($terminalReuseEvidenceExists) {
        @(Get-Content -LiteralPath $terminalReuseEvidencePath | ForEach-Object { $_ | ConvertFrom-Json -DateKind String -Depth 20 })
    } else { @() }
    $terminalReuseFailedEvidence = @($terminalReuseEvidence | Where-Object status -eq "failed")
    $terminalReuseErrorMessage = if ($null -eq $terminalReuseError) { "<none>" } else { $terminalReuseError.Exception.Message }
    $terminalReuseStateKeys = if ($null -eq $terminalReuseState) { @() } else {
        @($terminalReuseState.PSObject.Properties.Name | Sort-Object)
    }
    $terminalReuseEvidenceKeys = if ($terminalReuseFailedEvidence.Count -eq 1) {
        @($terminalReuseFailedEvidence[0].PSObject.Properties.Name | Sort-Object)
    } else { @() }
    $terminalReuseDetailKeys = if ($terminalReuseFailedEvidence.Count -eq 1) {
        @($terminalReuseFailedEvidence[0].details.PSObject.Properties.Name | Sort-Object)
    } else { @() }
    $expectedTerminalReuseStateKeys = @("action", "deadlineUtc", "error", "runId", "status", "step", "timestamp")
    $expectedTerminalReuseEvidenceKeys = @("action", "details", "error", "runId", "schemaVersion", "status", "timestamp", "type")
    $expectedTerminalReuseDetailKeys = @(
        "admissionRejected",
        "admissionStage",
        "awsReadStarted",
        "failureCode",
        "heartbeatStarted",
        "recoveryMutationStarted"
    )
    $terminalReuseAwsDelta = $global:SchoolPilotTestAwsCalls.Count - $terminalReuseAwsStart
    $terminalReuseUpdateDelta = $global:SchoolPilotTestUpdateServiceCallCount - $terminalReuseUpdateStart
    $terminalReuseRegisterDelta = $global:SchoolPilotTestAutoscalingRegisterCallCount - $terminalReuseRegisterStart
    Assert-Condition (
        $null -ne $terminalReuseError -and
        $terminalReuseError.Exception.Message -ceq "Application rollback found a terminal availability-violation checkpoint; progression remains blocked and this evidence directory cannot be reused." -and
        $terminalReuseAwsDelta -eq 0 -and $terminalReuseUpdateDelta -eq 0 -and $terminalReuseRegisterDelta -eq 0 -and
        $terminalReuseCheckpointExistsAfter -and
        $terminalReuseCheckpointHashAfter -eq $terminalReuseCheckpointHashBefore -and
        $terminalReuseCheckpointAfter.status -eq "completed_with_availability_violation" -and
        $terminalReuseStateExists -and $terminalReuseState.status -eq "failed" -and
        $terminalReuseState.step -eq "checkpoint-admission-rejected" -and
        @(Compare-Object $terminalReuseStateKeys $expectedTerminalReuseStateKeys).Count -eq 0 -and
        $terminalReuseState.runId -ceq [string]$terminalReuseConfig.runId -and
        $terminalReuseState.action -ceq "Application" -and
        $terminalReuseState.error -ceq "Application rollback rejected immutable terminal checkpoint reuse before heartbeat startup." -and
        $terminalReuseState.timestamp -is [string] -and
        $terminalReuseState.deadlineUtc -is [string] -and
        $terminalReuseEvidence.Count -eq 1 -and $terminalReuseFailedEvidence.Count -eq 1 -and
        @(Compare-Object $terminalReuseEvidenceKeys $expectedTerminalReuseEvidenceKeys).Count -eq 0 -and
        @(Compare-Object $terminalReuseDetailKeys $expectedTerminalReuseDetailKeys).Count -eq 0 -and
        $terminalReuseFailedEvidence[0].type -ceq "aws_rollout_rollback" -and
        $terminalReuseFailedEvidence[0].schemaVersion -is [long] -and
        $terminalReuseFailedEvidence[0].schemaVersion -eq 1 -and
        $terminalReuseFailedEvidence[0].runId -ceq [string]$terminalReuseConfig.runId -and
        $terminalReuseFailedEvidence[0].action -ceq "Application" -and
        $terminalReuseFailedEvidence[0].status -ceq "failed" -and
        $terminalReuseFailedEvidence[0].error -ceq "Application rollback rejected immutable terminal checkpoint reuse before heartbeat startup." -and
        $terminalReuseFailedEvidence[0].timestamp -is [string] -and
        $terminalReuseFailedEvidence[0].details.admissionRejected -is [bool] -and
        $terminalReuseFailedEvidence[0].details.admissionRejected -eq $true -and
        $terminalReuseFailedEvidence[0].details.admissionStage -ceq "application_recovery_checkpoint" -and
        $terminalReuseFailedEvidence[0].details.failureCode -ceq "terminal_checkpoint_reuse" -and
        $terminalReuseFailedEvidence[0].details.heartbeatStarted -is [bool] -and
        $terminalReuseFailedEvidence[0].details.heartbeatStarted -eq $false -and
        $terminalReuseFailedEvidence[0].details.awsReadStarted -is [bool] -and
        $terminalReuseFailedEvidence[0].details.awsReadStarted -eq $false -and
        $terminalReuseFailedEvidence[0].details.recoveryMutationStarted -is [bool] -and
        $terminalReuseFailedEvidence[0].details.recoveryMutationStarted -eq $false -and
        -not (Test-Path -LiteralPath $terminalReuseHeartbeatPath)
    ) "A terminal availability-violation checkpoint must fail closed before heartbeat startup or AWS/recovery mutation while sealing failure evidence (error=$terminalReuseErrorMessage; awsDelta=$terminalReuseAwsDelta; updateDelta=$terminalReuseUpdateDelta; registerDelta=$terminalReuseRegisterDelta; checkpointExists=$terminalReuseCheckpointExistsAfter; hashUnchanged=$($terminalReuseCheckpointHashAfter -eq $terminalReuseCheckpointHashBefore); status=$($terminalReuseCheckpointAfter.status); stateExists=$terminalReuseStateExists; stateStatus=$($terminalReuseState.status); evidenceCount=$($terminalReuseFailedEvidence.Count); heartbeatExists=$(Test-Path -LiteralPath $terminalReuseHeartbeatPath))."

    $malformedCheckpointConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -DateKind String -Depth 20
    $malformedCheckpointConfig.runId = "malformed-application-checkpoint-admission"
    [IO.File]::WriteAllText($rollbackConfigPath, ($malformedCheckpointConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, "{malformed-checkpoint", [Text.UTF8Encoding]::new($false))
    $malformedCheckpointHashBefore = (Get-FileHash -LiteralPath $applicationRecoveryCheckpointPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $malformedCheckpointStatePath = Join-Path $evidenceDirectory "$($malformedCheckpointConfig.runId)-rollback-state.json"
    $malformedCheckpointHeartbeatPath = Join-Path $evidenceDirectory "$($malformedCheckpointConfig.runId)-rollback-heartbeat.json"
    $malformedCheckpointEvidencePath = Join-Path $evidenceDirectory "$($malformedCheckpointConfig.runId)-rollback.jsonl"
    $malformedCheckpointAwsStart = $global:SchoolPilotTestAwsCalls.Count
    $malformedCheckpointUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $malformedCheckpointRegisterStart = $global:SchoolPilotTestAutoscalingRegisterCallCount
    $malformedCheckpointError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $malformedCheckpointError = $_ }
    $malformedCheckpointState = Get-Content -LiteralPath $malformedCheckpointStatePath -Raw | ConvertFrom-Json -DateKind String -Depth 20
    $malformedCheckpointEvidence = @(
        Get-Content -LiteralPath $malformedCheckpointEvidencePath |
            ForEach-Object { $_ | ConvertFrom-Json -DateKind String -Depth 20 }
    )
    $malformedCheckpointRecord = @($malformedCheckpointEvidence | Where-Object status -eq "failed")
    $malformedCheckpointHashAfter = (Get-FileHash -LiteralPath $applicationRecoveryCheckpointPath -Algorithm SHA256).Hash.ToLowerInvariant()
    Assert-Condition (
        $null -ne $malformedCheckpointError -and
        $malformedCheckpointError.Exception.Message -ceq "Application rollback checkpoint admission failed before heartbeat startup." -and
        ($global:SchoolPilotTestAwsCalls.Count - $malformedCheckpointAwsStart) -eq 0 -and
        ($global:SchoolPilotTestUpdateServiceCallCount - $malformedCheckpointUpdateStart) -eq 0 -and
        ($global:SchoolPilotTestAutoscalingRegisterCallCount - $malformedCheckpointRegisterStart) -eq 0 -and
        $malformedCheckpointHashAfter -eq $malformedCheckpointHashBefore -and
        $malformedCheckpointState.status -ceq "failed" -and
        $malformedCheckpointState.step -ceq "checkpoint-admission-rejected" -and
        $malformedCheckpointState.error -ceq "Application rollback checkpoint admission failed before heartbeat startup." -and
        $malformedCheckpointEvidence.Count -eq 1 -and $malformedCheckpointRecord.Count -eq 1 -and
        $malformedCheckpointRecord[0].error -ceq "Application rollback checkpoint admission failed before heartbeat startup." -and
        $malformedCheckpointRecord[0].details.failureCode -ceq "checkpoint_admission_invalid" -and
        $malformedCheckpointRecord[0].details.admissionRejected -is [bool] -and
        $malformedCheckpointRecord[0].details.admissionRejected -eq $true -and
        $malformedCheckpointRecord[0].details.heartbeatStarted -is [bool] -and
        $malformedCheckpointRecord[0].details.heartbeatStarted -eq $false -and
        $malformedCheckpointRecord[0].details.awsReadStarted -is [bool] -and
        $malformedCheckpointRecord[0].details.awsReadStarted -eq $false -and
        $malformedCheckpointRecord[0].details.recoveryMutationStarted -is [bool] -and
        $malformedCheckpointRecord[0].details.recoveryMutationStarted -eq $false -and
        -not (Test-Path -LiteralPath $malformedCheckpointHeartbeatPath)
    ) "A malformed checkpoint must fail with only sanitized admission evidence before heartbeat startup or AWS/recovery mutation."

    $evidenceSealFailureConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -DateKind String -Depth 20
    $evidenceSealFailureConfig.runId = "checkpoint-admission-evidence-seal-failure"
    [IO.File]::WriteAllText($rollbackConfigPath, ($evidenceSealFailureConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $evidenceSealFailureStatePath = Join-Path $evidenceDirectory "$($evidenceSealFailureConfig.runId)-rollback-state.json"
    $evidenceSealFailureHeartbeatPath = Join-Path $evidenceDirectory "$($evidenceSealFailureConfig.runId)-rollback-heartbeat.json"
    $evidenceSealFailureEvidencePath = Join-Path $evidenceDirectory "$($evidenceSealFailureConfig.runId)-rollback.jsonl"
    New-Item -ItemType Directory -Path $evidenceSealFailureEvidencePath -Force | Out-Null
    $evidenceSealFailureAwsStart = $global:SchoolPilotTestAwsCalls.Count
    $evidenceSealFailureUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $evidenceSealFailureRegisterStart = $global:SchoolPilotTestAutoscalingRegisterCallCount
    $evidenceSealFailureError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $evidenceSealFailureError = $_ }
    $evidenceSealFailureState = Get-Content -LiteralPath $evidenceSealFailureStatePath -Raw | ConvertFrom-Json -DateKind String -Depth 20
    $evidenceSealFailureCheckpointHashAfter = (Get-FileHash -LiteralPath $applicationRecoveryCheckpointPath -Algorithm SHA256).Hash.ToLowerInvariant()
    Assert-Condition (
        $null -ne $evidenceSealFailureError -and
        $evidenceSealFailureError.Exception.Message -ceq "Application rollback checkpoint admission failed and its failure evidence could not be sealed." -and
        ($global:SchoolPilotTestAwsCalls.Count - $evidenceSealFailureAwsStart) -eq 0 -and
        ($global:SchoolPilotTestUpdateServiceCallCount - $evidenceSealFailureUpdateStart) -eq 0 -and
        ($global:SchoolPilotTestAutoscalingRegisterCallCount - $evidenceSealFailureRegisterStart) -eq 0 -and
        $evidenceSealFailureCheckpointHashAfter -eq $malformedCheckpointHashBefore -and
        $evidenceSealFailureState.status -ceq "failed" -and
        $evidenceSealFailureState.step -ceq "checkpoint-admission-rejected" -and
        $evidenceSealFailureState.error -ceq "Application rollback checkpoint admission failed before heartbeat startup." -and
        (Test-Path -LiteralPath $evidenceSealFailureEvidencePath -PathType Container) -and
        -not (Test-Path -LiteralPath $evidenceSealFailureHeartbeatPath)
    ) "A checkpoint-admission evidence write failure must stay sanitized and must not start heartbeat, AWS reads, or recovery mutation."
    Remove-Item -LiteralPath $evidenceSealFailureEvidencePath -Force
    [IO.File]::Delete($applicationRecoveryCheckpointPath)

    $workerRestartConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $workerRestartConfig.runId = "connection-safe-worker-controller-restart"
    [IO.File]::WriteAllText($rollbackConfigPath, ($workerRestartConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-previous"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration.minimumHealthyPercent = 0
    $global:SchoolPilotTestTransientMixedDeploymentPolls.worker = 4
    $workerRestartPayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $workerRestartTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null
    $workerRestartPayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $workerRestartPayloadStart)
    $workerRestartTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $workerRestartTaskStart)
    Assert-Condition (
        $workerRestartTaskUpdates.Count -eq 0 -and
        $workerRestartPayloads.Count -eq 2 -and
        @($workerRestartPayloads | Where-Object service -eq "api").Count -eq 0 -and
        $workerRestartPayloads[0].service -eq "worker" -and
        [int]$workerRestartPayloads[0].configuration.maximumPercent -eq 100 -and
        [int]$workerRestartPayloads[0].configuration.minimumHealthyPercent -eq 0 -and
        $global:SchoolPilotTestTransientMixedDeploymentPolls.worker -eq 0 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent -eq 200 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.minimumHealthyPercent -eq 100
    ) "A restarted controller must install the zero-overlap worker policy before waiting on an already-selected but mixed worker revision."
    $workerRestartEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($workerRestartConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $workerRestartCompleted = @($workerRestartEvidence | Where-Object status -eq "completed")
    Assert-Condition (
        $workerRestartCompleted.Count -eq 1 -and
        $workerRestartCompleted[0].details.postcondition.workerRevisionAlreadySelected -eq $true -and
        $workerRestartCompleted[0].details.postcondition.workerInitiallyConverged -eq $false -and
        [int]$workerRestartCompleted[0].details.postcondition.initialWorkerConvergence.deploymentCount -eq 2 -and
        $workerRestartCompleted[0].details.postcondition.workerSafetyPolicyTouched -eq $true -and
        $workerRestartCompleted[0].details.postcondition.workerRollbackDispatched -eq $false -and
        $workerRestartCompleted[0].details.postcondition.recoveryRequired -eq $false
    ) "Worker-restart evidence must prove the mixed already-selected worker revision converged under zero-overlap policy."

    $preMutationFailureConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $preMutationFailureConfig.runId = "connection-safe-pre-mutation-autoscaling-failure"
    [IO.File]::WriteAllText($rollbackConfigPath, ($preMutationFailureConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $false
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $preMutationRegisterFailure = $global:SchoolPilotTestAutoscalingRegisterCallCount + 1
    $preMutationUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $global:SchoolPilotTestFailAutoscalingRegisterCalls = @($preMutationRegisterFailure)
    $preMutationFailureError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $preMutationFailureError = $_ }
    finally { $global:SchoolPilotTestFailAutoscalingRegisterCalls = @() }
    Assert-Condition (
        $null -ne $preMutationFailureError -and
        $preMutationFailureError.Exception.Message -eq "Mock register-scalable-target failure at call $preMutationRegisterFailure." -and
        $global:SchoolPilotTestUpdateServiceCallCount -eq $preMutationUpdateStart -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "A failure before API mutation must leave services untouched and restore the exact captured autoscaling state."
    $preMutationFailureEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($preMutationFailureConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $preMutationFailed = @($preMutationFailureEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $preMutationFailed.Count -eq 1 -and
        $preMutationFailed[0].details.recoveryRequired -eq $true -and
        $preMutationFailed[0].details.apiSafetyPolicyTouched -eq $false -and
        $preMutationFailed[0].details.apiAutoscalingHoldAttempted -eq $true -and
        $preMutationFailed[0].details.apiAutoscalingHoldApplied -eq $false -and
        $preMutationFailed[0].details.apiAutoscalingHoldRetained -eq $false -and
        $preMutationFailed[0].details.apiAutoscalingRestoration.success -eq $true
    ) "Pre-mutation failure evidence must prove exact autoscaling restoration rather than retaining a hold."
    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState

    $restartHoldFailureConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $restartHoldFailureConfig.runId = "connection-safe-restart-hold-failure"
    [IO.File]::WriteAllText($rollbackConfigPath, ($restartHoldFailureConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $restartHoldFailureCheckpoint = $restartCheckpoint | ConvertTo-Json -Depth 30 | ConvertFrom-Json -Depth 30
    $restartHoldFailureCheckpoint.initialRunId = "simulated-restart-before-hold-failure"
    [IO.File]::WriteAllText($applicationRecoveryCheckpointPath, ($restartHoldFailureCheckpoint | ConvertTo-Json -Depth 30), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-previous"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent = 100
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent = 83
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended = $true
    $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended = $true
    $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended = $true
    $restartHoldRegisterFailure = $global:SchoolPilotTestAutoscalingRegisterCallCount + 1
    $restartHoldUpdateStart = $global:SchoolPilotTestUpdateServiceCallCount
    $global:SchoolPilotTestFailAutoscalingRegisterCalls = @($restartHoldRegisterFailure)
    $restartHoldFailureError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $restartHoldFailureError = $_ }
    finally { $global:SchoolPilotTestFailAutoscalingRegisterCalls = @() }
    $restartHoldFailureEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($restartHoldFailureConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $restartHoldFailed = @($restartHoldFailureEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $null -ne $restartHoldFailureError -and
        $restartHoldFailureError.Exception.Message -eq "Mock register-scalable-target failure at call $restartHoldRegisterFailure." -and
        $global:SchoolPilotTestUpdateServiceCallCount -eq $restartHoldUpdateStart -and
        $restartHoldFailed.Count -eq 1 -and
        $restartHoldFailed[0].details.recoveryCheckpointResumed -eq $true -and
        $restartHoldFailed[0].details.apiConfigurationNeedsRestoration -eq $true -and
        $restartHoldFailed[0].details.apiSafetyPolicyTouched -eq $false -and
        $restartHoldFailed[0].details.apiAutoscalingRestoration.success -eq $true -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 100 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 83 -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        -not $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "A restarted controller that cannot establish the scaling hold must restore scaling and make zero ECS mutations even when a temporary API policy needs later restoration."
    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState

    $checkpointLossConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $checkpointLossConfig.runId = "connection-safe-checkpoint-loss"
    [IO.File]::WriteAllText($rollbackConfigPath, ($checkpointLossConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath = $applicationRecoveryCheckpointPath
    $checkpointLossError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $checkpointLossError = $_ }
    finally { $global:SchoolPilotTestDeleteCheckpointAfterApiPolicyApplyPath = "" }
    $checkpointLossEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($checkpointLossConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $checkpointLossFailed = @($checkpointLossEvidence | Where-Object status -eq "failed")
    $checkpointLossRecovery = Get-Content -LiteralPath $applicationRecoveryCheckpointPath -Raw | ConvertFrom-Json -Depth 30
    Assert-Condition (
        $null -ne $checkpointLossError -and $checkpointLossError.Exception.Message -match "lost its active durable recovery checkpoint" -and
        $checkpointLossFailed.Count -eq 1 -and
        $checkpointLossFailed[0].details.recoveryRequired -eq $true -and
        $checkpointLossFailed[0].details.safetyPolicyRetained -eq $true -and
        $checkpointLossFailed[0].details.apiAutoscalingHoldRetained -eq $true -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 100 -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended -and
        $checkpointLossRecovery.status -eq "active" -and
        $checkpointLossRecovery.lastFailure -match "lost its active durable recovery checkpoint"
    ) "Losing the active checkpoint after policy mutation must fail closed, retain policy/scaling containment, and recreate active recovery evidence."
    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState

    $apiUpdateFailureConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $apiUpdateFailureConfig.runId = "connection-safe-api-update-failure"
    [IO.File]::WriteAllText($rollbackConfigPath, ($apiUpdateFailureConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $apiFailurePayloadStart = $global:SchoolPilotTestDeploymentPayloads.Count
    $apiFailureTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestFailUpdateServiceSelector = [ordered]@{
        service = "api"
        taskDefinition = "api-previous"
    }
    $apiFailureError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $apiFailureError = $_ }
    finally { $global:SchoolPilotTestFailUpdateServiceSelector = $null }
    $apiFailureDiagnostic = [ordered]@{
        error = if ($null -eq $apiFailureError) { "<none>" } else { [string]$apiFailureError.Exception.Message }
        policyPayloadCount = $global:SchoolPilotTestDeploymentPayloads.Count - $apiFailurePayloadStart
        taskUpdateCount = $global:SchoolPilotTestTaskUpdateObservations.Count - $apiFailureTaskStart
        apiTaskDefinition = [string]$global:SchoolPilotTestServiceState.api.taskDefinition
        workerTaskDefinition = [string]$global:SchoolPilotTestServiceState.worker.taskDefinition
    } | ConvertTo-Json -Compress -Depth 10
    Assert-Condition (
        $null -ne $apiFailureError -and
        $apiFailureError.Exception.Message -eq
            "Mock update-service failure for service 'api' and task definition 'api-previous'."
    ) "An API revision-update failure must preserve the original exception. Observed: $apiFailureDiagnostic"
    $apiFailurePayloads = @($global:SchoolPilotTestDeploymentPayloads | Select-Object -Skip $apiFailurePayloadStart)
    Assert-Condition (
        $apiFailurePayloads.Count -eq 2 -and
        @($apiFailurePayloads | Where-Object service -eq "worker").Count -eq 0 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 100 -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.minimumHealthyPercent -eq 83 -and
        ($global:SchoolPilotTestServiceState.worker.deploymentConfiguration | ConvertTo-Json -Compress -Depth 20) -ceq $capturedWorkerDeploymentJson -and
        $global:SchoolPilotTestTaskUpdateObservations.Count -eq $apiFailureTaskStart
    ) "API update failure must retain the API non-overlap policy and leave the worker untouched."
    $apiFailureEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($apiUpdateFailureConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $apiFailureFailed = @($apiFailureEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $apiFailureFailed.Count -eq 1 -and
        $apiFailureFailed[0].details.recoveryRequired -eq $true -and
        $apiFailureFailed[0].details.recoveryStatus -eq "incomplete" -and
        $apiFailureFailed[0].details.failedStep -eq "restore-previous-api-revision" -and
        $apiFailureFailed[0].details.apiConverged -eq $false -and
        $apiFailureFailed[0].details.workerRollbackDispatched -eq $false -and
        $apiFailureFailed[0].details.safetyPolicyRetained -eq $true -and
        $apiFailureFailed[0].details.apiAutoscalingHoldRetained -eq $true -and
        $apiFailureFailed[0].details.apiAutoscalingHoldRetention.success -eq $true -and
        $apiFailureFailed[0].details.apiAutoscalingHoldRetention.verified.suspendedState.dynamicScalingInSuspended -eq $true -and
        $apiFailureFailed[0].details.apiAutoscalingHoldRetention.verified.suspendedState.dynamicScalingOutSuspended -eq $true -and
        $apiFailureFailed[0].details.apiAutoscalingHoldRetention.verified.suspendedState.scheduledScalingSuspended -eq $true -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "API failure evidence must explicitly require recovery and prove the safe policy was retained."

    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $workerUpdateFailureConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $workerUpdateFailureConfig.runId = "connection-safe-worker-update-failure"
    [IO.File]::WriteAllText($rollbackConfigPath, ($workerUpdateFailureConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $workerFailureCallStart = $global:SchoolPilotTestUpdateServiceCallCount
    $workerFailureTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestFailUpdateServiceSelector = [ordered]@{
        service = "worker"
        taskDefinition = "worker-previous"
    }
    $workerFailureError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $workerFailureError = $_ }
    finally { $global:SchoolPilotTestFailUpdateServiceSelector = $null }
    $workerFailureTaskUpdates = @($global:SchoolPilotTestTaskUpdateObservations | Select-Object -Skip $workerFailureTaskStart)
    $workerFailureDiagnostic = [ordered]@{
        error = if ($null -eq $workerFailureError) { $null } else { [string]$workerFailureError.Exception.Message }
        taskUpdateCount = $workerFailureTaskUpdates.Count
        taskUpdateServices = @($workerFailureTaskUpdates | ForEach-Object { [string]$_.service })
        apiTaskDefinition = [string]$global:SchoolPilotTestServiceState.api.taskDefinition
        workerTaskDefinition = [string]$global:SchoolPilotTestServiceState.worker.taskDefinition
        apiMaximumPercent = [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent
        workerMaximumPercent = [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent
        updateServiceCallsObserved = $global:SchoolPilotTestUpdateServiceCallCount - $workerFailureCallStart
    } | ConvertTo-Json -Compress -Depth 10
    Assert-Condition (
        $null -ne $workerFailureError -and
        $workerFailureError.Exception.Message -eq
            "Mock update-service failure for service 'worker' and task definition 'worker-previous'." -and
        $workerFailureTaskUpdates.Count -eq 1 -and $workerFailureTaskUpdates[0].service -eq "api" -and
        $global:SchoolPilotTestServiceState.api.taskDefinition -eq "api-previous" -and
        $global:SchoolPilotTestServiceState.worker.taskDefinition -eq "worker-current" -and
        [int]$global:SchoolPilotTestServiceState.api.deploymentConfiguration.maximumPercent -eq 100 -and
        [int]$global:SchoolPilotTestServiceState.worker.deploymentConfiguration.maximumPercent -eq 100
    ) "A worker update failure may occur only after exact API convergence and must retain both safe policies. Observed: $workerFailureDiagnostic"
    $workerFailureEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($workerUpdateFailureConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $workerFailureFailed = @($workerFailureEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $workerFailureFailed.Count -eq 1 -and
        $workerFailureFailed[0].details.recoveryRequired -eq $true -and
        $workerFailureFailed[0].details.apiConverged -eq $true -and
        $workerFailureFailed[0].details.workerConverged -eq $false -and
        $workerFailureFailed[0].details.safetyPolicyRetained -eq $true -and
        $workerFailureFailed[0].details.apiAutoscalingHoldRetained -eq $true -and
        $workerFailureFailed[0].details.apiAutoscalingHoldRetention.success -eq $true -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "Worker failure evidence must retain the mixed-revision recovery state without claiming success."

    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $failedDeploymentConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $failedDeploymentConfig.runId = "connection-safe-failed-deployment"
    [IO.File]::WriteAllText($rollbackConfigPath, ($failedDeploymentConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $failedDeploymentTaskStart = $global:SchoolPilotTestTaskUpdateObservations.Count
    $global:SchoolPilotTestFailedDeploymentSelector = [ordered]@{
        service = "api"
        taskDefinition = "api-previous"
    }
    $failedDeploymentError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $failedDeploymentError = $_ }
    finally { $global:SchoolPilotTestFailedDeploymentSelector = $null }
    $failedDeploymentTaskUpdates = @(
        $global:SchoolPilotTestTaskUpdateObservations |
            Select-Object -Skip $failedDeploymentTaskStart
    )
    $failedDeploymentDiagnostic = [ordered]@{
        error = if ($null -eq $failedDeploymentError) {
            "<none>"
        }
        else {
            [string]$failedDeploymentError.Exception.Message
        }
        taskUpdateCount = $failedDeploymentTaskUpdates.Count
        taskUpdateServices = @(
            $failedDeploymentTaskUpdates | ForEach-Object { [string]$_.service }
        )
        apiTaskDefinition = [string]$global:SchoolPilotTestServiceState.api.taskDefinition
        workerTaskDefinition = [string]$global:SchoolPilotTestServiceState.worker.taskDefinition
    } | ConvertTo-Json -Compress -Depth 10
    Assert-Condition (
        $null -ne $failedDeploymentError -and
        $failedDeploymentError.Exception.Message -match "rolloutState=FAILED" -and
        $global:SchoolPilotTestServiceState.worker.taskDefinition -eq "worker-current" -and
        @($failedDeploymentTaskUpdates | Where-Object service -eq "worker").Count -eq 0
    ) "A failed API deployment must stop before worker rollback. Observed: $failedDeploymentDiagnostic"
    $failedDeploymentEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($failedDeploymentConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $failedDeploymentFailed = @($failedDeploymentEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $failedDeploymentFailed.Count -eq 1 -and
        $failedDeploymentFailed[0].details.recoveryRequired -eq $true -and
        $failedDeploymentFailed[0].details.failedStep -eq "wait-api-exact-convergence" -and
        $failedDeploymentFailed[0].details.workerRollbackDispatched -eq $false -and
        $failedDeploymentFailed[0].details.lastObservedConvergence.failedDeployment -eq $true -and
        $failedDeploymentFailed[0].details.safetyPolicyRetained -eq $true -and
        $failedDeploymentFailed[0].details.apiAutoscalingHoldRetained -eq $true -and
        $failedDeploymentFailed[0].details.apiAutoscalingHoldRetention.success -eq $true -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "Failed-deployment evidence must record the exact failed observation and recovery requirement."

    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20
    $deadlineConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $deadlineConfig.runId = "connection-safe-deadline-expiry"
    # The rollback budget starts before the child heartbeat is ready. Leave enough
    # room for cold Windows process startup so this case deterministically expires
    # in the forced API-convergence loop that its evidence assertions exercise.
    $deadlineConfig | Add-Member -NotePropertyName rollbackMaximumSeconds -NotePropertyValue ([pscustomobject]@{ Application = 20 }) -Force
    [IO.File]::WriteAllText($rollbackConfigPath, ($deadlineConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestForceUnstableService = "api"
    $deadlineError = $null
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Application -Mode Execute | Out-Null }
    catch { $deadlineError = $_ }
    finally { $global:SchoolPilotTestForceUnstableService = "" }
    Assert-Condition (
        $null -ne $deadlineError -and
        $deadlineError.Exception.Message -match "deadline reached" -and
        $global:SchoolPilotTestServiceState.worker.taskDefinition -eq "worker-current"
    ) "Deadline expiry must stop before worker rollback."
    $deadlineEvidence = @(Get-Content -LiteralPath (Join-Path $evidenceDirectory "$($deadlineConfig.runId)-rollback.jsonl") |
        ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
    $deadlineFailed = @($deadlineEvidence | Where-Object status -eq "failed")
    Assert-Condition (
        $deadlineFailed.Count -eq 1 -and
        $deadlineFailed[0].details.recoveryRequired -eq $true -and
        $deadlineFailed[0].details.failedStep -eq "wait-api-exact-convergence" -and
        $deadlineFailed[0].details.safetyPolicyRetained -eq $true -and
        $deadlineFailed[0].details.apiAutoscalingHoldRetained -eq $true -and
        $deadlineFailed[0].details.apiAutoscalingHoldRetention.success -eq $true -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingInSuspended -and
        $global:SchoolPilotTestAutoscalingState.dynamicScalingOutSuspended -and
        $global:SchoolPilotTestAutoscalingState.scheduledScalingSuspended
    ) "Deadline evidence must require recovery and retain the API non-overlap policy."

    [IO.File]::Delete($applicationRecoveryCheckpointPath)
    Reset-SchoolPilotTestAutoscalingState
    $global:SchoolPilotTestServiceState.api.deploymentConfiguration = $capturedApiDeploymentJson | ConvertFrom-Json -Depth 20
    $global:SchoolPilotTestServiceState.worker.deploymentConfiguration = $capturedWorkerDeploymentJson | ConvertFrom-Json -Depth 20

    $global:SchoolPilotTestServiceState.api.taskDefinition = "api-current"
    $global:SchoolPilotTestServiceState.api.desired = 1
    $global:SchoolPilotTestServiceState.api.running = 1
    $global:SchoolPilotTestServiceState.api.pending = 0
    $global:SchoolPilotTestServiceState.worker.taskDefinition = "worker-current"
    $global:SchoolPilotTestServiceState.worker.desired = 1
    $global:SchoolPilotTestServiceState.worker.running = 1
    $global:SchoolPilotTestServiceState.worker.pending = 0

    $badOomConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $badOomConfig.runId = "bad-emergency-digest"
    $badOomConfig.emergencyTaskDefinitionEvidence.emergencyTaskDefinition.containerDefinitions[0].image = "repo@sha256:$('d'*64)"
    [IO.File]::WriteAllText($rollbackConfigPath, ($badOomConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $badOomRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Oom -Mode Validate | Out-Null }
    catch { $badOomRejected = $_.Exception.Message -match "non-digest-matched image" }
    Assert-Condition $badOomRejected "OOM preflight must reject an emergency revision that does not match the current immutable image digest."

    $smallHardCapConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $smallHardCapConfig.runId = "bad-emergency-hard-cap"
    $smallHardCapConfig.emergencyTaskDefinitionEvidence.emergencyTaskDefinition.containerDefinitions[0].memory = 1024
    [IO.File]::WriteAllText($rollbackConfigPath, ($smallHardCapConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $smallHardCapRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Oom -Mode Validate | Out-Null }
    catch { $smallHardCapRejected = $_.Exception.Message -match "memory contract" }
    Assert-Condition $smallHardCapRejected "OOM preflight must reject a defined 1024 MiB hard container cap on the 2048 MiB emergency task."

    foreach ($sizeCase in @(
            @{ runId = "bad-emergency-old-size"; target = "emergencyTaskDefinition"; cpu = "512"; memory = "2048" },
            @{ runId = "bad-emergency-shrinks-serving-api"; target = "currentTaskDefinition"; cpu = "2048"; memory = "4096" }
        )) {
        $sizeConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $sizeConfig.runId = $sizeCase.runId
        $sizeConfig.emergencyTaskDefinitionEvidence.($sizeCase.target).cpu = $sizeCase.cpu
        $sizeConfig.emergencyTaskDefinitionEvidence.($sizeCase.target).memory = $sizeCase.memory
        [IO.File]::WriteAllText($rollbackConfigPath, ($sizeConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        $sizeRejected = $false
        try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Oom -Mode Validate | Out-Null }
        catch { $sizeRejected = $_.Exception.Message -match "identity, size, roles" }
        Assert-Condition $sizeRejected "OOM preflight must reject $($sizeCase.runId): the emergency target is the reviewed 1024 CPU / 2048 MiB and never smaller than the serving API."
    }

    $misconfiguredCloneConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $misconfiguredCloneConfig.runId = "bad-emergency-clone"
    $misconfiguredCloneConfig.emergencyTaskDefinitionEvidence.emergencyTaskDefinition.containerDefinitions[0] | Add-Member -NotePropertyName command -NotePropertyValue @("unsafe") -Force
    [IO.File]::WriteAllText($rollbackConfigPath, ($misconfiguredCloneConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $misconfiguredCloneRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action Oom -Mode Validate | Out-Null }
    catch { $misconfiguredCloneRejected = $_.Exception.Message -match "not a configuration clone" }
    Assert-Condition $misconfiguredCloneRejected "OOM preflight must canonical-compare the full task/container configuration, not only image and roles."

    $alreadyEmergencyConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $alreadyEmergencyConfig.runId = "oom-already-emergency"
    [IO.File]::WriteAllText($rollbackConfigPath, ($alreadyEmergencyConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $expectedAlreadyEmergencyError = "OOM rollback is unavailable because the API already uses the reviewed emergency revision; progression is blocked without an AWS mutation."
    $priorApiTaskDefinition = [string]$global:SchoolPilotTestServiceState.api.taskDefinition
    $updateCallsBeforeEmergencyBlock = $null
    $alreadyEmergencyError = $null
    $alreadyEmergencyObservedTaskDefinition = $null
    $updateCallsAfterEmergencyBlock = $null
    try {
        $global:SchoolPilotTestServiceState.api.taskDefinition = $alreadyEmergencyConfig.emergencyApiTaskDefinition
        $updateCallsBeforeEmergencyBlock = @(
            $global:SchoolPilotTestAwsCalls | Where-Object { $_ -like "ecs update-service*" }
        ).Count
        & $rollbackScript -ConfigPath $rollbackConfigPath -Action Oom -Mode Execute | Out-Null
    }
    catch {
        $alreadyEmergencyError = $_
    }
    finally {
        $alreadyEmergencyObservedTaskDefinition = [string]$global:SchoolPilotTestServiceState.api.taskDefinition
        $updateCallsAfterEmergencyBlock = @(
            $global:SchoolPilotTestAwsCalls | Where-Object { $_ -like "ecs update-service*" }
        ).Count
        $global:SchoolPilotTestServiceState.api.taskDefinition = $priorApiTaskDefinition
    }
    $alreadyEmergencyDiagnostic = [ordered]@{
        error = if ($null -eq $alreadyEmergencyError) { "<none>" } else { [string]$alreadyEmergencyError.Exception.Message }
        expectedTaskDefinition = [string]$alreadyEmergencyConfig.emergencyApiTaskDefinition
        observedTaskDefinition = $alreadyEmergencyObservedTaskDefinition
        updateCallsBefore = $updateCallsBeforeEmergencyBlock
        updateCallsAfter = $updateCallsAfterEmergencyBlock
    } | ConvertTo-Json -Compress -Depth 5
    Assert-Condition ($null -ne $alreadyEmergencyError -and
        $alreadyEmergencyError.Exception.Message -ceq $expectedAlreadyEmergencyError) `
        "OOM rollback must report that the API already runs the reviewed emergency revision. Observed: $alreadyEmergencyDiagnostic"
    Assert-Condition ($alreadyEmergencyObservedTaskDefinition -eq $alreadyEmergencyConfig.emergencyApiTaskDefinition) `
        "OOM rollback must preserve the already-active emergency revision. Observed: $alreadyEmergencyDiagnostic"
    Assert-Condition ($updateCallsAfterEmergencyBlock -eq $updateCallsBeforeEmergencyBlock) `
        "OOM rollback must block without an ECS mutation when the API already runs the emergency revision. Observed: $alreadyEmergencyDiagnostic"

    $badLineageConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $badLineageConfig.runId = "bad-state-lineage"
    $badLineageConfig.terraformStateLineage = "wrong-lineage"
    [IO.File]::WriteAllText($rollbackConfigPath, ($badLineageConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $badLineageRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action NatRemoved -Mode Validate | Out-Null }
    catch { $badLineageRejected = $_.Exception.Message -match "does not match the local state" }
    Assert-Condition $badLineageRejected "NAT rollback must bind the reviewed plan to the exact Terraform state lineage."

    $invalidPlanShapeConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $invalidPlanShapeConfig.runId = "invalid-plan-shape"
    [IO.File]::WriteAllText($rollbackConfigPath, ($invalidPlanShapeConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $global:SchoolPilotTestPlanShapeInvalid = $true
    $invalidPlanShapeRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action NatRemoved -Mode Validate | Out-Null }
    catch { $invalidPlanShapeRejected = $_.Exception.Message -match "exactly six create-only|update/delete/non-create|unreviewed|extra, missing, or duplicate" }
    $global:SchoolPilotTestPlanShapeInvalid = $false
    Assert-Condition $invalidPlanShapeRejected "NAT rollback must reject any extra, updated, or unreviewed Terraform plan change."

    $longNatRunIdConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $longNatRunIdConfig.runId = "r" * 45
    [IO.File]::WriteAllText($rollbackConfigPath, ($longNatRunIdConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $longNatRunIdRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action NatRemoved -Mode Validate | Out-Null }
    catch { $longNatRunIdRejected = $_.Exception.Message -match "at most 44" }
    Assert-Condition $longNatRunIdRejected "NatRemoved validation must reject runIds whose derived backup phase exceeds 64 characters."

    $tamperPlanConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
    $tamperPlanConfig.runId = "nat-plan-pre-apply-tamper"
    [IO.File]::WriteAllText($rollbackConfigPath, ($tamperPlanConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
    $applyCallsBeforeTamper = @($global:SchoolPilotTestTerraformCalls | Where-Object { $_ -like 'apply *' }).Count
    $global:SchoolPilotTestTamperNatPlanBeforeApplyPath = $natPlanPath
    $global:SchoolPilotTestNatPlanTampered = $false
    $tamperBeforeApplyRejected = $false
    try { & $rollbackScript -ConfigPath $rollbackConfigPath -Action NatRemoved -Mode Execute | Out-Null }
    catch { $tamperBeforeApplyRejected = $_.Exception.Message -match "changed after initial validation" }
    $applyCallsAfterTamper = @($global:SchoolPilotTestTerraformCalls | Where-Object { $_ -like 'apply *' }).Count
    Assert-Condition ($tamperBeforeApplyRejected -and $global:SchoolPilotTestNatPlanTampered -and
        $applyCallsAfterTamper -eq $applyCallsBeforeTamper) `
        "NAT rollback must rehash the saved plan after initial validation and block a tampered plan before terraform apply."
    [IO.File]::WriteAllBytes($natPlanPath, [Text.Encoding]::UTF8.GetBytes("reviewed-nat-plan"))
    $global:SchoolPilotTestTamperNatPlanBeforeApplyPath = ""
    $global:SchoolPilotTestNatPlanTampered = $false

    foreach ($action in @("Application", "Oom", "Waf", "PublicEcs", "Redis", "NatRemoved")) {
        $actionConfig = $rollbackConfig | ConvertTo-Json -Depth 20 | ConvertFrom-Json -Depth 20
        $actionConfig.runId = "rollback-test-$($action.ToLowerInvariant())"
        [IO.File]::WriteAllText($rollbackConfigPath, ($actionConfig | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
        & $rollbackScript -ConfigPath $rollbackConfigPath -Action $action -Mode Execute | Out-Null
        $rollbackEvidencePaths += Join-Path $evidenceDirectory "$($actionConfig.runId)-rollback.jsonl"
    }

    $rollbackCalls = $global:SchoolPilotTestAwsCalls -join "`n"
    Assert-Condition (-not $rollbackCalls.Contains("ecs wait services-stable")) "Rollback execution must never call the fixed ECS services-stable waiter."
    Assert-Condition ($rollbackCalls.Contains("--task-definition api-previous")) "Application rollback must restore the prior API revision."
    Assert-Condition ($rollbackCalls.Contains("--task-definition worker-previous")) "Application rollback must restore the prior worker revision."
    Assert-Condition ($rollbackCalls.Contains("--task-definition arn:aws:ecs:us-east-1:000000000000:task-definition/test-emergency:1")) "OOM rollback must deploy the emergency API revision."
    Assert-Condition ($rollbackCalls.Contains("--cache-node-type cache.t4g.small")) "Redis rollback must restore cache.t4g.small."
    Assert-Condition ($global:SchoolPilotTestNetworkPayloads.Count -ge 4) "Public ECS and NAT rollbacks must restore both service network configurations."
    foreach ($payload in $global:SchoolPilotTestNetworkPayloads) {
        Assert-Condition ($payload.awsvpcConfiguration.assignPublicIp -eq "DISABLED") "Rollback must disable public task IPs."
        Assert-Condition (@($payload.awsvpcConfiguration.subnets).Count -eq 2) "Rollback must restore both captured private subnets."
    }
    Assert-Condition ($null -ne $global:SchoolPilotTestWafUpdate) "WAF rollback must submit an update."
    $rateRules = @($global:SchoolPilotTestWafUpdate.Rules | Where-Object { $_.Name -in @("DeviceIngestRateLimit", "ApiRateLimit") })
    Assert-Condition ($rateRules.Count -eq 2) "WAF rollback must find exactly the two reviewed rate rules."
    Assert-Condition (@($rateRules | Where-Object { $null -ne $_.Action.Count }).Count -eq 2) "Both rate rules must switch to COUNT."
    Assert-Condition (@($global:SchoolPilotTestWafUpdate.Rules | Where-Object Name -eq "Managed").Count -eq 1) "Managed WAF rules must remain attached."
    $terraformApplyCalls = @($global:SchoolPilotTestTerraformCalls | Where-Object { $_ -like 'apply *' })
    Assert-Condition ($terraformApplyCalls.Count -eq 1) "NAT rollback must apply exactly one reviewed Terraform plan."
    Assert-Condition ($terraformApplyCalls[0].Contains($natPlanPath)) "NAT rollback must apply the digest-verified saved plan."
    Assert-Condition (-not (Test-Path -LiteralPath $natPlanPath)) "Applied NAT rollback plans must be deleted."
    Assert-Condition (Test-Path -LiteralPath $natForwardPlanPath) "The hashed NatRemoved forward plan must remain as rollback-chain evidence."

    $rollbackEvidence = @($rollbackEvidencePaths | ForEach-Object { Get-Content -LiteralPath $_ } | ForEach-Object { $_ | ConvertFrom-Json })
    Assert-Condition ($rollbackEvidence.Count -eq 12) "Each of six rollback drills must record start and completion evidence."
    Assert-Condition (@($rollbackEvidence | Where-Object status -eq "failed").Count -eq 0) "Mock rollback drills must have no failure evidence."
    $aesCopies = @(Get-ChildItem -LiteralPath $stateRecoveryDirectory -Filter "*.aesgcm" -File)
    $dpapiCopies = @(Get-ChildItem -LiteralPath $stateBackupDirectory -Filter "*.dpapi" -File)
    $expectedRecoveryPhases = @(
        "nat-plan-pre-apply-tamper-nat-rollback-before",
        "rollback-test-natremoved-nat-rollback-before",
        "rollback-test-natremoved-nat-rollback-after"
    )
    Assert-Condition ($aesCopies.Count -eq 3 -and $dpapiCopies.Count -eq 3) "NAT rollback must protect the fail-closed tamper checkpoint plus the successful before/after state with DPAPI and real AES-GCM recovery copies."
    foreach ($recoveryPhase in $expectedRecoveryPhases) {
        Assert-Condition (@($aesCopies | Where-Object Name -like "*$recoveryPhase*").Count -eq 1) "NAT rollback must retain one AES-GCM recovery copy for '$recoveryPhase'."
        Assert-Condition (@($dpapiCopies | Where-Object Name -like "*$recoveryPhase*").Count -eq 1) "NAT rollback must retain one DPAPI state backup for '$recoveryPhase'."
    }
    $natCompletedEvidence = @($rollbackEvidence | Where-Object { $_.action -eq "NatRemoved" -and $_.status -eq "completed" })
    Assert-Condition ($natCompletedEvidence.Count -eq 1 -and $natCompletedEvidence[0].details.postcondition.afterStateBackup.recoveryDecryptionVerified -eq $true) "NAT rollback evidence must prove AES-GCM decrypt-and-compare verification."

    $testClock.Stop()
    Write-Host ("AWS rollout monitor and rollback automation tests: PASS ({0} assertions, {1:N1}s)" -f $script:AssertionCount,$testClock.Elapsed.TotalSeconds)
}
catch {
    $topLevelFailure = $_
}
finally {
    # Process ownership is the first outer cleanup operation. Evidence/temp
    # deletion must never race a surviving child or inherited redirect handle.
    if ($ownedTestProcesses.Count -gt 0) {
        try { try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses } finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses } }
        catch {
            $topLevelCleanupFailures.Add([InvalidOperationException]::new(
                "Final owned process drain failed.",
                $_.Exception
            ))
        }
    }
    if ($null -ne $topLevelFailure -and (Test-Path -LiteralPath $tempRoot)) {
        try {
            $failureOutput = if ($env:SCHOOLPILOT_ROLLOUT_TEST_EVIDENCE_DIRECTORY) {
                $env:SCHOOLPILOT_ROLLOUT_TEST_EVIDENCE_DIRECTORY
            } else { Join-Path ([IO.Path]::GetTempPath()) 'schoolpilot-rollout-test-failures' }
            $failureReceipt = Save-MockMonitorFailureEvidence -FixtureRoot $tempRoot -OutputRoot $failureOutput `
                -FailureMessage $topLevelFailure.Exception.Message `
                -SourcePaths @($PSCommandPath, $monitorScript, $rollbackScript, $supervisorScript)
            Write-Host "Preserved bounded mock monitor failure evidence: $failureReceipt"
        }
        catch {
            $topLevelCleanupFailures.Add([InvalidOperationException]::new('Mock monitor failure evidence preservation failed.', $_.Exception))
        }
    }
    if ($null -ne $previousRolloutTestSentinel) { $env:SCHOOLPILOT_ROLLOUT_TEST_MODE = $previousRolloutTestSentinel } else { Remove-Item Env:SCHOOLPILOT_ROLLOUT_TEST_MODE -ErrorAction SilentlyContinue }
    if (Get-Variable oldOneDrive -ErrorAction SilentlyContinue) { $env:OneDrive = $oldOneDrive }
    Remove-Item Function:\global:aws -ErrorAction SilentlyContinue
    Remove-Item Function:\global:terraform -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestAwsCalls -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTerraformCalls -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestWafUpdate -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestNetworkPayloads -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestDeploymentPayloads -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTaskUpdateObservations -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestUpdateServiceCallCount -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestFailUpdateServiceSelector -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestForceUnstableService -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestFailedDeploymentSelector -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTransientMixedDeploymentPolls -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTargetDrainingPolls -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTamperNatPlanBeforeApplyPath -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestNatPlanTampered -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestNatForwardPlanPath -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestTargetHealthCallCount -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestDeregistrationDelaySeconds -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestServiceState -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestWafCount -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestMetricQueryIds -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestMetricQueryPeriods -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestMetricLookbackSeconds -Scope Global -ErrorAction SilentlyContinue
    Remove-Variable SchoolPilotTestRouteLatency -Scope Global -ErrorAction SilentlyContinue
    if ($ownedTestProcesses.Count -eq 0 -and (Test-Path -LiteralPath $tempRoot)) {
        try {
            Remove-TestDirectoryWithRetry -Path $tempRoot
        }
        catch {
            $topLevelCleanupFailures.Add([InvalidOperationException]::new(
                "Final temporary-directory removal failed.",
                $_.Exception
            ))
        }
    }
    elseif ($ownedTestProcesses.Count -gt 0 -and (Test-Path -LiteralPath $tempRoot)) {
        $topLevelCleanupFailures.Add([InvalidOperationException]::new(
            "Temporary evidence was retained because $($ownedTestProcesses.Count) owned process entries could not be drained."
        ))
    }
    if ($null -ne $topLevelFailure -and $topLevelCleanupFailures.Count -gt 0) {
        Add-OwnedTestProcessCleanupFailures -Exception $topLevelFailure.Exception `
            -CleanupFailures ([Exception[]]$topLevelCleanupFailures.ToArray())
        throw $topLevelFailure
    }
    if ($null -ne $topLevelFailure) { throw $topLevelFailure }
    if ($topLevelCleanupFailures.Count -gt 0) {
        throw [AggregateException]::new(
            "Rollout automation final cleanup failed.",
            [Exception[]]$topLevelCleanupFailures.ToArray()
        )
    }
}
