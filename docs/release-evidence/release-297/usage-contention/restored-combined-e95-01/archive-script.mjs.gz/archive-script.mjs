import assert from 'node:assert/strict';
import {readFileSync,readdirSync,statSync,mkdirSync,writeFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp=process.env.TEMP,run=join(temp,'release297-role-restored-combined-e95-01'),driver=join(temp,'release297-restored-role-e95-driver-01');
const out='C:/Users/zinka/.codex/artifacts/release297-restored-combined-e95-evidence-01';
const sha=x=>createHash('sha256').update(x).digest('hex'),read=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const files=[],hashOnly=[];mkdirSync(out);
const scrubText=s=>s.replace(/(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi,'<REDACTED_LOCAL_CONNECTION_URL>').replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_SYNTHETIC_TOKEN>').replace(/C:[\\/]Users[\\/]zinka[\\/]AppData[\\/]Local[\\/]Temp/gi,'<TEMP>');
function scrub(v,k=''){if(/(?:password|secret|cookie|authorization|^nonce$|^token$|Token$|_URL$)/i.test(k))return'<REDACTED>';if(typeof v==='string')return scrubText(v);if(Array.isArray(v))return v.map(x=>scrub(x));if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([key,x])=>[key,scrub(x,key)]));return v;}
function add(path,name){const raw=readFileSync(path),safe=Buffer.from(path.endsWith('.json')?JSON.stringify(scrub(JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''))),null,2)+'\n':scrubText(raw.toString('utf8'))),gz=gzipSync(safe,{level:6});mkdirSync(dirname(join(out,name+'.gz')),{recursive:true});writeFileSync(join(out,name+'.gz'),gz,{flag:'wx'});files.push({path:name+'.gz',originalPath:path.replace(temp,'<TEMP>'),originalBytes:raw.length,originalSha256:sha(raw),sanitizedSha256:sha(safe),gzipSha256:sha(gz)});}
function exclude(path,reason){const raw=readFileSync(path);hashOnly.push({path:path.replace(temp,'<TEMP>'),bytes:raw.length,sha256:sha(raw),reason});}
function walk(directory,prefix,{privateOnly=false}={}){for(const entry of readdirSync(directory,{withFileTypes:true})){const path=join(directory,entry.name),name=prefix+'/'+entry.name;if(entry.isDirectory())walk(path,name,{privateOnly});else if(privateOnly||entry.name==='cold-fixture-state.json')exclude(path,'Private synthetic fixture/role credentials or populated state; original hash only.');else add(path,name);}}
const m=read(join(run,'usage-scale.json')),p=m.phases[0],cleanup=read(join(run,'all-owned-role-fixtures-cleanup.json')),host=read(join(run,'role-host-result.json')),manifest=read(join(run,'receipt-manifest.json'));
assert.equal(cleanup.cleanupPassed,true);assert.equal(cleanup.fixtures.resources.length,2);assert.equal(cleanup.roles.roles.length,4);assert.ok(cleanup.fixtures.resources.find(x=>x.role==='postgres').volumes.every(x=>x.confirmedAbsent));assert.equal(Object.keys(manifest.records).length,13);for(const row of Object.values(manifest.records))assert.equal(sha(readFileSync(join(run,row.file))),row.sha256);assert.equal(m.sourceUnchangedAtFinish,true);
const summary={source:m.sourceRevision,run:cleanup.run,startedAt:m.startedAt,finishedAt:m.finishedAt,cleanupFinishedAt:cleanup.finishedAt,capacityAccepted:false,acceptedRunCount:0,
 heartbeats:p.traffic.heartbeats,reports:{offered:p.traffic.reports.length,success:p.traffic.reports.filter(x=>x.status===200&&x.correct&&x.durationMs<20000).length},workers:p.workers,
 api:{cpuMicroseconds:p.api.cpuMicroseconds,eventLoop:p.api.eventLoop,acquisitions:p.api.database.acquisitions},insertedObservations:p.insertedObservations,httpStatuses:p.traffic.heartbeatStatuses,
 correctness:{passed:m.correctness.passed,csvAuditCount:m.correctness.csvAuditCount},preflightDrain:m.preflightDrain,serverDrain:p.serverDrain,
 lifecycle:{passed:p.traffic.lifecycle.passed,events:p.traffic.lifecycle.events,error:p.traffic.lifecycle.error},sourceAtFinish:m.sourceAtFinish,
 roleExits:host.roles.map(x=>({role:x.role,...x.exit})),cleanup,receiptManifestSha256:sha(readFileSync(join(run,'receipt-manifest.json'))),
 integration:{all13CustodyHashesVerified:true,actualRuntimeFacts:true,failedWorkloadExitPreserved:true,candidateContractPassed:false,knownValidatorMismatch:'Canonical preflightDrain is one API receipt; current candidate validator incorrectly assumes api/worker nesting. Historical raw receipts remain unchanged.'}};
writeFileSync(join(out,'summary.json'),JSON.stringify(scrub(summary),null,2)+'\n',{flag:'wx'});
walk(run,'run');walk(run+'-private','private',{privateOnly:true});
walk(join(temp,'release297-restored-role-e95-build-01'),'helper');walk(join(temp,'release297-restored-role-integration-review-02'),'review');walk(join(temp,'release297-restored-rejection-analysis-01'),'validation-analysis');
walk(join(driver,'scripts/load/usage/roles'),'source/roles');
for(const name of ['release297-restored-integration-prep-02.mjs','release297-restored-role-config-01.mjs','release297-restored-role-context-01.log','release297-restored-role-helper-01.log','release297-restored-role-host-ci-01.log','release297-restored-role-host-build-01.log','release297-role-restored-combined-e95-01.log','release297-restored-rejections-01.mjs','release297-restored-rejections-all-01.mjs'])add(join(temp,name),'commands/'+name);
for(const name of ['role-preparation.json','coordinator-overlay-receipt.json','.dockerignore','Dockerfile.roles','overlay/binding.json'])add(join(temp,'release297-restored-role-e95-context-01',name),'context/'+name);
const overlay=join(temp,'release297-restored-role-e95-context-01/overlay/scripts/load/usage');walk(overlay,'context/executed-harness');
add(fileURLToPath(import.meta.url),'archive-script.mjs');
for(const f of files){assert.equal(sha(readFileSync(join(out,f.path))),f.gzipSha256);assert.equal(sha(gunzipSync(readFileSync(join(out,f.path)))),f.sanitizedSha256);assert.equal(sha(readFileSync(f.originalPath.replace('<TEMP>',temp))),f.originalSha256);}
const packet={schemaVersion:1,createdAt:new Date().toISOString(),source:m.sourceRevision,run:cleanup.run,scope:'Actual full restored e95 diagnostic and 13-receipt collection; failed numerical acceptance preserved; candidate execution disabled.',summarySha256:sha(readFileSync(join(out,'summary.json'))),capacityAccepted:false,acceptedRunCount:0,
 limitations:['Original receipt hashes retained; sanitized copies are not acceptance inputs.','13 raw records seal correctly; a masked candidate preflight shape mismatch was found and must be corrected before candidate enablement.','Synthetic PG4CPU/4GiB differs from dated production db.t4g.medium; no deployed headroom proof.','No production operations, no host filesystem cache flush, no workload retry.','Immutable source/helper/snapshot bytes preserved; private credentials and populated fixture state excluded.'],files,hashOnly};
writeFileSync(join(out,'manifest.json'),JSON.stringify(packet,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({out,files:files.length,hashOnly:hashOnly.length,manifestSha256:sha(readFileSync(join(out,'manifest.json'))),summarySha256:packet.summarySha256}));
