import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const directory='<TEMP>/release297-ci-8148-frontend2-01';
const run=37153313271,job=111291457200,source='814844f344a45159152415b0fb6d7027f05b093e';
mkdirSync(directory);
const gh=args=>execFileSync('gh',args,{windowsHide:true,timeout:60000,maxBuffer:64*1024**2});
const files=[];
for(const[name,route]of [['run.json',`actions/runs/${run}`],['job.json',`actions/jobs/${job}`],['job.log',`actions/jobs/${job}/logs`]]){
  const bytes=gh(['api',`repos/bzinkan/SchoolPilot/${route}`]);writeFileSync(join(directory,name),bytes,{flag:'wx'});
  files.push({path:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
}
const runMeta=JSON.parse(readFileSync(join(directory,'run.json'),'utf8')),jobMeta=JSON.parse(readFileSync(join(directory,'job.json'),'utf8'));
assert.equal(runMeta.head_sha,source);assert.equal(jobMeta.run_id,run);assert.equal(jobMeta.head_sha,source);assert.equal(jobMeta.conclusion,'failure');
const manifest={schemaVersion:1,recordedAt:new Date().toISOString(),source,run,job,conclusion:jobMeta.conclusion,name:jobMeta.name,url:jobMeta.html_url,rawBytesUnmodified:true,rerunRequested:false,files};
const bytes=JSON.stringify(manifest,null,2)+'\n';writeFileSync(join(directory,'manifest.json'),bytes,{flag:'wx'});
console.log(JSON.stringify({directory,manifestSha256:createHash('sha256').update(bytes).digest('hex'),files}));
