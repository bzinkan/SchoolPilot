import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const root='<USER_HOME>/.codex/worktrees/release-stabilization-297/SchoolPilot';
const require=createRequire(root+'/package.json'),pg=require('pg');
const load=name=>import(pathToFileURL(root+'/'+name).href);
const helper=await load('scripts/load/usage/prepare-release-control-ownership.mjs');
helper.assertReleaseControlPreparationEnvironment(process.env);
const admin=new pg.Pool({connectionString:process.env.ADMIN_DATABASE_URL,max:2});
const {runWithTenantContext}=await load('dist/middleware/tenantContext.js');
const {getTenantStore}=await load('dist/db/tenantContext.js');
const storage=await load('dist/services/storage.js');
const schools=Array.from({length:2},(_,index)=>({index,id:randomUUID(),staff:randomUUID(),teachers:Array.from({length:100},()=>randomUUID()),students:Array.from({length:500},()=>randomUUID()),groups:Array.from({length:100},()=>randomUUID()),devices:Array.from({length:500},()=>`synthetic-scale-${randomUUID()}`),studentSessions:Array.from({length:500},()=>randomUUID()),teachingSessions:Array.from({length:100},()=>randomUUID())}));
const result={scope:'Native restricted-role control-only fixture; no heartbeat/load/capacity claim',passed:false,before:[],after:[],foreignControlsVisible:[],poolsClosed:false};
const command=school=>runWithTenantContext({schoolId:school.id},()=>{const id=randomUUID();return storage.createClasspilotCommandWithTargets({id,schoolId:school.id,teacherId:school.teachers[0],teachingSessionId:school.teachingSessions[0],supervisionContextId:null,targetScope:'students',commandType:'open-tab',commandPayload:{url:'https://example.test/synthetic'},status:'requested'},[{commandId:id,schoolId:school.id,teachingSessionId:school.teachingSessions[0],supervisionContextId:null,studentId:school.students[0],studentSessionId:school.studentSessions[0],deviceId:school.devices[0],status:'requested'}],{authority:{schoolId:school.id,actorId:school.teachers[0],teachingSessionId:school.teachingSessions[0]}});});
try{
 for(const school of schools){
  await admin.query("INSERT INTO schools(id,name,domain,status,is_active,plan_status,school_timezone) VALUES($1,'Synthetic control proof',$2,'active',true,'active','America/New_York')",[school.id,school.id+'.example.test']);
  await admin.query("INSERT INTO product_licenses(school_id,product,status) VALUES($1,'CLASSPILOT','active')",[school.id]);
  await admin.query("INSERT INTO settings(school_id,school_name,ws_shared_key,enable_tracking_hours) VALUES($1,'Synthetic','synthetic',false)",[school.id]);
  await admin.query("INSERT INTO users(id,email,first_name,last_name) SELECT id,'scale-'||id||'@example.test','Synthetic','Proof' FROM unnest($1::text[]) id",[[school.staff,...school.teachers]]);
  await admin.query("INSERT INTO school_memberships(school_id,user_id,role,status) SELECT $1,id,CASE WHEN id=$2 THEN 'school_admin' ELSE 'teacher' END,'active' FROM unnest($3::text[]) id",[school.id,school.staff,[school.staff,...school.teachers]]);
  await admin.query("INSERT INTO students(id,school_id,first_name,last_name,status,email) SELECT id,$2,'Synthetic','Proof','active','scale-'||id||'@example.test' FROM unnest($1::text[]) id",[school.students,school.id]);
  const writer=await admin.connect();try{await writer.query('BEGIN');await writer.query("INSERT INTO groups(id,school_id,teacher_id,name,group_type) SELECT id,$2,($3::text[])[ordinality::int],'Synthetic Class '||ordinality,'admin_class' FROM unnest($1::text[]) WITH ORDINALITY class(id,ordinality)",[school.groups,school.id,school.teachers]);await writer.query("INSERT INTO group_teachers(group_id,teacher_id,role) SELECT id,($2::text[])[ordinality::int],'primary' FROM unnest($1::text[]) WITH ORDINALITY class(id,ordinality)",[school.groups,school.teachers]);await writer.query('COMMIT');}catch(error){await writer.query('ROLLBACK');throw error;}finally{writer.release();}
  await admin.query('INSERT INTO group_students(student_id,group_id) SELECT id,($2::text[])[((ordinality-1)/5)::int+1] FROM unnest($1::text[]) WITH ORDINALITY student(id,ordinality)',[school.students,school.groups]);
  await admin.query('INSERT INTO devices(device_id,school_id,class_id) SELECT id,$2,($3::text[])[((ordinality-1)/5)::int+1] FROM unnest($1::text[]) WITH ORDINALITY device(id,ordinality)',[school.devices,school.id,school.groups]);
  await admin.query("INSERT INTO student_sessions(id,student_id,device_id,auth_kind,is_active) SELECT id,($2::text[])[ordinality::int],($3::text[])[ordinality::int],'managed_profile',true FROM unnest($1::text[]) WITH ORDINALITY session(id,ordinality)",[school.studentSessions,school.students,school.devices]);
  await admin.query("INSERT INTO teaching_sessions(id,school_id,group_id,teacher_id,start_time) SELECT id,$2,($3::text[])[ordinality::int],($4::text[])[ordinality::int],now()-interval '1 hour' FROM unnest($1::text[]) WITH ORDINALITY session(id,ordinality)",[school.teachingSessions,school.id,school.groups,school.teachers]);
  await admin.query("INSERT INTO classpilot_session_students(school_id,teaching_session_id,group_id,student_id,captured_at) SELECT $1,($2::text[])[((ordinality-1)/5)::int+1],($3::text[])[((ordinality-1)/5)::int+1],id,now()-interval '1 hour' FROM unnest($4::text[]) WITH ORDINALITY student(id,ordinality)",[school.id,school.teachingSessions,school.groups,school.students]);
  const ended=randomUUID();await admin.query("INSERT INTO teaching_sessions(id,school_id,group_id,teacher_id,start_time,end_time) VALUES($1,$2,$3,$4,now()-interval '2 days',now()-interval '47 hours')",[ended,school.id,school.groups[0],school.teachers[0]]);await admin.query('INSERT INTO classpilot_session_students(school_id,teaching_session_id,group_id,student_id,captured_at) VALUES($1,$2,$3,$4,now())',[school.id,ended,school.groups[0],school.students[0]]);
  const counts=(await admin.query('SELECT(SELECT COUNT(*)::int FROM classpilot_student_control_states WHERE school_id=$1) AS controls,(SELECT COUNT(*)::int FROM classpilot_session_staff WHERE school_id=$1) AS staff',[school.id])).rows[0];assert.deepEqual(counts,{controls:0,staff:0});
  await assert.rejects(command(school),error=>error.code==='COMMAND_ACTOR_AUTHORITY_STALE');
  result.before.push({schoolIndex:school.index,...counts,canonicalCommandRejected:'COMMAND_ACTOR_AUTHORITY_STALE'});
 }
 for(const school of schools){const prepared=await helper.prepareReleaseSchoolControls(school);const issued=await command(school);assert.equal(issued.targets.length,1);assert.equal(issued.targets[0].status,'requested');assert.equal(issued.targets[0].studentId,school.students[0]);assert.equal(issued.targets[0].studentSessionId,school.studentSessions[0]);assert.equal(issued.targets[0].deviceId,school.devices[0]);result.after.push({...prepared,exactCommandTargetAccepted:true});const foreign=await runWithTenantContext({schoolId:school.id},async()=>Number((await getTenantStore().client.query('SELECT COUNT(*)::int AS count FROM classpilot_student_control_states WHERE school_id=$1',[schools[1-school.index].id])).rows[0].count));assert.equal(foreign,0);result.foreignControlsVisible.push(foreign);}
 result.passed=true;
}finally{await helper.closeReleasePreparationPools();await admin.end();result.poolsClosed=true;writeFileSync(process.env.CONTROL_NATIVE_RESULT,JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify(result));
