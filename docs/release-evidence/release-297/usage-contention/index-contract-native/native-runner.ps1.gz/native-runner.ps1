$ErrorActionPreference='Stop'
$root='<user-home>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$container='schoolpilot-index-contract-'+$run
$db='index_contract_'+$run
$owner='index_owner_'+$run
$pass=[guid]::NewGuid().ToString('N')
$out=Join-Path $env:TEMP ('release297-index-contract-native-'+$run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $root
Copy-Item -LiteralPath (Join-Path $env:TEMP 'release297-contention-final-checks-03/unit.log') -Destination (Join-Path $out 'original-fullunit-failed-setup.log')
Copy-Item -LiteralPath (Join-Path $env:TEMP 'release297-contention-final-checks-03/result.json') -Destination (Join-Path $out 'original-fullunit-failed-setup-result.json')
foreach($n in @('DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS')){[Environment]::SetEnvironmentVariable($n,$null,'Process')}
$created=$false
try {
 $image=(docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect schoolpilot-db --format '{{.Image}}').Trim()
 if($LASTEXITCODE -ne 0){throw 'Local image inspection failed'}
 docker --host npipe:////./pipe/dockerDesktopLinuxEngine run --detach --name $container --label "codex.index-native=$run" --cpus 1 --memory 512m --publish '127.0.0.1::5432' --env "POSTGRES_DB=$db" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$pass" $image *> (Join-Path $out 'container-create.log')
 if($LASTEXITCODE -ne 0){throw 'Fixture create failed'};$created=$true
 $ready=$false
 for($i=0;$i -lt 80;$i++){docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec $container pg_isready -h 127.0.0.1 -U $owner -d $db *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250}
 if(-not $ready){throw 'Fixture not ready'}
 $binding=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .NetworkSettings.Ports}}'|ConvertFrom-Json
 $portBinding=$binding.'5432/tcp'[0]
 if($portBinding.HostIp -cne '127.0.0.1' -or $portBinding.HostPort -notmatch '^\d+$'){throw 'Nonlocal fixture binding'}
 $env:DATABASE_URL="<redacted-database-url>"
 $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL;$env:NODE_ENV='test';$env:REDIS_URL='';$env:SCHEDULER_ENABLED='false';$env:DB_POOL_PREWARM_ENABLED='false';$env:RLS_GUC_ENABLED='false'
 $env:JWT_SECRET=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
 $before=(Get-FileHash -LiteralPath tests/student-device-index-contract.test.ts -Algorithm SHA256).Hash.ToLower()
 node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/student-device-index-contract.test.ts *> (Join-Path $out 'native-test.log')
 $exit=$LASTEXITCODE
 $after=(Get-FileHash -LiteralPath tests/student-device-index-contract.test.ts -Algorithm SHA256).Hash.ToLower()
 [ordered]@{exitCode=$exit;sourceBase=(git rev-parse HEAD).Trim();testSha256Before=$before;testSha256After=$after;databaseKind='owned empty local PostgreSQL; TEMP table and index only';role='fixture owner; no RLS claim';productionMutations=0;image=$image}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'execution.json')
 Write-Output ([ordered]@{evidence=$out;exitCode=$exit}|ConvertTo-Json -Compress)
}finally{if($created){$labels=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .Config.Labels}}'|ConvertFrom-Json;if($labels.'codex.index-native' -cne $run -or $container -cne ('schoolpilot-index-contract-'+$run)){throw 'Cleanup ownership mismatch'};docker --host npipe:////./pipe/dockerDesktopLinuxEngine rm -f $container *> (Join-Path $out 'cleanup.log')}}
