import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp='C:/Users/zinka/AppData/Local/Temp';
const run=path.join(temp,'release297-recovery54-814844f3-73e1d87ed05d');
const launcher=path.join(temp,'release297-recovery54-launcher-814844f3-01');
const rehearsal=path.join(temp,'release297-source-rehearsal-814844f3-01');
const output=path.join(temp,'release297-recovery54-8148-evidence-01');
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const execution=read(path.join(run,'execution.json'));
const config=read(path.join(launcher,'final-config-02.json'));
const source='814844f344a45159152415b0fb6d7027f05b093e';
assert.equal(execution.source,source);assert.equal(execution.passed,true);assert.equal(execution.cleanupPassed,true);
assert.equal(execution.configSha256,hash(fs.readFileSync(path.join(launcher,'final-config-02.json'))));
assert.equal(execution.productionMutations,0);assert.equal(execution.capacityAccepted,false);assert.equal(execution.usageModes,'off/off');
assert.deepEqual(execution.results.map(r=>r.phase),['grant','seed','fallback','return']);
assert.equal(execution.cleanup.length,5);assert.deepEqual(execution.uncertainOwnership,[]);
const functionProof=read(path.join(run,'grant-result.json')).function;
for(const phase of execution.results){
  assert.equal(phase.attachExit,0);assert.equal(phase.daemonExit,0);assert.equal(phase.running,false);assert.equal(phase.oomKilled,false);
  const file=path.join(run,phase.phase+'-result.json'),bytes=fs.readFileSync(file),proof=read(file);
  assert.equal(hash(bytes),phase.proofSha256);assert.equal(proof.passed,true);assert.equal(proof.source,phase.source);
  assert.deepEqual(proof.function??proof.screenshotFunction,functionProof);
  assert.equal(proof.capacityAccepted,false);assert.equal(proof.productionMutations,0);
  if(phase.phase!=='grant'){assert.equal(proof.usageModes,'off/off');assert.equal(proof.inventoryCount,129);assert.equal(proof.ledgerUnchanged,true);}
  if(['fallback','return'].includes(phase.phase)){assert.equal(proof.privateEpochsAndGenerationVerified,true);assert.equal(proof.expiredReplyCount,4);assert.equal(proof.deliveredHistoryRetained,true);assert.equal(proof.focusStateVerified,true);}
}
for(const owner of execution.cleanup){assert.equal(owner.removed,true);assert.equal(owner.forced,false);assert.equal(owner.containerAbsenceConfirmed,true);for(const volume of owner.volumes)assert.equal(volume.confirmedAbsent,true);}
assert.equal(execution.cleanup.flatMap(r=>r.volumes).length,1);
assert.equal(functionProof.ledgerEntries,54);assert.equal(functionProof.publicExecute,false);assert.equal(functionProof.runtimeExecute,true);
for(const key of ['rehearsal','rehearsalCleanup','ledgerContract','schema','schemaReceipt'])assert.equal(hash(fs.readFileSync(config[key].path)),config[key].sha256);
const rehearse=read(config.rehearsal.path),schema=read(config.schemaReceipt.path),cleanup=read(config.rehearsalCleanup.path);
assert.equal(rehearse.passed,true);assert.equal(rehearse.candidateSha,source);assert.equal(rehearse.baselineMigrations,44);assert.equal(rehearse.candidateAdoptedMigrations,54);assert.equal(rehearse.retainedTenantTables,129);
for(const step of rehearse.steps)assert.equal(hash(fs.readFileSync(path.join(rehearsal,step.name))),step.sha256);
assert.equal(schema.schemaSha256,config.schema.sha256);assert.equal(schema.ledgerSha256,functionProof.ledgerSha256);assert.equal(schema.readOnly,true);
assert.equal(cleanup.containerId,schema.containerId);assert.equal(cleanup.containerAbsent,true);assert.equal(cleanup.volumesAbsent,true);assert.equal(cleanup.listingCommandsSucceeded,true);
const privateRoot=execution.privateMaterialDirectory;
const secrets=new Set();
for(const line of fs.readFileSync(path.join(privateRoot,'runtime.env'),'utf8').split(/\r?\n/)){
  const i=line.indexOf('=');if(i<0)continue;const key=line.slice(0,i),value=line.slice(i+1);
  if(/PASSWORD|SECRET|TOKEN|DATABASE_URL|REDIS_URL/.test(key)&&value.length>=8){secrets.add(value);try{const url=new URL(value);if(url.password.length>=8){secrets.add(url.password);secrets.add(decodeURIComponent(url.password));}}catch{}}
}
function sensitive(value,key=''){if(typeof value==='string'&&/token|password|secret/i.test(key)&&value.length>=8)secrets.add(value);else if(value&&typeof value==='object')for(const[k,v]of Object.entries(value))sensitive(v,k);}
function walk(directory){return fs.readdirSync(directory,{withFileTypes:true}).flatMap(entry=>{assert.equal(entry.isSymbolicLink(),false);const p=path.join(directory,entry.name);return entry.isDirectory()?walk(p):[p];});}
for(const file of walk(privateRoot).filter(p=>p.endsWith('private-state.json')))sensitive(read(file));
function scan(bytes,label){const text=bytes.toString('utf8');for(const secret of secrets)assert.equal(text.includes(secret),false,'Known private value in '+label);for(const pattern of [/AKIA[0-9A-Z]{16}/,/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,/\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\b/,/postgres(?:ql)?:\/\/[^\s'"$`{}]+:[^\s'"$`{}]+@/])assert.equal(pattern.test(text),false,'Credential pattern in '+label);}
const inputs=[];
function group(directory,prefix){for(const file of walk(directory))inputs.push({file,label:prefix+'/'+path.relative(directory,file).replaceAll('\\','/'),private:/\.(?:log|env)$/.test(file)});}
group(run,'execution');group(launcher,'launcher');group(rehearsal,'source-rehearsal');
group(privateRoot,'private');for(const input of inputs)if(input.label.startsWith('private/'))input.private=true;
for(const[name,file]of Object.entries({schema:config.schema.path,schemaReceipt:config.schemaReceipt.path,archiveScript:import.meta.filename}))inputs.push({file,label:'provenance/'+(name==='schema'?'schema.sql':name==='schemaReceipt'?'schema-receipt.json':'archive.mjs'),private:false});
for(const kind of ['candidate','fallback'])for(const key of ['preparation','scan']){const record=config[kind][key];assert.equal(hash(fs.readFileSync(record.path)),record.sha256);inputs.push({file:record.path,label:'images/'+kind+'-'+key+'.json',private:false});}
for(const input of inputs)if(!input.private)scan(fs.readFileSync(input.file),input.label);
assert.equal(fs.existsSync(output),false);fs.mkdirSync(output);
const records=[];let safeIndex=0;
for(const input of inputs){
  const raw=fs.readFileSync(input.file),rawSha256=hash(raw);
  if(input.private){records.push({logicalPath:input.label,originalPath:input.file,private:true,hashOnly:true,rawSha256,rawBytes:raw.length,reason:'Raw environment, synthetic private state or log retained externally; contents excluded from safe packet.'});continue;}
  const file=String(++safeIndex).padStart(3,'0')+'-'+path.basename(input.label)+'.gz',compressed=gzipSync(raw,{level:9});
  fs.writeFileSync(path.join(output,file),compressed,{flag:'wx'});assert.equal(hash(gunzipSync(compressed)),rawSha256);
  records.push({file,logicalPath:input.label,originalPath:input.file,originalSha256:rawSha256,rawSha256,rawBytes:raw.length,sanitizedSha256:rawSha256,sanitizedBytes:raw.length,gzipSha256:hash(compressed),sanitization:'Byte-identical, explicitly scanned; no private state or raw log included.'});
}
const summary={schemaVersion:1,source,fallbackSource:config.fallback.source,passed:true,capacityAccepted:false,productionReadiness:false,productionMutations:0,run:execution.run,startedAt:execution.startedAt,completedAt:execution.completedAt,phases:execution.results.map(({phase,source,containerId,attachExit,daemonExit,oomKilled,proofSha256})=>({phase,source,containerId,attachExit,daemonExit,oomKilled,proofSha256})),usageModes:'off/off',migrationCount:54,inventoryCount:129,functionProof,privateEpochsAndGenerationVerified:true,expiredReplyCount:4,deliveredHistoryRetained:true,focusStateVerified:true,cleanup:{containers:5,anonymousVolumes:1,allConfirmedAbsent:true,allUnforced:true,sourceRehearsalIndependentCleanup:true},schemaSha256:config.schema.sha256,sourceRehearsalSha256:config.rehearsal.sha256,limits:['Local synthetic restricted-tenant OCI bundled-function recovery, not production service traffic rollback.','Source rehearsal proves empty baseline44 to candidate54 with retained54 across fallback/reentry; behavior fixture imports that actual complete ledger into fresh schema-only state.','No browser enforcement or Redis relay exercised; existing process-local realtime capability fixture only.','Both Usage modes remain off; both images have coverage-contract1, so this does not prove below-correction aggregate recovery.','No capacity acceptance, production changes, AWS operations or registry push.']};
const json=x=>Buffer.from(JSON.stringify(x,null,2)+'\n');
fs.writeFileSync(path.join(output,'summary.json'),json(summary),{flag:'wx'});
const privacy={schemaVersion:1,passed:true,method:'Safe allowlisted source/JSON/schema only; all environment/state/raw logs hash-only. Each included uncompressed file checked for generated runtime credentials, private token values and credential patterns.',safeFiles:safeIndex,hashOnlyRecords:records.length-safeIndex,knownSecretValuesChecked:secrets.size,originalBytesUnchanged:true,primaryRepositoryWrites:false};
fs.writeFileSync(path.join(output,'privacy-review.json'),json(privacy),{flag:'wx'});
const manifest={schemaVersion:1,source,fallbackSource:config.fallback.source,passed:true,capacityAccepted:false,productionReadiness:false,sourceExecutionReceiptSha256:hash(fs.readFileSync(path.join(run,'execution.json'))),summarySha256:hash(json(summary)),privacyReviewSha256:hash(json(privacy)),records};
const manifestRaw=json(manifest);fs.writeFileSync(path.join(output,'manifest.json'),manifestRaw,{flag:'wx'});
for(const record of records.filter(r=>r.file)){const bytes=fs.readFileSync(path.join(output,record.file));assert.equal(hash(bytes),record.gzipSha256);assert.equal(hash(gunzipSync(bytes)),record.sanitizedSha256);}
console.log(JSON.stringify({output,manifestSha256:hash(manifestRaw),records:records.length,safeFiles:safeIndex,hashOnlyRecords:records.length-safeIndex,passed:true}));
