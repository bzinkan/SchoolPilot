from pathlib import Path
import json,hashlib,collections,sys
raw=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
p=json.loads((raw/'api.cpuprofile').read_text());r=json.loads((raw/'usage-scale.json').read_text())
phase=next(x for x in r['phases'] if x.get('api',{}).get('measurementStartedHrtimeMicroseconds'))
lo=phase['api']['measurementStartedHrtimeMicroseconds'];hi=phase['api']['snapshotHrtimeMicroseconds']
assert p['startTime']<=lo<hi<=p['endTime']
n={x['id']:x for x in p['nodes']};parent={c:x['id'] for x in p['nodes'] for c in x.get('children',[])}
def key(id):
 f=n[id]['callFrame'];return (f['functionName'] or '(anonymous)',f['url'].replace('file://',''),f['lineNumber']+1)
def group(k):
 name,url,line=k
 if name=='(garbage collector)':return 'gc'
 if name=='(idle)':return 'idle'
 if name in ['(program)','(root)']:return 'v8-program-root'
 if '/drizzle-orm/' in url:return 'drizzle'
 if any('/node_modules/'+s+'/' in url for s in ['pg','pg-pool','pg-protocol','pg-types','postgres-array','pg-int8','postgres-date','postgres-interval']):return 'pg-driver'
 if 'crypto' in url or '/node_modules/jsonwebtoken/' in url or '/node_modules/jws/' in url or '/node_modules/jwa/' in url:return 'crypto-jwt'
 if '/app/dist/' in url:return 'application'
 if '/diagnostic/' in url or '/prototype/' in url:return 'diagnostic'
 if '/node_modules/' in url:return 'other-dependencies'
 if url.startswith('node:') or url.startswith('internal/'):return 'node-runtime'
 return 'native-other'
def rows(c,pred=lambda k:True,limit=35):return [{'function':k[0],'url':k[1],'line':k[2],'sampledMs':v/1000}for k,v in c.most_common()if pred(k)][:limit]
def analyze(low,high):
 ex=collections.Counter();inc=collections.Counter();groups=collections.Counter();anc=collections.Counter();t=p['startTime'];latest=t;anomalies=[];overlap=0;samples=0
 for index,(id,dt)in enumerate(zip(p['samples'],p['timeDeltas'])):
  end=t+dt;start=max(t,latest)
  if dt<0:anomalies.append({'index':index,'microseconds':dt})
  elif start>t:overlap+=max(0,min(end,latest)-t)
  w=max(0,min(end,high)-max(start,low));latest=max(latest,end);t=end
  if not w:continue
  samples+=1;k=key(id);ex[k]+=w;groups[group(k)]+=w;stack=[];seen=set();at=id
  while at:
   f=key(at);stack.append(f)
   if f not in seen:inc[f]+=w;seen.add(f)
   at=parent.get(at)
  for family,match in [('drizzle-construction',lambda f:'/drizzle-orm/' in f[1] and f[0] in ['buildQueryFromSourceParams','buildSelectQuery','sqlToQuery','orderSelectedFields','prepareFields','_prepare']),('drizzle-decoding',lambda f:'/drizzle-orm/' in f[1] and f[0]=='mapResultRow')]:
   if any(match(f)for f in stack):anc[(family,next((f for f in stack if '/app/dist/' in f[1]),None))]+=w
 return {'window':{'start':low,'end':high,'wallMs':(high-low)/1000,'weightedSampledMs':sum(groups.values())/1000,'selectedSamples':samples},'timeDeltaAnomalies':anomalies,'overlapMicrosecondsExcluded':overlap,'exclusiveGroupsMs':{k:v/1000 for k,v in groups.most_common()},'exclusiveGroupsPercent':{k:100*v/sum(groups.values())for k,v in groups.most_common()},'topExclusive':rows(ex),'applicationExclusive':rows(ex,lambda k:group(k)=='application'),'applicationInclusive':rows(inc,lambda k:group(k)=='application'),'drizzleExclusive':rows(ex,lambda k:group(k)=='drizzle'),'drizzleInclusive':rows(inc,lambda k:group(k)=='drizzle'),'pgExclusive':rows(ex,lambda k:group(k)=='pg-driver'),'cryptoExclusive':rows(ex,lambda k:group(k)=='crypto-jwt'),'rowDecodeInclusive':rows(inc,lambda k:k[0]in['mapResultRow','mapFromDriverValue','parseRow','parseDataRowMessage']),'constructionOrDecodeApplicationAncestors':[{'family':k[0],'nearestAppFrame':k[1],'sampledMs':v/1000}for k,v in anc.most_common()][:40]}
result={'source':r.get('sourceRevision'),'profileSha256':hashlib.sha256((raw/'api.cpuprofile').read_bytes()).hexdigest(),'metricsSha256':hashlib.sha256((raw/'usage-scale.json').read_bytes()).hexdigest(),'phase':analyze(lo,hi),'wholeProcess':analyze(p['startTime'],p['endTime']),'limitations':['Exclusive categories partition sampled wall intervals, not process CPU time.','Inclusive stacks overlap; never sum them as disjoint costs.','Negative deltas retained on raw cursor; interval-union clipping excludes repeated wall intervals.','Async continuations may omit originating application/query frames.','Profiler overhead is not isolated by this run. No capacity acceptance.']}
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':result['source'],'profileSha256':result['profileSha256'],'phase':result['phase']['window'],'groupsMs':result['phase']['exclusiveGroupsMs'],'groupsPercent':result['phase']['exclusiveGroupsPercent'],'wholeWallMs':result['wholeProcess']['window']['wallMs']},indent=2))
