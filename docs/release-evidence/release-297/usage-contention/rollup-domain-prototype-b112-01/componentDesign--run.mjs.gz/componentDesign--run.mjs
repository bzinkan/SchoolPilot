import assert from 'node:assert/strict';
import { readFileSync,writeFileSync,mkdirSync,existsSync } from 'node:fs';
import { resolve,join,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { randomBytes,createHash } from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),handoffDir=resolve(process.argv[2]);
const read=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,'')),sha=b=>createHash('sha256').update(b).digest('hex');
const readyBytes=readFileSync(join(handoffDir,'ready.json')),ready=JSON.parse(readyBytes);
assert.equal(ready.source,'b11202fc305198d76e73c5e6d711b7dc9ed2d938');assert.equal(ready.restorationPassed,true);assert.equal(ready.allValidationClientsClosed,true);assert.equal(ready.otherClientsBeforeHandoff,0);assert.ok(Date.now()<Date.parse(ready.expiresAt));
assert.equal(ready.snapshotManifestSha256,'f66cddd44109c105aa9cb43cf16f493f3777a6c1d1f5c6c1def70a0a4802d749');
const config=read(ready.privateConfigurationFile),snapshot=read(join(config.snapshotDirectory,'manifest.json'));assert.equal(sha(readFileSync(join(config.snapshotDirectory,'manifest.json'))),ready.snapshotManifestSha256);assert.equal(snapshot.source,ready.source);
const input=join(config.snapshotDirectory,'cold-fixture-state.json'),bound=snapshot.records.find(r=>r.file==='cold-fixture-state.json');assert.equal(sha(readFileSync(input)),bound.sha256);
const artifact=read('<USER>/.codex/artifacts/release297-candidate-b11202fc-01/candidate-preparation.json');assert.equal(artifact.source,ready.source);assert.equal(artifact.passed,true);
const image=artifact.image.imageId,run=randomBytes(6).toString('hex'),name='schoolpilot-domain-map-'+run;
const temp='<TEMP>',out=join(temp,'release297-b112-domain-map-'+run),privateDir=join(temp,'release297-b112-domain-map-private-'+run);mkdirSync(out);mkdirSync(privateDir);
const env={...process.env};for(const k of Object.keys(env))if(/^DOCKER_|^BUILDX_BUILDER$/.test(k))delete env[k];
const docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe',endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
function command(args,{timeout=30000,log,allowFailure=false}={}){const r=spawnSync(docker,['--host',endpoint,...args],{env,encoding:'utf8',windowsHide:true,timeout,maxBuffer:8*1024*1024});if(log)writeFileSync(join(out,log),(r.stdout??'')+'\n'+(r.stderr??''));if(!allowFailure){assert.equal(r.error,undefined);assert.equal(r.status,0,'Docker operation failed: '+args[0]);}return r;}
function inspect(id){const r=command(['inspect',id],{allowFailure:true});assert.equal(r.error,undefined);if(r.status===0)return JSON.parse(r.stdout)[0];assert.match(r.stderr??'',/No such (object|container)/);return null;}
function verify(row,id){assert.ok(row);if(id)assert.equal(row.Id,id);assert.equal(row.Name,'/'+name);assert.equal(row.Config.Labels['codex.rollup-domain-map'],run);assert.equal(row.Config.Labels['codex.rollup-source'],ready.source);assert.equal(row.Config.Image,image);assert.ok([artifact.image.indexDigest,artifact.image.platformManifestDigest,artifact.image.configDigest].includes(row.Image));assert.equal(row.HostConfig.NetworkMode,'container:'+ready.pgContainerId);assert.equal(row.HostConfig.NanoCpus,500000000);assert.equal(row.HostConfig.Memory,1073741824);assert.equal(row.HostConfig.MemorySwap,1073741824);assert.equal(row.HostConfig.ReadonlyRootfs,true);return row;}
const receipt={schemaVersion:1,run,source:ready.source,image:artifact.image,startedAt:new Date().toISOString(),restoreReadySha256:sha(readyBytes),snapshotManifestSha256:ready.snapshotManifestSha256,inputSha256:bound.sha256,probeSha256:sha(readFileSync(join(here,'probe.mjs'))),runnerSha256:sha(readFileSync(fileURLToPath(import.meta.url))),domainMapModuleSha256:sha(readFileSync(join(here,'domain-map.mjs'))),diagnosticOnly:true,capacityAccepted:false,productionMutations:0,localDockerDaemon:endpoint,roleCaps:{cpu:0.5,memoryBytes:1073741824,workerPool:5},privateMaterialExcluded:true,pgCleanupOwnedByRestoreRunner:true};
let owner,passed=false,removed=false;
try{
 const pg=inspect(ready.pgContainerId);assert.equal(pg.Name,'/'+ready.pgContainer);assert.equal(pg.Config.Labels['codex.usage-snapshot-restore'],ready.run);assert.equal(pg.Config.Image,ready.pgImage);assert.equal(pg.State.Running,true);assert.equal(pg.HostConfig.NanoCpus,4000000000);assert.equal(pg.HostConfig.Memory,4294967296);
 const url=new URL(config.appUrl);assert.equal(url.hostname,'127.0.0.1');assert.equal(url.port,'5437');assert.equal(url.username,ready.freshRole);
 const secret=randomBytes(32).toString('hex'),envFile=join(privateDir,'runtime.env');writeFileSync(envFile,`DATABASE_URL=${config.appUrl}\nDATABASE_URL_PRIVILEGED=${config.appUrl}\nSCHEDULER_ENABLED=true\nPGAPPNAME=usage_release_worker\nNODE_ENV=production\nREDIS_URL=\nJWT_SECRET=${secret}\nSESSION_SECRET=${secret}\nSTUDENT_TOKEN_SECRET=${secret}\nEXPLAIN_SOURCE=${ready.source}\n`);
 const slash=p=>p.replaceAll('\\','/');
 const args=['create','--name',name,'--label','codex.rollup-domain-map='+run,'--label','codex.rollup-source='+ready.source,'--network','container:'+ready.pgContainerId,'--cpus','0.5','--memory','1g','--memory-swap','1g','--init','--cap-drop','ALL','--security-opt','no-new-privileges','--no-healthcheck','--read-only','--tmpfs','/tmp:rw,nosuid,noexec,size=32m','--env-file',envFile,'--mount','type=bind,source='+slash(join(here,'probe.mjs'))+',target=/probe.mjs,readonly','--mount','type=bind,source='+slash(join(here,'domain-map.mjs'))+',target=/domain-map.mjs,readonly','--mount','type=bind,source='+slash(input)+',target=/input/cold-fixture-state.json,readonly','--mount','type=bind,source='+slash(out)+',target=/out','--mount','type=bind,source='+slash(privateDir)+',target=/private','--entrypoint','node',image,'/probe.mjs'];
 const created=command(args,{allowFailure:true,log:'create.log'});const found=inspect(name);if(found){verify(found);owner=found.Id;}assert.equal(created.error,undefined);assert.equal(created.status,0);assert.ok(owner);
 const started=command(['start','--attach',owner],{timeout:100000,log:'probe.log',allowFailure:true});const ended=verify(inspect(owner),owner);receipt.exit={attachExit:started.status,daemonExit:ended.State.ExitCode,running:ended.State.Running,oomKilled:ended.State.OOMKilled};
 assert.equal(started.error,undefined);assert.equal(started.status,0);assert.equal(ended.State.Running,false);assert.equal(ended.State.ExitCode,0);assert.equal(ended.State.OOMKilled,false);
 const result=read(join(out,'result.json'));assert.equal(result.passed,true);assert.equal(result.poolCleanup,true);assert.equal(result.source,ready.source);receipt.resultSha256=sha(readFileSync(join(out,'result.json')));passed=true;
}catch(error){receipt.failure={name:error.name,code:error.code,message:String(error.message).slice(0,300)};process.exitCode=1;}
finally{
 try{if(owner){const row=verify(inspect(owner),owner);receipt.forcedCleanup=row.State.Running;command(['rm','--force','--volumes',owner],{log:'remove.log'});const absent=command(['container','ls','--all','--no-trunc','--format','{{.ID}}','--filter','id='+owner]);assert.equal(absent.stdout.trim(),'');removed=true;receipt.containerRemoved=true;receipt.absenceQueryExit=absent.status;}else receipt.containerCreationUnconfirmed=true;}catch(error){receipt.cleanupError=error.name;passed=false;process.exitCode=1;}
 receipt.containerId=owner??null;receipt.passed=passed;receipt.completedAt=new Date().toISOString();writeFileSync(join(out,'execution.json'),JSON.stringify(receipt,null,2)+'\n');
 // On a failed probe, role removal ends all of its processes/sockets. The
 // restore owner still removes PostgreSQL; no capacity reuse is permitted.
 if(removed){const completion={schemaVersion:1,run:ready.run,nonce:ready.nonce,clientsClosed:true,probePassed:passed,probeExecutionSha256:sha(readFileSync(join(out,'execution.json'))),roleContainerRemoved:true,fixtureConsumed:true};writeFileSync(join(handoffDir,'handoff-complete.json'),JSON.stringify(completion,null,2)+'\n',{flag:'wx'});}
 console.log(JSON.stringify({out,passed,containerRemoved:removed,failure:receipt.failure}));
}
