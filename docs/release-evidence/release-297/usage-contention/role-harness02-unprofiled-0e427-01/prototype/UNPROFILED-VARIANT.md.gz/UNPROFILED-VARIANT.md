# Harness02-derived unprofiled ingest variant

Only runtime change from the frozen harness02 manifest841173fe…0413: role-environment.mjs now requires an explicit supported phase(combined or ingest) and explicit CPU mode(true or false). It preserves requested ingest when CPU=false instead of incorrectly coercing that request to combined. Profiled mode still requires ingest and diagnostic=true. Unknown/missing modes fail closed.

The new closed runner/profile refuse CPU profiling. Actual role plans are tested to contain no --cpu-prof flags and no writable profile-file mount. API1CPU/2GiB, worker0.5CPU/1GiB, generator2CPU/1GiB, coordinator0.5CPU/1GiB and pool16/2/5/observer2 remain unchanged. Every numeric workload/deadline/lateness rule remains source-bound. Historical harness02 and raw results are untouched.

Focused red proof on unchanged harness02 behavior:1pass/2fail. Green variant plus full existing pure adapter/orchestrator tests:39pass/0fail/0skip. The old environment unit fixture gains explicit historical combined/CPU=false settings; other assertions are retained. This proof is not a new runtime or capacity claim. Existing native harness02 startup/exit containment proofs remain historical; new exact helper/runtime verification is required before use.
