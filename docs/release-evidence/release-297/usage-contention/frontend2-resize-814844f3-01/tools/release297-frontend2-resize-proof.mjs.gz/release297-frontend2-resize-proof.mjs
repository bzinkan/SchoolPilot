import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const [mode]=process.argv.slice(2);assert.ok(['red','green'].includes(mode));
const root='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/schoolpilot-app';
const out='<TEMP>/release297-frontend2-resize-proof-01';
if(!existsSync(out))mkdirSync(out);
const source=readFileSync(join(root,'scripts/classpilot-messages-roster-browser.test.mjs'),'utf8');
let transformed=source.replace("from 'playwright';",`from '${pathToFileURL(join(root,'node_modules/playwright/index.mjs')).href}';`)
  .replace("from 'vite';",`from '${pathToFileURL(join(root,'node_modules/vite/dist/node/index.js')).href}';`)
  .replace("const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');",`const APP_ROOT = ${JSON.stringify(root)};`);
const needle='  await page.clock.install({ time: new Date(ROSTER_CLOCK) });';assert.equal(transformed.split(needle).length,2);
const injection=`
  // External causal model only: defer the native resize notification, leaving
  // application code and its eventual real resize-handler execution unchanged.
  await page.addInitScript(() => {
    window.__releaseResizeProof = { deferred: 0, delivered: 0 };
    window.addEventListener('resize', event => {
      if (!event.isTrusted || window.innerWidth !== 600) return;
      event.stopImmediatePropagation();
      window.__releaseResizeProof.deferred += 1;
      setTimeout(() => {
        window.__releaseResizeProof.delivered += 1;
        window.dispatchEvent(new Event('resize'));
      }, 750);
    }, { capture: true });
  });`;
transformed=transformed.replace(needle,needle+injection);
const assertion="  assert.equal(await page.getByTestId('chat-conversations').count(), 0, 'the thread replaces the list');";
assert.equal(transformed.split(assertion).length,2);
transformed=transformed.replace(assertion,"  console.log('controlled-resize-proof', JSON.stringify(await page.evaluate(() => ({ ...window.__releaseResizeProof, width: window.innerWidth }))));\n"+assertion);
const file=join(out,`${mode}.test.mjs`);writeFileSync(file,transformed,{flag:'wx'});
const startedAt=new Date().toISOString();
const result=spawnSync(process.execPath,['--test','--test-name-pattern=a switch turned off elsewhere',file],{cwd:root,windowsHide:true,timeout:150000,encoding:'utf8',maxBuffer:8*1024**2});
writeFileSync(join(out,`${mode}.log`),result.stdout+'\n'+result.stderr,{flag:'wx'});
const sha=x=>createHash('sha256').update(x).digest('hex');
const receipt={schemaVersion:1,mode,startedAt,finishedAt:new Date().toISOString(),sourceSha256:sha(source),transformedSha256:sha(transformed),
  delayMs:750,controlledEventDeliveryOnly:true,applicationEdited:false,exitCode:result.status,signal:result.signal,error:result.error?.message??null,
  reproducedExpectedAssertion:result.stdout.includes('the thread replaces the list')&&result.stdout.includes('1 !== 0'),
  stdoutSha256:sha(result.stdout),stderrSha256:sha(result.stderr)};
writeFileSync(join(out,`${mode}.json`),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
assert.equal(result.status,mode==='red'?1:0);
if(mode==='red')assert.equal(receipt.reproducedExpectedAssertion,true);
