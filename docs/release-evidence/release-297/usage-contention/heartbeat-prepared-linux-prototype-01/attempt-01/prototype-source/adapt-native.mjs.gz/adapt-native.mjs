import fs from 'node:fs';
const dir=process.env.TEMP+'/release297-owned-pg-linux-prototype-01';let s=fs.readFileSync(dir+'/native-proof.mjs','utf8');
s=s.replace("import {builders,rawBuilders,factories,dialect,orm,repo}","import {builders,rawBuilders,factories,dialect,orm,repo,sourceRepo}");
s=s.replace("const {sql}=orm;","import {waitForTimingRelease,resourceSnapshot} from './timing-gate.mjs';\nconst {sql}=orm;");
s=s.replace('timeout:180000','timeout:1200000');
s=s.replace("assert.deepEqual(f,c,label);assert.deepEqual(d,c,label);","assert.deepEqual(f,c,label);assert.deepEqual(d,c,label);assert.deepEqual(await read(label,a.values,'cached'),c,label);");
s=s.replace("assert.deepEqual(d,c);assert.notEqual(d,c);","assert.deepEqual(d,c);assert.deepEqual(await read(label,a.values,'cached'),c);assert.notEqual(d,c);");
s=s.replace("assert.equal((await read('live_binding',b.values)).length,1);","assert.equal((await read('live_binding',b.values)).length,1);for(const label of ['locked_school','locked_license','screenshot_session','screenshot_control','screenshot_candidate'])assert.deepEqual(await read(label,b.values,'cached'),await read(label,b.values,'canonical'));");
const insertion=`
  await t.test('cached SELECT uses exact unnamed pg config and original mappers with fresh params',async()=>scoped(a.school.id,()=>enter(async({read,client})=>{
   const original=client.query,captured=[];
   client.query=function(config,values,...args){if(typeof config==='object'&&config.text&&config.name==='')captured.push({text:config.text,name:config.name,values:[...values],rowMode:config.rowMode});return original.call(this,config,values,...args);};
   try{for(const label of ['locked_school','locked_license','screenshot_session','screenshot_control','screenshot_candidate']){const c=await read(label,a.values,'canonical');const before=captured.length;const d=await read(label,a.values,'cached');assert.deepEqual(d,c);assert.equal(captured.length,before+1);const call=captured.at(-1),expected=builders[label](new (await mod('node_modules/drizzle-orm/pg-core/index.js')).QueryBuilder(),a.values).toSQL();assert.equal(call.text,expected.sql);assert.deepEqual(call.values,expected.params);assert.equal(call.name,'');assert.equal(call.rowMode,'array');}}finally{client.query=original;}
  })));
  await t.test('cached SELECT sees same-transaction type DDL and no persistent named-plan state',async()=>{
   await scoped(a.school.id,async()=>{
    await assert.rejects(enter(async({read,tx})=>{await read('screenshot_session',a.values,'cached');await tx.execute(sql.raw("ALTER TABLE student_sessions ALTER COLUMN started_at TYPE timestamptz USING started_at AT TIME ZONE 'UTC'"));assert.deepEqual(await read('screenshot_session',a.values,'cached'),await read('screenshot_session',a.values,'canonical'));throw Error('expected_ddl_rollback');}),/expected_ddl_rollback/);
    await enter(async({read})=>assert.deepEqual(await read('screenshot_session',a.values,'cached'),await read('screenshot_session',a.values,'canonical')));
   });
  });
  await t.test('early unawaited cached read failure is sticky and cannot COMMIT',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore(),original=store.client.query;let committed=false;
   store.client.query=function(config,...args){const text=typeof config==='string'?config:config.text;if(/^commit$/i.test(text))committed=true;if(config?.name===''&&text.includes('student_sessions'))return Promise.reject(Error('injected_cached_read_failure'));return original.call(this,config,...args);};
   try{await assert.rejects(enter(async({read})=>{void read('screenshot_session',a.values,'cached');await new Promise(r=>setImmediate(r));}),/injected_cached_read_failure/);assert.equal(committed,false);}finally{store.client.query=original;}
  }));
`;
s=s.replace('  // CPU/wall experiment',insertion+'  await waitForTimingRelease();\n  const resourceBefore=resourceSnapshot();\n  // CPU/wall experiment');
s=s.replace("const benchmark=[],perShape=[];", "const benchmark=[];");
s=s.replace("['canonical','flat','direct']", "['canonical','flat','direct','cached']");
s=s.replace("['direct','flat','canonical']:['canonical','flat','direct']", "['cached','direct','flat','canonical']:['canonical','flat','direct','cached']");
s=s.replace('n<100;n++','n<1000;n++');s=s.replace('iterations:100,queries:100*eligibleOrder.length','iterations:1000,queries:1000*eligibleOrder.length');
const begin=s.indexOf('   for(let round=0;round<3;round++)for(const label of');const end=s.indexOf('\n  }));',begin);s=s.slice(0,begin)+s.slice(end);
s=s.replace('benchmark,perShape,','benchmark,resourceBefore,resourceAfter:resourceSnapshot(),');
s=s.replace("readFileSync(repo+'/'+file)","readFileSync((file.startsWith('src/')?sourceRepo:repo)+'/'+file)");
s=s.replace("'No named prepared plans or custom DDL retry; direct unnamed query only.'", "'No named prepared plans or custom DDL retry. Cached mode uses five public Drizzle prepare-empty-name SELECTs and canonical raw fences; direct and flat retain their existing explicit decoder proof.'");
fs.writeFileSync(dir+'/native-proof.mjs',s);
