import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {SOURCE,FALLBACK,CLONE,artifact,record,json,sha,validateConfig} from './binding.mjs';
const here=dirname(fileURLToPath(import.meta.url));
const [candidatePreparation,rehearsalDirectory,schemaPath,schemaReceipt,output]=process.argv.slice(2);
assert.ok(candidatePreparation&&rehearsalDirectory&&schemaPath&&schemaReceipt&&output,'Usage: node bind-config.mjs <actual candidate-preparation.json> <passed source-rehearsal54 directory> <actual54 schema.sql> <schema-receipt.json> <new final-config.json>');
const rehearsalPath=join(resolve(rehearsalDirectory),'rehearsal.json');
const config={schemaVersion:1,executeMode:'local-synthetic-recovery54',source:SOURCE,cleanClone:CLONE,createdAt:new Date().toISOString(),
 candidate:artifact(candidatePreparation,SOURCE),fallback:artifact('C:/Users/zinka/.codex/artifacts/release297-compatible-rollback-6e251f2d-01/candidate-preparation.json',FALLBACK),
 rehearsal:record(rehearsalPath),rehearsalCleanup:record(join(resolve(rehearsalDirectory),'independent-cleanup.json')),
 ledgerContract:record(join(resolve(rehearsalDirectory),'candidate-after-rollback-contract.json')),
 schema:record(schemaPath),schemaReceipt:record(schemaReceipt),schemaSource:SOURCE,postgresImage:json(rehearsalPath).postgresImageId,
 packageLockSha256:sha(readFileSync(join(CLONE,'package-lock.json'))),capacityAccepted:false,productionMutations:0,
 files:['binding.mjs','function-retention.mjs','grant.mjs','probe.mjs','run.mjs'].map(name=>({name,sha256:sha(readFileSync(join(here,name)))}))};
validateConfig(config,here);writeFileSync(resolve(output),JSON.stringify(config,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({config:resolve(output),sha256:sha(readFileSync(resolve(output))),state:'bound; not executed',source:SOURCE}));
