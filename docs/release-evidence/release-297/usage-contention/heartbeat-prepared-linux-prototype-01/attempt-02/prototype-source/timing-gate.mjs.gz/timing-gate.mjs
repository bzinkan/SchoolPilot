import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
export function resourceSnapshot(){const result={at:new Date().toISOString(),cpuUsage:process.cpuUsage(),memory:process.memoryUsage()};for(const name of ['cpu.max','cpu.stat','memory.max','memory.current','memory.peak','memory.events','memory.swap.max'])result[name]=readFileSync('/sys/fs/cgroup/'+name,'utf8').trim();return result;}
export async function waitForTimingRelease(){
 const plan=JSON.parse(readFileSync('/control/plan.json','utf8'));
 const ready={schemaVersion:1,run:plan.run,nonce:plan.nonce,source:plan.source,image:plan.image,prototypeSha256:plan.prototypeSha256,phase:'native-parity-passed-timing-held',resource:resourceSnapshot(),at:new Date().toISOString(),capacityAccepted:false};
 writeFileSync('/evidence/ready.json',JSON.stringify(ready,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({event:'timing-held',run:plan.run,at:ready.at}));
 const deadline=performance.now()+600000;
 while(!existsSync('/control/release.json')){assert.ok(performance.now()<deadline,'Root timing gate expired');await new Promise(r=>setTimeout(r,250));}
 const release=JSON.parse(readFileSync('/control/release.json','utf8'));
 for(const key of ['run','nonce','source','image','prototypeSha256'])assert.equal(release[key],plan[key],'Release binding mismatch '+key);
 assert.equal(release.authorized,true);assert.equal(release.phase,'eligible-eight-read-microproof');
 writeFileSync('/evidence/release-observed.json',JSON.stringify({...release,observedAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({event:'timing-start',run:plan.run,at:new Date().toISOString()}));
}
