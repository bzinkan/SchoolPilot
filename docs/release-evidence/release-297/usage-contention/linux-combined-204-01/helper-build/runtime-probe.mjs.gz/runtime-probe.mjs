import assert from 'node:assert/strict';
import {realpathSync,readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
import {assertRuntime} from '/prototype-tools/verify-runtime.mjs';
const runtime=assertRuntime('/prototype-tools/base-runtime.json');
assert.equal(process.cwd(),'/app');
for(const name of ['dist','node_modules','package.json'])assert.equal(realpathSync('/diagnostic/'+name),'/app/'+name);
const require=createRequire('/diagnostic/package.json');
assert.ok(require.resolve('pg').startsWith('/app/node_modules/'));
assert.ok(require.resolve('bcryptjs').startsWith('/app/node_modules/'));
const profile=await import('/diagnostic/scripts/load/usage/release-enabled-profile.mjs');
assert.deepEqual(profile.releaseTrafficOptions({USAGE_RELEASE_LINUX_DIAGNOSTIC:'true',USAGE_RELEASE_DIAGNOSTIC:'true',USAGE_RELEASE_CPU_PROFILE:'false',USAGE_RELEASE_PHASE:'combined'}),{});
assert.equal(profile.RELEASE_ENABLED_PROFILE.httpOffering.requestsPerSecond*profile.RELEASE_ENABLED_PROFILE.httpOffering.durationMs/1000,6000);
assert.equal(profile.RELEASE_ENABLED_PROFILE.reportOffers.total,64);
assert.equal(profile.capacityAcceptance({diagnosticOnly:true}).acceptanceRun,false);
for(const name of ['release-enabled-scale.mjs','release-enabled-process.mjs','release-enabled-generator.mjs'])execFileSync(process.execPath,['--check','/diagnostic/scripts/load/usage/'+name],{stdio:'pipe'});
const binding=JSON.parse(readFileSync('/diagnostic/binding.json','utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const name of ['release-enabled-process.mjs','release-enabled-generator.mjs'])
  assert.equal(sha(readFileSync('/diagnostic/scripts/load/usage/'+name)),sha(readFileSync('/source/scripts/load/usage/'+name)));
for(const name of ['sql-shape-diagnostics.mjs','sql-shape-integration.mjs'])assert.equal(existsSync('/diagnostic/scripts/load/usage/'+name),false);
console.log(JSON.stringify({passed:true,applicationSource:binding.applicationSource,candidateImageId:binding.candidateImageId,
  runtime,sourceClean:true,sourceRoot:'/source',runtimeRoot:'/app',harnessRoot:'/diagnostic',forkCwd:'/app',
  expectedHeartbeatOffers:6000,expectedReports:64,profile:profile.RELEASE_ENABLED_PROFILE.name,
  apiAndGeneratorMatchSource:true,sqlShapeInstrumentationPresent:false,collectApiCpuProfile:false,
  diagnosticOnly:true,capacityAccepted:false,databaseConnections:0,apiProcessesStarted:0},null,2));
