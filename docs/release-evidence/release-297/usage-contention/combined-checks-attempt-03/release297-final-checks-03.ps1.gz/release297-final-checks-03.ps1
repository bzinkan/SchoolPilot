$ErrorActionPreference = 'Stop'
$repository = '<USER_HOME>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$output = '<USER_HOME>\AppData\Local\Temp\release297-contention-final-checks-03'
if (Test-Path -LiteralPath $output) { throw 'Evidence directory already exists' }
New-Item -ItemType Directory -Path $output | Out-Null
Set-Location -LiteralPath $repository
$env:NODE_ENV = 'test'
$env:SCHEDULER_ENABLED = 'false'
$env:REDIS_URL = ''
$env:DATABASE_URL = <REDACTED_SYNTHETIC_VALUE>
$env:JWT_SECRET = <REDACTED_SYNTHETIC_VALUE>
$env:SESSION_SECRET = <REDACTED_SYNTHETIC_VALUE>
$env:STUDENT_TOKEN_SECRET = <REDACTED_SYNTHETIC_VALUE>
$env:DOTENV_CONFIG_PATH = Join-Path $output 'absent-dotenv'
$env:DOTENV_CONFIG_QUIET = 'true'
$names = @(git ls-files --cached --others --exclude-standard -- src tests scripts package.json package-lock.json tsconfig.json | Sort-Object -Unique)
function Snapshot {
  @($names | ForEach-Object { [ordered]@{ path=$_; sha256=(Get-FileHash -LiteralPath (Join-Path $repository $_) -Algorithm SHA256).Hash.ToLower() } })
}
$before = Snapshot
$before | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-before.json')
$result = [ordered]@{ sourceHead=(git rev-parse HEAD).Trim(); startedAt=[DateTime]::UtcNow.ToString('o'); output=$output; commands=@() }
function Run-Check {
  param([string]$Name,[string[]]$Arguments)
  $start = [DateTime]::UtcNow.ToString('o')
  & npm.cmd @Arguments *> (Join-Path $output ($Name+'.log'))
  $code=$LASTEXITCODE
  $script:result.commands += [ordered]@{name=$Name; arguments=$Arguments; exitCode=$code; startedAt=$start; finishedAt=[DateTime]::UtcNow.ToString('o')}
  Write-Output ($Name+': '+$code)
  return $code
}
$install = Run-Check 'clean-install' @('ci','--no-audit','--no-fund')
if ($install[-1] -eq 0) {
  $build = Run-Check 'build' @('run','build')
  if ($build[-1] -eq 0) {
    $null = Run-Check 'test-types' @('run','check:tests')
    $null = Run-Check 'test-casts' @('run','check:test-casts')
    $null = Run-Check 'unit' @('run','test:unit')
  }
  $null = Run-Check 'production-audit' @('audit','--omit=dev','--audit-level=high','--json')
  $null = Run-Check 'full-audit' @('audit','--audit-level=high','--json')
}
$after = Snapshot
$after | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-after.json')
$result.sourceFileCount=$before.Count
$result.sourceUnchanged=(@(Compare-Object ($before | ConvertTo-Json -Depth 6) ($after | ConvertTo-Json -Depth 6)).Count -eq 0)
$result.finishedAt=[DateTime]::UtcNow.ToString('o')
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $output 'result.json')
$result | ConvertTo-Json -Depth 8
if (-not $result.sourceUnchanged -or @($result.commands | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) { exit 1 }
