# Current-source unprofiled ingest diagnostic preparation

External variant only. Source-bound wiring tests useb6dc88c5358a5339067d0b255c9cffabfd91fc52, whose application and load code are byte-equivalent to6035239b. Parent will select the final diagnostic source after the pending Focus wire correction; no application source has been selected/built or fixture launched by this variant yet.

Use the existing supported candidate/helper preparation workflow with a fresh clean source clone, exact candidate image and provenance guards. Do not overlay current dist onto5d54 or relax the candidate source/dist/dependency checks. Cached dependency build layers are allowed and must be recorded; this is diagnostic artifact preparation, not a final release-artifact claim.

The runner is generated asrun-role-ingest-unprofiled.ps1 and is invoked with-Phase ingest -DiagnosticOnly, without-CollectApiCpuProfile. Coordinator and profile requireCPU=false. Full6000offers/100rps/60seconds/max-in-flight1000/20second request bound/100ms lateness threshold are unchanged. The full2school/2million observation fixture is prepared; reports and rollups are absent from ingest phase, so no combined acceptance claim is possible. Original generator, process code, lifecycle/preflight, readiness, pool limits, source checks, drain and cleanup are retained.

Topology: API1CPU2GiB,worker0.5CPU1GiB,driver2CPU1GiB,coordinator0.5CPU1GiB,512MiB heaps;PG4CPU4GiB,Redis1CPU256MiB;API16/session2/worker5/observer2 pools. All role containers share only the exact-ownedPG network namespace. NoCPU profiler argument or writable profile output mount. Role CPU/memory/exit receipts remain required.

All names and output directories must be fresh. Preparation stops at the original nonce/run/source/image-bound cold gate. Root alone authorizes timed release after exact runtime proof and local quiet. No automatic retry/follow-on measurement. Capacity/resource acceptance remainsfalse. New source plus omitted profiler establishes current unprofiled behavior; it is not an isolated numeric profiler-overhead comparison against5d54.
