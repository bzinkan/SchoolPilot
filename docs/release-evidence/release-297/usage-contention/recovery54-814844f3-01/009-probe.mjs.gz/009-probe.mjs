import assert from 'node:assert/strict';
import {readFunctionRetention} from '/function-retention.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
import {randomUUID,randomBytes,createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire('/app/package.json'),pg=require('pg');
const phase=process.argv[2];assert.ok(['seed','fallback','return'].includes(phase));
const sha=b=>createHash('sha256').update(b).digest('hex');
const statePath='/proof/private-state.json';
const registry=JSON.parse(readFileSync('/app/dist/config/rlsRegistry.json','utf8'));
const tables=registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables;assert.equal(tables.length,129);
Object.assign(process.env,{NODE_ENV:'test',REDIS_URL:'',SCHEDULER_ENABLED:'false',RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:tables.join(','),CLASSPILOT_USAGE_ROLLUP_MODE:'off',CLASSPILOT_DIGITAL_USAGE_MODE:'off',CLASSPILOT_PROTOCOL_V3_ENABLED:'true',CLASSPILOT_CAP_SCOPED_AUTHORITY_CHECKS_V1:'true',CLASSPILOT_CAP_STUDENT_CHAT_IDEMPOTENCY_V1:'true',CLASSPILOT_CAP_PRIVATE_CHAT_LIFECYCLE_V1:'true',CLASSPILOT_CAP_FOCUS_TAB_V1:'true',CLASSPILOT_SCHEDULED_CLASSROOM_MODE:'on'});
let state=phase==='seed'?{school:randomUUID(),teacher:randomUUID(),student:randomUUID(),device:randomUUID(),group:randomUUID()}:JSON.parse(readFileSync(statePath,'utf8'));
process.env.CLASSPILOT_CLASS_TOOLS_SCHOOLS_JSON=JSON.stringify({[state.school]:5});
const admin=new pg.Pool({connectionString:process.env.ADMIN_DATABASE_URL,max:2});
const storage=await import('/app/dist/services/storage.js'),lifecycle=await import('/app/dist/services/classpilotPrivateChatLifecycle.js');
const database=await import('/app/dist/db.js'),tenant=await import('/app/dist/middleware/tenantContext.js');
const realtime=await import('/app/dist/services/classpilotRealtimeStatus.js'),dispatcher=await import('/app/dist/services/classpilotCommandDispatcher.js');
const focus=await import('/app/dist/services/classpilotFocus.js'),modes=await import('/app/dist/config/classpilotUsageModes.js');
const under=work=>tenant.runWithTenantContext({schoolId:state.school},work);
const exact=()=>({schoolId:state.school,studentId:state.student,studentSessionId:state.session,deviceId:state.device});
const scope=()=>({schoolId:state.school,studentId:state.student,teachingSessionId:state.teaching});
const token=async()=>{const response=await under(()=>lifecycle.teacherPrivateChatLifecycles(scope()));assert.equal(response.privateChatLifecycleRequired,true);const found=response.privateChatLifecycles.find(x=>x.studentId===state.student);assert.ok(found);return found.privateChatLifecycle;};
const reply=(expected,content='Synthetic pair probe')=>under(()=>storage.createTeacherChatReplyWithDelivery({...scope(),teacherId:state.teacher,content,expectedPrivateChatLifecycle:expected}));
const ack=(id,expected)=>under(()=>storage.acknowledgeTeacherChatDelivery({...exact(),chatMessageId:id,status:'delivered',privateChatLifecycle:expected}));
const claim=()=>under(()=>storage.withClasspilotStudentControlDeliveryAuthority({...exact(),claimTeacherChatDeliveries:true},async()=>undefined,rows=>rows.map(x=>x.message.id)));
const control=()=>under(()=>storage.getClasspilotStudentControlState(state.school,state.student));
const code=expected=>error=>error?.code===expected||(error?.cause&&code(expected)(error.cause));
const capabilities=['scopedAuthorityChecksV1','studentChatIdempotencyV1','privateChatLifecycleV1','scheduledClassroomV1','focusTabV1'];
const cache=new Map();
realtime.setClasspilotRealtimeStatusCommandForTests(async args=>{if(args[0]==='MGET')return args.slice(1).map(k=>cache.get(k)??null);if(args[0]==='EVAL'&&args[3]&&args[5]?.startsWith('{')){cache.set(args[3],args[5]);return args[5];}return undefined;});
const refresh=()=>realtime.writeClasspilotRealtimeStatus({...exact(),heartbeatId:randomUUID(),observedAt:Date.now(),acceptedCapabilities:capabilities,tabSnapshotRevision:9,allOpenTabs:[{tabRef:'pair-exact-tab',url:'https://example.org/lesson',title:'Synthetic lesson'}]});
const issue=(commandType,payload,available=true)=>under(()=>dispatcher.executeClasspilotCommand({schoolId:state.school,actorId:state.teacher,teachingSessionId:state.teaching,targetScope:'students',commandType,rawCommandPayload:payload,targets:[{...exact(),studentName:'Synthetic',available,stateAuthorized:true,...(!available?{unavailableReason:'Offline synthetic fixture'}:{})}]}));
const durableSnapshot=async()=>({settings:(await admin.query('SELECT private_chat_lifecycle_required,private_chat_epoch FROM settings WHERE school_id=$1',[state.school])).rows,
 activity:(await admin.query('SELECT private_chat_epoch,chat_enabled FROM session_settings WHERE school_id=$1 AND session_id=$2',[state.school,state.teaching])).rows,
 threads:(await admin.query('SELECT id,generation,authority_assignment_id FROM classpilot_private_chat_threads WHERE school_id=$1 ORDER BY id',[state.school])).rows,
 deliveries:(await admin.query('SELECT id,state,attempt_count FROM classpilot_chat_deliveries WHERE school_id=$1 ORDER BY id',[state.school])).rows});
const verifyExpired=async({disabled=false}={})=>{
 const current=await token();assert.deepEqual(current,state.currentToken);
 for(const id of state.expiredIds){assert.equal(await under(()=>lifecycle.isPrivateChatMessageExpired(id,state.school)),true);assert.equal(await ack(id,state.messageTokens[id]),undefined);assert.equal(await under(()=>storage.classpilotTeacherChatAckRejection({schoolId:state.school,studentId:state.student,chatMessageId:id})),'PRIVATE_CHAT_EXPIRED');}
 for(const expected of Object.values(state.messageTokens))await assert.rejects(reply(expected),code(disabled?'PRIVATE_CHAT_DISABLED':'PRIVATE_CHAT_LIFECYCLE_STALE'));
 const recovered=await claim();assert.equal(recovered.authorized,true);assert.deepEqual(recovered.value,[]);
 const history=await under(()=>storage.getChatMessages(state.teaching,state.school));const projected=await under(()=>lifecycle.projectPrivateChatMessages(history));
 assert.equal(projected.find(x=>x.id===state.deliveredId)?.deliveryStatus,'delivered');for(const id of state.expiredIds)assert.equal(projected.find(x=>x.id===id)?.deliveryStatus,'expired');
};
const result={schemaVersion:1,phase,passed:false,source:process.env.PROBE_SOURCE,usageModes:'off/off',capacityAccepted:false,productionMutations:0,actualOciBundledFunctions:true,actualBrowserDelivery:false,redisRelayExercised:false,scope:'One synthetic restricted-tenant storage/cleanup pair probe. Process-local realtime capability fixture, no production records or service rollback.'};
try{
 assert.deepEqual(modes.readClasspilotUsageModes(process.env),{rollupMode:'off',digitalUsageMode:'off'});assert.equal(modes.CLASSPILOT_USAGE_COVERAGE_CONTRACT_VERSION,1);
 assert.equal(lifecycle.PRIVATE_CHAT_LIFECYCLE_WRITER_VERSION,1);assert.equal(lifecycle.PRIVATE_CHAT_BRIDGE_VERSION,1);assert.match(readFileSync('/app/dist/realtime/websocket.js','utf8'),/export const PRIVATE_CHAT_RELAY_VERSION = 1;/);
 result.inventoryCount=129;result.writerVersion=1;result.bridgeVersion=1;result.relayVersion=1;result.coverageContractVersion=1;
 assert.deepEqual((await database.pool.query('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user')).rows,[{rolsuper:false,rolbypassrls:false}]);
 const rlsProof=await admin.query("SELECT count(*)::int AS count FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname=ANY($1::text[]) AND c.relrowsecurity AND c.relforcerowsecurity",[tables]);assert.equal(rlsProof.rows[0].count,129);
 const ledgerBefore=(await admin.query('SELECT id,checksum,mode,status,application_sha FROM schema_migrations ORDER BY id')).rows;
 const functionBefore=await readFunctionRetention(database.pool);
 if(phase!=='fallback'){
  const installation=await import('/app/dist/db/classpilotHeartbeatScreenshotEvidenceInstallation.js');
  await installation.assertClasspilotHeartbeatScreenshotEvidence(database.pool);
  result.candidateRuntimeAssertion=true;
 }
 if(phase==='seed')state.screenshotFunctionRetention=functionBefore;else assert.deepEqual(functionBefore,state.screenshotFunctionRetention);
 if(phase==='seed'){
  await admin.query("INSERT INTO schools(id,name,domain,status,plan_status) VALUES($1,'Pair synthetic',$2,'active','active')",[state.school,`${state.school}.example.edu`]);
  await admin.query("INSERT INTO users(id,email,first_name,last_name) VALUES($1,$2,'Pair','Teacher')",[state.teacher,`${state.teacher}@example.edu`]);
  await admin.query("INSERT INTO school_memberships(school_id,user_id,role,status) VALUES($1,$2,'teacher','active')",[state.school,state.teacher]);
  await admin.query("INSERT INTO product_licenses(school_id,product,status) VALUES($1,'CLASSPILOT','active')",[state.school]);
  await admin.query("INSERT INTO students(id,school_id,first_name,last_name,status) VALUES($1,$2,'Pair','Student','active')",[state.student,state.school]);
  await admin.query("INSERT INTO settings(school_id,school_name,ws_shared_key,enable_tracking_hours,after_hours_mode,pause_chat_during_testing) VALUES($1,'Pair synthetic','synthetic',false,'off',false)",[state.school]);
  await under(async()=>{await storage.createDevice({schoolId:state.school,deviceId:state.device,classId:'default'});state.session=(await storage.startStudentSessionWithReplacements(state.school,state.student,state.device,{authKind:'manual_shared',sessionRecoveryTokenHash:randomBytes(32).toString('hex')})).session.id;await storage.createGroup({id:state.group,schoolId:state.school,teacherId:state.teacher,name:'Pair class',groupType:'admin_class',status:'active'});await storage.addGroupStudentsDetailed(state.group,[state.student]);state.teaching=(await storage.createTeachingSession({groupId:state.group,teacherId:state.teacher,sessionMode:'live'})).id;});
  await refresh();state.originalToken=await token();
  const delivered=await reply(state.originalToken),queued=await reply(state.originalToken),attempted=await reply(state.originalToken);
  await under(()=>storage.markTeacherChatDeliveryAttempt({...exact(),chatMessageId:delivered.message.id}));assert.ok(await ack(delivered.message.id,state.originalToken));
  await under(()=>storage.markTeacherChatDeliveryAttempt({...exact(),chatMessageId:attempted.message.id}));
  state.deliveredId=delivered.message.id;state.expiredIds=[queued.message.id,attempted.message.id];state.messageTokens=Object.fromEntries(state.expiredIds.map(id=>[id,state.originalToken]));
  const closed=await under(()=>storage.authorizeClasspilotTeacherCloseChat({...scope(),actorId:state.teacher,expectedPrivateChatLifecycle:state.originalToken}));state.currentToken=closed.privateChatLifecycle;
  assert.equal(state.currentToken.threadGeneration,state.originalToken.threadGeneration+1);assert.equal(state.currentToken.schoolEpoch,state.originalToken.schoolEpoch);assert.equal(state.currentToken.activityEpoch,state.originalToken.activityEpoch);
  await verifyExpired();
  await issue('focus-tab',{tabTargets:[{studentId:state.student,tabRef:'pair-exact-tab',observedRevision:9}]});
  const saved=await control();assert.ok(focus.readFocusAssignment(saved.desiredState));assert.equal(focus.readFocusRestriction(focus.focusRecord(saved.desiredState).restrictions)?.active,true);
  state.otherRestrictions={blockList:{active:true,blockedDomains:['blocked.example'],name:'Retained policy'},tabLimit:4};
  state.focusState={...saved.desiredState,restrictions:{...focus.focusRecord(saved.desiredState).restrictions,...state.otherRestrictions}};
  await admin.query('UPDATE classpilot_student_control_states SET desired_state=$2::jsonb WHERE id=$1',[saved.id,JSON.stringify(state.focusState)]);
  state.controlRevision=saved.revision;state.durable=await durableSnapshot();
 }else{
  await refresh();assert.deepEqual(await durableSnapshot(),state.durable);await verifyExpired();
  if(phase==='fallback'){
   const saved=await control();assert.deepEqual(saved.desiredState,state.focusState);assert.equal(saved.revision,state.controlRevision);
   process.env.CLASSPILOT_CAP_PRIVATE_CHAT_LIFECYCLE_V1='false';await assert.rejects(reply(state.currentToken),code('PRIVATE_CHAT_DISABLED'));await verifyExpired({disabled:true});process.env.CLASSPILOT_CAP_PRIVATE_CHAT_LIFECYCLE_V1='true';
   const previous=state.currentToken,schoolPending=await reply(previous);state.expiredIds.push(schoolPending.message.id);state.messageTokens[schoolPending.message.id]=previous;
   assert.equal(await under(()=>lifecycle.isPrivateChatMessageExpired(schoolPending.message.id,state.school)),false);
   await admin.query('UPDATE settings SET student_messaging_enabled=false WHERE school_id=$1',[state.school]);await admin.query('UPDATE settings SET student_messaging_enabled=false WHERE school_id=$1',[state.school]);
   const off=await token();assert.equal(off.schoolEpoch,previous.schoolEpoch+1);assert.equal(off.threadGeneration,previous.threadGeneration);assert.equal(off.activityEpoch,previous.activityEpoch);
   await admin.query('UPDATE settings SET student_messaging_enabled=true WHERE school_id=$1',[state.school]);state.currentToken=off;await verifyExpired();
   const activityPending=await reply(state.currentToken);state.expiredIds.push(activityPending.message.id);state.messageTokens[activityPending.message.id]=state.currentToken;
   assert.equal(await under(()=>lifecycle.isPrivateChatMessageExpired(activityPending.message.id,state.school)),false);
   await admin.query('UPDATE session_settings SET chat_enabled=false WHERE school_id=$1 AND session_id=$2',[state.school,state.teaching]);await admin.query('UPDATE session_settings SET chat_enabled=true WHERE school_id=$1 AND session_id=$2',[state.school,state.teaching]);
   const activityOn=await token();assert.equal(activityOn.schoolEpoch,off.schoolEpoch);assert.equal(activityOn.activityEpoch,off.activityEpoch+1);assert.equal(activityOn.threadGeneration,off.threadGeneration);state.currentToken=activityOn;await verifyExpired();
   process.env.CLASSPILOT_CAP_FOCUS_TAB_V1='false';await issue('stop-focus',{},false);
   const stopped=await control();assert.equal(focus.readFocusAssignment(stopped.desiredState),null);assert.equal(focus.readFocusRestriction(focus.focusRecord(stopped.desiredState).restrictions),null);assert.ok(stopped.desiredState.focusCleanupV1);assert.ok(stopped.revision>state.controlRevision);
   const restrictions=focus.focusRecord(stopped.desiredState).restrictions;for(const [key,value]of Object.entries(state.otherRestrictions))assert.deepEqual(restrictions[key],value);
   state.stoppedDesired=stopped.desiredState;state.stoppedRevision=stopped.revision;state.durable=await durableSnapshot();
  }else{
   const stopped=await control();assert.deepEqual(stopped.desiredState,state.stoppedDesired);assert.equal(stopped.revision,state.stoppedRevision);
   const {prepareClasspilotFocusCleanupFrame}=await import('/app/dist/services/classpilotFocusCleanup.js');
   const recovered=await under(()=>storage.withClasspilotStudentControlDeliveryAuthority(exact(),tx=>prepareClasspilotFocusCleanupFrame(tx,stopped,exact(),['scopedAuthorityChecksV1']),(_rows,frame)=>frame));
   assert.equal(recovered.authorized,true);assert.ok(recovered.value);assert.equal(recovered.value.command.type,'stop-focus');
   for(const [key,value]of Object.entries(exact()))assert.equal(recovered.value.exactBinding[key],value);assert.equal(recovered.value.exactBinding.controlRevision,stopped.revision);
  }
 }
 assert.deepEqual((await admin.query('SELECT id,checksum,mode,status,application_sha FROM schema_migrations ORDER BY id')).rows,ledgerBefore);
 assert.deepEqual(await readFunctionRetention(database.pool),state.screenshotFunctionRetention);result.screenshotFunctionRetained=true;result.screenshotFunction=state.screenshotFunctionRetention;
 result.ledgerEntries=ledgerBefore.length;result.ledgerUnchanged=true;result.privateEpochsAndGenerationVerified=true;result.expiredReplyCount=state.expiredIds.length;result.deliveredHistoryRetained=true;result.focusStateVerified=true;result.privateStateSha256=sha(Buffer.from(JSON.stringify(state)));
 result.embeddedHashes=Object.fromEntries(['services/storage.js','services/classpilotFocus.js','services/classpilotPrivateChatLifecycle.js','services/classpilotCommandDispatcher.js','services/classpilotFocusCleanup.js','config/classpilotUsageModes.js','config/rlsRegistry.json'].map(p=>[p,sha(readFileSync('/app/dist/'+p))]));
 writeFileSync(statePath,JSON.stringify(state,null,2)+'\n');result.passed=true;
}catch(error){result.failure={name:error?.name,code:error?.code,message:String(error?.message).slice(0,500)};process.exitCode=1;}
finally{
 realtime.setClasspilotRealtimeStatusCommandForTests(undefined);
 const websocket=await import('/app/dist/realtime/websocket.js');websocket.stopWebSocketWork();await websocket.drainWebSocketWork();await (await import('/app/dist/realtime/ws-redis.js')).disposeWSRedis();
 await (await import('/app/dist/services/errorMonitor.js')).default.disposeAndWait();await tenant.drainTenantContextReleases();
 const scheduler=await import('/app/dist/services/schedulerDb.js');await Promise.all([database.pool.end(),database.sessionPool.end(),scheduler.schedulerPool.end(),scheduler.schedulerLockPool.end(),admin.end()]);
 writeFileSync('/proof/'+phase+'-result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}
