import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance,PerformanceObserver} from 'node:perf_hooks';
import v8 from 'node:v8';
import * as orm from '/app/node_modules/drizzle-orm/index.js';
import {PgDialect} from '/app/node_modules/drizzle-orm/pg-core/index.js';
import * as schema from '/app/dist/schema/index.js';
import {currentStudentSessionAuthorityPredicate} from '/app/dist/services/classpilotStudentSessionAuthority.js';
import {compileFixedScalarQuery} from './fixed-scalar.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
const source=JSON.parse(readFileSync(new URL('./templates.json',import.meta.url)));
const bindings={...orm,...schema,currentStudentSessionAuthorityPredicate};
bindings.classpilotEntitledSchoolPredicate=new Function(...Object.keys(bindings),source.predicate+';return classpilotEntitledSchoolPredicate;')(...Object.values(bindings));
const builders=Object.fromEntries(Object.entries(source.compiled).map(([label,body])=>[label,new Function(...Object.keys(bindings),'return function(options){const foreground=options;'+body+'}').apply(null,Object.values(bindings))]));
const keys=['schoolId','studentId','studentSessionId','deviceId','teachingSessionId','controlRevision'];
const placeholders=Object.fromEntries(keys.map(key=>[key,orm.sql.placeholder(key)]));
const factories=Object.fromEntries(Object.entries(builders).map(([key,build])=>[key,compileFixedScalarQuery(build(placeholders))]));
const dialect=new PgDialect();
const contexts=Array.from({length:6},(_,i)=>Object.fromEntries(keys.map(key=>[key,key==='controlRevision'?[0,37,2147483647,Number.MAX_SAFE_INTEGER,null,-1][i]:i===4?null:i===3?`${key}-O'Reilly-${i}-学校-$1-\\`:`${key}-synthetic-${i}`])));
const parity=[];
for(const [label,build]of Object.entries(builders))for(const values of contexts){
 const canonical=dialect.sqlToQuery(build(values)),flat=dialect.sqlToQuery(factories[label](values));
 assert.equal(flat.sql,canonical.sql);assert.deepEqual(flat.params,canonical.params);assert.deepEqual(flat.typings,canonical.typings);
 const again=dialect.sqlToQuery(factories[label]({...values}));assert.notEqual(again.params,flat.params);assert.deepEqual(again.params,flat.params);
 parity.push({label,sqlSha256:hash(canonical.sql),parameters:canonical.params.length,sqlExact:true,paramsExact:true,typingsExact:true,freshParameterArray:true});
}
const gc=[];const observer=new PerformanceObserver(list=>{for(const entry of list.getEntries())gc.push({start:entry.startTime,duration:entry.duration,kind:entry.detail.kind});});observer.observe({entryTypes:['gc']});
const turn=()=>new Promise(resolve=>setImmediate(resolve));
const pause=async()=>{await turn();await turn();};
const methods={canonical:(label,v)=>dialect.sqlToQuery(builders[label](v)),flat:(label,v)=>dialect.sqlToQuery(factories[label](v))};
let checksum=0;const count=5000,rounds=[];
for(const label of Object.keys(builders))for(const mode of Object.keys(methods))for(let i=0;i<250;i++)checksum+=methods[mode](label,{...contexts[i%3],controlRevision:i}).params.length;
for(let round=0;round<5;round++)for(const label of Object.keys(builders))for(const mode of round%2?['flat','canonical']:['canonical','flat']){
 global.gc();await pause();const before=v8.getHeapStatistics(),cpu=process.cpuUsage(),start=performance.now();
 for(let i=0;i<count;i++)checksum+=methods[mode](label,{...contexts[i%3],controlRevision:i}).params.length;
 const end=performance.now(),used=process.cpuUsage(cpu),after=v8.getHeapStatistics();await pause();const entries=gc.filter(x=>x.start>=start&&x.start<end);
 global.gc();await pause();const retained=v8.getHeapStatistics();
 rounds.push({round,label,mode,iterations:count,elapsedMs:end-start,cpuMicroseconds:used,heapUsedBefore:before.used_heap_size,heapUsedAfter:after.used_heap_size,heapUsedAfterForcedGc:retained.used_heap_size,gcCount:entries.length,gcDurationMs:entries.reduce((n,x)=>n+x.duration,0),gcKinds:entries.map(x=>x.kind)});
}
observer.disconnect();
const median=xs=>xs.toSorted((a,b)=>a-b)[Math.floor(xs.length/2)];
const summary=Object.fromEntries(Object.keys(builders).map(label=>[label,Object.fromEntries(Object.keys(methods).map(mode=>{const rows=rounds.filter(x=>x.label===label&&x.mode===mode);return[mode,{medianMsPer1000:median(rows.map(x=>x.elapsedMs))/5,medianCpuMsPer1000:median(rows.map(x=>(x.cpuMicroseconds.user+x.cpuMicroseconds.system)/1000))/5,minMsPer1000:Math.min(...rows.map(x=>x.elapsedMs))/5,maxMsPer1000:Math.max(...rows.map(x=>x.elapsedMs))/5,totalObservedGcMs:rows.reduce((n,x)=>n+x.gcDurationMs,0),totalObservedGcCount:rows.reduce((n,x)=>n+x.gcCount,0),medianHeapUsedGrowth:median(rows.map(x=>x.heapUsedAfter-x.heapUsedBefore))}];}))]));
const result={source:source.source,node:process.version,v8:process.versions.v8,execArgv:process.execArgv,heapLimitBytes:v8.getHeapStatistics().heap_size_limit,realDatabaseCalls:0,capacityAccepted:false,parity,rounds,summary,checksum,templateSha256:hash(readFileSync(new URL('./templates.json',import.meta.url))),helperSha256:hash(readFileSync(new URL('./fixed-scalar.mjs',import.meta.url))),limitations:['Compile-only public PgDialect/SQL APIs; no actual pg/client/query execution or authority result reused.','Exact SQL/ordered params/typings checked against current canonical source for each synthetic tuple and null/boundary revision.','gc() occurs only outside timed rounds to equalize starting live heap. GC observation may lag; rows retain observed start times.','Heap growth is net used heap, not total allocated bytes; GC entries are observed pauses, not a lifetime allocation counter.','Microbenchmark is not capacity evidence and does not include required executor ownership guards, PostgreSQL, transport or full route work.','No change to production source, SQL, lock or transaction order; no additional query removed.']};
writeFileSync('/result/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({parity:parity.length,summary,realDatabaseCalls:0,capacityAccepted:false})+'\n');
