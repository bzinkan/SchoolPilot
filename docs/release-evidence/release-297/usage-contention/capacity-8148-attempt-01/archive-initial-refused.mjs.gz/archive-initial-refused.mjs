import assert from 'node:assert/strict';
import {readFileSync,readdirSync,statSync,lstatSync,mkdirSync,writeFileSync,existsSync,createReadStream} from 'node:fs';
import {join,dirname,relative,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp='<TEMP>',artifacts='C:/Users/zinka/.codex/artifacts';
const source='814844f344a45159152415b0fb6d7027f05b093e';
const run=join(temp,'release297-capacity-8148-attempt-01'),seed=join(temp,'release297-schema54-seed-8148-01');
const campaign=join(artifacts,'release297-capacity-campaign-814844f3-01'),snapshot=join(artifacts,'release297-synthetic-prepared-814844f3-01');
const helper=join(artifacts,'release297-role-helper-814844f3-01'),context=join(artifacts,'release297-role-context-814844f3-01');
const out=join(artifacts,'release297-capacity-8148-attempt-01-evidence');
const sha=x=>createHash('sha256').update(x).digest('hex');
const hash=async path=>{const digest=createHash('sha256');for await(const chunk of createReadStream(path))digest.update(chunk);return digest.digest('hex');};
const read=path=>JSON.parse(readFileSync(path,'utf8').replace(/^\uFEFF/,''));
const fileSha=path=>sha(readFileSync(path));
const metrics=read(join(run,'usage-scale.json')),plan=read(join(run,'run-plan.json')),validation=read(join(run,'validation-result.json'));
const cleanup=read(join(run,'all-owned-role-fixtures-cleanup.json')),host=read(join(run,'role-host-result.json')),custody=read(join(run,'receipt-manifest.json'));
assert.equal(plan.source,source);assert.equal(plan.mode,'capacity-candidate');assert.equal(plan.ordinal,1);assert.equal(plan.diagnosticOnly,false);
assert.equal(validation.capacityAccepted,false);assert.equal(validation.runPassed,false);assert.deepEqual(validation.failures,['preparation','metrics','ownership']);
assert.equal(Object.keys(custody.records).length,13);for(const item of Object.values(custody.records))assert.equal(fileSha(join(run,item.file)),item.sha256);
assert.equal(validation.receiptManifestSha256,fileSha(join(run,'receipt-manifest.json')));
assert.equal(cleanup.cleanupPassed,true);assert.equal(cleanup.roles.roles.length,4);assert.equal(cleanup.fixtures.resources.length,2);
for(const item of [...cleanup.roles.roles,...cleanup.fixtures.resources]){assert.equal(item.cleanupPassed,true);assert.equal(item.confirmedAbsent,true);}
assert.ok(cleanup.fixtures.resources.find(x=>x.role==='postgres').volumes.every(x=>x.confirmedAbsent===true));
const final=read(join(run,'final-source-receipt.json'));assert.equal(final.source,source);assert.equal(final.clean,true);assert.equal(final.unchanged,true);
const registration=read(join(campaign,'001.registration.json')),completion=read(join(campaign,'001.completion.json'));
assert.equal(fileSha(join(campaign,'campaign.json')),plan.campaignSha256);assert.equal(registration.planRaw,readFileSync(join(run,'run-plan.json'),'utf8'));
assert.equal(completion.entry.registrationSha256,fileSha(join(campaign,'001.registration.json')));assert.equal(completion.entry.receiptManifestSha256,validation.receiptManifestSha256);
assert.equal(completion.cleanupRaw,readFileSync(join(run,'all-owned-role-fixtures-cleanup.json'),'utf8'));assert.equal(completion.entry.ownershipReleased,true);
const campaignNames=readdirSync(campaign).sort();assert.deepEqual(campaignNames,['001.completion.json','001.registration.json','campaign.json']);
const abort=read(join(seed,'measurement-abort-receipt.json')),seedCleanup=read(join(seed,'independent-cleanup.json'));
assert.equal(abort.code,'ABORTED_BEFORE_MEASUREMENT');assert.equal(abort.measurementStarted,false);assert.equal(abort.source,source);
assert.equal(seedCleanup.containerAbsent,true);assert.equal(seedCleanup.volumesAbsent,true);assert.equal(seedCleanup.listingCommandsSucceeded,true);assert.equal(seedCleanup.measurementReleaseAbsent,true);
assert.equal(existsSync(join(seed,'measurement-go.json')),false);assert.equal(existsSync(join(seed,'usage-scale.json')),false);
const snapshotManifest=read(join(snapshot,'manifest.json'));assert.equal(snapshotManifest.source,source);assert.equal(snapshotManifest.migrations,54);assert.equal(snapshotManifest.run,abort.run);
assert.equal(snapshotManifest.readOnlyExport,true);assert.equal(snapshotManifest.measurementGoAbsent,true);assert.equal(snapshotManifest.sourceUnchanged,true);
for(const item of snapshotManifest.records)assert.equal(await hash(join(snapshot,item.file)),item.sha256,item.file);
const snapshotSha=fileSha(join(snapshot,'manifest.json'));assert.equal(snapshotSha,'014054a38bb4c9b498b9d8c7677ca506ab0eb30b659880997a6ac742fd278a23');
const binding=read(join(helper,'role-image-binding.json'));assert.equal(fileSha(join(helper,'role-image-binding.json')),plan.identity.helper.bindingSha256);
for(const[name,expected]of Object.entries(binding.roleHarnessSha256))assert.equal(fileSha(join(context,'prototype',name)),expected,name);
assert.equal(plan.identity.harness.identity,binding.harnessIdentity);
assert.equal(existsSync(out),false);mkdirSync(out);
const files=[],hashOnly=[],emptyPrivateFiles=[];
const safePath=path=>path.replaceAll('\\','/').replace(temp,'<TEMP>');
const scrubText=value=>value.replace(/(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi,'<REDACTED_LOCAL_CONNECTION_URL>')
  .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_SYNTHETIC_TOKEN>')
  .replace(/\b(?:ghp|ghs|github_pat)_[A-Za-z0-9_]+\b/g,'<REDACTED_GITHUB_TOKEN>')
  .replace(/C:[\\/]+Users[\\/]+zinka[\\/]+AppData[\\/]+Local[\\/]+Temp/gi,'<TEMP>');
function scrub(value,key=''){
  if(/(?:password|secret|cookie|authorization|credentials|^nonce$|^token$|Token$|_URL$)/i.test(key))return'<REDACTED>';
  if(typeof value==='string'){
    if(key.endsWith('Raw')){try{return JSON.stringify(scrub(JSON.parse(value)));}catch{}}
    return scrubText(value);
  }
  if(Array.isArray(value))return value.map(x=>scrub(x));
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,x])=>[key,scrub(x,key)]));
  return value;
}
function add(path,name){
  assert.equal(lstatSync(path).isSymbolicLink(),false);const raw=readFileSync(path),text=raw.toString('utf8');assert.ok(Buffer.from(text).equals(raw),name+' must be UTF-8');
  const safe=Buffer.from(path.endsWith('.json')?JSON.stringify(scrub(JSON.parse(text.replace(/^\uFEFF/,''))),null,2)+'\n':scrubText(text));
  assert.equal(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b|SCRAM-SHA-256\$\d+:/.test(safe.toString()),false,'Unexpected private material: '+name);
  const gz=gzipSync(safe,{level:6}),packetPath=name+'.gz';mkdirSync(dirname(join(out,packetPath)),{recursive:true});writeFileSync(join(out,packetPath),gz,{flag:'wx'});
  files.push({path:packetPath,originalPath:safePath(path),originalBytes:raw.length,originalSha256:sha(raw),sanitizedSha256:sha(safe),gzipSha256:sha(gz)});
}
async function exclude(path,reason){const item={path:safePath(path),bytes:statSync(path).size,sha256:await hash(path),reason};(item.bytes===0?emptyPrivateFiles:hashOnly).push(item);}
async function walk(directory,prefix,privateOnly=false){
  for(const entry of readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){assert.equal(entry.isSymbolicLink(),false);const path=join(directory,entry.name),name=prefix+'/'+entry.name;
    if(entry.isDirectory())await walk(path,name,privateOnly);
    else if(privateOnly||entry.name==='cold-fixture-state.json'||/\.private\.|\.env$/.test(entry.name))await exclude(path,'Private synthetic fixture/role/env material; no contents copied.');
    else add(path,name);
  }
}
await walk(run,'attempt');await walk(seed,'seed-abort');await walk(campaign,'campaign-journal');
await walk(join(temp,'release297-capacity-8148-private-01'),'private',true);
await walk(snapshot,'snapshot');await walk(helper,'helper');await walk(join(context,'prototype'),'context/prototype');await walk(join(context,'overlay'),'context/overlay');
for(const name of ['.dockerignore','Dockerfile.roles','role-preparation.json','coordinator-overlay-receipt.json','verify-runtime.mjs'])add(join(context,name),'context/'+name);
await walk(join(temp,'release297-capacity-8148-config-01'),'attempt-config');await walk(join(temp,'release297-campaign-config-8148-01'),'config-generator');
await walk(join(temp,'release297-ci-8148-final-01'),'ci-final');await walk(join(temp,'release297-ci-8148-frontend2-01'),'ci-frontend2-failure');
await walk(join(temp,'release297-schema54-snapshot-plan-01'),'snapshot-preserver');
for(const name of ['release297-capacity-8148-input-01.json','release297-capacity-8148-attempt-01.predeclared-plan.json','release297-capacity-8148-attempt-01-console.log','release297-schema54-seed-8148-01-console.log','release297-schema54-seed-8148-owner.json','release297-role-context-814844f3-01.log','release297-role-host-814844f3-install.log','release297-reader-8148-final-binding.json'])add(join(temp,name),'commands/'+name);
for(const [index,directory]of process.argv.slice(2).entries())await walk(resolve(directory),`independent-analysis-${index+1}`);
add(fileURLToPath(import.meta.url),'archive-script.mjs');
const phase=metrics.phases[0],ciSummary=read(join(temp,'release297-ci-8148-final-01/summary.json'));
const summary={schemaVersion:1,source,run:plan.run,mode:plan.mode,diagnosticOnly:false,capacityAccepted:false,acceptedRunCount:0,
  campaign:{sha256:plan.campaignSha256,ordinal:1,registrationSha256:fileSha(join(campaign,'001.registration.json')),completionSha256:fileSha(join(campaign,'001.completion.json')),status:completion.entry.status,ownershipReleased:true,closed:false,originalComparisonRun:false},
  timing:{preparedAt:read(join(run,'measurement-ready.json')).preparedAt,releasedAt:read(join(run,'measurement-release-receipt.json')).releasedAt,startedAt:metrics.startedAt,finishedAt:metrics.finishedAt,cleanupFinishedAt:cleanup.finishedAt},
  heartbeats:phase.traffic.heartbeats,heartbeatStatuses:phase.traffic.heartbeatStatuses,insertedObservations:phase.insertedObservations,
  reports:{offered:phase.traffic.reports.length,successful:phase.traffic.reports.filter(x=>x.status===200&&x.correct&&x.durationMs<20000).length},workers:phase.workers,
  api:{cpuMicroseconds:phase.api.cpuMicroseconds,eventLoop:phase.api.eventLoop,acquisitions:phase.api.database.acquisitions},
  correctness:{passed:metrics.correctness.passed,currentObservationCutoff:metrics.correctness.currentObservationCutoff,currentDayWorkers:metrics.correctness.currentDayWorkers,csvAuditCount:metrics.correctness.csvAuditCount},preflightDrain:metrics.preflightDrain,serverDrain:phase.serverDrain,lifecycle:phase.traffic.lifecycle,
  sourceAtFinish:metrics.sourceAtFinish,finalSourceReceipt:final,roleExits:host.roles.map(x=>({role:x.role,...x.exit})),cleanup,
  validation,independentSafetyReview:{method:'Read-only in-memory exhaustive assertion replay; parent/safety messages retained, no separately archived replay file.',assertions:880,unexpectedShapeBindingOrCleanupFailures:0,preparationFailure:'execution.exitCode=1',ownershipFailures:'Eight consequences of coordinator numerical-failure exit1; original validation retained.'},all13OriginalReceiptHashesVerified:true,receiptManifestSha256:fileSha(join(run,'receipt-manifest.json')),
  seed:{run:abort.run,abortedAt:abort.abortedAt,code:abort.code,measurementStarted:false,releaseAbsent:true,trafficAbsent:true,cleanup:seedCleanup},
  immutableSnapshot:{directory:snapshot,manifestSha256:snapshotSha,source:snapshotManifest.source,migrations:54,tables:129,heartbeatRows:snapshotManifest.heartbeatRows,readOnlyExport:true,privateFilesHashOnly:true},
  finalCi:ciSummary,limitations:['Failed candidate attempt, not accepted capacity. A completed journal status means execution and cleanup completed; validation remains false.',
    'Sanitized records are evidence copies, never acceptance inputs. All original raw hashes and local private artifacts remain unchanged.',
    'Synthetic PostgreSQL4CPU/4GiB is not dated production db.t4g.medium; no deployed headroom claim.',
    'Fresh PostgreSQL/role restart does not flush host filesystem caches. No resource/deadline changes or automatic retries.',
    'Every original acceptance/validator failure is retained; no failure is relabeled or omitted.']};
const summaryRaw=JSON.stringify(scrub(summary),null,2)+'\n';writeFileSync(join(out,'summary.json'),summaryRaw,{flag:'wx'});
const privacy={schemaVersion:1,records:files.length,hashOnly:hashOnly.length,emptyPrivateFiles:emptyPrivateFiles.length,privateDumpCopied:false,privateRoleDdlCopied:false,environmentFilesCopied:false,
  redactions:['credential/password/secret/cookie/token/nonce fields including nested raw JSON','database/Redis URL literals','JWT and GitHub token patterns','temporary-directory prefix'],
  privateKeyAccessKeyScramPatternScanPassed:true,scope:'Synthetic owned local capacity/seed/campaign evidence only; no production or real-school data.'};
const privacyRaw=JSON.stringify(privacy,null,2)+'\n';writeFileSync(join(out,'privacy-review.json'),privacyRaw,{flag:'wx'});
for(const item of files){const bytes=readFileSync(join(out,item.path));assert.equal(sha(bytes),item.gzipSha256);assert.equal(sha(gunzipSync(bytes)),item.sanitizedSha256);assert.equal(fileSha(item.originalPath.replace('<TEMP>',temp)),item.originalSha256);}
assert.deepEqual(readdirSync(campaign).sort(),campaignNames);
const manifest={schemaVersion:1,createdAt:new Date().toISOString(),source,run:plan.run,mode:plan.mode,diagnosticOnly:false,capacityAccepted:false,acceptedRunCount:0,
  scope:'First registered8148 capacity-candidate failed; immutable seed-only capture/explicit abort, actual13 owner receipts and append-only declaration/registration/completion preserved.',
  summarySha256:sha(summaryRaw),privacyReviewSha256:sha(privacyRaw),files,hashOnly,emptyPrivateFiles,limitations:summary.limitations};
const bytes=JSON.stringify(manifest,null,2)+'\n';writeFileSync(join(out,'manifest.json'),bytes,{flag:'wx'});
console.log(JSON.stringify({out,records:files.length,hashOnly:hashOnly.length,emptyPrivateFiles:emptyPrivateFiles.length,manifestSha256:sha(bytes),summarySha256:sha(summaryRaw),receiptManifestSha256:summary.receiptManifestSha256}));
