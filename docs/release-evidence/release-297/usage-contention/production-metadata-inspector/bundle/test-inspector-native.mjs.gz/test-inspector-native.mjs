import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const require=createRequire('[USERPROFILE]/.codex/worktrees/release297-compatible-rollback/SchoolPilot/package.json');
const nativePg=require('pg');
const original=readFileSync(new URL('./inspect-release-metadata.mjs',import.meta.url),'utf8');
const source=original.replace(/^import .*;\r?\n/gm,'');
const admin=new nativePg.Client({connectionString:process.env.INSPECTOR_FIXTURE_OWNER});
await admin.connect();
const errors=[],cases=[];
const uuid='11111111-1111-4111-8111-111111111111';
async function inspect(uri){
 const output=[];let ended=false;let phase=0;
 class Client{
  constructor(options){assert.equal(options.ssl.rejectUnauthorized,true);assert.equal(options.host,'schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com');this.native=new nativePg.Client({connectionString:uri});}
  on(...args){this.native.on(...args)}async connect(){await this.native.connect()}
  async query(...args){phase++;try{return await this.native.query(...args)}catch(error){errors.push({phase,code:error.code??'unknown',position:error.position??null});throw error}}
  async end(){ended=true;await this.native.end()}
 }
 const proc={env:{DATABASE_URL:'[REDACTED_DATABASE_URL]'},stdout:{write:line=>output.push(JSON.parse(line))},exit:()=>{throw new Error('local synthetic exit')},exitCode:0};
 const context=vm.createContext({pg:{Client},assert,readFileSync:path=>{assert.equal(path,'/app/rds-ca.pem');return 'SYNTHETIC_CA'},createHash,URL,Buffer,process:proc,setTimeout,clearTimeout});
 await new vm.Script('(async()=>{'+source+'})()').runInContext(context);
 assert.ok(ended);
 return {exitCode:proc.exitCode,output,payload:output[0]?.failed?null:JSON.parse(Buffer.concat(output.map(part=>Buffer.from(part.data,'base64'))).toString())};
}
try{
 await admin.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"; CREATE TYPE fixture_state AS ENUM ('a','b'); CREATE DOMAIN fixture_positive AS integer CHECK(VALUE>0); CREATE TABLE schema_migrations(id text PRIMARY KEY,checksum char(64) NOT NULL,mode text NOT NULL,status text NOT NULL,application_sha text NOT NULL); INSERT INTO schema_migrations VALUES('synthetic-migration',repeat('a',64),'transactional','complete','synthetic'); CREATE TABLE schools(id varchar PRIMARY KEY,name text NOT NULL,domain text,status text NOT NULL,is_active boolean NOT NULL,deleted_at timestamptz,disabled_at timestamptz,plan_status text NOT NULL,active_until timestamptz); CREATE TABLE product_licenses(id serial PRIMARY KEY,school_id text REFERENCES schools(id),product text,status text,expires_at timestamptz); CREATE TABLE fixture_tenant(id serial PRIMARY KEY,school_id text NOT NULL,state fixture_state DEFAULT 'a'); ALTER TABLE fixture_tenant ENABLE ROW LEVEL SECURITY; ALTER TABLE fixture_tenant FORCE ROW LEVEL SECURITY; CREATE POLICY tenant_isolation ON fixture_tenant USING(school_id=current_setting('app.school_id',true)); CREATE INDEX fixture_school ON fixture_tenant(school_id); CREATE VIEW fixture_view AS SELECT id FROM fixture_tenant; CREATE FUNCTION fixture_trigger() RETURNS trigger LANGUAGE plpgsql AS 'BEGIN RETURN NEW; END'; CREATE TRIGGER fixture_update BEFORE UPDATE ON fixture_tenant FOR EACH ROW EXECUTE FUNCTION fixture_trigger(); GRANT SELECT ON ALL TABLES IN SCHEMA public TO fixture_reader; GRANT USAGE ON SCHEMA public TO fixture_reader;`);
 const owner=process.env.INSPECTOR_FIXTURE_OWNER,reader=process.env.INSPECTOR_FIXTURE_READER;
 const absent=await inspect(reader);assert.equal(absent.exitCode,0);assert.equal(absent.payload.pilot.matches,0);assert.equal(absent.payload.role.superuser,false);assert.equal(absent.payload.role.bypassRls,false);cases.push({name:'native restricted-role complete catalog and missing pilot',passed:true});
 await admin.query("INSERT INTO schools(id,name,domain,status,is_active,plan_status) VALUES($1,'Synthetic school','desalescincy.org','active',true,'active');",[uuid]);
 await admin.query("INSERT INTO product_licenses(school_id,product,status) VALUES($1,'CLASSPILOT','active')",[uuid]);
 for(const [name,uri] of [['owner',owner],['restricted',reader]]){const r=await inspect(uri);assert.equal(r.exitCode,0);assert.equal(r.payload.pilot.school.id,uuid);assert.equal(r.payload.pilot.school.classpilotEntitled,true);assert.ok(r.payload.inventory.extensions.some(e=>e.name==='uuid-ossp'));assert.ok(r.payload.inventory.policies.length>0);assert.ok(r.payload.inventory.functions.length>0);assert.ok(r.payload.inventory.types.length>0);assert.ok(r.payload.inventory.triggers.length>0);cases.push({name:'native '+name+' unique pilot and full metadata SQL',passed:true})}
 await admin.query("INSERT INTO schools(id,name,domain,status,is_active,plan_status) VALUES('22222222-2222-4222-8222-222222222222','Other synthetic','desalescincy.org','active',true,'active')");
 const ambiguous=await inspect(reader);assert.equal(ambiguous.exitCode,0);assert.equal(ambiguous.payload.pilot.matches,2);assert.equal(ambiguous.payload.pilot.school,null);cases.push({name:'native ambiguous pilot cannot select a binding',passed:true});
 await admin.query('ALTER TABLE schools ENABLE ROW LEVEL SECURITY; ALTER TABLE schools FORCE ROW LEVEL SECURITY');
 const drift=await inspect(reader);assert.equal(drift.exitCode,1);assert.equal(drift.output[0].code,'RELEASE_METADATA_FAILED');cases.push({name:'unexpected global RLS fails before silent absence',passed:true});
 await admin.query('ALTER TABLE schools DISABLE ROW LEVEL SECURITY');
 const check=new nativePg.Client({connectionString:owner});await check.connect();try{await check.query('BEGIN READ ONLY');await assert.rejects(check.query("DELETE FROM schools"),e=>e.code==='25006');await check.query('ROLLBACK')}finally{await check.end()};cases.push({name:'native READ ONLY rejects writes even for owner',passed:true});
}finally{
 await admin.end();
 const record={schemaVersion:1,at:new Date().toISOString(),sourceSha256:createHash('sha256').update(original).digest('hex'),status:cases.length===6?'passed_native_sql_fixture':'failed_native_sql_fixture',cases,sqlErrors:errors,limits:['Original source SQL executed through a test-only pg adapter into a uniquely owned synthetic local PostgreSQL16 database.','Production hostname/TLS option checks remain asserted; TLS handshake and real RDS privileges are not established.','No production queries, cloud mutations, or application data.']};
 writeFileSync(new URL('./local-native-sql-validation.json',import.meta.url),JSON.stringify(record,null,2)+'\n');
 console.log(JSON.stringify({cases:cases.length,sqlErrors:errors}));
}
