import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export async function proveFloor(repository,source,output,imageDigest){
  const git=args=>execFileSync('git',args,{cwd:repository,encoding:'utf8'}).trim();
  assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'');
  const paths={registry:'src/config/rlsRegistry.json',writer:'src/services/classpilotPrivateChatLifecycle.ts',migration:'src/db/classpilotPrivateChatLifecycleMigration.ts',protocol:'src/services/classpilotProtocol.ts',relay:'src/realtime/websocket.ts'};
  const sources=Object.fromEntries(Object.entries(paths).map(([key,path])=>[key,execFileSync('git',['show',`${source}:${path}`],{cwd:repository,encoding:'utf8'})]));
  const tables=JSON.parse(sources.registry).inventories.classpilotPrivateChatLifecyclePostExpand.tables;
  const make=name=>({synthetic:true,notDeployable:true,containerDefinitions:[{name,image:'synthetic.invalid/schoolpilot-candidate@'+imageDigest,
    command:['node',name==='api'?'dist/index.js':'dist/worker.js'],environment:Object.entries({GIT_SHA:source,RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:tables.join(','),
      CLASSPILOT_USAGE_ROLLUP_MODE:'off',CLASSPILOT_DIGITAL_USAGE_MODE:'off',CLASSPILOT_CAP_PRIVATE_CHAT_LIFECYCLE_V1:'false',
      CLASSPILOT_CAPABILITY_ROLLOUTS_JSON:JSON.stringify({privateChatLifecycleV1:{mode:'off'}})}).map(([name,value])=>({name,value}))}]});
  const api=make('api'),worker=make('scheduler-worker');
  const {assertPrivateChatReleaseFloor,verifyPrivateChatSourceImages}=await import(pathToFileURL(resolve(repository,'scripts/enforce-private-chat-release-floor.mjs')));
  const args={apiTaskDefinition:api,workerTaskDefinition:worker,candidateSources:sources,rollbackSourcesBySha:{[source]:sources},candidateTaskDefinitions:[{taskDefinition:api,containerName:'api'},{taskDefinition:worker,containerName:'scheduler-worker'}]};
  assert.deepEqual(assertPrivateChatReleaseFloor(args),{required:true,writerVersion:1,inventoryCount:129});
  assert.equal(verifyPrivateChatSourceImages({apiTaskDefinition:api,workerTaskDefinition:worker,expectedRepository:'synthetic.invalid/schoolpilot-candidate',lookupDigest:sha=>{assert.equal(sha,source);return imageDigest;}}),true);
  assert.throws(()=>assertPrivateChatReleaseFloor({...args,rollbackSourcesBySha:{[source]:{...sources,relay:''}}}));
  const partial=structuredClone(worker);partial.containerDefinitions[0].environment.find(row=>row.name==='RLS_ENABLED_TABLES').value=tables.slice(0,128).join(',');
  assert.throws(()=>assertPrivateChatReleaseFloor({...args,workerTaskDefinition:partial}));
  const proof={passed:true,source,imageDigest,writerVersion:1,bridgeVersion:1,relayVersion:1,inventoryCount:129,bothUsageModesOff:true,synthetic:true,
    sourceHashes:Object.fromEntries(Object.entries(sources).map(([key,value])=>[paths[key],createHash('sha256').update(value).digest('hex')])),
    scope:'Pure synthetic admission/source lookup only. Not registered, deployable, or proof of actual production/rollback task bindings.'};
  for(const[name,value]of Object.entries({'synthetic-api-task.json':api,'synthetic-worker-task.json':worker,'synthetic-release-floor-proof.json':proof}))writeFileSync(resolve(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
  return proof;
}
