import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const sha=value=>createHash('sha256').update(value).digest('hex');
export function verifyBinding(path) {
 const bytes=readFileSync(path),binding=JSON.parse(bytes);
 assert.equal(binding.applicationSource,'0e427e3ca9b82125e0bb8692176accad21f4f699');
 assert.equal(binding.roleImageId,'sha256:8bed6f5d266670c31d2b9c502b5d0ff065bd3bd9eed18a855506b15ab6bd1687');
 assert.equal(binding.runtimeFidelity.profile,'release-enabled-linux-role-ingest-candidate-default-v1');
 assert.equal(binding.runtimeFidelity.applicationChanges,0);assert.equal(binding.runtimeFidelity.harnessImageChanged,false);
 assert.equal(binding.capacityAccepted,false);assert.equal(binding.resourceAcceptance,false);
 for(const row of binding.runtimeFidelity.hostFiles) {
  assert.match(row.file,/^(?:(?:\.\.\/generated\/)?[a-z0-9.-]+\.(?:mjs|ps1)|\.\.\/verify-binding\.mjs)$/);
  assert.equal(sha(readFileSync(new URL(row.file,new URL('./prototype/launch-role-preflight.mjs',import.meta.url)))),row.sha256);
 }
 assert.equal(sha(readFileSync(new URL('./prototype/runtime-fidelity.mjs',import.meta.url))),binding.runtimeFidelity.preloaderSha256);
 return {profile:binding.runtimeFidelity.profile,bindingSha256:sha(bytes),preloaderSha256:binding.runtimeFidelity.preloaderSha256};
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url) console.log(JSON.stringify(verifyBinding(process.argv[2])));

