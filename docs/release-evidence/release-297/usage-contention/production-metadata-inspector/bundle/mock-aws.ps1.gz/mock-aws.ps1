# Injected only into a test copy after reviewed helper definitions. Every AWS call is intercepted.
$script:MockRoot=$PSScriptRoot
$script:MockCase=$env:INSPECTOR_LOCAL_MOCK_CASE
$script:MockStatePath=Join-Path $script:MockRoot 'mock-state.json'
$script:MockCalls=[Collections.Generic.List[string]]::new()
function Start-Sleep { param($Seconds,$Milliseconds) }
function Mock-Arg($Arguments,$Name){$i=[Array]::IndexOf($Arguments,$Name);if($i -lt 0){return $null};return $Arguments[$i+1]}
function Mock-Save($Value){[IO.File]::WriteAllText($script:MockStatePath,($Value|ConvertTo-Json -Depth 30));}
function Mock-Read {if(Test-Path -LiteralPath $script:MockStatePath){return Get-Content -LiteralPath $script:MockStatePath -Raw|ConvertFrom-Json};return [pscustomobject]@{definition=$null;run=$null;runCalls=0;deregistered=$false;stopped=$false}}
function Mock-Worker([string]$Name,[string]$Family,[int]$Revision){
 $arn="arn:aws:ecs:us-east-1:135775632425:task-definition/${Family}:$Revision"
 return [pscustomobject]@{taskDefinition=[pscustomobject]@{taskDefinitionArn=$arn;status='ACTIVE';family=$Family;taskRoleArn='arn:aws:iam::135775632425:role/synthetic-application';executionRoleArn='arn:aws:iam::135775632425:role/synthetic-execution';networkMode='awsvpc';containerDefinitions=@([pscustomobject]@{name=$Name;image='135775632425.dkr.ecr.us-east-1.amazonaws.com/schoolpilot-production-api@sha256:c87433cdf3d88e0c291a50d1ae74fbc116f167048f7db9d6c2d1d0ebfc52b9e8';environment=@([pscustomobject]@{name='GIT_SHA';value='7af9d0dd5bc2bd3e13b96d35a577725e07f8b678'},[pscustomobject]@{name='RLS_GUC_ENABLED';value='true'},[pscustomobject]@{name='RLS_ENABLED_TABLES';value=((1..121|ForEach-Object {'t'+$_})-join ',')});secrets=@([pscustomobject]@{name='DATABASE_URL';valueFrom='arn:aws:secretsmanager:us-east-1:135775632425:secret:synthetic-database-reference'});mountPoints=@();logConfiguration=[pscustomobject]@{logDriver='awslogs';options=[pscustomobject]@{'awslogs-region'='us-east-1';'awslogs-group'='/ecs/schoolpilot-production-scheduler-worker';'awslogs-stream-prefix'='ecs'}}});volumes=@();placementConstraints=@();requiresCompatibilities=@('FARGATE');cpu='512';memory='1024'};tags=@()}
}
function Get-ServiceSnapshot {
 $network=[pscustomobject]@{awsvpcConfiguration=[pscustomobject]@{subnets=@('subnet-05bb1ca172f49ee60','subnet-090021e7e1057b451');securityGroups=@('sg-08af33c99e705a4b7');assignPublicIp='ENABLED'}}
 $make={param($arn) [pscustomobject]@{status='ACTIVE';deploymentController=[pscustomobject]@{type='ECS'};desiredCount=1;runningCount=1;pendingCount=0;taskDefinition=$arn;networkConfiguration=$network;deployments=@([pscustomobject]@{status='PRIMARY';rolloutState='COMPLETED';taskDefinition=$arn;desiredCount=1;runningCount=1;pendingCount=0;failedTasks=0})}}
 return [pscustomobject]@{Api=(& $make 'arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-api-emergency:163');Worker=(& $make 'arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-scheduler-worker:179')}
}
function Invoke-AwsJson {param([string[]]$Arguments)
 $op=$Arguments[0]+' '+$Arguments[1];$script:MockCalls.Add($op)
 [IO.File]::WriteAllText((Join-Path $script:MockRoot 'mock-calls.json'),($script:MockCalls.ToArray()|ConvertTo-Json))
 $state=Mock-Read
 switch -CaseSensitive ($op){
 'sts get-caller-identity' {return [pscustomobject]@{Account='135775632425'}}
 'rds describe-db-instances' {return [pscustomobject]@{DBInstances=@([pscustomobject]@{DBInstanceStatus='available';DBName='schoolpilot';Endpoint=[pscustomobject]@{Address='schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com';Port=5432};DBSubnetGroup=[pscustomobject]@{VpcId='vpc-0e286e71a65c73ecb'};Engine='postgres';EngineVersion='16.4'})}}
 'ecs describe-task-definition' {
  $arn=Mock-Arg $Arguments '--task-definition'
  if($arn.EndsWith('schoolpilot-production-api-emergency:163')){return Mock-Worker 'api' 'schoolpilot-production-api-emergency' 163}
  if($arn.EndsWith('schoolpilot-production-scheduler-worker:179')){return Mock-Worker 'scheduler-worker' 'schoolpilot-production-scheduler-worker' 179}
  if($state.definition -and $state.definition.taskDefinition.taskDefinitionArn -ceq $arn){return $state.definition}
  throw 'Unrecognized synthetic definition'
 }
 'ecs register-task-definition' {
  $p=(Mock-Arg $Arguments '--cli-input-json').Substring(7);$request=Get-Content -LiteralPath $p -Raw|ConvertFrom-Json
  $tags=$request.tags;$request.PSObject.Properties.Remove('tags')
  $request|Add-Member taskDefinitionArn ('arn:aws:ecs:us-east-1:135775632425:task-definition/'+$request.family+':1')
  $request|Add-Member status 'ACTIVE'
  $state.definition=[pscustomobject]@{taskDefinition=$request;tags=$tags};Mock-Save $state
  if($script:MockCase -ceq 'lost-registration'){throw 'Synthetic lost registration response'}
  return $state.definition
 }
 'ecs run-task' {
  $p=(Mock-Arg $Arguments '--cli-input-json').Substring(7);$request=Get-Content -LiteralPath $p -Raw|ConvertFrom-Json
  if($state.run -and (Get-CanonicalJsonSha256 $state.run) -cne (Get-CanonicalJsonSha256 $request)){throw 'Changed RunTask idempotency request'}
  $state.run=$request;$state.runCalls++;Mock-Save $state
  if($script:MockCase -ceq 'lost-run-stopped' -or $script:MockCase -ceq 'lost-run-unknown' -or ($script:MockCase -ceq 'lost-run' -and $state.runCalls -eq 1)){throw 'Synthetic lost run response'}
  return [pscustomobject]@{failures=@();tasks=@([pscustomobject]@{taskArn=('arn:aws:ecs:us-east-1:135775632425:task/schoolpilot-production-cluster/'+('a'*32))})}
 }
 'ecs describe-tasks' {
  $owner=$state.run.startedBy;if($script:MockCase -ceq 'wrong-owner'){$owner='different-owner'}
  return [pscustomobject]@{failures=@();tasks=@([pscustomobject]@{taskArn=('arn:aws:ecs:us-east-1:135775632425:task/schoolpilot-production-cluster/'+('a'*32));taskDefinitionArn=$state.run.taskDefinition;startedBy=$owner;lastStatus='STOPPED';containers=@([pscustomobject]@{name='scheduler-worker';exitCode=0})})}
 }
 'logs get-log-events' {
  if($script:MockCase -ceq 'bad-logs'){return [pscustomobject]@{events=@([pscustomobject]@{message='{"unexpected":"synthetic secret must not be retained"}'});nextForwardToken='done'}}
  $token=Mock-Arg $Arguments '--next-token';$events=if($token){@()}else{@(Get-Content -LiteralPath (Join-Path $script:MockRoot 'synthetic-transport.json') -Raw|ConvertFrom-Json)}
  return [pscustomobject]@{events=$events;nextForwardToken='done'}
 }
 'ecs list-task-definitions' {return [pscustomobject]@{taskDefinitionArns=@($state.definition.taskDefinition.taskDefinitionArn)}}
 'ecs list-tasks' {
  if((Mock-Arg $Arguments '--started-by') -and (Mock-Arg $Arguments '--desired-status')){throw 'Invalid ECS startedBy filter combination'}
  if((Mock-Arg $Arguments '--family') -and $script:MockCase -ceq 'lost-run-stopped'){return [pscustomobject]@{taskArns=@('arn:aws:ecs:us-east-1:135775632425:task/schoolpilot-production-cluster/'+('a'*32))}}
  return [pscustomobject]@{taskArns=@()}
 }
 'ecs stop-task' {$state.stopped=$true;Mock-Save $state;return [pscustomobject]@{}}
 'ecs deregister-task-definition' {$state.deregistered=$true;Mock-Save $state;return [pscustomobject]@{}}
 default {throw "AWS command escaped the allowlisted synthetic adapter: $op"}
 }
}
