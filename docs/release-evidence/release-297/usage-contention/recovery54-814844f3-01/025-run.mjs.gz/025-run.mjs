// External local-only adapter. All application imports execute inside the
// scanned OCI images. No fixture is created until every immutable input binds.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {randomBytes} from 'node:crypto';
import {SOURCE,CLONE,ENDPOINT,json,sha,checked,validateConfig,assertSource} from './binding.mjs';
const here=dirname(fileURLToPath(import.meta.url));
assert.equal(process.argv.length,3,'Usage: node run.mjs <bound final-config.json>');
const configPath=resolve(process.argv[2]),config=json(configPath);
const {ledger}=validateConfig(config,here);
const pg=createRequire(join(CLONE,'package.json'))('pg');
const temp='C:/Users/zinka/AppData/Local/Temp',run=randomBytes(6).toString('hex');
const out=join(temp,'release297-recovery54-814844f3-'+run),privateDir=join(temp,'release297-recovery54-private-'+run),shared=join(privateDir,'state');
mkdirSync(out);mkdirSync(privateDir);mkdirSync(shared);
writeFileSync(join(out,'bound-config.json'),readFileSync(configPath));
for(const name of ['binding.mjs','function-retention.mjs','grant.mjs','probe.mjs','run.mjs'])writeFileSync(join(out,name),readFileSync(join(here,name)));
const docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe';
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(PATH|SystemRoot|WINDIR|TEMP|TMP|APPDATA|LOCALAPPDATA|USERPROFILE|COMSPEC|PATHEXT)$/i.test(key)));
const owners=[],results=[];let admin,passed=false;
const receipt={schemaVersion:1,run,startedAt:new Date().toISOString(),source:SOURCE,candidate:config.candidate,fallback:config.fallback,
 configSha256:sha(readFileSync(configPath)),localDockerDaemon:ENDPOINT,actualImageFunctions:true,syntheticDataOnly:true,
 liveCatalogProven:false,serviceTrafficRollback:false,capacityAccepted:false,productionMutations:0,usageModes:'off/off',
 migrationCount:54,inventoryCount:129,results,cleanup:[],uncertainOwnership:[],privateMaterialDirectory:privateDir,privateMaterialExcludedFromSafeEvidence:true};
function command(args,{timeout=60000,input,log,allowFailure=false}={}){
 const result=spawnSync(docker,['--host',ENDPOINT,...args],{env,encoding:'utf8',windowsHide:true,timeout,maxBuffer:20*1024*1024,input});
 if(log){const raw=(result.stdout??'')+'\n'+(result.stderr??'');writeFileSync(join(privateDir,log),raw);(receipt.privateLogs??=[]).push({name:log,sha256:sha(raw),bytes:Buffer.byteLength(raw)});}
 if(!allowFailure){assert.equal(result.error,undefined,'Docker operation did not settle');assert.equal(result.status,0,'Docker '+args[0]+' failed');}
 return result;
}
function find(nameOrId,byId=false){
 const filter=byId?'id='+nameOrId:'name=^/'+nameOrId+'$';
 const found=command(['container','ls','--all','--no-trunc','--format','{{.ID}}','--filter',filter]);
 const ids=found.stdout.trim().split(/\r?\n/).filter(Boolean);assert.ok(ids.length<=1,'Ambiguous exact container lookup');if(!ids.length)return null;
 assert.match(ids[0],/^[a-f0-9]{64}$/);if(byId)assert.equal(ids[0],nameOrId);
 return JSON.parse(command(['inspect',ids[0]]).stdout)[0];
}
function matches(row,owner){return row?.Id===owner.id&&row?.Name==='/'+owner.name&&row?.Config?.Labels?.['codex.recovery54']===run
 &&row?.Config?.Labels?.['codex.recovery-role']===owner.role&&row?.Config?.Image===owner.image&&row?.Image===owner.runtimeImageReference;}
function create(role,image,args,cmd=[]){
 const name='schoolpilot-recovery54-'+run+'-'+role;
 const created=command(['create','--name',name,'--label','codex.recovery54='+run,'--label','codex.recovery-role='+role,...args,image,...cmd],{allowFailure:true,log:role+'-create.log'});
 let row;try{row=find(name);}catch(error){receipt.uncertainOwnership.push({name,role,reason:'creation outcome lookup failed'});throw error;}
 const valid=row?.Name==='/'+name&&row?.Config?.Labels?.['codex.recovery54']===run&&row?.Config?.Labels?.['codex.recovery-role']===role&&row?.Config?.Image===image;
 if(!valid){receipt.uncertainOwnership.push({name,role,reason:'exact creation ownership unavailable'});assert.fail('Exact creation ownership unavailable');}
 const owner={id:row.Id,name,role,image,runtimeImageReference:row.Image,volumes:row.Mounts.filter(m=>m.Type==='volume').map(m=>({name:m.Name,destination:m.Destination}))};owners.push(owner);
 assert.equal(created.error,undefined,'Create did not settle');assert.equal(created.status,0,'Create failed after recoverable ownership');return {owner,row};
}
function artifactImage(artifact){
 const row=JSON.parse(command(['image','inspect',artifact.image.imageId]).stdout)[0];
 const accepted=[artifact.image.indexDigest,artifact.image.platformManifestDigest,artifact.image.configDigest];
 assert.ok(accepted.includes(row.Id));assert.equal(row.Os,'linux');assert.equal(row.Architecture,'amd64');return row;
}
async function phase(phaseName,artifact,postgres,envPath){
 const image=artifact.image.imageId,entry=phaseName==='grant'?'/grant.mjs':'/probe.mjs';
 const args=['--network','container:'+postgres.id,'--cpus','1','--memory','2g','--memory-swap','2g','--cap-drop','ALL','--security-opt','no-new-privileges',
 '--no-healthcheck','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=32m','--env-file',envPath,'--env','PROBE_SOURCE='+artifact.source,
 '--mount','type=bind,source='+join(here,'function-retention.mjs').replaceAll('\\','/')+',target=/function-retention.mjs,readonly',
 '--mount','type=bind,source='+join(here,phaseName==='grant'?'grant.mjs':'probe.mjs').replaceAll('\\','/')+',target='+entry+',readonly',
 '--mount','type=bind,source='+shared.replaceAll('\\','/')+',target=/proof','--entrypoint','node'];
 const {owner,row}=create(phaseName,image,args,phaseName==='grant'?[entry]:[entry,phaseName]);
 assert.ok([artifact.image.indexDigest,artifact.image.platformManifestDigest,artifact.image.configDigest].includes(row.Image));
 assert.deepEqual(row.Config.Entrypoint,['node']);assert.deepEqual(row.Config.Cmd,phaseName==='grant'?[entry]:[entry,phaseName]);
 assert.equal(row.HostConfig.NetworkMode,'container:'+postgres.id);assert.equal(row.HostConfig.NanoCpus,1e9);assert.equal(row.HostConfig.Memory,2147483648);
 assert.equal(row.HostConfig.MemorySwap,2147483648);assert.equal(row.HostConfig.ReadonlyRootfs,true);assert.equal(row.HostConfig.Privileged,false);
 assert.deepEqual(row.HostConfig.CapDrop,['ALL']);assert.ok(row.HostConfig.SecurityOpt.includes('no-new-privileges'));assert.equal(owner.volumes.length,0);
 assert.equal(row.Mounts.filter(m=>m.Type==='bind').length,3);
 assert.ok(row.Mounts.every(m=>m.Type==='bind'||(m.Type==='tmpfs'&&m.Destination==='/tmp')));
 for(const target of ['/function-retention.mjs',entry])assert.equal(row.Mounts.find(m=>m.Destination===target)?.RW,false);
 assert.equal(row.Mounts.find(m=>m.Destination==='/proof')?.RW,true);
 const attached=command(['start','--attach',owner.id],{timeout:120000,log:phaseName+'.log',allowFailure:true});
 const ended=find(owner.id,true);assert.ok(matches(ended,owner));
 const result={phase:phaseName,source:artifact.source,image,runtimeImageReference:ended.Image,verifiedArtifactConfigDigest:artifact.image.configDigest,
 containerId:owner.id,attachExit:attached.status,daemonExit:ended.State.ExitCode,running:ended.State.Running,oomKilled:ended.State.OOMKilled,
 resourceProof:{cpu:1,memoryBytes:2147483648,memorySwapBytes:2147483648,readOnlyRoot:true,networkContainerId:postgres.id}};results.push(result);
 const resultPath=join(shared,phaseName+'-result.json');if(existsSync(resultPath)){const bytes=readFileSync(resultPath);writeFileSync(join(out,phaseName+'-result.json'),bytes);result.proofSha256=sha(bytes);}
 assert.equal(attached.error,undefined,'Phase did not settle');assert.equal(attached.status,0);assert.equal(ended.State.Running,false);assert.equal(ended.State.OOMKilled,false);assert.equal(ended.State.ExitCode,0);
 const proof=json(resultPath);assert.equal(proof.passed,true);assert.equal(proof.source,artifact.source);assert.equal(proof.capacityAccepted,false);assert.equal(proof.productionMutations,0);
 if(phaseName!=='grant'){
  assert.equal(proof.ledgerEntries,54);assert.equal(proof.ledgerUnchanged,true);assert.equal(proof.screenshotFunctionRetained,true);
  assert.equal(proof.usageModes,'off/off');assert.equal(proof.privateEpochsAndGenerationVerified,true);assert.equal(proof.deliveredHistoryRetained,true);assert.equal(proof.focusStateVerified,true);
  if(phaseName!=='fallback')assert.equal(proof.candidateRuntimeAssertion,true);
  result.privateStateSha256=sha(readFileSync(join(shared,'private-state.json')));result.privateStateExcluded=true;
 }
 return proof;
}
try{
 artifactImage(config.candidate);artifactImage(config.fallback);
 const password=randomBytes(24).toString('hex'),appPassword=randomBytes(24).toString('hex'),database='sptest',appRole='recovery54_app_'+run;
 const {owner:postgres,row:pgCreated}=create('postgres',config.postgresImage,['--cpus','4','--memory','4g','--memory-swap','4g','--publish','127.0.0.1::5432',
 '--env','POSTGRES_USER=recovery_owner','--env','POSTGRES_DB='+database,'--env','POSTGRES_PASSWORD='+password]);
 assert.equal(pgCreated.HostConfig.NanoCpus,4e9);assert.equal(pgCreated.HostConfig.Memory,4294967296);assert.equal(pgCreated.HostConfig.MemorySwap,4294967296);
 assert.equal(postgres.volumes.length,1);assert.equal(postgres.volumes[0].destination,'/var/lib/postgresql/data');assert.match(postgres.volumes[0].name,/^[a-f0-9]{64}$/);
 writeFileSync(join(out,'postgres-owner.json'),JSON.stringify(postgres,null,2)+'\n');
 command(['start',postgres.id]);let ready=false;for(let n=0;n<50;n++){if(command(['exec',postgres.id,'pg_isready','-h','127.0.0.1','-U','recovery_owner','-d',database],{allowFailure:true}).status===0){ready=true;break;}await new Promise(r=>setTimeout(r,200));}assert.equal(ready,true);
 const pgInspect=find(postgres.id,true);assert.ok(matches(pgInspect,postgres));const ports=pgInspect.NetworkSettings.Ports['5432/tcp'];assert.equal(ports.length,1);const port=ports[0];assert.equal(port.HostIp,'127.0.0.1');
 command(['exec','-i',postgres.id,'psql','-U','recovery_owner','-d',database,'-v','ON_ERROR_STOP=1'],{input:checked(config.schema).toString('utf8'),log:'restore.log'});
 admin=new pg.Pool({connectionString:`postgresql://recovery_owner:${password}@127.0.0.1:${port.HostPort}/${database}`,max:2,connectionTimeoutMillis:5000,statement_timeout:15000});
 assert.equal((await admin.query('SELECT count(*)::int AS count FROM schema_migrations')).rows[0].count,0,'Schema-only fixture must not contain ledger data');
 await admin.query(`CREATE ROLE ${appRole} LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '${appPassword}'; GRANT USAGE ON SCHEMA public TO ${appRole}; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO ${appRole}; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO ${appRole}`);
 for(const row of ledger)await admin.query('INSERT INTO schema_migrations(id,checksum,mode,status,application_sha) VALUES($1,$2,$3,$4,$5)',[row.id,row.checksum,row.mode,row.status,row.application_sha]);
 receipt.syntheticLedgerRows=ledger.length;receipt.syntheticLedgerSource=config.ledgerContract;receipt.schema=config.schema;
 receipt.ledgerBootstrap='Actual complete54 ledger copied from successful source reentry into fresh schema-only behavior fixture; not independent migration application or a production restore.';
 const secret=randomBytes(32).toString('hex'),envPath=join(privateDir,'runtime.env');
 writeFileSync(envPath,`DATABASE_URL=postgresql://${appRole}:${appPassword}@127.0.0.1:5432/${database}\nDATABASE_URL_PRIVILEGED=postgresql://${appRole}:${appPassword}@127.0.0.1:5432/${database}\nADMIN_DATABASE_URL=postgresql://recovery_owner:${password}@127.0.0.1:5432/${database}\nJWT_SECRET=${secret}\nSESSION_SECRET=${secret}\nSTUDENT_TOKEN_SECRET=${secret}\nNODE_ENV=test\nREDIS_URL=\nSCHEDULER_ENABLED=false\nCLASSPILOT_USAGE_ROLLUP_MODE=off\nCLASSPILOT_DIGITAL_USAGE_MODE=off\n`,{flag:'wx'});
 const granted=await phase('grant',config.candidate,postgres,envPath);assert.equal(granted.clientsClosed,true);
 for(const [name,artifact]of [['seed',config.candidate],['fallback',config.fallback],['return',config.candidate]]){
  const proof=await phase(name,artifact,postgres,envPath);assert.deepEqual(proof.screenshotFunction,granted.function,'Whole54 ledger, body and ACL must be retained without repair');
 }
 validateConfig(config,here);passed=true;
}catch(error){receipt.failure={name:error?.name,code:error?.code,message:String(error?.message).slice(0,500)};process.exitCode=1;}
finally{
 try{await admin?.end();}catch(error){receipt.adminCloseFailure=error?.name;passed=false;process.exitCode=1;}
 for(const owner of [...owners].reverse()){
  const cleanup={...owner,removed:false,volumes:owner.volumes.map(row=>({...row,confirmedAbsent:false}))};receipt.cleanup.push(cleanup);
  try{
   let current=find(owner.id,true);assert.ok(matches(current,owner),'Cleanup ownership changed');cleanup.wasRunning=current.State.Running;
   if(owner.role==='postgres'&&current.State.Running){
    cleanup.gracefulStopRequested=true;
    try{
     command(['stop','--time','15',owner.id],{timeout:30000,log:'postgres-stop.log'});
     current=find(owner.id,true);assert.ok(matches(current,owner));assert.equal(current.State.Running,false);assert.equal(current.State.OOMKilled,false);assert.equal(current.State.ExitCode,0);
    }catch(error){cleanup.gracefulStopFailure={name:error?.name,code:error?.code};passed=false;process.exitCode=1;}
    // A stop failure must not bypass containment of the still-exact owned ID.
    current=find(owner.id,true);assert.ok(matches(current,owner),'Cleanup ownership changed after stop');
   }
   cleanup.forced=current.State.Running;
   command(['rm','--force','--volumes',owner.id]);assert.equal(find(owner.id,true),null);cleanup.removed=true;cleanup.containerAbsenceConfirmed=true;
   for(const volume of cleanup.volumes){const absent=command(['volume','ls','--format','{{.Name}}','--filter','name=^'+volume.name+'$']);assert.equal(absent.stdout.trim(),'');volume.confirmedAbsent=true;}
   if(cleanup.forced){passed=false;process.exitCode=1;}
  }catch(error){cleanup.error={name:error?.name,code:error?.code};passed=false;process.exitCode=1;}
 }
 receipt.cleanupPassed=receipt.uncertainOwnership.length===0&&owners.length>0&&receipt.cleanup.length===owners.length&&receipt.cleanup.every(row=>row.removed&&row.volumes.every(v=>v.confirmedAbsent));
 receipt.passed=passed&&receipt.cleanupPassed;receipt.completedAt=new Date().toISOString();
 writeFileSync(join(out,'execution.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({out,passed:receipt.passed,phases:results.length,cleanupPassed:receipt.cleanupPassed,failure:receipt.failure}));
 if(!receipt.passed)process.exitCode=1;
}
