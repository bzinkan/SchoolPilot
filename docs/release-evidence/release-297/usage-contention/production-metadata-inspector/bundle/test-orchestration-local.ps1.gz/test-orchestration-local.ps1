$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='[USERPROFILE]\.codex\worktrees\release-stabilization-297\SchoolPilot'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$evidence=Join-Path $env:TEMP ('release297-inspector-orchestration-'+$run)
New-Item -ItemType Directory -Path $evidence | Out-Null
$original=[IO.File]::ReadAllText((Join-Path $root 'run-release-metadata-inspector.ps1'))
$anchor=". (Join-Path `$RepositoryRoot 'scripts/run-mydesk-readiness.ps1')"
if(-not $original.Contains($anchor)){throw 'Test adapter injection anchor changed'}
$adapted=$original.Replace($anchor,$anchor+"`n. (Join-Path `$bundleRoot 'mock-aws.ps1')")
$results=@()
foreach($case in @('success','lost-registration','lost-run','lost-run-stopped','lost-run-unknown','wrong-owner','bad-logs')){
 $fixture=Join-Path $evidence $case;New-Item -ItemType Directory -Path $fixture|Out-Null
 foreach($name in @('inspect-release-metadata.mjs','mock-aws.ps1','synthetic-transport.json')){Copy-Item -LiteralPath (Join-Path $root $name) -Destination (Join-Path $fixture $name)}
 [IO.File]::WriteAllText((Join-Path $fixture 'run-release-metadata-inspector.ps1'),$adapted,[Text.UTF8Encoding]::new($false))
 $manifest=[ordered]@{files=@(Get-ChildItem -LiteralPath $fixture -File|ForEach-Object {@{file=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}});repositoryHelpers=@()}
 [IO.File]::WriteAllText((Join-Path $fixture 'bundle.json'),($manifest|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
 $env:INSPECTOR_LOCAL_MOCK_CASE=$case;$planDir=Join-Path $fixture 'plan'
 & pwsh -NoProfile -File (Join-Path $fixture 'run-release-metadata-inspector.ps1') -Mode Plan -RepositoryRoot $repo -OutDir $planDir *> (Join-Path $fixture 'plan.log')
 if($LASTEXITCODE){throw "Mock plan failed: $case"}
 $calls=Get-Content -LiteralPath (Join-Path $fixture 'mock-calls.json') -Raw|ConvertFrom-Json
 if(@($calls|Where-Object {$_ -match 'register|run-task|stop-task'}).Count){throw 'Plan mutated mock cloud'}
 $hash=(Get-FileHash -LiteralPath (Join-Path $planDir 'plan.json')).Hash.ToLowerInvariant()
 & pwsh -NoProfile -File (Join-Path $fixture 'run-release-metadata-inspector.ps1') -Mode Execute -RepositoryRoot $repo -OutDir $planDir -ApprovedPlanSha256 $hash *> (Join-Path $fixture 'execute.log')
 $exit=$LASTEXITCODE;$receipt=Get-Content -LiteralPath (Join-Path $planDir 'receipt.json') -Raw|ConvertFrom-Json
 $state=Get-Content -LiteralPath (Join-Path $fixture 'mock-state.json') -Raw|ConvertFrom-Json
 if($case -cin @('success','lost-run')){if($exit -ne 0 -or $receipt.status -cne 'inventoried' -or -not $receipt.taskStopped -or -not $state.deregistered){throw "Expected successful cleanup: $case"}}
 elseif($case -cin @('wrong-owner','lost-run-unknown')){if($exit -eq 0 -or $receipt.status -cne 'cleanup_unresolved' -or $state.stopped -or $state.deregistered){throw 'Unowned task modified'}}
 else{if($exit -eq 0 -or -not $state.deregistered){throw "Failed operation did not retain receipt/owned cleanup: $case"}}
 if($case -cin @('lost-run','lost-run-stopped','lost-run-unknown') -and $state.runCalls -ne 2){throw 'Idempotent retry not exercised'}
 if($case -ceq 'lost-run-stopped' -and -not $receipt.taskStopped){throw 'Stopped unknown RunTask not recovered'}
 if($case -ceq 'bad-logs' -and ([IO.File]::ReadAllText((Join-Path $planDir 'receipt.json'))).Contains('synthetic secret')){throw 'Unvalidated payload persisted'}
 $results+=@{case=$case;passed=$true;exit=$exit;receiptStatus=$receipt.status;taskStopped=$receipt.taskStopped;definitionDeregistered=$state.deregistered}
}
Remove-Item Env:INSPECTOR_LOCAL_MOCK_CASE
$result=[ordered]@{schemaVersion=1;at=[DateTimeOffset]::UtcNow.ToString('o');status='passed_local_orchestration_adapter';originalWrapperSha256=(Get-FileHash -LiteralPath (Join-Path $root 'run-release-metadata-inspector.ps1')).Hash.ToLowerInvariant();adapter='A test-only copied wrapper adds one dot-source after the existing helpers; all AWS transport and sleeps are intercepted. Production wrapper is unchanged.';evidenceDirectory=$evidence;cases=$results;productionMutations=0}
[IO.File]::WriteAllText((Join-Path $root 'local-orchestration-validation.json'),($result|ConvertTo-Json -Depth 10)+"`n",[Text.UTF8Encoding]::new($false))
Write-Output ($result|ConvertTo-Json -Depth 8)
