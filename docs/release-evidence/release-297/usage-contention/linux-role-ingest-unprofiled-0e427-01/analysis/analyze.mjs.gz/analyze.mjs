import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root='<TEMP>';
const raw=root+'/release297-role-ingest-unprofiled-0e427-01';
const out=root+'/release297-role-ingest-unprofiled-0e427-analysis-01';
mkdirSync(out);
const read=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const hash=b=>createHash('sha256').update(b).digest('hex');
const j=read(raw+'/usage-scale.json'),p=j.phases[0],a=p.api;
const operations=Object.fromEntries(Object.entries(a.operations.operations).filter(([,v])=>v.timings.operationMs.count||v.timings.holdMs.count).map(([k,v])=>[k,{
 counters:v.counters,operation:v.timings.operationMs,checkout:v.timings.checkoutMs,
 hold:{...v.timings.holdMs,meanMs:v.timings.holdMs.totalMs/v.timings.holdMs.count||0},
 sql:{...v.timings.sqlMs,meanMs:v.timings.sqlMs.totalMs/v.timings.sqlMs.count||0},
 activeOperations:v.activeOperations,activeCheckouts:v.activeCheckouts,pendingCheckouts:v.pendingCheckouts
}]));
for(const v of Object.values(operations))for(const key of ['operation','checkout','hold','sql'])delete v[key].buckets;
const waits=new Map();
for(const sample of p.pgWaitSamples)for(const row of sample.rows){const key=[row.role,row.state,row.wait_type,row.wait_event].join('/');const n=waits.get(key)||{key,samples:0,connections:0,max:0};n.samples++;n.connections+=Number(row.count);n.max=Math.max(n.max,Number(row.count));waits.set(key,n);}
const resource=Object.fromEntries(Object.entries(j.roleResources).map(([role,v])=>[role,{cpuMax:v.before.cpuMax,memoryMax:v.before.memoryMax,delta:v.delta}]));
const receipt={schemaVersion:1,source:j.sourceRevision,profile:j.profile,metricsSha256:hash(readFileSync(raw+'/usage-scale.json')),phaseStartedAt:p.startedAt,finishedAt:j.finishedAt,phaseMs:p.durationMs,diagnosticOnly:j.diagnosticOnly,capacityAccepted:j.capacityAccepted,cpuProfile:j.cpuProfile,
 heartbeats:p.traffic.heartbeats,persisted:p.insertedObservations,cpuMicroseconds:a.cpuMicroseconds,eventLoop:a.eventLoop,rssBytes:a.rssBytes,database:a.database,operations,resource,
 pgWaitSamples:p.pgWaitSamples.length,pgWaitGroups:[...waits.values()].sort((x,y)=>y.connections-x.connections),postgresPressure:p.postgresPressure.delta,
 preflightDrain:j.preflightDrain,phaseDrains:p.serverDrain,childShutdownClean:j.childShutdownClean,sourceUnchanged:j.sourceUnchangedAtFinish,roleResourceEvidenceComplete:j.roleResourceEvidenceComplete,
 hostExits:Object.fromEntries(['coordinator','api','worker','generator'].map(role=>[role,read(root+'/schoolpilot-role-control-2ecef5ccc4b1/host-receipts/'+role+'.json')])),cleanup:read(raw+'/all-owned-role-fixtures-cleanup.json'),failure:j.failure,
 limitations:['This is an unprofiled current-source ingestion diagnostic, not a combined report/rollup acceptance run.','Historical5d54 CPU attribution is not current-source attribution or a profiler A/B.','SQL elapsed time includes network and Node callback scheduling, not just PostgreSQL execution.','Cumulative lease/SQL/checkout durations overlap across requests and are not wall time.','Resource throttled_usec is not additional CPU consumption and cannot be added to wall/CPU time.']};
writeFileSync(out+'/compact-metrics.json',JSON.stringify(receipt,null,2)+'\n');
writeFileSync(out+'/analyze.mjs',readFileSync(new URL(import.meta.url)));
console.log(JSON.stringify({out,sha256:hash(readFileSync(out+'/compact-metrics.json')),waits:receipt.pgWaitGroups.slice(0,8),perSuccessfulFinalQueries:operations.heartbeat_final_delivery.sql.count/p.traffic.heartbeats.succeeded,perStartedCpuMs:(a.cpuMicroseconds.user+a.cpuMicroseconds.system)/1000/p.traffic.heartbeats.started}));
