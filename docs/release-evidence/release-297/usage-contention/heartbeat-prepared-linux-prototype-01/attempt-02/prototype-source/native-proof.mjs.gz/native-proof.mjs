import assert from 'node:assert/strict';
import test from 'node:test';
import {randomUUID,createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {withOwnedReadTransaction,labels,directConfig,rawTypes} from './owned-executor.mjs';
import {builders,rawBuilders,factories,dialect,orm,repo,sourceRepo} from './canonical-capture.mjs';
import {waitForTimingRelease,resourceSnapshot} from './timing-gate.mjs';
const {sql}=orm;
const mod=relative=>import(pathToFileURL(repo+'/'+relative).href);
test('external fixed-read executor native ownership/parity/cost proof',{timeout:1200000},async t=>{
 const {db,pool,sessionPool}=await mod('dist/db.js');
 const storage=await mod('dist/services/storage.js');
 const context=await mod('dist/middleware/tenantContext.js');
 const {tenantALS}=await mod('dist/db/tenantContext.js');
 const scoped=(schoolId,fn)=>context.runWithTenantContext({schoolId},fn);
 const enter=fn=>withOwnedReadTransaction(context.getOwnedTenantStore,fn);
 const id=()=>randomUUID(),tag='owned_fixed_'+id().replaceAll('-','');
 const createFixture=async()=>{
  const school=await storage.createSchool({name:tag+id(),slug:tag+id(),domain:tag+'.example.invalid'});
  const teacher=await storage.createUser({email:id()+'@'+tag+'.example.invalid',firstName:'Synthetic',lastName:'Executor'});
  await storage.createMembership({schoolId:school.id,userId:teacher.id,role:'teacher',status:'active'});
  await storage.createProductLicense({schoolId:school.id,product:'CLASSPILOT',status:'active'});
  return scoped(school.id,async()=>{
   const student=await storage.createStudent({schoolId:school.id,firstName:'Synthetic',lastName:'Executor',status:'active'});
   const group=await storage.createGroup({schoolId:school.id,teacherId:teacher.id,name:tag,groupType:'teacher_created'});
   await storage.addGroupStudentsDetailed(group.id,[student.id]);
   const deviceId=tag+'_'+id();await storage.createDevice({deviceId,schoolId:school.id,classId:'default'});
   const old=await storage.setActiveStudentForDevice(deviceId,student.id);
   await db.execute(sql`UPDATE student_sessions SET is_active=false,ended_at=now() WHERE id=${old.id}`);
   const studentSessionId=id();await db.execute(sql`INSERT INTO student_sessions(id,student_id,device_id,auth_kind,manual_lease_expires_at,session_recovery_token_hash) VALUES(${studentSessionId},${student.id},${deviceId},'manual_shared',clock_timestamp()+interval '1 hour',${id().replaceAll('-','')+id().replaceAll('-','')})`);
   const teaching=await storage.createTeachingSession({groupId:group.id,teacherId:teacher.id,startTime:new Date(Date.now()-60000)});
   await db.execute(sql`UPDATE classpilot_student_control_states SET revision=8,hard_expires_at=clock_timestamp()+interval '1 hour',scheduled_end_at=NULL WHERE school_id=${school.id} AND student_id=${student.id}`);
   return{school,student,teacher,group,values:{schoolId:school.id,studentId:student.id,studentSessionId,deviceId,teachingSessionId:teaching.id,controlRevision:8}};
  });
 };
 let proofFailures=0;const check=(name,fn)=>t.test(name,async child=>{try{return await fn(child);}catch(error){proofFailures++;throw error;}});
 const results=[];let a,b;
 try{
  assert.equal((await pool.query('SELECT rolsuper OR rolbypassrls AS bypass FROM pg_roles WHERE rolname=current_user')).rows[0].bypass,false);
  const policies=(await pool.query("SELECT relrowsecurity enabled,relforcerowsecurity forced FROM pg_class WHERE oid=ANY(ARRAY['students'::regclass,'devices'::regclass,'teaching_sessions'::regclass,'classpilot_student_control_states'::regclass])")).rows;
  assert.equal(policies.length,4);assert.ok(policies.every(p=>p.enabled&&p.forced));
  a=await createFixture();b=await createFixture();
  await check('nine canonical SQL/params and real row mappings agree in one restricted transaction',async()=>scoped(a.school.id,()=>enter(async({read})=>{
   for(const label of labels){
    const original=builders[label](new (await mod('node_modules/drizzle-orm/pg-core/index.js')).QueryBuilder(),a.values).toSQL();
    const flat=dialect.sqlToQuery(factories[label].bind(a.values));const direct=directConfig(label,a.values);
    assert.equal(direct.text,flat.sql);assert.equal(flat.sql.replace(/ as "__fixed_\d+"/g,''),original.sql);assert.deepEqual(direct.values,original.params);
    const c=await read(label,a.values,'canonical'),f=await read(label,a.values,'flat'),d=await read(label,a.values,'direct');assert.deepEqual(f,c,label);assert.deepEqual(d,c,label);assert.deepEqual(await read(label,a.values,'cached'),c,label);
    results.push({label,rows:c.length,exactParams:true,exactSqlApartFromOutputAliases:true,nativeRowsEqual:true});
   }
  })));
  await check('timestamp/null precision and fresh within-transaction updates preserve schema decoding',async()=>scoped(a.school.id,()=>enter(async({read,tx})=>{
   await tx.execute(sql`UPDATE student_sessions SET started_at='2026-11-01 01:30:00.123456'::timestamp WHERE id=${a.values.studentSessionId}`);
   await tx.execute(sql`UPDATE classpilot_student_control_states SET updated_at='2026-11-01 01:30:00.999999'::timestamp,scheduled_end_at=NULL WHERE school_id=${a.school.id} AND student_id=${a.student.id}`);
   for(const label of ['screenshot_session','screenshot_control','screenshot_candidate']){const c=await read(label,a.values,'canonical'),d=await read(label,a.values,'direct');assert.deepEqual(d,c);assert.deepEqual(await read(label,a.values,'cached'),c);assert.notEqual(d,c);if(c[0])assert.notEqual(d[0],c[0]);}
   await tx.execute(sql`UPDATE classpilot_student_control_states SET revision=9 WHERE school_id=${a.school.id} AND student_id=${a.student.id}`);
   assert.equal((await read('screenshot_control',a.values))[0].revision,9);
   assert.deepEqual(await read('foreground_fence',a.values),[]);
   await tx.execute(sql`UPDATE classpilot_student_control_states SET revision=8 WHERE school_id=${a.school.id} AND student_id=${a.student.id}`);
  })));
  await check('foreign school exact tuple cannot gain rows and fresh lease rejects an old store',async()=>{
   let escaped,oldStore,firstClient;
   await scoped(a.school.id,()=>enter(async({read,client})=>{escaped=read;firstClient=client;oldStore=context.getOwnedTenantStore();assert.throws(()=>read('live_binding',b.values),/Foreign tenant/);assert.deepEqual(await read('live_binding',{...b.values,schoolId:a.school.id}),[]);}));
   assert.throws(()=>escaped('live_binding',a.values),/no longer owned/);
   await scoped(b.school.id,()=>enter(async({read,client})=>{
    const oldResult=await tenantALS.run(oldStore,async()=>{assert.equal(context.getOwnedTenantStore(),undefined);await assert.rejects(enter(async()=>assert.fail('foreign retained store entered')),/Owned non-super/);return true;});assert.equal(oldResult,true);
    assert.equal(client,firstClient,'This case must exercise actual physical-client school reuse');assert.throws(()=>read('live_binding',a.values),/Foreign tenant/);assert.deepEqual(await read('live_binding',{...a.values,schoolId:b.school.id}),[]);assert.equal((await read('live_binding',b.values)).length,1);for(const label of ['locked_school','locked_license','screenshot_session','screenshot_control','screenshot_candidate'])assert.deepEqual(await read(label,b.values,'cached'),await read(label,b.values,'canonical'));
    results.push({samePhysicalClientAcrossSchoolReuse:client===firstClient,staleStoreRefused:true});
   }));
  });
  await check('concurrent owned transactions remain on different explicit clients',async()=>{
   let unblock;const gate=new Promise(r=>unblock=r);let entered;const ready=new Promise(r=>entered=r);let clientA;
   const first=scoped(a.school.id,()=>enter(async({read,client})=>{clientA=client;entered();await gate;assert.equal((await read('live_binding',a.values)).length,1);}));
   await ready;try{await scoped(b.school.id,()=>enter(async({read,client})=>{assert.notEqual(client,clientA);assert.equal((await read('live_binding',b.values)).length,1);assert.throws(()=>read('live_binding',a.values),/Foreign tenant/);}));}finally{unblock();await first;}
  });
  await check('nested entry and mutation of captured store fields are refused before a query',async()=>scoped(a.school.id,()=>enter(async({read})=>{
   await assert.rejects(enter(async()=>assert.fail('nested root must not start')),/Nested owned root|already-active external/);
   const store=context.getOwnedTenantStore();for(const [key,value] of [['client',{}],['db',{}],['schoolId',b.school.id],['isSuper',true]]){const old=store[key];try{store[key]=value;assert.throws(()=>read('live_binding',a.values),/no longer owned/);}finally{store[key]=old;}}
   assert.equal((await read('live_binding',a.values)).length,1);
  })));
  await check('an unrelated acknowledged outer transaction is refused and remains uncommitted',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore();const before=(await db.execute(sql`SELECT first_name FROM students WHERE id=${a.student.id}`)).rows[0].first_name;
   await assert.rejects(store.db.transaction(async tx=>{await tx.execute(sql`UPDATE students SET first_name='outer-must-rollback' WHERE id=${a.student.id}`);await assert.rejects(enter(async()=>assert.fail('foreign outer entered')),/already-active external/);assert.equal(store.client.getTransactionStatus(),'T');throw Error('expected_outer_rollback');}),/expected_outer_rollback/);
   assert.equal((await db.execute(sql`SELECT first_name FROM students WHERE id=${a.student.id}`)).rows[0].first_name,before);assert.equal(store.client.getTransactionStatus(),'I');
  }));
  await check('failed callback closes token before pending real query settles and before rollback',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore(),original=store.client.query;let release;const gate=new Promise(r=>release=r);let began;const ready=new Promise(r=>began=r);let rawSettled=false,rollback=false,escaped;
   store.client.query=function(config,...args){const text=typeof config==='string'?config:config.text;if(/^rollback$/i.test(text)){rollback=true;assert.equal(rawSettled,true);}const actual=original.call(this,config,...args);if(text.includes('SELECT "student_sessions"."id"'))return actual.then(async v=>{began();await gate;rawSettled=true;return v;});return actual;};
   const op=enter(async({read})=>{escaped=read;void read('live_binding',a.values);await ready;throw Error('intentional_callback_abort');});void op.catch(()=>{});
   try{await ready;await new Promise(r=>setImmediate(r));assert.equal(rollback,false);assert.throws(()=>escaped('live_binding',a.values),/no longer owned/);release();await assert.rejects(op,/intentional_callback_abort/);assert.equal(rollback,true);}finally{release();await Promise.allSettled([op]);store.client.query=original;}
  }));
  await check('actual row-lock wait settles before caller-aborted ownership is released',async()=>{
   let unlock;const gate=new Promise(r=>unlock=r);let locked;const ready=new Promise(r=>locked=r);
   const writer=scoped(a.school.id,()=>context.getOwnedTenantStore().db.transaction(async tx=>{await tx.execute(sql`UPDATE students SET first_name=first_name WHERE id=${a.student.id}`);locked();await gate;}));await ready;
   let done=false,readFinished=false;const start=performance.now();
   const reader=scoped(a.school.id,()=>enter(async({read})=>{void read('live_binding',a.values).then(()=>readFinished=true);throw Error('intentional_caller_abort');})).finally(()=>done=true);
   void reader.catch(()=>{});try{await new Promise(r=>setTimeout(r,70));assert.equal(done,false);assert.equal(readFinished,false);unlock();await writer;await assert.rejects(reader,/intentional_caller_abort/);assert.equal(readFinished,true);assert.ok(performance.now()-start>=65);}finally{unlock();await Promise.allSettled([writer,reader]);}
  });
  await check('an early rejected unawaited mandatory read cannot become transaction success',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore(),original=store.client.query;let committed=false;
   store.client.query=function(config,...args){const text=typeof config==='string'?config:config.text;if(/^commit$/i.test(text))committed=true;return original.call(this,config,...args);};
   try{await assert.rejects(enter(async({read})=>{void read('foreground_fence',{...a.values,controlRevision:'invalid-native-integer'});await new Promise(r=>setTimeout(r,30));return 'must-not-succeed';}),error=>error.code==='22P02');assert.equal(committed,false);}finally{store.client.query=original;}
  }));
  await check('fresh manual expiry and entitlement fence results remain canonical',async()=>scoped(a.school.id,()=>enter(async({read,tx})=>{
   await tx.execute(sql`UPDATE student_sessions SET manual_lease_expires_at=clock_timestamp()+interval '30 milliseconds' WHERE id=${a.values.studentSessionId}`);await tx.execute(sql`SELECT pg_sleep(0.04)`);
   for(const label of ['live_binding','final_fence','foreground_fence'])assert.deepEqual(await read(label,a.values),await read(label,a.values,'canonical'));
   assert.deepEqual(await read('live_binding',a.values),[]);
   await tx.execute(sql`UPDATE student_sessions SET manual_lease_expires_at=clock_timestamp()+interval '1 hour' WHERE id=${a.values.studentSessionId}`);
  })));
  await check('raw driver date/array parser contract matches the pinned Drizzle path',async()=>scoped(a.school.id,()=>enter(async({tx,client})=>{
   const text="SELECT '2026-11-01 01:30:00.123456'::timestamp AS ts, '2026-11-01 01:30:00.123456+00'::timestamptz AS tz, '2026-11-01'::date AS day, '1 day 02:00:00'::interval AS span, ARRAY['2026-11-01'::date] AS dates, ARRAY[1.5::numeric] AS nums";
   const c=await tx.execute(sql.raw(text)),d=await client.query({text,types:rawTypes});assert.deepEqual(d.rows,c.rows);assert.equal(typeof d.rows[0].ts,'string');assert.match(d.rows[0].ts,/123456/);
  })));

  await check('cached SELECT uses exact unnamed pg config and original mappers with fresh params',async()=>scoped(a.school.id,()=>enter(async({read,client})=>{
   const original=client.query,captured=[];
   client.query=function(config,values,...args){if(typeof config==='object'&&config.text&&config.name==='')captured.push({text:config.text,name:config.name,values:[...values],rowMode:config.rowMode});return original.call(this,config,values,...args);};
   try{for(const label of ['locked_school','locked_license','screenshot_session','screenshot_control','screenshot_candidate']){const c=await read(label,a.values,'canonical');const before=captured.length;const d=await read(label,a.values,'cached');assert.deepEqual(d,c);assert.equal(captured.length,before+1);const call=captured.at(-1),expected=builders[label](new (await mod('node_modules/drizzle-orm/pg-core/index.js')).QueryBuilder(),a.values).toSQL();assert.equal(call.text,expected.sql);assert.deepEqual(call.values,expected.params);assert.equal(call.name,'');assert.equal(call.rowMode,'array');}}finally{client.query=original;}
  })));
  await check('cached SELECT survives owner DDL between restricted leases without named-plan state',async()=>{
   const {Client}=createRequire(repo+'/package.json')('pg');const admin=new Client({connectionString:process.env.ADMIN_DATABASE_URL,statement_timeout:15000});await admin.connect();let clientBefore;
   try{
    await scoped(a.school.id,()=>enter(async({read,client})=>{clientBefore=client;await read('screenshot_session',a.values,'cached');}));
    await admin.query("ALTER TABLE student_sessions ALTER COLUMN started_at TYPE timestamp(3) USING started_at::timestamp(3)");
    await scoped(a.school.id,()=>enter(async({read,client})=>{assert.equal(client,clientBefore);const cached=await read('screenshot_session',a.values,'cached');assert.deepEqual(cached,await read('screenshot_session',a.values,'canonical'));assert.ok(cached[0].startedAt instanceof Date&&Number.isFinite(cached[0].startedAt.getTime()));}));
   }finally{try{await admin.query("ALTER TABLE student_sessions ALTER COLUMN started_at TYPE timestamp USING started_at::timestamp");}finally{await admin.end();}}
   await scoped(a.school.id,()=>enter(async({read})=>assert.deepEqual(await read('screenshot_session',a.values,'cached'),await read('screenshot_session',a.values,'canonical'))));
  });
  await check('early unawaited cached read failure is sticky and cannot COMMIT',async()=>scoped(a.school.id,async()=>{
   const store=context.getOwnedTenantStore(),original=store.client.query;let committed=false;
   store.client.query=function(config,...args){const text=typeof config==='string'?config:config.text;if(/^commit$/i.test(text))committed=true;if(config?.name===''&&text.includes('student_sessions'))return Promise.reject(Error('injected_cached_read_failure'));return original.call(this,config,...args);};
   try{await assert.rejects(enter(async({read})=>{void read('screenshot_session',a.values,'cached');await new Promise(r=>setImmediate(r));}),error=>error.cause?.message==='injected_cached_read_failure');assert.equal(committed,false);}finally{store.client.query=original;}
  }));
  assert.equal(proofFailures,0,'All native correctness cases must pass before the ready gate');
  await waitForTimingRelease();
  const resourceBefore=resourceSnapshot();
  // CPU/wall experiment on one native restricted client/transaction. Order of
  // query labels is identical; alternatives alternate each round, never concurrent.
  const eligibleOrder=['locked_school','locked_license','live_binding','screenshot_session','screenshot_control','screenshot_candidate','live_binding','final_fence'];
  const benchmark=[];await scoped(a.school.id,()=>enter(async({read})=>{
   for(const mode of ['canonical','flat','direct','cached'])for(const label of eligibleOrder)assert.equal((await read(label,a.values,mode)).length,1,'benchmark must read the populated positive fixture');
   for(let round=0;round<3;round++)for(const mode of round%2?['cached','direct','flat','canonical']:['canonical','flat','direct','cached']){
    const cpu=process.cpuUsage(),start=performance.now();for(let n=0;n<1000;n++)for(const label of eligibleOrder)await read(label,a.values,mode);
    benchmark.push({round,mode,iterations:1000,queries:1000*eligibleOrder.length,wallMs:performance.now()-start,cpuMicroseconds:process.cpuUsage(cpu)});
   }

  }));
  const sourceFiles=['src/services/storage.ts','src/services/classpilotEntitlement.ts','src/middleware/tenantContext.ts','dist/services/classpilotStudentSessionAuthority.js','node_modules/drizzle-orm/package.json'];
  const receipt={schemaVersion:1,source:'0e427e3ca9b82125e0bb8692176accad21f4f699',applicationEdits:0,capacityAccepted:false,namedPreparedStatements:false,sqlOrder:eligibleOrder,excludedFromBenefit:['unlocked_entitlement (middleware outside private root)','foreground_fence (optional SAVEPOINT semantics excluded)'],parity:results,benchmark,resourceBefore,resourceAfter:resourceSnapshot(),sourceBindings:sourceFiles.map(file=>({file,sha256:createHash('sha256').update(readFileSync((file.startsWith('src/')?sourceRepo:repo)+'/'+file)).digest('hex')})),limitations:['One synthetic restricted local fixture with two schools; no API workload or capacity claim.','Eight-read sequence models only eligible fixed reads; intervening other production queries/side effects remain outside this comparison.','Each alternative uses identical sequence/row predicates inside one actual transaction; no lock/fence removal.','No named prepared plans or custom DDL retry. Cached mode uses five public Drizzle prepare-empty-name SELECTs and canonical raw fences; direct and flat retain their existing explicit decoder proof.','All reads are mandatory in this closed prototype; sticky read failure prevents unawaited failure from being forgotten. A production optional SAVEPOINT recovery scope requires separate explicit proof before adoption.','Actual Date/null/raw-array result parity and ownership failure checks are covered; this is not complete production authority-race acceptance.','Public pg transaction status guards acknowledged outside transactions; exclusive private root ownership is still required against concurrently queued foreign BEGIN.']};
  writeFileSync(process.env.OWNED_EXECUTOR_RESULT,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 }finally{await context.drainTenantContextReleases();await Promise.allSettled([pool.end(),sessionPool.end()]);}
});
