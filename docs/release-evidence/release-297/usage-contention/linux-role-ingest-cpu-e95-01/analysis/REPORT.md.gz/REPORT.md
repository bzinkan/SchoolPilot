# Exact e95 API CPU diagnostic

The run failed ingestion capacity: 6000 offered, 5081 successful, 478 failed, 441 refused at the existing in-flight ceiling, zero late offers. API CPU was 68.140 seconds over a 68.523-second reset-through-drained-snapshot window (ELU 0.996916); cgroup throttling was 30.371 seconds with 669 of 686 periods throttled. All child exits were unforced zero, coordinator exit was 1, both server drains had zero owners/aborts, and all six containers plus the recorded PostgreSQL volume were removed. The valid profile is diagnostic only and includes profiler overhead.

## Attribution

The 68.523272-second monotonic window lies inside the original 85.577946-second profile. Exactly 50,582 selected samples cover the clipped window; no negative deltas occurred. These are sampled elapsed intervals, not a partition of process CPU seconds. Exclusive category groups partition the window. Inclusive paths and families overlap and must not be added.

Drizzle self totals 8.183 seconds, but compiler-family union is 3.682 seconds; all Drizzle is not removable compilation. Pg row metadata/decoding accounts for 2.487 seconds self / 3.286 inclusive, including addFields at 1.669 self. ORM mapping is only 0.445 inclusive. Native writev contains 4.533 seconds under pg.submit; writeBuffer contains 1.448 under pg._send. Those spans include native/scheduling effects and do not measure purely SQL transport or server CPU. Complete self and inclusive family definitions/results are retained in families-and-operations.json and its source script.

## Ranked bounded recommendations

1. Only bounded raw-fence compilation reuse has directly identified repeated construction work. Nearest application construction frames are storage.ts:25085 live binding 0.821327 seconds; storage.ts:20505 final binding/entitlement 0.567708; storage.ts:20612 foreground temporal fence 0.515503. Their disjoint nearest-caller construction sum is 1.904538 seconds (2.78% of the sampled window), not a throughput forecast. Canonical clocks, SQL/parameter encoding, ordering, locks and queries must remain. The existing prepared read token is sealed before the final fence; reuse cannot reopen it or bypass its final synchronous settled guard. No application change is justified as a capacity fix by this envelope alone.
2. Await the separate closed result-width audit before additional implementation. Pg field metadata is meaningful, but the five prepared SELECTs already return only 7/1/4/6/8 fields. The profile does not tie addFields to a specific remaining broad result. A narrower projection requires exact consumer proof; no removal of any fresh authority read is proposed.
3. Do not optimize global middleware/async hooks from inclusive totals. Final-core callback 5.223 seconds, heartbeat route 3.432, Usage request 2.779, tenant middleware 2.723, cached read 2.462 and screenshot projection 2.129 are overlapping downstream stacks. Async hooks self is 1.711 seconds and instrumentation self 1.349; their larger inclusive totals contain actual downstream operations. Capability checking is 0.598 seconds self and rollout parsing already caches raw configuration. Telemetry family is 1.592 self / 1.992 inclusive; bounded cloning and transport cannot simply be removed.

## Pool and PostgreSQL context

Final delivery held 5081 leases for 846.013 aggregate seconds (166.505 ms mean), 108637 SQL calls / 770.617 aggregate SQL seconds; mean checkout wait 3148.58 ms. Persistence held 5295 leases for 203.526 aggregate seconds (38.437 ms mean), 21206 SQL calls / 200.282 aggregate SQL seconds; mean checkout wait 3003.61 ms. Aggregate holds/SQL overlap across clients and are not CPU time. There were no SQL failures, 478 acquisition failures and no optional telemetry/inbox failures.

PG observer tallies are summed concurrent sampled waiters, not time: idle-in-transaction ClientRead 2514, idle ClientRead 1216, active/no-wait 315, WALWrite 179, WALSync 77. No sampled lock/advisory wait appears. Evidence supports CPU/scheduling and many sequential protocol operations, but does not identify one safely removable transaction, lock or final check.

## Limitations and retained failures

This restored ingestion-only run is not a controlled comparison with full combined or fresh-seed historical runs. No report/worker capacity claim is made. The earlier restored attempt failed before offering any traffic because Redis joined the pre-restart PG network namespace; API was force-stopped and its empty profile is unusable. That attempt remains unchanged. A separate zero-traffic namespace proof confirmed the cause. The corrected adapter only moves Redis creation/readiness after the PG cold restart, matching the original runner.
