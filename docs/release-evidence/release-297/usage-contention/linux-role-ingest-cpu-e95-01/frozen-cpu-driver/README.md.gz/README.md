# Linux role workload

This successor preserves the original release-enabled workload and runs its API,
worker, generator and coordinator in separate, owned Linux containers. It uses
the candidate's untouched Node, dependencies and compiled application under
`/app`. The clean application checkout is `/source`; generated harness files are
under `/diagnostic`; ownership/runtime modules are `/prototype`.

API: 1 CPU / 2 GiB, worker: 0.5 CPU / 1 GiB, driver: 2 CPU / 1 GiB,
coordinator: 0.5 CPU / 1 GiB. PostgreSQL remains 4 CPU / 4 GiB and Redis remains
1 CPU / 256 MiB. Pools, acquisition/statement/request deadlines and the original
report and worker acceptance thresholds are unchanged. Runtime roles use the
candidate's default V8 settings, with numeric heap/cgroup observations retained.
The historical seeder still uses its existing 512 MiB heap and memory assertion.
These are declared synthetic limits. In particular, the local PostgreSQL
4 CPU / 4 GiB cap is not the dated production `db.t4g.medium` configuration.
A local campaign result cannot establish actual production headroom; deployed
Usage observation and current production evidence remain separate requirements.

The diagnostic entry point supports the complete 60-second, 6,000-offer ingest
or combined workload (64 reports and both million-observation school workers).
It never applies the historical diagnostic 10-second shortcut. Current Focus
ACK/public-state checks and lifecycle proofs come from the exact source's
canonical generator. API main/session and worker pools receive one additional
pre-measurement restricted-role/GUC verification on the actual pool.

`prepare-context.ps1` takes an exact clean repository commit, its passing image
scan receipt, a new context directory and a separate new host checkout. Install
host fixture dependencies there; do not install them in the Docker context.
`build-role-helper.mjs` builds locally from the bound candidate and verifies the
untouched runtime in a network-disabled owned probe. No image is pushed.
`run-role-scale.ps1` uses the host checkout and helper binding, creates only owned
local fixtures and stops at `measurement-ready.json` before the cold restart.
The exact nonce/source/image/harness/profile marker must be released by the
operator before measurement. Inspect the resulting owned exit and cleanup
receipts even when the workload fails.

**Acceptance is not yet enabled.** Every single run has `capacityAccepted:false`.
The candidate mode is refused until the raw-receipt loader, snapshot restore
proof and complete three-run campaign validation are integrated and reviewed.
Historical diagnostics cannot be relabeled as accepted runs. The receipt-loader
module is preparation for that next step, not an active acceptance command.

Run the pure guard suite with:

```text
node --test tests/private-load-usage-profiles.test.mjs
```

The original scripts and previous failure artifacts remain unchanged. Cold
means fresh processes and PostgreSQL shared buffers, not flushed host caches.
Synthetic protocol acknowledgements do not establish managed-browser behavior,
production RDS capacity or the separate deployed Usage observation days.
