$ErrorActionPreference = 'Stop'
$repository = '<user-home>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$output = '<user-home>\AppData\Local\Temp\release297-contention-final-checks-05'
if (Test-Path -LiteralPath $output) { throw 'Evidence directory already exists' }
New-Item -ItemType Directory -Path $output | Out-Null
Set-Location -LiteralPath $repository
$env:NODE_ENV = 'test'; $env:SCHEDULER_ENABLED = 'false'; $env:REDIS_URL = ''
Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
$env:DOTENV_CONFIG_PATH = Join-Path $output 'absent-dotenv'; $env:DOTENV_CONFIG_QUIET = 'true'
$names = @(git ls-files --cached --others --exclude-standard -- src tests scripts package.json package-lock.json tsconfig.json | Sort-Object -Unique)
function Snapshot { @($names | ForEach-Object { [ordered]@{ path=$_; sha256=(Get-FileHash -LiteralPath (Join-Path $repository $_) -Algorithm SHA256).Hash.ToLower() } }) }
$before = Snapshot
$before | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-before.json')
$start=[DateTime]::UtcNow.ToString('o')
& npm.cmd run test:unit *> (Join-Path $output 'unit.log')
$code=$LASTEXITCODE
$after=Snapshot
$after | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-after.json')
$result=[ordered]@{sourceHead=(git rev-parse HEAD).Trim(); startedAt=$start; finishedAt=[DateTime]::UtcNow.ToString('o'); unitExit=$code; sourceFileCount=$before.Count; sourceUnchanged=(@(Compare-Object ($before | ConvertTo-Json -Depth 6) ($after | ConvertTo-Json -Depth 6)).Count -eq 0); configuration='DATABASE_URL absent, matching ordinary unit CI; individual unit fixtures configure their own imports'; purpose='Combined unit verification after Stop Focus exact V2 transport correction; native/frame tests have separate database-lane evidence'; output=$output}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'result.json')
$result | ConvertTo-Json -Depth 6
if ($code -ne 0 -or -not $result.sourceUnchanged) {exit 1}
