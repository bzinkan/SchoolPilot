# External Linux diagnostic prototype — not executed

Prepared 2026-10-03. No tracked SchoolPilot files changed. No Docker calls, image builds, fixture creation, database requests, AWS calls, or load measurements were made by this preparation. This is a reviewable prototype, not release evidence or deployment approval.

The observed checkout HEAD was `bcb2b33c6ef08243a1147d9818cfe3d668ea3f27` with pending integration changes. `generated-01/prototype-source-receipt.json` records that state and exact input helper hashes. Regenerate against the later clean committed source before considering an image build. The future candidate and diagnostic image IDs remain unbound.

## What it measures and what it cannot prove

Native Windows Node was v22.18.0, V8 12.4.254.21-node.27, libuv 1.51.0, OpenSSL 3.0.16. Previously read local Docker metadata showed Linux x86_64, WSL2 kernel 6.6.87.2, 16 CPUs, 33,577,676,800 bytes available, cgroup v2. The available historical candidate/fallback runtime used Node 22.23.3. These observations are context, not a binding to the next candidate.

The native profile crosses the Windows/Docker Desktop boundary for every PostgreSQL and Redis request. Its CPU profile can therefore include host-specific socket/writev behavior. That is a confound worth investigating; it does not invalidate the recorded failed Windows runs or prove Linux will pass. The proposed diagnostic uses the exact future candidate runtime and production dependencies, with PG/Redis/API traffic on a shared Linux loopback namespace.

One diagnostic container forks the unchanged API, worker, and generator with the existing IPC protocol and 512 MiB old-space caps. Their CPU and RSS are still not limited per role. This does not reproduce the documented production API 1 vCPU/2 GiB or worker 0.5 vCPU/1 GiB task isolation. PG remains 4 CPUs/4 GiB, Redis 1 CPU/256 MiB; pools remain 16 API + 2 session + 5 worker, with all existing deadlines and assertion thresholds. Evidence uses a Windows external bind mount, so logging still crosses the host filesystem boundary. Cold restart resets PG shared buffers, not host filesystem caches or RDS I/O.

The profile is `release-enabled-linux-shared-namespace-diagnostic-100rps-v1`. It sets `diagnosticOnly:true` and permanently `capacityAccepted:false`. It retains the complete 60-second, 6,000-heartbeat and 64-report workload, all capability/lifecycle checks, exact correctness checks, and drain/failure counters. `diagnosticChecksPassed` reports whether every existing technical check passed; `acceptanceRun` remains false. No old capacity result is reinterpreted.

## Files and preparation path

- `prototype-core.mjs`: exact-anchor Node patches, fixed environment allowlist, argument construction, and owned cleanup.
- `create-prototype.mjs`: creates fresh external patched Node/PowerShell files; rejects changed upstream anchors.
- `prepare-context.ps1`: later creates a self-contained shallow local Git clone at an exact clean source, `core.autocrlf=false`, no alternates, no inherited ignored files. Requires an exact passing candidate scan receipt. It does not build or run Docker.
- `Dockerfile.prototype`: derives from an immutable candidate ID. It adds Git, refusing changes to pre-existing APK versions, Node bytes/versions, production node_modules, compiled dist, or package manifests. The clean app Git tree stays in `/app`; the separately hash-bound diagnostic harness is in `/diagnostic`.
- `verify-runtime.mjs`: checks runtime/source/harness bindings before any measurement. No app process or DB is started by this verifier.
- `generated-01/run-linux-diagnostic.prototype.ps1`: preserves the existing host fixture preparation, then changes only internal PG port to 5437 and Redis to 6387. Redis and the harness join the exact owned PG container ID after the cold restart. Existing loopback URL guards remain intact.
- `launch-linux-diagnostic.mjs`: exact local image/revision checks, no healthcheck, real existing prewarm, readonly root, no Docker socket, no cloud credentials, no privileged mode or new port publications. Only fixed synthetic fixture variables are forwarded. No shell interpolation is used, including Windows paths with spaces.
- `cleanup-linux-fixtures.mjs`: bounded Docker calls; exact owned harness → Redis → PG cleanup, continuing after one cleanup error. An unconfirmed kill/removal is failure. Inner children escalate to SIGKILL after the existing shutdown deadline, marking the diagnostic failed.

After parent approval and a clean final source, the operator would: build/scan the exact candidate separately; run `prepare-context.ps1` against its passing scan receipt; build the diagnostic image locally with immutable candidate ID and source/candidate OCI labels; capture derived image/config/runtime hashes; create a reviewed `diagnostic-image-binding.json`; install host preparation dependencies in the clean clone; then invoke the generated runner with that clone, exact image binding, and fresh evidence directory. The image receipt needs `applicationSource`, `candidateImageId`, `diagnosticImageId`, `diagnosticOnly:true`, `prototypeValidated:true`; these are not filled from guessed values. Source clean/runtime identity and byte checks run again before measurement.

The diagnostic image contains local Git metadata and must never be published or deployed. Host fixture preparation remains the existing Windows procedure; the measured API/worker/generator use the candidate Linux bytes. Native scanner/Docker build and actual orchestration still require validation in an approved non-capacity window. Source-generator tests do not prove those operations work.

## Validation retained

`mock-tests-01.log`: 13 passed, 1 failed because JavaScript replacement-string `$'` expansion corrupted the generated PowerShell text. Fixed by functional replacement; the original log is retained.

`mock-tests-02.log`: 14/14 passed. `mock-tests-03.log`: 15/15 passed, including continued PG cleanup after Redis cleanup fails. Tests exercise full-workload selection, unchanged acceptance function, source/harness separation, fail-closed anchors, environment filtering, paths with spaces, identity mismatches, unknown create outcomes, and cleanup failures. `parse-01.json`: both proposed PowerShell scripts parse without errors. No native runtime or capacity acceptance is claimed.

Stop all external validation/build activity during the parent's timed capacity runs. Preserve all earlier Windows and diagnostic failures unchanged.
