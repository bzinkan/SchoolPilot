import assert from 'node:assert/strict';
import net from 'node:net';
import { once } from 'node:events';
import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createFairMainPoolClass } from './fair-main-pool.mjs';
const require = createRequire('C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/package.json');
const pg = require('pg');
const probe = net.createServer(); probe.listen(0, '127.0.0.1'); await once(probe, 'listening');
const port = probe.address().port; await new Promise(resolve => probe.close(resolve));
const results = [];
for (const variant of ['native-baseline', 'fair-prototype']) {
  let live = 0, peak = 0, constructed = 0, closed = 0;
  class ObservedClient extends pg.Client {
    constructor(options) {
      super(options); constructed++; live++; peak = Math.max(peak, live);
      this.connection.stream.once('close', () => { live--; closed++; });
    }
  }
  const Pool = variant === 'native-baseline' ? pg.Pool : createFairMainPoolClass(pg.Pool, { readOperation: () => 'default' });
  const pool = new Pool({ host: '127.0.0.1', port, user: 'synthetic_unused', database: 'synthetic_unused',
    max: 16, connectionTimeoutMillis: 5000, idleTimeoutMillis: 0, Client: ObservedClient });
  pool.on('error', () => {});
  const started = performance.now();
  const requests = Array.from({ length: 64 }, () => pool.connect().then(client => { client.release(); return 'unexpected-connected'; }, error => error.code ?? error.name));
  const outcomes = await Promise.all(requests); await pool.end();
  const liveWhenEndResolved = live;
  await new Promise(resolve => setTimeout(resolve, 20));
  results.push({ variant, configuredMax: 16, offers: 64, constructed, closed, peakSocketObjectsBeforeClose: peak,
    liveWhenEndResolved, finalLive: live, elapsedMs: performance.now() - started,
    outcomes: Object.fromEntries([...new Set(outcomes)].map(code => [code, outcomes.filter(x => x === code).length])) });
}
const receipt = { schemaVersion: 1, createdAt: new Date().toISOString(), fixture: 'Fresh local unused TCP port; no database or external network',
  adapterSha256: createHash('sha256').update(readFileSync(new URL('./fair-main-pool.mjs', import.meta.url))).digest('hex'),
  semantics: 'Counted real pg.Client socket objects from constructor until actual net.Socket close; baseline retained for comparison', results };
writeFileSync(new URL('./native-socket-proof-03.json', import.meta.url), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(receipt));
assert.equal(results[1].finalLive, 0);
assert.equal(results[1].outcomes.ECONNREFUSED, 64); // Closing-socket ceiling is explicitly not the native pool ceiling.
assert.equal(results[1].liveWhenEndResolved, 0, 'Fair end must await pre-connect socket cleanup');
