$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$name='schoolpilot-inspector-fixture-'+$run
$engine='npipe:////./pipe/dockerDesktopLinuxEngine'
$pwdOwner=[guid]::NewGuid().ToString('N');$pwdReader=[guid]::NewGuid().ToString('N')
$created=$false;$cleanup=$false;$exitCode=99
$out=Join-Path $root ('native-'+$run);New-Item -ItemType Directory -Path $out|Out-Null
try{
 $image=(docker --host $engine inspect schoolpilot-db --format '{{.Image}}').Trim()
 if($LASTEXITCODE -or $image -cnotmatch '^sha256:[a-f0-9]{64}$'){throw 'Local fixture donor image unknown'}
 docker --host $engine run --detach --name $name --label "codex.metadata-fixture=$run" --cpus 1 --memory 512m --publish '127.0.0.1::5432' --env 'POSTGRES_DB=schoolpilot' --env 'POSTGRES_USER=fixture_owner' --env "POSTGRES_PASSWORD=$pwdOwner" $image *> (Join-Path $out 'create.log')
 if($LASTEXITCODE){throw 'Fixture creation failed'};$created=$true
 $ready=$false;for($i=0;$i -lt 40;$i++){docker --host $engine exec $name pg_isready -h 127.0.0.1 -U fixture_owner -d schoolpilot *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250}
 if(-not $ready){throw 'Owned fixture not ready'}
 $ports=docker --host $engine inspect $name --format '{{json .NetworkSettings.Ports}}'|ConvertFrom-Json
 if($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1'){throw 'Nonlocal fixture refused'};$port=$ports.'5432/tcp'[0].HostPort
 "CREATE ROLE fixture_reader LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$pwdReader';"|docker --host $engine exec -i $name psql -U fixture_owner -d schoolpilot -v ON_ERROR_STOP=1 *> (Join-Path $out 'role.log')
 if($LASTEXITCODE){throw 'Fixture role failed'}
 $env:INSPECTOR_FIXTURE_OWNER="[REDACTED_DATABASE_URL]";$env:INSPECTOR_FIXTURE_READER="[REDACTED_DATABASE_URL]"
 node (Join-Path $root 'test-inspector-native.mjs') *> (Join-Path $out 'native.log');$exitCode=$LASTEXITCODE
}finally{
 Remove-Item Env:INSPECTOR_FIXTURE_OWNER,Env:INSPECTOR_FIXTURE_READER -ErrorAction SilentlyContinue
 if($created){$labels=docker --host $engine inspect $name --format '{{json .Config.Labels}}'|ConvertFrom-Json;if($name -cne ('schoolpilot-inspector-fixture-'+$run) -or $labels.'codex.metadata-fixture' -cne $run){throw 'Cleanup ownership mismatch'};docker --host $engine rm -f $name *> (Join-Path $out 'cleanup.log');$cleanup=$LASTEXITCODE -eq 0}
 [ordered]@{at=[DateTimeOffset]::UtcNow.ToString('o');container=$name;image=$image;exitCode=$exitCode;ownedFixtureRemoved=$cleanup;productionMutations=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8NoBOM
}
Get-Content -LiteralPath (Join-Path $out 'native.log') | Select-Object -Last 25
Write-Output "Native fixture evidence: $out"
if($exitCode -or -not $cleanup){exit 1}
