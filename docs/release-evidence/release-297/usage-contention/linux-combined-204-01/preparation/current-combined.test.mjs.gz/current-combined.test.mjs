import test from'node:test';import assert from'node:assert/strict';import{readFileSync}from'node:fs';
import{patchRunner}from'./create-prototype.mjs';
const source=readFileSync('C:/Users/zinka/AppData/Local/Temp/release297-linux-204-candidate-source-01/scripts/load/usage/run-release-enabled-scale.ps1','utf8').replaceAll('\r\n','\n');
test('exact release gate precedes current combined cold restart and launch',()=>{
 const runner=patchRunner(source),gate=runner.indexOf("node (Join-Path $prototypeDirectory 'measurement-gate.mjs')");
 assert.ok(gate>runner.indexOf('Canonical release control preparation failed'));assert.ok(gate<runner.indexOf('restart $container'));
 assert.ok(gate<runner.indexOf("'launch-linux-diagnostic.mjs'"));assert.match(runner,/\$Phase -cne 'combined' -or \$CollectApiCpuProfile/);
 assert.match(runner,/--cpus 4 --memory 4g/);assert.match(runner,/--cpus 1 --memory 256m/);
});
test('runtime proof rejects carried-over SQL instrumentation and matches actual API/generator source',()=>{
 const probe=readFileSync(new URL('./runtime-probe.mjs',import.meta.url),'utf8');
 assert.match(probe,/\['release-enabled-process\.mjs','release-enabled-generator\.mjs'\]/);
 assert.match(probe,/existsSync\('\/diagnostic\/scripts\/load\/usage\/\'\+name\),false/);
 assert.match(probe,/sqlShapeInstrumentationPresent:false,collectApiCpuProfile:false/);
});
