#requires -Version 7.5
# EXTERNAL PROTOTYPE. Creates only a fresh local context; never invokes Docker.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Repository,
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{40}$')][string]$SourceSha,
  [Parameter(Mandatory=$true)][ValidatePattern('^sha256:[a-f0-9]{64}$')][string]$CandidateImageId,
  [Parameter(Mandatory=$true)][string]$CandidateScanReceipt,
  [Parameter(Mandatory=$true)][string]$HostFixtureDirectory,
  [Parameter(Mandatory=$true)][string]$ContextDirectory
)
$ErrorActionPreference = 'Stop'
$contextPath = [IO.Path]::GetFullPath($ContextDirectory)
$repositoryPath = [IO.Path]::GetFullPath($Repository)
$hostFixturePath = [IO.Path]::GetFullPath($HostFixtureDirectory)
if (Test-Path -LiteralPath $contextPath) { throw 'Use a fresh external context; nothing is overwritten or removed.' }
if (Test-Path -LiteralPath $hostFixturePath) { throw 'Use a separate fresh host fixture checkout.' }
if ($contextPath.StartsWith($repositoryPath + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Context must be outside the repository.' }
foreach ($pair in @(@($hostFixturePath,$contextPath),@($contextPath,$hostFixturePath),@($hostFixturePath,$repositoryPath))) {
  if ($pair[0].Equals($pair[1],[StringComparison]::OrdinalIgnoreCase) -or $pair[0].StartsWith($pair[1]+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Host preparation must be outside both Docker context and source repository.' }
}
$head = (& git -C $repositoryPath rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $head -cne $SourceSha) { throw 'Exact current source required.' }
$status = (& git -C $repositoryPath status --porcelain) -join "`n"
if ($LASTEXITCODE -ne 0 -or $status.Length -ne 0) { throw 'Commit all source and evidence before preparing context.' }
$scan = Get-Content -LiteralPath $CandidateScanReceipt -Raw | ConvertFrom-Json -DateKind String
if ($scan.passed -ne $true -or $scan.sourceSha -cne $SourceSha -or $scan.imageId -cne $CandidateImageId -or $scan.counts.HIGH -ne 0 -or $scan.counts.CRITICAL -ne 0) { throw 'Require exact candidate source/image passing scan receipt from verify-legacy-deploy-image.mjs.' }
$scanHash = (Get-FileHash -LiteralPath $CandidateScanReceipt -Algorithm SHA256).Hash.ToLower()
New-Item -ItemType Directory -Path $contextPath | Out-Null
$clonePath = Join-Path $contextPath 'clean-source'
& git init $clonePath | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Owned clone init failed.' }
& git -C $clonePath config core.autocrlf false
if ($LASTEXITCODE -ne 0) { throw 'LF clone configuration failed.' }
& git -C $clonePath config core.longpaths true
if ($LASTEXITCODE -ne 0) { throw 'Clone-local long-path configuration failed.' }
$localUri = [Uri]::new($repositoryPath + [IO.Path]::DirectorySeparatorChar).AbsoluteUri
& git -C $clonePath fetch --depth 1 --no-tags $localUri $SourceSha | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Self-contained local exact commit fetch failed.' }
& git -C $clonePath checkout --detach $SourceSha | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Exact checkout failed.' }
if (Test-Path -LiteralPath (Join-Path $clonePath '.git/objects/info/alternates')) { throw 'External object alternates are forbidden.' }
$cloneStatus = (& git -C $clonePath status --porcelain) -join "`n"
if ($LASTEXITCODE -ne 0 -or $cloneStatus.Length -ne 0) { throw 'Fresh clone is not clean.' }
# Separate self-contained checkout for host npm ci/build and fixture preparation.
# Never install host dependencies or place dist/.env files inside Docker context.
& git init $hostFixturePath | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Host fixture clone init failed.' }
& git -C $hostFixturePath config core.autocrlf false
if ($LASTEXITCODE -ne 0) { throw 'Host fixture LF configuration failed.' }
& git -C $hostFixturePath config core.longpaths true
if ($LASTEXITCODE -ne 0) { throw 'Host fixture long-path configuration failed.' }
& git -C $hostFixturePath fetch --depth 1 --no-tags $localUri $SourceSha | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Host fixture exact fetch failed.' }
& git -C $hostFixturePath checkout --detach $SourceSha | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Host fixture exact checkout failed.' }
if (Test-Path -LiteralPath (Join-Path $hostFixturePath '.git/objects/info/alternates')) { throw 'Host fixture cannot depend on external objects.' }
foreach ($forbidden in @('dist','node_modules','.env','.env.local')) {
  if (Test-Path -LiteralPath (Join-Path $clonePath $forbidden)) { throw 'Clone contains ignored runtime or credential files.' }
}
$generated = Join-Path $contextPath 'generated'
node (Join-Path $PSScriptRoot 'create-prototype.mjs') $clonePath $generated
if ($LASTEXITCODE -ne 0) { throw 'Prototype anchors changed; inspect and regenerate the reviewed patch.' }
$overlay = Join-Path $contextPath 'overlay/scripts/load/usage'
New-Item -ItemType Directory -Path $overlay -Force | Out-Null
$trackedHelpers = & git -C $clonePath ls-files scripts/load/usage
if ($LASTEXITCODE -ne 0) { throw 'Tracked helper listing failed.' }
foreach ($relative in $trackedHelpers) {
  $tail = $relative.Substring('scripts/load/usage/'.Length)
  $destination = Join-Path $overlay $tail
  New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($destination)) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $clonePath $relative) -Destination $destination
}
foreach ($file in @('release-enabled-scale.mjs','release-enabled-profile.mjs')) {
  Copy-Item -LiteralPath (Join-Path $generated "overlay/scripts/load/usage/$file") -Destination (Join-Path $overlay $file)
}
$hashes = [ordered]@{}
Get-ChildItem -LiteralPath $overlay -File -Recurse | Sort-Object FullName | ForEach-Object {
  $relative = [IO.Path]::GetRelativePath($overlay,$_.FullName).Replace('\','/')
  $hashes[$relative] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower()
}
[ordered]@{ schemaVersion=1; applicationSource=$SourceSha; candidateImageId=$CandidateImageId; candidateScanReceiptSha256=$scanHash; diagnosticOnly=$true; capacityAccepted=$false; executedHarnessSha256=$hashes } |
  ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $contextPath 'overlay/binding.json') -Encoding utf8NoBOM
foreach ($file in @('verify-runtime.mjs','Dockerfile.prototype')) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $contextPath $file) }
# Never COPY generated launchers, host dependencies, fixture data, or artifacts.
@'
*
!Dockerfile.prototype
!verify-runtime.mjs
!clean-source/**
!overlay/**
clean-source/**/node_modules
clean-source/**/node_modules/**
clean-source/**/dist
clean-source/**/dist/**
clean-source/.env*
clean-source/**/.env*
!clean-source/.env.example
!clean-source/**/.env.example
'@ | Set-Content -LiteralPath (Join-Path $contextPath '.dockerignore') -Encoding utf8NoBOM
[ordered]@{ source=$SourceSha; context=$contextPath; hostFixtureCheckout=$hostFixturePath; candidateImageId=$CandidateImageId; dockerBuildExecuted=$false; helperImageId=$null; requiresLaterReviewAndBuild=$true } | ConvertTo-Json
