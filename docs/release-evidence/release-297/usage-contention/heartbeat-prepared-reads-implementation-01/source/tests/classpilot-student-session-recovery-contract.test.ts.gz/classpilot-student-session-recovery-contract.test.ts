import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

function source(path: string): string {
  return readFileSync(new URL(path, import.meta.url), "utf8").replace(/\r\n/g, "\n");
}

test("manual student sessions use database-time leases and exact recovery capabilities", () => {
  const schema = source("../src/schema/classpilot.ts");
  const migrations = source("../src/db/migrations27.ts");
  const storage = source("../src/services/storage.ts");
  const entitlement = source("../src/services/classpilotEntitlement.ts");
  const authority = source("../src/services/classpilotStudentSessionAuthority.ts");
  const routes = source("../src/routes/classpilot/devices.ts");
  const requestId = source("../src/middleware/requestId.ts");

  assert.match(schema, /authKind: text\("auth_kind"\).*default\("legacy"\)/);
  assert.match(schema, /manualLeaseExpiresAt: timestamp\("manual_lease_expires_at"/);
  assert.match(schema, /sessionRecoveryTokenHash: varchar\("session_recovery_token_hash"/);
  assert.match(schema, /student_sessions_recovery_token_hash_check/);
  assert.match(migrations, /20260827_classpilot_student_session_recovery_expand/);
  assert.match(migrations, /session_recovery_token_hash ~ '\^\[0-9a-f\]\{64\}\$'/);
  assert.match(storage, /clock_timestamp\(\) \+ interval '300 seconds'/);
  assert.match(storage, /session\.deviceId === deviceId/);
  assert.match(storage, /session\.sessionRecoveryTokenHash === options\.reclaimRecoveryTokenHash/);
  assert.match(
    storage,
    /authoritative[\s\S]{0,160}session\.id !== recoveredSession\?\.session\.id[\s\S]{0,160}session\.id !== selectedTransferSession\?\.session\.id/
  );
  assert.match(storage, /recoveredSession\.session\.studentId !== studentId/);
  assert.match(storage, /code: "STUDENT_SESSION_ACTIVE"/);
  assert.match(storage, /endStudentSessionExact[\s\S]*studentSessionId[\s\S]*deviceId/);
  const issuance = source("../src/services/classpilotStudentAuth.ts");
  assert.doesNotMatch(issuance, /linkStudentDevice/);
  const issueStart = issuance.indexOf("export async function issueStudentDeviceSessionToken");
  const issueEnd = issuance.indexOf("export async function finalizeStudentDeviceSessionIssuance", issueStart);
  const issue = issuance.slice(issueStart, issueEnd);
  assert.match(issue, /const sessionId = crypto\.randomUUID\(\)/);
  assert.ok(
    issue.indexOf("signStudentToken ?? createStudentToken")
      < issue.indexOf("ensureClassPilotDeviceForSchool"),
    "JWT signing must precede even device creation"
  );
  assert.ok(
    issue.indexOf("signStudentToken ?? createStudentToken")
      < issue.indexOf("startStudentSessionWithReplacements"),
    "JWT signing must precede the canonical replacement transaction"
  );
  const sessionStart = storage.slice(
    storage.indexOf("export async function startStudentSessionWithReplacements"),
    storage.indexOf("export async function endStudentSessionExact(")
  );
  assert.match(authority, /CLASSPILOT_MANUAL_SHARED_ISSUANCE_DEFAULT = true/);
  assert.ok(
    sessionStart.indexOf("assertClasspilotManualSharedSessionIssuanceEnabled()")
      < sessionStart.indexOf("db.transaction"),
    "the canonical writer must fail dark before any durable transaction"
  );
  assert.match(sessionStart, /Invalid preallocated student session id/);
  assert.match(sessionStart, /\.values\(\{[\s\S]*options\.sessionId[\s\S]*id: options\.sessionId/);
  const manualLogin = routes.slice(
    routes.indexOf('router.post("/extension/student-login"'),
    routes.indexOf('router.post(\n  "/extension/session-release"')
  );
  assert.match(manualLogin, /status\(503\)[\s\S]*CLASSPILOT_MANUAL_SESSION_ISSUANCE_UNAVAILABLE/);
  assert.ok(
    manualLogin.indexOf("classpilotManualSharedSessionIssuanceEnabled()")
      < manualLogin.indexOf("const recoveryToken"),
    "the public manual-login route must fail dark before credential or DB work"
  );
  assert.match(
    sessionStart,
    /assertClasspilotEntitled\(schoolId, transactionDb, \{[\s\S]*lock: true,[\s\S]*afterSchoolLockBeforeLicense: \(\) => takePasspilotClassLock\(tx, schoolId\),[\s\S]*\}\)[\s\S]*lockClasspilotStudentControlAuthorities\(/
  );
  assert.ok(
    sessionStart.indexOf("assertClasspilotEntitled(schoolId, transactionDb, {")
      < sessionStart.indexOf("lockClasspilotStudentControlAuthorities("),
    "session transfer must finish combined entitlement/config authority before student-control locking"
  );
  const schoolLock = entitlement.indexOf("const [school] = await readHeartbeatSchool(dbInstance, schoolId)");
  const bridge = entitlement.indexOf("await options.afterSchoolLockBeforeLicense?.()");
  const schoolRecheck = entitlement.indexOf(
    "if (!isClasspilotSchoolActive(school, new Date()))",
    bridge
  );
  const licenseQuery = entitlement.indexOf("await readHeartbeatLicense(dbInstance, schoolId)", bridge);
  assert.ok(
    schoolLock >= 0 && schoolLock < bridge && bridge < schoolRecheck && schoolRecheck < licenseQuery,
    "combined entitlement authority must use school-row -> class bridge -> fresh school check -> license-row order"
  );
  assert.match(
    entitlement,
    /afterSchoolLockBeforeLicense && !options\.lock[\s\S]*requires lock: true/
  );
  const readQueries = source("../src/services/classpilotHeartbeatReadQueries.ts");
  const lockedSchoolQuery = readQueries.slice(readQueries.indexOf("export function heartbeatSchoolQuery"), readQueries.indexOf("export function heartbeatLicenseQuery"));
  const lockedLicenseQuery = readQueries.slice(readQueries.indexOf("export function heartbeatLicenseQuery"), readQueries.indexOf("export function heartbeatSessionQuery"));
  assert.match(lockedSchoolQuery, /from\(schools\)[\s\S]*eq\(schools\.id, options\.schoolId\)[\s\S]*for\("share"\)/);
  assert.match(lockedLicenseQuery, /productLicenses\.expiresAt, sql`clock_timestamp\(\)`/);
  assert.match(lockedLicenseQuery, /eq\(productLicenses\.schoolId, options\.schoolId\)[\s\S]*for\("share"\)/);
  assert.ok(
    sessionStart.indexOf("const conflictStudentCandidates")
      < sessionStart.indexOf("lockClasspilotStudentControlAuthorities("),
    "session transfer must discover every affected source/destination before authority locking"
  );
  assert.match(
    sessionStart,
    /lockClasspilotStudentControlAuthorities\([\s\S]{0,180}\[studentId, \.\.\.conflictStudentCandidates\.map\(\(row\) => row\.studentId\)\]/,
    "cross-student recovery must lock the source and destination authority keys together"
  );
  assert.ok(
    sessionStart.indexOf("lockClasspilotStudentControlAuthorities(")
      < sessionStart.indexOf(".from(devices)"),
    "session transfer must serialize against deferred state before locking its source device"
  );
  assert.ok(
    sessionStart.indexOf("const [device] =")
      < sessionStart.indexOf("const conflicting ="),
    "session transfer must keep the heartbeat-compatible device-before-session lock order"
  );
  assert.ok(
    sessionStart.indexOf("assertClasspilotEntitled(schoolId, transactionDb, {")
      < sessionStart.indexOf(".insert(studentSessions)"),
    "locked entitlement must be checked before credential-bearing session issuance"
  );
  assert.ok(
    sessionStart.indexOf('code: "STUDENT_SESSION_ACTIVE"')
      < sessionStart.indexOf(".insert(studentDevices)"),
    "student/device association must follow the authoritative conflict guard"
  );
  assert.doesNotMatch(
    sessionStart,
    /session\.studentId === studentId[\s\S]{0,200}sessionRecoveryTokenHash/,
    "same-device recovery must not be limited to resuming the previous student"
  );
  assert.match(routes, /manualSessionCrossStudentHandoff/);
  assert.match(
    routes,
    /captureClasspilotStudentAuthGateIngress[\s\S]*req\.requestReceivedAtMs[\s\S]*router\.post\([\s\S]*"\/extension\/session-gate-presence",[\s\S]*captureClasspilotStudentAuthGateIngress,[\s\S]*extensionSessionGatePresenceIpLimiter[\s\S]*renewClasspilotStudentAuthGatePresence\([\s\S]*requestObservedAt\)/,
    "gate presence must preserve request ordering before limiter and authorization awaits"
  );
  assert.match(requestId, /req\.requestReceivedAtMs = Date\.now\(\)/);
  assert.match(
    storage,
    /EXTRACT\(EPOCH FROM clock_timestamp\(\)\) \* 1000 AS "databaseNowMs"/,
    "post-lock transfer expiry must use a wall clock that advances during lock waits"
  );
  assert.doesNotMatch(storage, /export async function startStudentSession\(/);

  const latePersistence = storage.slice(
    storage.indexOf("export async function persistClasspilotControlCommandState"),
    storage.indexOf("export async function upsertClasspilotClassroomStates", storage.indexOf("export async function persistClasspilotControlCommandState"))
  );
  assert.ok(
    latePersistence.indexOf("lockClasspilotStudentControlAuthorities")
      < latePersistence.indexOf("expectedDeviceIds"),
    "late-sign-in persistence must take shared authority before exact binding locks"
  );
  assert.ok(
    latePersistence.indexOf(".from(devices)")
      < latePersistence.indexOf(".from(studentSessions)"),
    "late-sign-in exact persistence must lock devices before represented sessions"
  );
  assert.match(
    latePersistence,
    /manualLeaseExpiresAt} > clock_timestamp\(\)/,
    "late-sign-in persistence must revalidate the manual-session lease against database time under lock"
  );
  const deliveryAuthority = storage.slice(
    storage.indexOf("async function withClasspilotStudentControlDeliveryAuthorityCore"),
    storage.indexOf("async function assertClasspilotHeartbeatDeliveryCurrent")
  );
  assert.ok(
    deliveryAuthority.indexOf("assertClasspilotEntitled(options.schoolId, transactionDb, { lock: true })")
      < deliveryAuthority.indexOf("lockClasspilotStudentControlAuthorities("),
    "exact-bound delivery must use entitlement -> student-control lock order"
  );
});

test("school lifecycle rows precede the shared class-configuration lock", () => {
  const storage = source("../src/services/storage.ts");
  const staffLifecycle = source("../src/services/staffAssignmentLifecycle.ts");
  const slices = [
    ["createLegacyPass", "returnPass"],
    ["getKioskStudentState", "returnKioskPassForStudent"],
    ["returnKioskPassForStudent", "getAllActivePasses"],
    ["createCanonicalPass", "updateCanonicalKioskClass"],
    ["updateCanonicalKioskClass", "updateLegacyKioskClass"],
    ["updateLegacyKioskClass", "getPasspilotClassMigrationInventory"],
    ["completePasspilotClassMigration", "export type InstructionalCalendarMonthState"],
  ] as const;
  for (const [functionName, nextMarker] of slices) {
    const start = storage.indexOf(`export async function ${functionName}`);
    const body = storage.slice(start, storage.indexOf(nextMarker, start));
    const schoolRow = body.indexOf(".from(schools)");
    const schoolForUpdate = body.indexOf('.for("update")', schoolRow);
    const classLock = body.indexOf("takePasspilotClassLock(");
    assert.ok(
      start >= 0
        && schoolRow >= 0
        && schoolForUpdate > schoolRow
        && schoolForUpdate < classLock,
      `${functionName} must lock its school row before the class-configuration advisory lock`);
  }
  const transitionStart = staffLifecycle.indexOf("export async function transitionStaffAssignments");
  const transition = staffLifecycle.slice(transitionStart);
  assert.ok(
    transitionStart >= 0
      && transition.indexOf("lockStaffAssignmentLifecycleSchool(")
        < transition.indexOf("passpilot-class-source:"),
    "staff assignment transitions must retain the repo-wide school-row -> class-config order"
  );
});

test("heartbeat authority expires atomically and renews only an accepted manual session", () => {
  const storage = source("../src/services/storage.ts");
  const routes = source("../src/routes/classpilot/devices.ts");
  const heartbeat = storage.slice(
    storage.indexOf("export async function createHeartbeatAndRefreshPresence"),
    storage.indexOf("export async function updateHeartbeatClassification")
  );
  const refresh = storage.slice(
    storage.indexOf("export async function refreshStudentSessionAuthorityWithoutTelemetry"),
    storage.indexOf("export async function createHeartbeat(")
  );
  assert.ok(
    heartbeat.indexOf("locked_student_authority AS MATERIALIZED")
      < heartbeat.indexOf("locked_device AS MATERIALIZED"),
    "heartbeat authority must serialize with transfer before device/session locks"
  );
  assert.ok(
    heartbeat.indexOf("locked_device AS MATERIALIZED")
      < heartbeat.indexOf("represented_session AS MATERIALIZED"),
    "heartbeat authority must lock the device before the represented session"
  );
  assert.match(heartbeat, /classpilot:student-control:\$\{data\.schoolId\}:\$\{data\.studentId\}/);
  assert.match(heartbeat, /locked_device[\s\S]*FOR UPDATE/);
  assert.match(heartbeat, /auth_kind <> 'manual_shared'[\s\S]*manual_lease_expires_at > clock_timestamp\(\)/);
  assert.match(heartbeat, /WHEN auth_kind = 'manual_shared' THEN clock_timestamp\(\) \+ interval '300 seconds'/);
  assert.match(heartbeat, /FOR UPDATE OF represented/);
  assert.ok(
    refresh.indexOf("locked_student_authority AS MATERIALIZED")
      < refresh.indexOf("locked_device AS MATERIALIZED"),
    "short-circuit resume must serialize with transfer before device/session locks"
  );
  assert.match(refresh, /classpilot:student-control:\$\{options\.schoolId\}:\$\{options\.studentId\}/);
  const route = routes.slice(
    routes.indexOf('router.post("/device/heartbeat"'),
    routes.indexOf('router.get("/device/screenshot/:deviceId"')
  );
  const heartbeatDbResult = route.indexOf("const heartbeatDbResult = await");
  const recordedBindingCacheWrite = route.indexOf(
    "setBoundedMap(deviceLastHeartbeat",
    heartbeatDbResult
  );
  assert.ok(
    heartbeatDbResult !== -1 && heartbeatDbResult < recordedBindingCacheWrite,
    "only a database-accepted heartbeat may populate the short-circuit cache"
  );
  assert.match(route, /authorityExpiresAtMs: heartbeat\.authorityExpiresAt\?\.getTime\(\) \?\? null/);
  assert.match(route, /refreshExactSessionAuthority/);
  assert.match(
    route,
    /canShortCircuitAcceptedHeartbeat[\s\S]*?refreshExactSessionAuthority\(\)[\s\S]*?res\.status\(204\)\.send\(\)/
  );
  assert.match(
    route,
    /monitoringPolicy\.mode !== "full"[\s\S]*?refreshStudentSessionAuthorityWithoutTelemetry[\s\S]*?outside_tracking_window/
  );
  assert.match(route, /resolveClasspilotMonitoringPolicy\(trackingSettings,[\s\S]*?acceptedCapabilities: protocol\.acceptedCapabilities/);
});

test("recovery release and legacy sign-out are exact, generic, and do not enumerate bindings", () => {
  const routes = source("../src/routes/classpilot/devices.ts");
  const releaseStart = routes.search(/router\.post\(\r?\n  "\/extension\/session-release"/);
  const signOutStart = routes.indexOf('router.post("/extension/sign-out"');
  const signOutEnd = routes.indexOf("// POST /api/classpilot/register", signOutStart);
  assert.notEqual(releaseStart, -1);
  assert.notEqual(signOutStart, -1);
  const release = routes.slice(releaseStart, signOutStart);
  const signOut = routes.slice(signOutStart, signOutEnd);
  assert.match(release, /SESSION_RELEASE_INVALID/);
  assert.match(release, /SESSION_RELEASE_UNAVAILABLE/);
  assert.match(release, /res\.status\(204\)\.end\(\)/);
  assert.match(signOut, /requireCryptographicDeviceAuth/);
  assert.match(signOut, /endStudentSessionExact/);
  assert.doesNotMatch(signOut, /getActiveStudentForDevice/);
  assert.match(signOut, /durable exact cleanup remains a successful no-op contract/);
});

test("manual roster authority uses the database lease without an app-clock freshness override", () => {
  const routes = source("../src/routes/classpilot/devices.ts");
  const storage = source("../src/services/storage.ts");
  const start = routes.indexOf('router.get("/extension/login-roster"');
  const end = routes.indexOf('router.get("/extension/settings"', start);
  const roster = routes.slice(start, end);
  assert.match(roster, /getStudentIdsHiddenFromClasspilotLoginRoster/);
  assert.match(roster, /studentId !== reclaimableSession\?\.studentId/);
  const hidden = storage.slice(
    storage.indexOf("export async function getStudentIdsHiddenFromClasspilotLoginRoster"),
    storage.indexOf("// ============================================================================\n// ClassPilot - Teaching Session operations")
  );
  assert.match(hidden, /manualLeaseExpiresAt} > clock_timestamp\(\)/);
  assert.match(hidden, /authKind, "managed_profile"/);
  assert.match(hidden, /authKind, "legacy"/);
  assert.doesNotMatch(hidden, /lastSeenAt} > now\(\) - interval '300 seconds'/);
});

test("the worker reaps expired leases in bounded locked batches", () => {
  const lifecycle = source("../src/services/classpilotStudentSessionLifecycle.ts");
  const scheduler = source("../src/services/scheduler.ts");
  assert.match(lifecycle, /FOR UPDATE OF session SKIP LOCKED/);
  assert.match(lifecycle, /session\.manual_lease_expires_at <= clock_timestamp\(\)/);
  assert.match(lifecycle, /session_recovery_token_hash = NULL/);
  assert.match(lifecycle, /publicationConcurrency/);
  assert.match(lifecycle, /dbInstance: schedulerDb/);
  assert.match(scheduler, /expireClasspilotManualStudentSessions/);
  assert.match(scheduler, /ManualStudentSessionExpiryBacklog/);
});

test("dashboard and authorization projections exclude expired manual sessions", () => {
  const snapshot = source("../src/services/classpilotDashboardSnapshot.ts");
  const authority = source("../src/services/classpilotStudentSessionAuthority.ts");
  const auth = source("../src/services/classpilotStudentAuth.ts");
  assert.match(snapshot, /session\.auth_kind <> 'manual_shared'[\s\S]*session\.manual_lease_expires_at > clock_timestamp\(\)/);
  assert.match(authority, /manualLeaseExpiresAt} > clock_timestamp\(\)/);
  assert.match(auth, /currentStudentSessionAuthorityPredicate\(\)/);
});

test("staff session responses never serialize recovery capability fields", () => {
  const monitoring = source("../src/routes/classpilot/monitoring.ts");
  const start = monitoring.indexOf('router.get("/sessions/active/:deviceId"');
  const end = monitoring.indexOf('router.get("/sessions/all"', start);
  const activeSessionRoute = monitoring.slice(start, end);
  assert.doesNotMatch(activeSessionRoute, /session: session \|\| null/);
  assert.doesNotMatch(
    activeSessionRoute,
    /sessionRecoveryTokenHash|manualLeaseExpiresAt|authKind/
  );
  assert.match(activeSessionRoute, /isActive: session\.isActive/);
});

test("device removal atomically ends every exact session and publishes returned tombstones", () => {
  const storage = source("../src/services/storage.ts");
  const routes = source("../src/routes/classpilot/devices.ts");
  const lifecycle = source("../src/services/classpilotStudentSessionLifecycle.ts");
  const deletion = storage.slice(
    storage.indexOf("export async function deleteDeviceWithEndedSessions"),
    storage.indexOf("export async function deleteDevice(deviceId")
  );
  assert.match(deletion, /\.update\(studentSessions\)[\s\S]*sessionRecoveryTokenHash: null/);
  assert.match(deletion, /\.delete\(devices\)/);
  assert.match(deletion, /endedSessions/);
  const route = routes.slice(
    routes.indexOf('router.delete("/devices/:deviceId"'),
    routes.indexOf('router.get("/heartbeats"')
  );
  assert.match(route, /removeClasspilotDeviceAndPublishSessionEnds/);
  assert.match(lifecycle, /deleteDeviceWithEndedSessions/);
  assert.match(lifecycle, /reason: "device_removed"/);
  assert.match(lifecycle, /Promise\.allSettled/);
});

test("legacy active-student mutation cannot switch authenticated students", () => {
  const routes = source("../src/routes/classpilot/devices.ts");
  const start = routes.indexOf('router.post("/device/:deviceId/active-student"');
  const end = routes.indexOf("// POST /api/classpilot/extension/runtime-error", start);
  const route = routes.slice(start, end);
  assert.match(route, /studentId !== res\.locals\.studentId/);
  assert.match(route, /STUDENT_LOGIN_REQUIRED/);
  assert.doesNotMatch(route, /setActiveStudentForDevice/);
});

test("staff bulk sign-out completes durable ends despite per-row publication failure", () => {
  const dispatcher = source("../src/services/classpilotCommandDispatcher.ts");
  const start = dispatcher.indexOf("async function endStudentSessionsForSignOut");
  const end = dispatcher.indexOf("async function persistActiveState", start);
  const signOut = dispatcher.slice(start, end);
  assert.match(signOut, /endStudentSessionExact/);
  assert.match(signOut, /publicationFailures \+= 1/);
  assert.ok(
    signOut.indexOf("completedStudentIds.add")
      < signOut.indexOf("await publishClasspilotStudentSessionEnded"),
    "the durable transition must be marked complete before optional publication"
  );
  assert.match(signOut, /markClasspilotCommandTargetsServerCompleted/);
  assert.doesNotMatch(signOut, /studentId:.*console|deviceId:.*console/);
});

test("startup duplicate-session cleanup preserves current authority before freshness", () => {
  const index = source("../src/index.ts");
  const start = index.indexOf("WITH ranked AS (", index.indexOf("duplicate identities together"));
  const end = index.indexOf("// Reassign student_sessions", start);
  const duplicateSessionCleanup = index.slice(start, end);
  const authorityRank = duplicateSessionCleanup.indexOf("session.auth_kind IN ('legacy', 'managed_profile')");
  const manualLeaseRank = duplicateSessionCleanup.indexOf(
    "session.manual_lease_expires_at > clock_timestamp()"
  );
  const freshnessRank = duplicateSessionCleanup.indexOf("session.last_seen_at DESC");
  assert.match(duplicateSessionCleanup, /session\.ended_at IS NULL/);
  assert.ok(authorityRank >= 0, "legacy and managed sessions must rank as authoritative");
  assert.ok(manualLeaseRank >= 0, "only an unexpired manual lease may rank as authoritative");
  assert.ok(
    authorityRank < freshnessRank && manualLeaseRank < freshnessRank,
    "current authority must be ranked before heartbeat freshness"
  );
  assert.match(duplicateSessionCleanup, /WHERE session\.is_active = true/);
  assert.match(duplicateSessionCleanup, /SET is_active = false/);
  assert.match(duplicateSessionCleanup, /session_recovery_token_hash = NULL/);
});

test("manual-session authority always rechecks the database wall clock after lock waits", () => {
  const sources = [
    source("../src/index.ts"),
    source("../src/services/classpilotDashboardSnapshot.ts"),
    source("../src/services/classpilotStudentSessionAuthority.ts"),
    source("../src/services/classpilotStudentSessionLifecycle.ts"),
    source("../src/services/classpilotTileAuthorizationPlanCheck.ts"),
    source("../src/services/storage.ts"),
  ].join("\n");
  assert.doesNotMatch(
    sources,
    /manual(?:_lease_expires_at|LeaseExpiresAt)[^\n]*(?:>|<=)[^\n]*\bnow\(\)/,
    "transaction-start time must not preserve a manual lease that expires while authority waits on a lock"
  );
  assert.match(
    source("../src/services/classpilotStudentSessionAuthority.ts"),
    /manualLeaseExpiresAt} > clock_timestamp\(\)/
  );
});

test("post-commit login failure compensates only the exact issued session", () => {
  const auth = source("../src/services/classpilotStudentAuth.ts");
  const routes = source("../src/routes/classpilot/devices.ts");
  const compensation = auth.slice(
    auth.indexOf("export async function finalizeStudentDeviceSessionIssuance"),
    auth.indexOf("async function lookupActiveStudentTokenSession")
  );
  assert.match(compensation, /endStudentSessionExact/);
  assert.match(compensation, /issuedSession\.studentId/);
  assert.match(compensation, /issuedSession\.deviceId/);
  assert.match(compensation, /issuedSession\.id/);
  assert.match(compensation, /throw error/);
  const login = routes.slice(
    routes.indexOf("async function completeStudentDeviceLogin"),
    routes.indexOf("async function recordRemoteActionTimeline")
  );
  assert.match(login, /finalizeStudentDeviceSessionIssuance/);
  assert.match(login, /onCompensated/);
  assert.match(login, /reason: "login_completion_failed"/);
});

test("the reaper publishes every committed batch before loading the next", () => {
  const lifecycle = source("../src/services/classpilotStudentSessionLifecycle.ts");
  const start = lifecycle.indexOf("export async function reapExpiredManualStudentSessions");
  const reaper = lifecycle.slice(start);
  const loop = reaper.indexOf("for (let batch = 0;");
  const query = reaper.indexOf("schedulerPool.query", loop);
  const publish = reaper.indexOf("publishEndedSession(row)", query);
  const loopExit = reaper.indexOf("if (result.rows.length < batchSize) break", publish);
  assert.ok(loop !== -1 && query < publish && publish < loopExit);
  assert.match(reaper, /await options\.beforeBatch\?\.\(batch\)/);
});
