import { randomUUID } from "node:crypto";
import {
  Column, is, Name, noopDecoder, noopEncoder, Param, Placeholder, SQL,
  StringChunk, Table, type DriverValueEncoder, type SQLChunk,
} from "drizzle-orm";
import { PgDialect } from "drizzle-orm/pg-core";

export type FixedScalarValue = string | number | boolean | null;

type Slot = Readonly<
  | { kind: "constant"; value: FixedScalarValue }
  | { kind: "binding"; name: string; encoder: DriverValueEncoder<unknown, unknown> }
>;

function scalar(value: unknown): value is FixedScalarValue {
  return value === null || typeof value === "string" || typeof value === "boolean"
    || (typeof value === "number" && Number.isFinite(value));
}

function assertIdentityEncoder(encoder: DriverValueEncoder<unknown, unknown>): void {
  if (encoder.mapToDriverValue !== noopEncoder.mapToDriverValue
    && !(is(encoder, Column) && encoder.mapToDriverValue === Column.prototype.mapToDriverValue)) {
    throw new TypeError("Fixed scalar SQL requires an identity parameter encoder");
  }
}

function validateChunk(chunk: unknown, ancestors: Set<SQL>): void {
  if (is(chunk, SQL)) {
    if (ancestors.has(chunk)) throw new TypeError("Cyclic fixed scalar SQL");
    if (Reflect.get(chunk, "shouldInlineParams") !== false
      || Reflect.get(chunk, "decoder") !== noopDecoder) {
      throw new TypeError("Fixed scalar SQL does not support inline parameters or result decoders");
    }
    ancestors.add(chunk);
    for (const nested of chunk.queryChunks) validateChunk(nested, ancestors);
    ancestors.delete(chunk);
  } else if (is(chunk, Param)) {
    assertIdentityEncoder(chunk.encoder);
    if (!is(chunk.value, Placeholder) && !scalar(chunk.value)) {
      throw new TypeError("Fixed scalar SQL contains a non-scalar parameter");
    }
  } else if (is(chunk, Placeholder)) {
    if (!chunk.name) throw new TypeError("Fixed scalar SQL requires named placeholders");
  } else if (chunk !== undefined && !scalar(chunk)
    && !is(chunk, StringChunk) && !is(chunk, Name) && !is(chunk, Table) && !is(chunk, Column)) {
    // Arbitrary SQLWrapper objects may construct SQL from mutable state.
    throw new TypeError("Unsupported fixed scalar SQL chunk");
  }
}

/**
 * Flatten one canonical, structural SQL template at module initialization.
 * Templates use sql.placeholder(name); each invocation still creates a fresh
 * SQL value and fresh Params for normal transactionDb.execute(). No database,
 * client, authority result or request value is retained. This deliberately
 * supports only the repository's default PostgreSQL dialect and scalar fences,
 * not query-builder selections, custom encoders or result decoders.
 */
export function compileFixedScalarQuery(template: SQL): (
  values: Readonly<Record<string, FixedScalarValue>>,
) => SQL {
  validateChunk(template, new Set());
  const dialect = new PgDialect();
  const prefix = `\0fixed-scalar:${randomUUID()}:`;
  const markers: string[] = [];
  dialect.escapeParam = (index: number): string => {
    if (index !== markers.length) throw new TypeError("Unexpected fixed scalar parameter index");
    const marker = `${prefix}${index}\0`;
    markers.push(marker);
    return marker;
  };
  const compiled = dialect.sqlToQuery(template);
  if (markers.length !== compiled.params.length) throw new TypeError("Fixed scalar parameter count changed");

  const slots: readonly Slot[] = Object.freeze(compiled.params.map((parameter, index): Slot => {
    if (is(parameter, Placeholder)) {
      if (!parameter.name) throw new TypeError("Fixed scalar SQL requires named placeholders");
      return Object.freeze({ kind: "binding", name: parameter.name, encoder: noopEncoder });
    }
    if (is(parameter, Param) && is(parameter.value, Placeholder)) {
      assertIdentityEncoder(parameter.encoder);
      if (!parameter.value.name) throw new TypeError("Fixed scalar SQL requires named placeholders");
      return Object.freeze({ kind: "binding", name: parameter.value.name, encoder: parameter.encoder });
    }
    if (!scalar(parameter) || (compiled.typings?.[index] ?? "none") !== "none") {
      throw new TypeError("Fixed scalar SQL requires untyped scalar constants");
    }
    return Object.freeze({ kind: "constant", value: parameter });
  }));
  const text: string[] = [];
  let offset = 0;
  for (const marker of markers) {
    const at = compiled.sql.indexOf(marker, offset);
    if (at < 0 || compiled.sql.indexOf(marker, at + marker.length) !== -1) {
      throw new TypeError("Fixed scalar parameter marker collision");
    }
    text.push(compiled.sql.slice(offset, at));
    offset = at + marker.length;
  }
  text.push(compiled.sql.slice(offset));
  if (text.some(part => part.includes(prefix))) throw new TypeError("Fixed scalar parameter marker collision");
  Object.freeze(text);

  return values => {
    const chunks: SQLChunk[] = [];
    for (let index = 0; index < slots.length; index++) {
      chunks.push(new StringChunk(text[index]!));
      const slot = slots[index]!;
      if (slot.kind === "constant") {
        chunks.push(new Param(slot.value));
      } else {
        const descriptor = Object.getOwnPropertyDescriptor(values, slot.name);
        if (!descriptor || !("value" in descriptor) || !scalar(descriptor.value)) {
          throw new TypeError(`Missing or non-scalar fixed SQL binding: ${slot.name}`);
        }
        // Schema encoders are shared metadata, never a place for mutable
        // request transforms. Fail closed if one was changed after compilation.
        assertIdentityEncoder(slot.encoder);
        chunks.push(new Param(descriptor.value, slot.encoder));
      }
    }
    chunks.push(new StringChunk(text[text.length - 1]!));
    return new SQL(chunks);
  };
}
