#requires -Version 7.5
$ErrorActionPreference='Stop'
$docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe'
$endpoint='npipe:////./pipe/dockerDesktopLinuxEngine'
foreach($key in @('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH')){[Environment]::SetEnvironmentVariable($key,$null,'Process')}
$prototype=Join-Path $env:TEMP 'release297-owned-pg-linux-prototype-01'
$repo=Join-Path $env:TEMP 'release297-role-0e427-unprofiled-host-01'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$out=Join-Path $env:TEMP ('release297-owned-pg-linux-'+$run)
$control=Join-Path $env:TEMP ('release297-owned-pg-linux-control-'+$run)
New-Item -ItemType Directory -Path $out,$control|Out-Null
$source='0e427e3ca9b82125e0bb8692176accad21f4f699'
$image='sha256:8bed6f5d266670c31d2b9c502b5d0ff065bd3bd9eed18a855506b15ab6bd1687'
$manifestHash=(Get-FileHash -LiteralPath (Join-Path $prototype 'manifest.json') -Algorithm SHA256).Hash.ToLower()
$plan=[ordered]@{schemaVersion=1;run=$run;nonce=[guid]::NewGuid().ToString();source=$source;image=$image;prototypeSha256=$manifestHash;apiCpu=1;apiMemoryBytes=2147483648;apiOldSpaceMiB=512;postgresCpu=4;postgresMemoryBytes=4294967296;capacityAccepted=$false;applicationChanges=0;sequenceReads=8;rounds=3;iterationsPerRound=1000}
$plan|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $control 'plan.json') -Encoding utf8
$plan|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'plan.json') -Encoding utf8
$owners=[System.Collections.Generic.List[object]]::new();$exitCode=1;$apiExit=$null;$attach=$null;$capture=$null;$clean=$true;$failure=$null
function Docker([string[]]$a){$o=& $docker --host $endpoint @a 2>&1;if($LASTEXITCODE -ne 0){throw "Docker operation failed ($($a[0])): $($o -join ' ')"};return ($o -join "`n")}
function Inspect([string]$id){$parsed=(Docker @('inspect',$id))|ConvertFrom-Json;if($parsed.Count -ne 1){throw 'Expected exact single inspect'};return $parsed[0]}
function OwnCreate([string]$name,[string]$role,[string]$expectedImage,[string[]]$a){
 $problem=$null
 try{[void](Docker (@('create','--name',$name,'--label',"codex.micro.run=$run",'--label',"codex.micro.role=$role")+$a))}catch{$problem=$_}
 $found=$null;try{$found=Inspect $name}catch{}
 if($found -and $found.Name -ceq ('/'+$name) -and $found.Image -ceq $expectedImage -and $found.Config.Labels.'codex.micro.run' -ceq $run -and $found.Config.Labels.'codex.micro.role' -ceq $role){$owners.Add([pscustomobject]@{id=$found.Id;name=$name;role=$role;image=$expectedImage})}else{throw 'Creation ownership not confirmed; no unrelated cleanup permitted'}
 if($problem){throw $problem};return $found.Id
}
function SaveInspect($item,[string]$name){$item.Config.Env=@('[redacted: exact keys stored separately]');$item|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $out $name) -Encoding utf8}
try{
 $manifest=Get-Content -LiteralPath (Join-Path $prototype 'manifest.json') -Raw|ConvertFrom-Json
 foreach($file in $manifest.files){if((Get-FileHash -LiteralPath (Join-Path $prototype $file.path) -Algorithm SHA256).Hash.ToLower() -cne $file.sha256){throw 'Prototype source hash mismatch'}}
 Copy-Item -LiteralPath (Join-Path $prototype 'manifest.json') -Destination (Join-Path $out 'prototype-manifest.json')
 $pgImage=(Inspect 'schoolpilot-db').Image
 if($pgImage -cnotmatch '^sha256:[a-f0-9]{64}$'){throw 'PG image binding invalid'}
 $database='micro_'+$run;$owner='owner_'+$run;$role='app_'+$run;$password=[guid]::NewGuid().ToString('N');$rolePassword=[guid]::NewGuid().ToString('N')
 $pgEnv=Join-Path $control 'postgres.env';@("POSTGRES_DB=$database","POSTGRES_USER=$owner","POSTGRES_PASSWORD=$password")|Set-Content -LiteralPath $pgEnv -Encoding utf8
 $pg=OwnCreate "schoolpilot-micro-pg-$run" 'postgres' $pgImage @('--cpus','4','--memory','4g','--memory-swap','4g','--env-file',$pgEnv,$pgImage)
 [void](Docker @('start',$pg))
 $ready=$false
 for($i=0;$i -lt 80;$i++){& $docker --host $endpoint exec $pg pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250};if(-not $ready){throw 'PG readiness failed'}
 $pgInspect=Inspect $pg;if($pgInspect.HostConfig.NanoCpus -ne 4000000000 -or $pgInspect.HostConfig.Memory -ne 4294967296 -or $pgInspect.HostConfig.MemorySwap -ne 4294967296 -or @($pgInspect.HostConfig.PortBindings.PSObject.Properties).Count -gt 0){throw 'PG resource/network posture mismatch'};SaveInspect $pgInspect 'postgres-inspect.json'
 Copy-Item -LiteralPath "$env:TEMP/release297-role-ingest-unprofiled-0e427-01/post-convergence-schema.sql" -Destination (Join-Path $out 'schema.sql')
 Get-Content -LiteralPath (Join-Path $out 'schema.sql') -Raw|& $docker --host $endpoint exec -i $pg psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log');if($LASTEXITCODE -ne 0){throw 'Schema restore failed'}
 "CREATE ROLE $role LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$rolePassword'; GRANT USAGE ON SCHEMA public TO $role; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $role; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $role;"|& $docker --host $endpoint exec -i $pg psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'role.log');if($LASTEXITCODE -ne 0){throw 'Restricted role creation failed'}
 $registry=Get-Content -LiteralPath (Join-Path $repo 'src/config/rlsRegistry.json') -Raw|ConvertFrom-Json
 $secret=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N')
 $envMap=[ordered]@{DATABASE_URL="<REDACTED_LOCAL_URL>";DATABASE_URL_PRIVILEGED="<REDACTED_LOCAL_URL>";ADMIN_DATABASE_URL="<REDACTED_LOCAL_URL>";JWT_SECRET=$secret;SESSION_SECRET=$secret;STUDENT_TOKEN_SECRET=$secret;NODE_ENV='test';REDIS_URL='';SCHEDULER_ENABLED='false';RLS_GUC_ENABLED='true';DOTENV_CONFIG_PATH='/no-env';DOTENV_CONFIG_QUIET='true';RLS_ENABLED_TABLES=($registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ',');OWNED_EXECUTOR_RESULT='/evidence/native-result.json'}
 $apiEnv=Join-Path $control 'api.env';$envMap.GetEnumerator()|ForEach-Object{"$($_.Key)=$($_.Value)"}|Set-Content -LiteralPath $apiEnv -Encoding utf8
 @($envMap.Keys)|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'environment-keys.json') -Encoding utf8
 $api=OwnCreate "schoolpilot-micro-api-$run" 'api' $image @('--cpus','1','--memory','2g','--memory-swap','2g','--network',"container:$pg",'--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--init','--no-healthcheck','--user','node','--workdir','/app','--env-file',$apiEnv,'--mount',"type=bind,source=$prototype,target=/micro,readonly",'--mount',"type=bind,source=$out,target=/evidence",'--mount',"type=bind,source=$control,target=/control,readonly",'--entrypoint','node',$image,'--max-old-space-size=512','/micro/entry.mjs')
 $a=Inspect $api
 if($a.HostConfig.NanoCpus -ne 1000000000 -or $a.HostConfig.Memory -ne 2147483648 -or $a.HostConfig.MemorySwap -ne 2147483648 -or $a.HostConfig.NetworkMode -cne "container:$pg" -or -not $a.HostConfig.ReadonlyRootfs -or $a.Config.User -cne 'node' -or $a.Config.WorkingDir -cne '/app'){throw 'API runtime posture mismatch'}
 if(($a.Config.Entrypoint -join ' ') -cne 'node' -or ($a.Config.Cmd -join ' ') -cne '--max-old-space-size=512 /micro/entry.mjs' -or $a.HostConfig.Init -ne $true -or ($a.HostConfig.CapDrop -join ',') -cne 'ALL' -or ($a.HostConfig.SecurityOpt -join ',') -cne 'no-new-privileges' -or ($a.Config.Healthcheck.Test -join ',') -cne 'NONE'){throw 'API execution posture mismatch'}
 if($a.Mounts.Count -ne 3){throw 'Unexpected mounts'};foreach($mount in $a.Mounts){if($mount.Type -cne 'bind' -or $mount.Destination -cnotin @('/micro','/evidence','/control') -or $mount.RW -ne ($mount.Destination -ceq '/evidence')){throw 'Mount permissions mismatch'}}
 SaveInspect $a 'api-inspect-before.json'
 $psi=[System.Diagnostics.ProcessStartInfo]::new();$psi.FileName=$docker;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 foreach($arg in @('--host',$endpoint,'start','--attach',$api)){$psi.ArgumentList.Add($arg)}
 $attach=[System.Diagnostics.Process]::new();$attach.StartInfo=$psi;[void]$attach.Start()
 $stdout=[System.IO.File]::Create((Join-Path $out 'native.log'));$stderr=[System.IO.File]::Create((Join-Path $out 'native.stderr.log'))
 $copyOut=$attach.StandardOutput.BaseStream.CopyToAsync($stdout);$copyErr=$attach.StandardError.BaseStream.CopyToAsync($stderr)
 $stop=[DateTime]::UtcNow.AddMinutes(22)
 while(-not $attach.WaitForExit(500)){if($copyOut.IsFaulted -or $copyErr.IsFaulted){throw 'Log capture failed'};if([DateTime]::UtcNow -gt $stop){throw 'Native process deadline exceeded'}}
 [System.Threading.Tasks.Task]::WaitAll(@($copyOut,$copyErr));$stdout.Dispose();$stderr.Dispose();$capture=$true
 $attachExit=$attach.ExitCode;$daemonExit=[int](Docker @('wait',$api));$final=Inspect $api;$apiExit=$final.State.ExitCode
 if($attachExit -ne $daemonExit -or $daemonExit -ne $apiExit -or $final.State.Running){throw 'Exit receipts disagree'}
 SaveInspect $final 'api-inspect-after.json';$exitCode=$apiExit
 [ordered]@{attachExit=$attachExit;daemonExit=$daemonExit;inspectExit=$apiExit;oomKilled=$final.State.OOMKilled;forced=$false;logCaptureComplete=$capture}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'exit.json') -Encoding utf8
} catch{$exitCode=1;$failure=$_.Exception.Message;$failure|Set-Content -LiteralPath (Join-Path $out 'failure.log') -Encoding utf8}
finally{
 $cleanup=[System.Collections.Generic.List[object]]::new()

 for($i=$owners.Count-1;$i -ge 0;$i--){$o=$owners[$i];try{$f=Inspect $o.id;if($f.Id -cne $o.id -or $f.Name -cne ('/'+$o.name) -or $f.Image -cne $o.image -or $f.Config.Labels.'codex.micro.run' -cne $run -or $f.Config.Labels.'codex.micro.role' -cne $o.role){throw 'Cleanup owner mismatch'};$forced=$f.State.Running;[void](Docker @('rm','--force',$o.id));& $docker --host $endpoint inspect $o.id *> $null;$absent=$LASTEXITCODE -ne 0;if(-not $absent){throw 'Container remains'};$cleanup.Add([ordered]@{id=$o.id;role=$o.role;image=$o.image;forced=$forced;removed=$true})}catch{$clean=$false;$cleanup.Add([ordered]@{id=$o.id;role=$o.role;removed=$false;error=$_.Exception.Message})}}
 if($attach -and -not $attach.HasExited){[void]$attach.WaitForExit(10000)}
 if($stdout){$stdout.Dispose()};if($stderr){$stderr.Dispose()}
 $prototypeUnchanged=(Get-FileHash -LiteralPath (Join-Path $prototype 'manifest.json') -Algorithm SHA256).Hash.ToLower() -ceq $manifestHash
 $cleanup|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'cleanup.json') -Encoding utf8
 [ordered]@{run=$run;source=$source;image=$image;out=$out;control=$control;testExit=$apiExit;runnerExit=$exitCode;cleanupPassed=$clean;prototypeManifestUnchanged=$prototypeUnchanged;failure=$failure;capacityAccepted=$false;productionMutations=0}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
 Write-Output ([ordered]@{out=$out;control=$control;testExit=$apiExit;cleanup=$clean;failure=$failure}|ConvertTo-Json -Compress)
}
exit $exitCode
