import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
const root='<WORKTREE>';
const output='<RAW_EVIDENCE>';
const path='tests/classpilot-runtime-security-contract.test.ts';
const original=readFileSync(resolve(root,path),'utf8');
let updated=original;
function once(before,after){ assert.equal(updated.split(before).length-1,1); updated=updated.replace(before,()=>after); }
once(String.raw`    assert.match(inbox, /inbox_command\.expires_at IS NULL OR inbox_command\.expires_at > now\(\)/);`,String.raw`    assert.match(inbox, /inbox_command\.expires_at IS NULL OR inbox_command\.expires_at > \$\{classpilotAuthorityClockSql\(clock\)\}/);
    assert.match(inbox, /return getPendingMessagesForStudentWithAuthorityLocked\(options, transactionDb, "transaction"\)/);
    const heartbeatDelivery = storage.slice(
      storage.indexOf("export async function withClasspilotHeartbeatDeliveryAuthority"),
      storage.indexOf("export async function withClasspilotStudentWebSocketBootstrapAuthority")
    );
    assert.match(heartbeatDelivery, /getPendingMessagesForStudentWithAuthorityLocked\(\s*\{ \.\.\.options, excludeMessageIds: inboxExclusions \}, transactionDb, "current",\s*\)/);
    assert.match(storage, /function classpilotAuthorityClockSql\(clock: ClasspilotAuthorityClock\): SQL \{\s*return clock === "current" \? sql`+'`'+String.raw`clock_timestamp\(\)`+'`'+String.raw` : sql`+'`'+String.raw`now\(\)`+'`'+String.raw`;\s*\}/);`);
once(String.raw`    assert.match(heartbeat, /filter\(\(message\) => !message\.commandId\)/);`,String.raw`    assert.match(heartbeat, /const legacyDeliveredIds = recent\.filter\(message => !message\.commandId\)\.map\(message => message\.id\)/);`);
// Retain the original repository's CRLF convention in every inserted line.
if(original.includes('\r\n')) updated=updated.replace(/\r?\n/g,'\r\n');
const file=resolve(output,'classpilot-runtime-security-contract.proposed.test.ts');
writeFileSync(file,updated,{flag:'wx'});
const diff=spawnSync('git',['diff','--no-index','--no-ext-diff','--',resolve(root,path),file],{encoding:'utf8',windowsHide:true});
assert.equal(diff.status,1);assert.equal(diff.stderr,'');
const lines=diff.stdout.split('\n'); lines[0]=`diff --git a/${path} b/${path}`; lines[2]=`--- a/${path}`;lines[3]=`+++ b/${path}`;
const patch=lines.join('\n');writeFileSync(resolve(output,'runtime-security-clock-only.patch'),patch,{flag:'wx'});
const sha=v=>createHash('sha256').update(v).digest('hex');
const receipt={source:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),file:path,sourceSha256:sha(original),proposedSha256:sha(updated),patchSha256:sha(patch),primaryEdits:0,testsRun:false,ci:{run:37107874564,job:111159846331,passed:1478,failed:1,skipped:8},retrievalAttempt01:'Wrong guessed repository returned404; not a CI test result',preservedAssertions:true};
writeFileSync(resolve(output,'proposed-patch.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
