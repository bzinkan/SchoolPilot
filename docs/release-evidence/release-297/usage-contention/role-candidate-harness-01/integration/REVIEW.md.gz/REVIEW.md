# Candidate harness review checkpoint

No application/schema/resource/pool/deadline changes; accepted count remains zero.

- Activation: `build-role-helper.mjs` records candidate intent before build, `measurement-gate.mjs`/`launch-role-scale.mjs` bind exact mode/nonce/helper. Existing diagnostic bindings cannot become candidates.
- Ownership: `run-campaign.mjs` registers one immutable attempt before invoking the actual restored owner. `campaign-journal.mjs` checks the exact pending registration, retains all failures and forbids advancement after unconfirmed cleanup. No automatic retry or gate release.
- Runtime: `run-restored-role-scale.mjs`/`restore-snapshot.mjs` consume the registered plan before fixtures and retain the proven restore/ANALYZE/revalidate/restart/Redis/role/cleanup order.
- Producer: `patch-coordinator.mjs`/`create-context.mjs` generate a source-bound modern overlay. It requires six capabilities on every HTTP200, rejects all204, and binds exact-school independent raw/persisted/rollup counts including six priming observations per school. Canonical scripts remain untouched.
- Validator: strict modern counts from reviewed safety slice plus exact pre-reset gauge proof. Missing/nonzero gauges fail even if summary says physically idle and final snapshots are zero. Original native comparison remains historical criteria.
- Proof: `runtime-contract.test.mjs`, `restored-role-scale.test.mjs`, `campaign-validation.test.mjs`, `campaign-journal.test.mjs`; discovered by `roles/suite.mjs` and `tests/private-load-usage-profiles.test.mjs`.

Initial focused failures were a CRLF-sensitive exact generator anchor and a synthetic fixture nonce not following the actual registered nonce; both were repaired without weakening checks. The 12 preflight red cases reproduce the prior validator defect. Latest aggregate is378/378,0skip; all56 owned files unchanged during it. New native candidate execution is pending root review and a performant candidate; no full workload is scheduled here.
