import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {domainMapPrototype} from './domain-map.mjs';
const sha=s=>createHash('sha256').update(s).digest('hex'), source='b11202fc305198d76e73c5e6d711b7dc9ed2d938';
const fixture=JSON.parse(readFileSync('/input/cold-fixture-state.json','utf8'));assert.equal(fixture.sourceRevision,source);assert.equal(process.env.EXPLAIN_SOURCE,source);
const rollup=await import('/app/dist/services/classpilotUsageRollup.js'), time=await import('/app/dist/util/schoolTime.js'), scheduler=await import('/app/dist/services/schedulerDb.js'), admission=await import('/app/dist/services/classpilotUsageRollupAdmission.js');
const pool=scheduler.schedulerPool,school=fixture.schools.find(s=>s.index===0),day=rollup.classpilotUsageRollupDay(time.addLocalDays(fixture.today,-2),'America/New_York');
assert.equal(pool.options.max,5);assert.equal(pool.options.connectionTimeoutMillis,10000);assert.equal(pool.options.statement_timeout,60000);
const sql=domainMapPrototype(rollup.CLASSPILOT_USAGE_ROLLUP_INSERT_SQL),params=[school.id,time.utcTimestampForSql(day.dayStartUtc),time.utcTimestampForSql(day.dayEndUtc),day.date,'[]'];
writeFileSync('/out/original.sql',sql.original);writeFileSync('/out/candidate.sql',sql.candidate);
const result={schemaVersion:1,source,diagnosticOnly:true,capacityAccepted:false,passed:false,sqlHashes:sql.hashes,parameterSha256:sha(JSON.stringify(params)),scope:sql.scope,rounds:[],limitations:['Warm component comparison on a fresh restored synthetic snapshot; no concurrent API/report traffic and no capacity claim.','ABBA includes PostgreSQL EXPLAIN timing overhead and temp-table writes. It excludes the persistent INSERT, FK triggers and COMMIT cost; baseline actual full writer is a separate preserved probe.','The same real scheduler pool/admission and total60s success budget own every compared query and rollback. No durability, resource, schema, index or timeout increase.','All temp tables are transaction-local and rolled back; no persistent application row is changed. Buffer/WAL parent counters overlap.']};
const cleanPlan=p=>JSON.stringify(p,null,2).replace(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/gi,'<SYNTHETIC_ID>')+'\n';
const values=[null,'','chrome://settings','about:blank','ftp://example.test','https://','http:///path','http://:8080/path','http://@/','HTTP://WWW.Example.TEST/path?x=1','https://user:pass@WWW.Example.test:443/path','http://user@other@host.example:80/','https://[::1]:443/a','https://www.example.test.','https://éxample.test/path','https://I.EXAMPLE.test','https://example.test\\path',' https://example.test','https://example.test\n/path','https://example.test/?x=1','https://example.test/?x=2','https://example.test/#fragment','https://www.example.test','https://example.test:','https://user@','http://user:pass@www.example.test:80/a'];
values.push('https://'+'a'.repeat(300)+'.example.test/path','https://example.test/é/路径','https://WWW.ÉXAMPLE.TEST/路径','https:/broken','https:////broken');
const edge=values.flatMap((url,i)=>[0,1].map(s=>({ordinal:i*2+s,student_id:'student-'+s,active_tab_url:url,category:['educational','non-educational','unknown'][i%3],teacher_intent_exempt:s===1})));edge.push({...edge[20],ordinal:edge.length});
const classification=sql.original.slice(sql.original.indexOf('classified AS (\n  SELECT normalized.*,')+'classified AS (\n  SELECT normalized.*,'.length,sql.original.indexOf('\n  FROM normalized\n),\nroster_window'));
assert.match(classification,/AS classification$/);
function kernel(input,candidate){
 const projection=candidate?"COALESCE(url_domains.domain, '') AS domain":sql.canonicalDomain.trim().slice(0,-1);
 const maps=candidate?`distinct_urls AS MATERIALIZED (SELECT DISTINCT ON (student_id,active_tab_url COLLATE "C") student_id,active_tab_url FROM deduplicated),url_domains AS MATERIALIZED (SELECT observation.student_id,observation.active_tab_url,${sql.canonicalDomain.trim().slice(0,-1)} FROM distinct_urls observation),`:'';
 return `WITH deduplicated AS MATERIALIZED (${input}),${maps}normalized AS (SELECT observation.ordinal,observation.student_id,observation.category,observation.teacher_intent_exempt,${projection} FROM deduplicated observation ${candidate?'LEFT JOIN url_domains ON url_domains.student_id=observation.student_id AND url_domains.active_tab_url COLLATE "C"=observation.active_tab_url COLLATE "C"':''}),classified AS (SELECT normalized.*,${classification} FROM normalized) SELECT ordinal,student_id,domain,classification FROM classified`;
}
const edgeInput='SELECT * FROM jsonb_to_recordset($1::jsonb) AS x(ordinal int,student_id text,active_tab_url text,category text,teacher_intent_exempt boolean)';
const distinctInput="SELECT n AS ordinal,'student-'||(n%2) AS student_id,'https://host-'||n||'.example.test/path?x='||n AS active_tab_url,CASE WHEN n%3=0 THEN 'educational' WHEN n%3=1 THEN 'non-educational' ELSE 'unknown' END AS category,n%2=0 AS teacher_intent_exempt FROM generate_series(1,6000) n";
try{
 const role=(await pool.query("SELECT rolsuper,rolbypassrls,current_setting('app.is_super') AS super_guc FROM pg_roles WHERE rolname=current_user")).rows[0];assert.deepEqual(role,{rolsuper:false,rolbypassrls:false,super_guc:'on'});result.workerPosture=role;
 const start=performance.now(),cpu=process.cpuUsage();
 await admission.withClasspilotUsageRollupOperation(pool,async(client,budget,markBroken)=>{
  await client.query('BEGIN');let rolledBack=false;
  try{
   await budget.query(client,rollup.CLASSPILOT_USAGE_ROLLUP_LOCK_SQL,[school.id]);
   const before=(await budget.query(client,'SELECT (SELECT COUNT(*)::int FROM classpilot_usage_rollups WHERE school_id=$1 AND usage_date=$2::date) AS rows,(SELECT COUNT(*)::int FROM classpilot_usage_rollup_days WHERE school_id=$1 AND usage_date=$2::date) AS coverage',[school.id,day.date])).rows[0];assert.deepEqual(before,{rows:0,coverage:0});result.before=before;
   for(const [name,kind]of [['baseline_a','baseline'],['candidate_a','candidate'],['candidate_b','candidate'],['baseline_b','baseline']]){
    const text='CREATE TEMP TABLE '+name+' ON COMMIT DROP AS '+(kind==='baseline'?sql.originalGrains:sql.candidateGrains),started=performance.now();
    const plan=(await budget.query(client,'EXPLAIN (ANALYZE,BUFFERS,WAL,FORMAT JSON) '+text,params)).rows[0]['QUERY PLAN'];
    writeFileSync('/out/'+name+'.plan.json',cleanPlan(plan));result.rounds.push({name,kind,driverMs:performance.now()-started,executionMs:plan[0]['Execution Time'],planningMs:plan[0]['Planning Time'],rootRows:plan[0].Plan['Actual Rows'],sqlSha256:sha(text),planSha256:sha(cleanPlan(plan))});
   }
   const cols='school_id,usage_date,student_id,class_id,session_id,domain,classification,seconds,heartbeat_count';result.comparedColumns=cols.split(',');result.perGrain=[];
   for(const name of ['candidate_a','candidate_b','baseline_b']){
    const diff=(await budget.query(client,`SELECT (SELECT COUNT(*)::int FROM (SELECT ${cols} FROM baseline_a EXCEPT ALL SELECT ${cols} FROM ${name}) a) AS baseline_minus,(SELECT COUNT(*)::int FROM (SELECT ${cols} FROM ${name} EXCEPT ALL SELECT ${cols} FROM baseline_a) b) AS candidate_minus`)).rows[0];assert.deepEqual(diff,{baseline_minus:0,candidate_minus:0});result.perGrain.push({name,...diff});
   }
   const aggregate=(await budget.query(client,'SELECT COUNT(*)::int AS rows,SUM(seconds)::bigint AS seconds,SUM(heartbeat_count)::bigint AS heartbeats,COUNT(*) FILTER(WHERE seconds=0)::int AS zero_second_grains FROM baseline_a')).rows[0];assert.deepEqual({rows:aggregate.rows,seconds:Number(aggregate.seconds),heartbeats:Number(aggregate.heartbeats)},{rows:84000,seconds:10002500,heartbeats:1000000});result.aggregate=aggregate;
   const instant=seconds=>time.utcTimestampForSql(new Date(day.dayStartUtc.getTime()+8*3600000+seconds*1000));
   const excluded=[{studentId:'',start:instant(5),end:instant(15)},{studentId:school.students[0],start:instant(195),end:instant(225)}];
   const narrow=text=>text.replace('WHERE student_scope.school_id = $1','WHERE student_scope.school_id = $1 AND student_scope.id = ANY($6::text[])');
   assert.notEqual(narrow(sql.originalGrains),sql.originalGrains);
   const scopedParams=[...params.slice(0,4),JSON.stringify(excluded),school.students.slice(0,2)];
   const exclusionDiff=(await budget.query(client,`WITH old AS (${narrow(sql.originalGrains)}),next AS (${narrow(sql.candidateGrains)}) SELECT (SELECT COUNT(*)::int FROM old) AS rows,(SELECT COUNT(*)::int FROM (SELECT ${cols} FROM old EXCEPT ALL SELECT ${cols} FROM next) a) AS old_minus,(SELECT COUNT(*)::int FROM (SELECT ${cols} FROM next EXCEPT ALL SELECT ${cols} FROM old) b) AS new_minus`,scopedParams)).rows[0];assert.equal(exclusionDiff.old_minus,0);assert.equal(exclusionDiff.new_minus,0);result.exclusionBoundaries={...exclusionDiff,students:2,parametersSha256:sha(JSON.stringify(scopedParams)),scope:'Same canonical grains for2selected students with school-wide and student-specific exclusion boundaries, actual AI/category/teacher-intent input preserved.'};
   for(const [label,input,bindings]of [['edge',edgeInput,[JSON.stringify(edge)]],['highDistinct',distinctInput,undefined]]){
    const old=kernel(input,false),next=kernel(input,true);
    const diff=(await budget.query(client,`WITH old AS (${old}),next AS (${next}) SELECT (SELECT COUNT(*)::int FROM old) AS rows,(SELECT COUNT(*)::int FROM (SELECT * FROM old EXCEPT ALL SELECT * FROM next) a) AS old_minus,(SELECT COUNT(*)::int FROM (SELECT * FROM next EXCEPT ALL SELECT * FROM old) b) AS new_minus`,bindings)).rows[0];assert.equal(diff.old_minus,0);assert.equal(diff.new_minus,0);result[label]={...diff,inputSha256:sha(input),parametersSha256:sha(JSON.stringify(bindings??[])),timings:[]};
    for(const [kind,k]of [['baseline',old],['candidate',next]]){const p=(await budget.query(client,'EXPLAIN (ANALYZE,BUFFERS,WAL,FORMAT JSON) '+k,bindings)).rows[0]['QUERY PLAN'];writeFileSync('/out/'+label+'-'+kind+'.plan.json',cleanPlan(p));result[label].timings.push({kind,executionMs:p[0]['Execution Time'],rows:p[0].Plan['Actual Rows']});}
   }
   await client.query('ROLLBACK');rolledBack=true;result.transactionRolledBack=true;
  }finally{if(!rolledBack){try{await client.query('ROLLBACK');result.transactionRolledBack=true;}catch{markBroken();throw Error('Component rollback failed');}}}
 });
 result.completeOperationMs=performance.now()-start;result.processCpuMicroseconds=process.cpuUsage(cpu);assert.ok(result.completeOperationMs<=60000);
 const after=(await pool.query('SELECT (SELECT COUNT(*)::int FROM classpilot_usage_rollups WHERE school_id=$1 AND usage_date=$2::date) AS rows,(SELECT COUNT(*)::int FROM classpilot_usage_rollup_days WHERE school_id=$1 AND usage_date=$2::date) AS coverage',[school.id,day.date])).rows[0];assert.deepEqual(after,result.before);result.after=after;result.passed=true;
}catch(error){result.failure={name:error.name,code:error.code,message:String(error.message).replace(/[a-f0-9]{8}-[a-f0-9-]{27,}/gi,'<SYNTHETIC_ID>').slice(0,500)};process.exitCode=1;}
finally{try{await pool.end();await scheduler.schedulerLockPool.end();await(await import('/app/dist/services/errorMonitor.js')).default.disposeAndWait();const db=await import('/app/dist/db.js');await db.pool.end();await db.sessionPool.end();result.poolCleanup=true;}catch(error){result.poolCleanup=false;result.cleanupError=error.name;result.passed=false;process.exitCode=1;}writeFileSync('/out/result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:result.passed,completeOperationMs:result.completeOperationMs,rounds:result.rounds,edge:result.edge,highDistinct:result.highDistinct,failure:result.failure,poolCleanup:result.poolCleanup}));}
