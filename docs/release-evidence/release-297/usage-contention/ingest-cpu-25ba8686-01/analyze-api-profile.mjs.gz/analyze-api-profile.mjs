import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const directory = process.argv[2];
assert.ok(directory);
const bytes = readFileSync(resolve(directory, 'api.cpuprofile'));
const profile = JSON.parse(bytes);
const result = JSON.parse(readFileSync(resolve(directory, 'usage-scale.json')));
const phase = result.phases[0];
const from = phase.api.measurementStartedHrtimeMicroseconds;
const until = phase.api.snapshotHrtimeMicroseconds;
assert.ok(from >= profile.startTime && until <= profile.endTime && from < until,
  'Node hrtime measurement window must fit the V8 monotonic profile clock');
const nodes = new Map(profile.nodes.map(node => [node.id, node]));
const parents = new Map();
for (const node of profile.nodes) for (const child of node.children ?? []) parents.set(child, node.id);
const describe = node => ({ name: node.callFrame.functionName || '(anonymous)',
  url: node.callFrame.url, line: node.callFrame.lineNumber + 1 });
const key = node => JSON.stringify(describe(node));
const exclusive = new Map(), inclusive = new Map();
function count(map, node, duration) {
  const id = key(node), row = map.get(id) ?? { ...describe(node), microseconds: 0, samples: 0 };
  row.microseconds += duration; row.samples++; map.set(id, row);
}
let clock = profile.startTime, total = 0, acceptedSamples = 0;
for (let index = 0; index < profile.samples.length; index++) {
  const delta = profile.timeDeltas[index], end = clock + delta;
  const overlap = Math.max(0, Math.min(end, until) - Math.max(clock, from));
  clock = end;
  if (!overlap) continue;
  total += overlap; acceptedSamples++;
  let node = nodes.get(profile.samples[index]);
  assert.ok(node); count(exclusive, node, overlap);
  const seen = new Set();
  while (node) {
    const id = key(node);
    if (!seen.has(id)) { count(inclusive, node, overlap); seen.add(id); }
    node = nodes.get(parents.get(node.id));
  }
}
const rank = map => [...map.values()].sort((a, b) => b.microseconds - a.microseconds)
  .map(row => ({ ...row, milliseconds: Math.round(row.microseconds / 1000), percent: +(100 * row.microseconds / total).toFixed(2) }));
const output = { source: result.sourceRevision, profileSha256: createHash('sha256').update(bytes).digest('hex'),
  measurement: { from, until, durationSeconds: (until - from) / 1e6, sampledSeconds: total / 1e6, acceptedSamples },
  semantics: 'V8 statistical wall-clock samples limited to API reset through drained snapshot; inclusive stacks overlap. Profiling overhead means this is diagnostic only.',
  exclusive: rank(exclusive), inclusive: rank(inclusive) };
writeFileSync(resolve(directory, 'api-profile-analysis.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ ...output, exclusive: output.exclusive.slice(0, 30), inclusive: output.inclusive.slice(0, 35) }, null, 2));
