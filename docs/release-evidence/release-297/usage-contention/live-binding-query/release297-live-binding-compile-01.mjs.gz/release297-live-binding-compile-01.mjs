import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import ts from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/node_modules/typescript/lib/typescript.js";
import { and, eq, sql } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/node_modules/drizzle-orm/index.js";
import { drizzle } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/node_modules/drizzle-orm/node-postgres/index.js";
import { PgDialect } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/node_modules/drizzle-orm/pg-core/index.js";
import { devices, studentSessions } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/src/schema/classpilot.ts";
import { students } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/src/schema/students.ts";
import { currentStudentSessionAuthorityPredicate } from "file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/src/services/classpilotStudentSessionAuthority.ts";

// Execute the actual private storage helper without importing its database pool.
const source = readFileSync(new URL("file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/src/services/storage.ts"), "utf8");
const body = source.slice(source.indexOf("async function hasExactClasspilotTelemetryBinding("),
  source.indexOf("export type ClasspilotScreenshotAuthorityClaim"));
const javascript = ts.transpileModule(body, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText;
const checkBinding = new Function("sql", "and", "eq", "studentSessions", "students", "devices",
  "currentStudentSessionAuthorityPredicate", `${javascript}; return hasExactClasspilotTelemetryBinding;`)(
  sql, and, eq, studentSessions, students, devices, currentStudentSessionAuthorityPredicate);
const dialect = new PgDialect();
const database = drizzle.mock();
const binding = { schoolId: "synthetic-school", studentId: "synthetic-student",
  studentSessionId: "synthetic-session", deviceId: "synthetic-device" };

const previousQuery = () => database.select({ id: studentSessions.id }).from(studentSessions)
  .innerJoin(students, and(eq(students.id, studentSessions.studentId), eq(students.schoolId, binding.schoolId), eq(students.status, "active")))
  .innerJoin(devices, and(eq(devices.deviceId, studentSessions.deviceId), eq(devices.schoolId, binding.schoolId)))
  .where(and(eq(studentSessions.id, binding.studentSessionId), eq(studentSessions.studentId, binding.studentId),
    eq(studentSessions.deviceId, binding.deviceId), currentStudentSessionAuthorityPredicate()))
  .limit(1).for("share").toSQL();
const normalize = text => text.toLowerCase().replace(/\s+/g, " ").replace(/\s*([(),])\s*/g, "$1").trim();


const iterations=3000,rounds=6;const mock={execute: query=>{dialect.sqlToQuery(query);return {rows:[{id:binding.studentSessionId}]}}};
for(let i=0;i<1000;i++){previousQuery();await checkBinding(binding,mock)}
const results=[];for(let round=0;round<rounds;round++){const measures={};for(const kind of (round%2 ? ['raw','previous']:['previous','raw'])){const start=performance.now();for(let i=0;i<iterations;i++){if(kind==='previous')previousQuery();else await checkBinding(binding,mock)}measures[kind+'Ms']=performance.now()-start;}results.push({round,...measures});}
const median=key=>{const x=results.map(r=>r[key]).sort((a,b)=>a-b);return(x[2]+x[3])/2};console.log(JSON.stringify({mode:'compile-only, no database or production activity',iterationsPerRound:iterations,rounds,warmup:1000,results,previousMedianMs:median('previousMs'),rawMedianMs:median('rawMs'),ratio:median('previousMs')/median('rawMs'),queryCountBefore:1,queryCountAfter:1,authorityCaching:false,capacityAcceptance:false},null,2));
