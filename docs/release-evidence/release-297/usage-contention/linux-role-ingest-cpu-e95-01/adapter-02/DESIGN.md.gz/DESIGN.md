# Restored e95 API CPU diagnostic

Exact e95 application/runtime; ingestion only, 6000 canonical offers, default heap, unchanged server caps, pools, deadlines and lateness limits. Diagnostic only, permanently no capacity acceptance.

The separately captured native-proven snapshot owner restores and validates the immutable same-source snapshot, owns PostgreSQL and its anonymous volume, rechecks the authority horizon at the root-controlled nonce release, restarts the same PG instance, and verifies final clients and cleanup. The adapter retains the frozen CPU launcher and workload tail, owns fresh Redis and all four role containers, and settles both independent cleanup owners before returning to the snapshot owner. No campaign journal or 13-receipt workload entry is invoked.

The configuration hashes candidate, helper/runtime, adapter, all harness modules and owner capture. The one writable API profile file is created wx and only read after actual unforced API exit. Network-none node UID1000 flush proof passed separately. Profiling measures synchronous samples including startup/drain; analysis will separately clip reset-through-drained-snapshot using recorded profiler times.

The snapshot was prepared earlier; no clock renewal or fixture mutation occurs. This restored diagnostic is not a paired fresh-seed throughput comparison. All numerical failures, nonzero coordinator exits and cleanup errors remain failures. No automatic traffic release or retry.
