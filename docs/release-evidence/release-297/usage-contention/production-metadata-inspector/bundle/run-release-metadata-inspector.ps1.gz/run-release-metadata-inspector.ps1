#requires -Version 7.5
# External review candidate: Plan performs AWS reads only; Execute is a separate authorized operation.
[CmdletBinding()]
param(
 [ValidateSet('Plan','Execute')][string]$Mode='Plan',
 [string]$RepositoryRoot='[USERPROFILE]\.codex\worktrees\release-stabilization-297\SchoolPilot',
 [Parameter(Mandatory=$true)][string]$OutDir,
 [string]$ApprovedPlanSha256
)
$ErrorActionPreference='Stop'
if($env:SCHOOLPILOT_RUNTIME_CONFIG_TEST_MODE){throw 'A production metadata operation cannot use the runtime AWS test handler'}
$requestedEvidenceDirectory=$OutDir
$bundleRoot=$PSScriptRoot
$bundleManifest=Get-Content -LiteralPath (Join-Path $bundleRoot 'bundle.json') -Raw | ConvertFrom-Json
foreach($entry in $bundleManifest.files){
 $target=Join-Path $bundleRoot $entry.file
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'External reviewed bundle changed'}
}
foreach($entry in $bundleManifest.repositoryHelpers){
 $target=Join-Path $RepositoryRoot $entry.file
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'Pinned repository helper changed'}
}
. (Join-Path $RepositoryRoot 'scripts/run-mydesk-readiness.ps1')
$OutDir=$requestedEvidenceDirectory # Dot-sourced script parameters share the caller's scope.
$script:EvidenceRootMarkerName='.schoolpilot-release-metadata-evidence-v1'
$script:EvidenceRootMarkerBytes=[Text.Encoding]::UTF8.GetBytes("schoolpilot-release-metadata-evidence-v1`n")
$expectedApi='arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-api-emergency:163'
$expectedWorker='arn:aws:ecs:us-east-1:135775632425:task-definition/schoolpilot-production-scheduler-worker:179'
$expectedSha='7af9d0dd5bc2bd3e13b96d35a577725e07f8b678'
$expectedDigest='sha256:c87433cdf3d88e0c291a50d1ae74fbc116f167048f7db9d6c2d1d0ebfc52b9e8'
$expectedImage="135775632425.dkr.ecr.us-east-1.amazonaws.com/schoolpilot-production-api@$expectedDigest"
$sourcePath=Join-Path $bundleRoot 'inspect-release-metadata.mjs'
$sourceText=[IO.File]::ReadAllText($sourcePath)
$sourceHash=Get-FileSha256 $sourcePath
if([Text.Encoding]::UTF8.GetByteCount($sourceText) -gt 32768){throw 'Inspector command exceeded the reviewed bound'}

function Assert-MetadataProperties($Value,[string[]]$Names,[string]$Label){
 Assert-ExactProperties $Value $Names $Label
 if(@($Value.PSObject.Properties.Name).Count -ne $Names.Count -or @($Value.PSObject.Properties.Name | Where-Object { $_ -cnotin $Names }).Count -gt 0){throw "Incomplete or unexpected $Label fields"}
}
function Get-OneEnvironmentValue($Container,[string]$Name){
 $entries=@($Container.environment | Where-Object name -CEQ $Name)
 if($entries.Count -ne 1 -or @($Container.secrets | Where-Object name -CEQ $Name).Count -gt 0){throw 'Runtime environment binding is ambiguous'}
 return [string]$entries[0].value
}
function Get-BoundProductionContext {
 $identity=Invoke-AwsJson -Arguments @('sts','get-caller-identity','--output','json')
 if($identity.Account -cne '135775632425'){throw 'Wrong account'}
 $services=Get-ServiceSnapshot
 Assert-StableService $services.Api $expectedApi 1 1 'API'
 Assert-StableService $services.Worker $expectedWorker 1 1 'worker'
 $api=Get-TaskDefinitionResponse $expectedApi
 $worker=Get-TaskDefinitionResponse $expectedWorker
 foreach($entry in @(@{Response=$api;Name='api';Arn=$expectedApi},@{Response=$worker;Name='scheduler-worker';Arn=$expectedWorker})){
  $task=$entry.Response.taskDefinition
  if($task.taskDefinitionArn -cne $entry.Arn -or $task.status -cne 'ACTIVE' -or @($task.containerDefinitions).Count -ne 1){throw 'Task definition identity drifted'}
  $container=$task.containerDefinitions[0]
  if($container.name -cne $entry.Name -or $container.image -cne $expectedImage -or (Get-OneEnvironmentValue $container 'GIT_SHA') -cne $expectedSha -or (Get-OneEnvironmentValue $container 'RLS_GUC_ENABLED') -cne 'true'){throw 'Serving source/image/admission drifted'}
 }
 $apiTables=(Get-OneEnvironmentValue $api.taskDefinition.containerDefinitions[0] 'RLS_ENABLED_TABLES').Split(',')
 $workerTables=(Get-OneEnvironmentValue $worker.taskDefinition.containerDefinitions[0] 'RLS_ENABLED_TABLES').Split(',')
 if($apiTables.Count -ne 121 -or @($apiTables | Sort-Object -Unique).Count -ne 121 -or ($apiTables -join ',') -cne ($workerTables -join ',')){throw 'Expected paired121 admission changed'}
 if($worker.taskDefinition.cpu -cne '512' -or $worker.taskDefinition.memory -cne '1024'){throw 'Worker resource profile drifted'}
 $network=$services.Worker.networkConfiguration
 Assert-MetadataProperties $network @('awsvpcConfiguration') 'network'
 Assert-MetadataProperties $network.awsvpcConfiguration @('subnets','securityGroups','assignPublicIp') 'network configuration'
 if($network.awsvpcConfiguration.assignPublicIp -cne 'ENABLED' -or @($network.awsvpcConfiguration.securityGroups).Count -ne 1 -or $network.awsvpcConfiguration.securityGroups[0] -cne 'sg-08af33c99e705a4b7' -or @($network.awsvpcConfiguration.subnets).Count -lt 1){throw 'Worker network changed'}
 $database=Invoke-AwsJson -Arguments @('rds','describe-db-instances','--db-instance-identifier','schoolpilot-production-db','--region','us-east-1','--output','json')
 if(@($database.DBInstances).Count -ne 1){throw 'Database identity ambiguous'}
 $db=$database.DBInstances[0]
 if($db.DBInstanceStatus -cne 'available' -or $db.DBName -cne 'schoolpilot' -or $db.Endpoint.Address -cne 'schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com' -or $db.Endpoint.Port -ne 5432 -or $db.DBSubnetGroup.VpcId -cne 'vpc-0e286e71a65c73ecb' -or $db.Engine -cne 'postgres' -or $db.EngineVersion -cne '16.4'){throw 'Database binding drifted'}
 return [pscustomobject]@{Services=$services;Worker=$worker;Network=$network;Admission=$apiTables;Context=[ordered]@{account='135775632425';region='us-east-1';cluster='schoolpilot-production-cluster';apiArn=$expectedApi;workerArn=$expectedWorker;sourceSha=$expectedSha;image=$expectedImage;networkSha256=(Get-CanonicalJsonSha256 $network);admissionSha256=(Get-CanonicalJsonSha256 $apiTables);database='schoolpilot-production-db';databaseEndpoint=$db.Endpoint.Address;databaseName=$db.DBName;engineVersion=$db.EngineVersion}}
}
function New-InspectorRequest($Worker,[string]$Family,[string]$RunId){
 $request=New-MyDeskReadinessTaskRequest $Worker $expectedDigest
 $request.family=$Family
 if(@($request.volumes).Count -gt 0 -or @($request.containerDefinitions[0].mountPoints).Count -gt 0){throw 'Unexpected worker mounts'}
 $container=$request.containerDefinitions[0]
 if($container.PSObject.Properties['workingDirectory'] -and $container.workingDirectory -and $container.workingDirectory -cne '/app'){throw 'Unexpected working directory'}
 if($container.logConfiguration.options.PSObject.Properties['awslogs-create-group'] -and $container.logConfiguration.options.'awslogs-create-group' -cne 'false'){throw 'Do not create a log group'}
 $container.secrets=@($container.secrets | Where-Object name -CEQ 'DATABASE_URL')
 $container.environment=@(@{name='NODE_ENV';value='production'},@{name='SCHEDULER_ENABLED';value='false'},@{name='RUN_MIGRATIONS_ONLY';value='false'},@{name='RUN_MIGRATIONS_ON_STARTUP';value='false'})
 $container | Add-Member -MemberType NoteProperty -Name command -Value @('node','--input-type=module','-e',$sourceText) -Force
 $container | Add-Member -MemberType NoteProperty -Name workingDirectory -Value '/app' -Force
 $container | Add-Member -MemberType NoteProperty -Name readonlyRootFilesystem -Value $true -Force
 $container | Add-Member -MemberType NoteProperty -Name healthCheck -Value @{command=@('CMD','node','-e','process.exit(0)');interval=30;timeout=2;retries=1;startPeriod=0} -Force
 $request.PSObject.Properties.Remove('taskRoleArn') # Only the execution role reads the existing secret/log references.
 $request | Add-Member -MemberType NoteProperty -Name tags -Value @(@{key='release-metadata-run';value=$RunId}) -Force
 return $request
}
function Get-RegistrationProjection($Response){
 $fields=@('family','taskRoleArn','executionRoleArn','networkMode','containerDefinitions','volumes','placementConstraints','requiresCompatibilities','cpu','memory','runtimePlatform','ephemeralStorage','proxyConfiguration','inferenceAccelerators','pidMode','ipcMode','enableFaultInjection')
 $metadata=@('taskDefinitionArn','revision','status','requiresAttributes','compatibilities','registeredAt','registeredBy','deregisteredAt','tags')
 $request=[ordered]@{}
 foreach($property in $Response.taskDefinition.PSObject.Properties){if($property.Name -cin $fields){if($null -ne $property.Value){$request[$property.Name]=$property.Value}}elseif($property.Name -cnotin $metadata){throw 'Unreviewed registration response field'}}
 if(@($Response.tags).Count -gt 0){$request.tags=@($Response.tags)}
 return $request
}
function Read-SafeMetadataPayload($Events){
 if(@($Events).Count -lt 1 -or @($Events).Count -gt 256){throw 'Incomplete or oversized metadata transport'}
 $parts=@();$totalBytes=0
 foreach($event in $Events){
  $line=[string]$event.message;$totalBytes+=[Text.Encoding]::UTF8.GetByteCount($line)
  if($totalBytes -gt 3200000 -or $line.Length -gt 12000){throw 'Metadata transport exceeded its bound'}
  $part=ConvertFrom-StrictJsonText $line
  Assert-MetadataProperties $part @('version','index','count','payloadSha256','data') 'metadata transport'
  if($part.version -ne 1 -or -not(Test-IsJsonInteger $part.index) -or -not(Test-IsJsonInteger $part.count) -or $part.count -lt 1 -or $part.count -gt 256 -or $part.index -lt 0 -or $part.index -ge $part.count -or $part.payloadSha256 -cnotmatch '^[a-f0-9]{64}$' -or $part.data -cnotmatch '^[A-Za-z0-9+/]*={0,2}$'){throw 'Invalid metadata transport'}
  $parts+=,$part
 }
 $count=$parts[0].count;$payloadHash=$parts[0].payloadSha256
 if($parts.Count -ne $count -or @($parts.index | Sort-Object -Unique).Count -ne $count){throw 'Missing metadata transport part'}
 $memory=[IO.MemoryStream]::new()
 try{
  foreach($part in @($parts | Sort-Object index)){
   if($part.count -ne $count -or $part.payloadSha256 -cne $payloadHash){throw 'Mixed metadata transport'}
   $bytes=[Convert]::FromBase64String($part.data);if($bytes.Length -gt 8192){throw 'Oversized metadata part'}
   $memory.Write($bytes,0,$bytes.Length)
  }
  $payload=$memory.ToArray();if($payload.Length -gt 2097152 -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($payload)).ToLowerInvariant() -cne $payloadHash){throw 'Metadata integrity failure'}
  $report=ConvertFrom-StrictJsonText ([Text.UTF8Encoding]::new($false,$true).GetString($payload))
 }finally{$memory.Dispose()}
 Assert-MetadataProperties $report @('version','mode','observedAt','serverVersionNum','readOnly','role','inventory','ledger','pilot') 'metadata report'
 if($report.version -ne 1 -or $report.mode -cne 'read_only_release_metadata' -or $report.readOnly -ne $true -or $report.serverVersionNum -lt 160000 -or $report.serverVersionNum -ge 170000){throw 'Wrong metadata contract'}
 [void][DateTimeOffset]::Parse($report.observedAt)
 Assert-MetadataProperties $report.role @('superuser','bypassRls') 'metadata role'
 if($report.role.superuser -isnot [bool] -or $report.role.bypassRls -isnot [bool]){throw 'Invalid role flags'}
 $shape=@{
  schemas=@('name');relations=@('schema','name','kind','rls','forced','partition','definitionSha256');columns=@('schema','table','name','typeSha256','notNull','identity','generated','defaultSha256');constraints=@('schema','table','name','kind','validated','definitionSha256');indexes=@('schema','table','name','valid','ready','unique','primary','definitionSha256');policies=@('schema','table','name','permissive','command','rolesSha256','usingSha256','checkSha256');triggers=@('schema','table','name','enabled','definitionSha256');functions=@('schema','name','signatureSha256','securityDefiner','volatility','kind','definitionSha256');types=@('schema','name','kind','definitionSha256');sequences=@('schema','name','attributesSha256');views=@('schema','name','kind','definitionSha256');extensions=@('name','attributesSha256')
 }
 $caps=@{schemas=32;relations=512;columns=12000;constraints=4096;indexes=4096;policies=2048;triggers=2048;functions=2048;types=2048;sequences=512;views=512;extensions=128}
 Assert-MetadataProperties $report.inventory @($shape.Keys) 'metadata inventory'
 foreach($kind in $shape.Keys){
  if(@($report.inventory.$kind).Count -gt $caps[$kind]){throw 'Metadata catalog exceeds its bound'}
  foreach($row in @($report.inventory.$kind)){
   Assert-MetadataProperties $row $shape[$kind] 'catalog row'
   foreach($field in $shape[$kind]){
    $value=$row.$field
    if($field -cin @('schema','table','name')){if($value -isnot [string] -or $(if($kind -ceq 'extensions'){$value -cnotmatch '^[A-Za-z_][A-Za-z0-9_$-]{0,127}$'}else{$value -cnotmatch '^[A-Za-z_][A-Za-z0-9_$]{0,127}$'})){throw 'Invalid catalog identifier'}}
    elseif($field.EndsWith('Sha256')){if($value -isnot [string] -or $value -cnotmatch '^[a-f0-9]{64}$'){throw 'Invalid catalog hash'}}
    elseif($field -cin @('kind','enabled','identity','generated','volatility','command')){if($value -isnot [string] -or $value -cnotmatch '^[rpcvSmSfdebuixatODRAisw*]?$'){throw 'Invalid catalog enum'}}
    elseif($value -isnot [bool]){throw 'Invalid catalog Boolean'}
   }
  }
 }
 if(@($report.ledger).Count -lt 1 -or @($report.ledger).Count -gt 1024){throw 'Invalid ledger size'}
 foreach($row in @($report.ledger)){
  Assert-MetadataProperties $row @('id','checksum','mode','status','application_sha') 'ledger row'
  if($row.id -cnotmatch '^[A-Za-z0-9._:-]{1,160}$' -or $row.checksum -cnotmatch '^[a-f0-9]{64}$' -or $row.mode -cnotin @('transactional','nontransactional') -or $row.status -cnotin @('running','complete','failed') -or $row.application_sha -cnotmatch '^[A-Za-z0-9._:-]{1,128}$'){throw 'Invalid ledger metadata'}
 }
 Assert-MetadataProperties $report.pilot @('matches','school') 'pilot result'
 if($report.pilot.matches -cnotin @(0,1,2)){throw 'Invalid pilot count'}
 if($report.pilot.matches -eq 1){
  $school=$report.pilot.school
  Assert-MetadataProperties $school @('id','domain','nameSha256','flags','licenses','classpilotEntitled') 'pilot school'
  if($school.id -cnotmatch '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' -or $school.domain -cne 'desalescincy.org' -or $school.nameSha256 -cnotmatch '^[a-f0-9]{64}$' -or $school.classpilotEntitled -isnot [bool]){throw 'Invalid pilot projection'}
  Assert-MetadataProperties $school.flags @('active_status','is_active','not_deleted','not_disabled','plan_not_canceled','within_paid_through') 'pilot flags'
  foreach($value in $school.flags.PSObject.Properties.Value){if($value -isnot [bool]){throw 'Invalid pilot flag'}}
  if(@($school.licenses).Count -gt 3){throw 'Invalid license count'}
  foreach($license in @($school.licenses)){Assert-MetadataProperties $license @('product','active_status','unexpired') 'license';if($license.product -cnotin @('CLASSPILOT','PASSPILOT','GOPILOT') -or $license.active_status -isnot [bool] -or $license.unexpired -isnot [bool]){throw 'Invalid license projection'}}
 }elseif($null -ne $report.pilot.school){throw 'Ambiguous pilot must not return a binding'}
 return $report
}

$directory=Assert-PrivateExternalRoot $OutDir $RepositoryRoot
$planPath=Join-Path $directory 'plan.json';$receiptPath=Join-Path $directory 'receipt.json'
$current=Get-BoundProductionContext
if($Mode -ceq 'Plan'){
 if(Test-Path -LiteralPath $planPath){throw 'Use a new plan directory; do not replace prior evidence'}
 $runId=[Guid]::NewGuid().ToString('N');$family='schoolpilot-production-release-metadata-'+$runId.Substring(0,12)
 $request=New-InspectorRequest $current.Worker $family $runId
 $plan=[ordered]@{version=1;mode='bounded_read_only_metadata_task';createdAt=[DateTimeOffset]::UtcNow.ToString('o');runId=$runId;family=$family;context=$current.Context;sourceSha256=$sourceHash;wrapperSha256=(Get-FileSha256 $PSCommandPath);bundleSha256=(Get-FileSha256 (Join-Path $bundleRoot 'bundle.json'));request=$request;network=$current.Network;requestSha256=(Get-CanonicalJsonSha256 $request);limits=@{connections=1;connectSeconds=10;statementSeconds=15;lockSeconds=2;processSeconds=45;taskMinutes=4;outputBytes=2097152};cloudMutationsPerformed=0}
 Write-SanitizedJson $planPath $plan
 Write-Output "Plan only: $planPath sha256=$(Get-FileSha256 $planPath)"
 return
}
if($ApprovedPlanSha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-FileSha256 $planPath) -cne $ApprovedPlanSha256){throw 'Exact reviewed plan hash is required'}
if(Test-Path -LiteralPath $receiptPath){throw 'An execution receipt already exists; inspect/recover that operation instead of starting another'}
$plan=ConvertFrom-StrictJsonText -Text (Get-Content -LiteralPath $planPath -Raw)
if($plan.version -ne 1 -or $plan.mode -cne 'bounded_read_only_metadata_task' -or $plan.runId -cnotmatch '^[a-f0-9]{32}$' -or $plan.family -cne ('schoolpilot-production-release-metadata-'+$plan.runId.Substring(0,12)) -or $plan.sourceSha256 -cne $sourceHash -or $plan.wrapperSha256 -cne (Get-FileSha256 $PSCommandPath) -or $plan.bundleSha256 -cne (Get-FileSha256 (Join-Path $bundleRoot 'bundle.json'))){throw 'Reviewed inspector identity changed'}
if((Get-CanonicalJsonSha256 $plan.context) -cne (Get-CanonicalJsonSha256 $current.Context) -or (Get-CanonicalJsonSha256 $plan.request) -cne (Get-CanonicalJsonSha256 (New-InspectorRequest $current.Worker $plan.family $plan.runId))){throw 'Reviewed source/network/request changed'}
$definitionArn=$null;$taskArn=$null;$stopped=$false;$registered=$false;$runAttempted=$false
$receipt=[ordered]@{version=1;runId=$plan.runId;planSha256=$ApprovedPlanSha256;status='preparing';definitionArn=$null;taskArn=$null;cleanup=@();databaseWrites=0;servicesUpdated=0}
Write-SanitizedJson $receiptPath $receipt
try{
 $inputPath=Write-PrivateAwsJsonInput $plan.request
 try{$response=Invoke-AwsJson -Arguments @('ecs','register-task-definition','--cli-input-json',('file://'+$inputPath.Replace('\','/')),'--region','us-east-1','--output','json')}finally{Remove-Item -LiteralPath $inputPath -Force -ErrorAction SilentlyContinue}
 $definitionArn=[string]$response.taskDefinition.taskDefinitionArn
 if($definitionArn -cnotmatch ('^arn:aws:ecs:us-east-1:135775632425:task-definition/'+[regex]::Escape($plan.family)+':[1-9][0-9]*$')){throw 'Unexpected inspector definition identity'}
 $registered=$true;$receipt.definitionArn=$definitionArn;Write-SanitizedJson $receiptPath $receipt
 $verified=Get-TaskDefinitionResponse $definitionArn
 if((Get-CanonicalJsonSha256 (Get-RegistrationProjection $verified)) -cne $plan.requestSha256){throw 'Registered inspector payload drifted'}
 $registered=$true;$receipt.definitionArn=$definitionArn;Write-SanitizedJson $receiptPath $receipt
 $request=[ordered]@{cluster='schoolpilot-production-cluster';taskDefinition=$definitionArn;count=1;launchType='FARGATE';clientToken=$plan.runId;startedBy=$plan.runId;enableExecuteCommand=$false;networkConfiguration=$plan.network}
 $inputPath=Write-PrivateAwsJsonInput $request
 $runAttempted=$true
 try{try{$started=Invoke-AwsJson -Arguments @('ecs','run-task','--cli-input-json',('file://'+$inputPath.Replace('\','/')),'--region','us-east-1','--output','json')}catch{$started=Invoke-AwsJson -Arguments @('ecs','run-task','--cli-input-json',('file://'+$inputPath.Replace('\','/')),'--region','us-east-1','--output','json')}}finally{Remove-Item -LiteralPath $inputPath -Force -ErrorAction SilentlyContinue}
 if(@($started.failures).Count -ne 0 -or @($started.tasks).Count -ne 1){throw 'Inspector task did not start exactly once'}
 $taskArn=[string]$started.tasks[0].taskArn
 if($taskArn -cnotmatch '^arn:aws:ecs:us-east-1:135775632425:task/schoolpilot-production-cluster/[a-f0-9]{32}$'){throw 'Unexpected inspector task identity'}
 $receipt.taskArn=$taskArn;$receipt.status='running';Write-SanitizedJson $receiptPath $receipt
 $deadline=[DateTimeOffset]::UtcNow.AddMinutes(4)
 do{
  $observed=Invoke-AwsJson -Arguments @('ecs','describe-tasks','--cluster','schoolpilot-production-cluster','--tasks',$taskArn,'--region','us-east-1','--output','json')
  if(@($observed.failures).Count -ne 0 -or @($observed.tasks).Count -ne 1){throw 'Inspector task is missing'}
  $task=$observed.tasks[0]
  if($task.taskArn -cne $taskArn -or $task.taskDefinitionArn -cne $definitionArn -or $task.startedBy -cne $plan.runId){throw 'Inspector task ownership drifted'}
  if($task.lastStatus -ceq 'STOPPED'){$stopped=$true;break}
  Start-Sleep -Seconds 3
 }while([DateTimeOffset]::UtcNow -lt $deadline)
 if(-not $stopped -or @($task.containers).Count -ne 1 -or $task.containers[0].name -cne 'scheduler-worker' -or -not $task.containers[0].PSObject.Properties['exitCode'] -or $task.containers[0].exitCode -ne 0){throw 'Inspector did not finish successfully within its deadline'}
 $logging=$plan.request.containerDefinitions[0].logConfiguration.options
 $stream=$logging.'awslogs-stream-prefix'+'/scheduler-worker/'+$taskArn.Split('/')[-1]
 $report=$null
 for($attempt=0;$attempt -lt 10;$attempt++){
  try{
  $events=@();$token=$null;$pages=0
  do{
   $arguments=@('logs','get-log-events','--log-group-name',$logging.'awslogs-group','--log-stream-name',$stream,'--start-from-head','--limit','1000','--region','us-east-1','--output','json')
   if($token){$arguments+=@('--next-token',$token)}
   $page=Invoke-AwsJson -Arguments $arguments;$events+=@($page.events);$next=[string]$page.nextForwardToken;$pages++
   if($events.Count -gt 256){throw 'Metadata log envelope exceeded its bound'}
   if($next -ceq $token){break};$token=$next
  }while($pages -lt 8)
  $report=Read-SafeMetadataPayload $events;break
  }catch{if($attempt -eq 9){throw 'Complete allowlisted metadata was not available'}}
  Start-Sleep -Seconds 3
 }
 if($null -eq $report){throw 'No verified metadata result'}
 $receipt.status='inventoried';$receipt.observedAt=[DateTimeOffset]::UtcNow.ToString('o');$receipt.report=$report
 Write-SanitizedJson $receiptPath $receipt
}catch{
 $receipt.status='failed';$receipt.failureCode='BOUNDED_METADATA_INSPECTION_FAILED';Write-SanitizedJson $receiptPath $receipt
 throw 'Inspector failed; inspect the private receipt. No serving service was updated.'
}finally{
 # Recover only this unique family/run if AWS lost a registration or RunTask response.
 try{
  if(-not $definitionArn){
   $definitions=Invoke-AwsJson -Arguments @('ecs','list-task-definitions','--family-prefix',$plan.family,'--max-items','10','--region','us-east-1','--output','json')
   if($definitions.PSObject.Properties['NextToken'] -or $definitions.PSObject.Properties['nextToken'] -or @($definitions.taskDefinitionArns).Count -gt 1){throw 'Ambiguous inspector registration outcome'}
   if(@($definitions.taskDefinitionArns).Count -eq 1){$candidate=Get-TaskDefinitionResponse $definitions.taskDefinitionArns[0];if((Get-CanonicalJsonSha256 (Get-RegistrationProjection $candidate)) -cne $plan.requestSha256){throw 'Unowned inspector definition'};$definitionArn=[string]$candidate.taskDefinition.taskDefinitionArn;$registered=$true;$receipt.definitionArn=$definitionArn}
  }
  if($definitionArn -and -not $taskArn -and $runAttempted){
   # ECS startedBy must be its only filter (cluster and pagination are scope).
   $running=Invoke-AwsJson -Arguments @('ecs','list-tasks','--cluster','schoolpilot-production-cluster','--started-by',$plan.runId,'--max-items','2','--region','us-east-1','--output','json')
   if($running.PSObject.Properties['NextToken'] -or $running.PSObject.Properties['nextToken'] -or @($running.taskArns).Count -gt 1){throw 'Ambiguous inspector task outcome'}
   if(@($running.taskArns).Count -eq 1){$taskArn=[string]$running.taskArns[0]}
   else {
    # An unknown RunTask response may already have reached STOPPED. Family is
    # unique to this reviewed operation; describe still verifies exact startedBy.
    $finished=Invoke-AwsJson -Arguments @('ecs','list-tasks','--cluster','schoolpilot-production-cluster','--family',$plan.family,'--desired-status','STOPPED','--max-items','2','--region','us-east-1','--output','json')
    if($finished.PSObject.Properties['NextToken'] -or $finished.PSObject.Properties['nextToken'] -or @($finished.taskArns).Count -ne 1){throw 'Unknown inspector RunTask outcome remains unresolved'}
    $taskArn=[string]$finished.taskArns[0]
   }
   if($taskArn -cnotmatch '^arn:aws:ecs:us-east-1:135775632425:task/schoolpilot-production-cluster/[a-f0-9]{32}$'){throw 'Unexpected recovered inspector identity'}
   $receipt.taskArn=$taskArn
  }
  if($taskArn -and -not $stopped){
   $observed=Invoke-AwsJson -Arguments @('ecs','describe-tasks','--cluster','schoolpilot-production-cluster','--tasks',$taskArn,'--region','us-east-1','--output','json')
   if(@($observed.tasks).Count -ne 1 -or $observed.tasks[0].taskDefinitionArn -cne $definitionArn -or $observed.tasks[0].startedBy -cne $plan.runId){throw 'Refuse cleanup of an unowned task'}
   if($observed.tasks[0].lastStatus -cne 'STOPPED'){[void](Invoke-AwsJson -Arguments @('ecs','stop-task','--cluster','schoolpilot-production-cluster','--task',$taskArn,'--reason','Bounded read-only metadata inspection cleanup','--region','us-east-1','--output','json'));$receipt.cleanup+=,'Owned task stop requested; verify terminal STOPPED before closing operation'}else{$stopped=$true}
  }
  if($definitionArn -and $registered){[void](Invoke-AwsJson -Arguments @('ecs','deregister-task-definition','--task-definition',$definitionArn,'--region','us-east-1','--output','json'));$receipt.cleanup+=,'Owned inspector definition deregistered'}
 }catch{$receipt.cleanup+=,'Cleanup state unresolved; inspect only the recorded owned run/family/task before retry';$receipt.status='cleanup_unresolved'}
 $receipt.taskStopped=$stopped;Write-SanitizedJson $receiptPath $receipt
}
if($receipt.status -cne 'inventoried' -or -not $receipt.taskStopped){throw 'Inspection or cleanup remains incomplete'}
Write-Output "Metadata inspection: $receiptPath sha256=$(Get-FileSha256 $receiptPath)"

