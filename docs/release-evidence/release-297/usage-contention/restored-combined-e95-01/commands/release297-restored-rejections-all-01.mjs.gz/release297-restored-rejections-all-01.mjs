import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const temp=process.env.TEMP,driver=join(temp,'release297-restored-role-e95-driver-01/scripts/load/usage/roles'),run=join(temp,'release297-role-restored-combined-e95-01'),out=join(temp,'release297-restored-rejection-analysis-01');
const hash=x=>createHash('sha256').update(x).digest('hex');
const collector=`import nativeAssert from 'node:assert/strict';
export const assertionFailures=[];
const scalar=x=>x===undefined?'undefined':x===null||typeof x==='boolean'||typeof x==='number'?x:typeof x==='string'?x.slice(0,150):Array.isArray(x)?{type:'array',length:x.length}:{type:typeof x,keys:Object.keys(x??{}).slice(0,12)};
const assert=new Proxy(nativeAssert,{get(target,key){const fn=target[key];if(typeof fn!=='function')return fn;return(...args)=>{try{return fn(...args);}catch(error){assertionFailures.push({operator:error.operator,actual:scalar(error.actual),expected:scalar(error.expected),lines:String(error.stack).split('\\n').filter(x=>x.includes('validator-collect.mjs')).slice(1,3)});}};}});`;
const raw=readFileSync(join(driver,'campaign-validation.mjs'),'utf8');
const source=raw.replace("import assert from 'node:assert/strict';",collector).replace(/from '([^']+)'/g,(all,name)=>name.startsWith('.')?`from '${pathToFileURL(join(driver,name)).href}'`:all)+'\nexport {planCheck,imageCheck,preparationCheck,metricsCheck,ownershipCheck};\n';
writeFileSync(join(out,'validator-collect.mjs'),source,{flag:'wx'});
const mod=await import(pathToFileURL(join(out,'validator-collect.mjs'))),loader=await import(pathToFileURL(join(driver,'receipt-loader.mjs'))),manifest=readFileSync(join(run,'receipt-manifest.json')),plan=readFileSync(join(run,'run-plan.json')),b=loader.loadBoundRun(run,hash(manifest),hash(plan)).bundle;
const result={analysisOnly:true,validityClaim:false,description:'Records otherwise masked assertion failures without changing any run receipt. This instrumented evaluator cannot validate acceptance.',checks:{}};
for(const name of ['planCheck','imageCheck','preparationCheck','metricsCheck','ownershipCheck']){mod.assertionFailures.length=0;let stopped;try{mod[name](b,hash(plan));}catch(e){stopped={message:e.message,stack:String(e.stack).split('\n').filter(x=>x.includes('validator-collect.mjs')).slice(0,2)};}result.checks[name]={failures:[...mod.assertionFailures],stopped};}
writeFileSync(join(out,'all-rejections.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
