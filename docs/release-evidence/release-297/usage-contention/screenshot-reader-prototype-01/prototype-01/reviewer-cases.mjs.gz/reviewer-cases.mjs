import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';

// Independent external correctness additions. This module never owns a fixture,
// changes application code, starts timing, or publishes an authority result.
export async function runReviewerCases({
  check,a,b,admin,observer,pool,root,storage,context,sql,
  sequential,combined,comparableEvidence,projectionFromEvidence,waitBlocked,
}) {
  const readers={sequential,combined};
  const insertOwner=async(id,offset="interval '1 day'")=>{
    // Only fixed test-authored interval expressions are accepted here.
    assert.ok(["interval '1 day'","interval '2 days'"].includes(offset));
    const teaching=await admin.query(`INSERT INTO teaching_sessions
      (id,group_id,teacher_id,school_id,start_time,control_updated_at,
       session_mode,roster_snapshot_completed_at,created_at)
      SELECT $1,group_id,teacher_id,school_id,start_time,
        COALESCE(control_updated_at,start_time)+${offset},
        'live',roster_snapshot_completed_at,created_at
      FROM teaching_sessions WHERE id=$2 RETURNING id`,[id,a.teaching.id]);
    assert.equal(teaching.rowCount,1);
    const roster=await admin.query(`INSERT INTO classpilot_session_students
      (id,school_id,teaching_session_id,group_id,student_id,student_name_snapshot,captured_at)
      SELECT $1,school_id,$2,group_id,student_id,student_name_snapshot,captured_at
      FROM classpilot_session_students WHERE teaching_session_id=$3 AND student_id=$4
      RETURNING id`,[randomUUID(),id,a.teaching.id,a.student.id]);
    assert.equal(roster.rowCount,1);
  };
  const removeOwners=async ids=>{
    await admin.query('DELETE FROM classpilot_session_students WHERE teaching_session_id=ANY($1::text[])',[ids]);
    await admin.query('DELETE FROM teaching_sessions WHERE id=ANY($1::text[])',[ids]);
  };
  const rankEvidence=(evidence)=>storage.getClasspilotTelemetryOwnerProjection(
    a.school.id,a.student.id,{execute:async()=>({rows:evidence.owners})});

  for(const mode of ['sequential','combined']) {
    await check(`${mode}: Q4 sees new winning owner committed while Q3 teaching lock waits`,async()=>{
      const winner=randomUUID();let operation;
      await admin.query('BEGIN');
      try {
        // Q1/session and Q2/control are free. Only the existing Q3 teaching
        // candidate is blocked, so Q4 must obtain a fresh subsequent snapshot.
        assert.equal((await admin.query('UPDATE teaching_sessions SET control_updated_at=control_updated_at WHERE id=$1',[a.teaching.id])).rowCount,1);
        let announce;const started=new Promise(resolve=>announce=resolve);let pid;
        operation=root(a.school.id,async tx=>{
          pid=context.getOwnedTenantStore().client.processID;announce();
          const evidence=await readers[mode](tx,a.options);
          assert.equal(evidence.stage,'owner');
          assert.equal(evidence.candidate.teachingSessionId,a.teaching.id);
          assert.ok(evidence.owners.some(row=>row.id===winner));
          assert.equal((await rankEvidence(evidence)).teachingSessionId,winner);
          const projected=await projectionFromEvidence(a.options,evidence);
          assert.equal(projected.projection.authority.kind,'student_session');
          const actual=await storage.getClasspilotScreenshotAuthorityProjection(a.options,tx);
          assert.deepEqual(projected.projection,actual);
          return evidence;
        });
        void operation.catch(()=>{});await started;await waitBlocked(pid);
        await insertOwner(winner);
        await admin.query('COMMIT');
        await operation;
      } finally {
        await admin.query('ROLLBACK').catch(()=>{});
        if(operation)await Promise.allSettled([operation]);
        await removeOwners([winner]);
      }
    });
  }

  await check('native tied owner rows retain actual localeCompare ranking and null control timestamp fallback',async()=>{
    const suffix=randomUUID(),ids=['spi_tie_a_'+suffix,'spi_tie_B_'+suffix];
    // Deliberately distinguish JS locale ranking from binary text ordering.
    const expected=[...ids].sort((left,right)=>right.localeCompare(left))[0];
    assert.notEqual(expected,[...ids].sort().at(-1));
    try {
      await admin.query('BEGIN');
      for(const id of ids)await insertOwner(id,"interval '2 days'");
      // Equal effective control/start/creation times require the final ID tie
      // break; a null controlUpdatedAt must use startTime unchanged.
      await admin.query(`UPDATE teaching_sessions SET control_updated_at=NULL,
        start_time=(SELECT COALESCE(control_updated_at,start_time)+interval '2 days' FROM teaching_sessions WHERE id=$1),
        created_at='2026-01-01 00:00:00.123456'::timestamp WHERE id=ANY($2::text[])`,[a.teaching.id,ids]);
      await admin.query('COMMIT');
      await root(a.school.id,async tx=>{
        const old=await sequential(tx,a.options),next=await combined(tx,a.options);
        assert.deepEqual(comparableEvidence(next),comparableEvidence(old));
        const tied=next.owners.filter(row=>ids.includes(row.id));assert.equal(tied.length,2);
        assert.ok(tied.every(row=>row.controlUpdatedAt===null));
        assert.equal((await rankEvidence(old)).teachingSessionId,expected);
        assert.equal((await rankEvidence(next)).teachingSessionId,expected);
        assert.equal((await storage.getClasspilotTelemetryOwnerProjection(a.school.id,a.student.id,tx)).teachingSessionId,expected);
        assert.deepEqual((await projectionFromEvidence(a.options,next)).projection,
          await storage.getClasspilotScreenshotAuthorityProjection(a.options,tx));
      });
    } finally {
      await admin.query('ROLLBACK').catch(()=>{});
      await removeOwners(ids);
    }
  });

  await check('actual null-owner anchor retains null fields and unchanged JS student fallback',async()=>root(a.school.id,async tx=>{
    let rows;
    // A missing roster owner is a real raw-query result, not an invented empty
    // array. Joining it to collected evidence below tests only the unchanged
    // JS branch; it does not claim the function reached Q4 without Q3.
    const owner=await storage.getClasspilotTelemetryOwnerProjection(a.school.id,randomUUID(),{
      execute:async query=>{const result=await tx.execute(query);rows=result.rows;return result;},
    });
    assert.equal(rows.length,1);
    assert.deepEqual(rows[0],{hasActiveSupervision:false,id:null,controlUpdatedAt:null,startTime:null,createdAt:null});
    assert.deepEqual(owner,{hasActiveSupervision:false,teachingSessionId:undefined});
    const old=await sequential(tx,a.options),next=await combined(tx,a.options);
    const projectedOld=await projectionFromEvidence(a.options,{...old,owners:rows});
    const projectedNext=await projectionFromEvidence(a.options,{...next,owners:rows});
    assert.equal(projectedNext.projection.authority.kind,'student_session');
    assert.deepEqual(projectedNext,projectedOld);
  }));

  await check('function retains all six joined row locks until the outer transaction releases',async()=>{
    const rows=[
      ['session','SELECT id FROM student_sessions WHERE id=$1 FOR UPDATE NOWAIT',[a.options.studentSessionId]],
      ['student','SELECT id FROM students WHERE id=$1 FOR UPDATE NOWAIT',[a.student.id]],
      ['device','SELECT device_id FROM devices WHERE device_id=$1 FOR UPDATE NOWAIT',[a.options.deviceId]],
      ['control','SELECT id FROM classpilot_student_control_states WHERE school_id=$1 AND student_id=$2 FOR UPDATE NOWAIT',[a.school.id,a.student.id]],
      ['teaching','SELECT id FROM teaching_sessions WHERE id=$1 FOR UPDATE NOWAIT',[a.teaching.id]],
      ['roster','SELECT id FROM classpilot_session_students WHERE teaching_session_id=$1 AND student_id=$2 FOR UPDATE NOWAIT',[a.teaching.id,a.student.id]],
    ];
    let announce,release;const ready=new Promise(resolve=>announce=resolve),held=new Promise(resolve=>release=resolve);
    const operation=root(a.school.id,async tx=>{
      assert.equal((await combined(tx,a.options)).stage,'owner');announce();await held;
    });
    void operation.catch(()=>{});
    try {
      await Promise.race([ready,operation.then(()=>assert.fail('transaction closed before held proof'))]);
      for(const [name,text,params]of rows){
        await admin.query('BEGIN');
        try {await assert.rejects(admin.query(text,params),error=>error.code==='55P03',name+' must remain SHARE locked');}
        finally {await admin.query('ROLLBACK');}
      }
      release();await operation;
      for(const [name,text,params]of rows){
        await admin.query('BEGIN');
        try {assert.equal((await admin.query(text,params)).rowCount,1,name+' must unlock after transaction');}
        finally {await admin.query('ROLLBACK');}
      }
    } finally {release();await Promise.allSettled([operation]);}
  });

  await check('A to B to A uses one restricted physical client with fresh GUCs, parameters and rows',async()=>{
    const leases=[];let firstRevision;
    for(const [index,fixture]of [a,b,a].entries()){
      if(index===2)await admin.query('UPDATE classpilot_student_control_states SET revision=revision+1 WHERE school_id=$1 AND student_id=$2',[a.school.id,a.student.id]);
      await root(fixture.school.id,async tx=>{
        const store=context.getOwnedTenantStore();
        const posture=(await tx.execute(sql`SELECT current_setting('app.school_id') AS school,
          current_setting('app.is_super') AS super,pg_backend_pid() AS pid,
          rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user`)).rows[0];
        assert.equal(posture.school,fixture.school.id);assert.equal(posture.super,'off');
        assert.equal(posture.rolsuper,false);assert.equal(posture.rolbypassrls,false);
        assert.equal(posture.pid,store.client.processID);
        const next=await combined(tx,fixture.options),old=await sequential(tx,fixture.options);
        assert.deepEqual(comparableEvidence(next),comparableEvidence(old));
        assert.equal(next.session.id,fixture.options.studentSessionId);
        assert.equal(next.candidate.teachingSessionId,fixture.teaching.id);
        const foreign=fixture===a?b:a;
        assert.deepEqual(await combined(tx,foreign.options),{stage:'session_missing'});
        if(index===0)firstRevision=next.control.revision;
        if(index===2){assert.equal(next.control.revision,firstRevision+1);assert.notStrictEqual(next,leases[0].evidence);}
        leases.push({client:store.client,pid:posture.pid,evidence:next});
      });
      await context.drainTenantContextReleases();
    }
    assert.strictEqual(leases[0].client,leases[1].client,'native fixture must actually exercise one physical client');
    assert.strictEqual(leases[1].client,leases[2].client);
    assert.equal(new Set(leases.map(lease=>lease.pid)).size,1);
  });
}
