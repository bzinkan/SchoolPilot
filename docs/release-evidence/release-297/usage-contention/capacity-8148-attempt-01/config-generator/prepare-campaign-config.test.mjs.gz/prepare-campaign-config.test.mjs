import test from 'node:test';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {SOURCE,disjoint,prepare,originalScriptHashes} from './prepare-campaign-config.mjs';

test('source is the final reviewed immutable commit',()=>assert.equal(SOURCE,'814844f344a45159152415b0fb6d7027f05b093e'));
test('closed input rejects mode/resource/retry overrides before accessing receipts',async()=>{
  for(const input of[{}, {mode:'diagnostic'}, {autoRelease:true}, {apiCpu:2}, {retry:3}])await assert.rejects(prepare(input),/Closed input schema/);
});
test('Windows path equality and both nesting directions are refused',()=>{
  const root=resolve('C:/example/campaign'),child=resolve('C:/example/campaign/private');
  assert.throws(()=>disjoint(root,root));assert.throws(()=>disjoint(root,child));assert.throws(()=>disjoint(child,root));
  assert.throws(()=>disjoint(resolve('C:/example/campaign'),resolve('C:\\example\\campaign\\private')));
  assert.doesNotThrow(()=>disjoint(root,resolve('C:/example/campaign-sibling')));
});
test('original comparison uses the complete canonical coordinator inventory',()=>{
  const inventory=originalScriptHashes('C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot');
  for(const name of['run-release-enabled-scale.ps1','release-enabled-scale.mjs','release-enabled-generator.mjs','release-enabled-process.mjs','release-enabled-profile.mjs','prepare-release-control-ownership.mjs','local-usage-scale.mjs'])assert.match(inventory[name],/^[a-f0-9]{64}$/);
  assert.ok(Object.keys(inventory).length>7);
});
