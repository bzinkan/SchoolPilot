import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {execFileSync} from 'node:child_process';
export const SOURCE='814844f344a45159152415b0fb6d7027f05b093e';
export const FALLBACK='6e251f2d1eece2b98fa2325e1fa46bd2b8553420';
export const CLONE='C:/Users/zinka/.codex/artifacts/release297-source-814844f3-lf-01';
export const ENDPOINT='npipe:////./pipe/dockerDesktopLinuxEngine';
export const SCANNER='aquasec/trivy@sha256:af6acf9a6b85dfe389a1941505c0ce9efef52a4719635e1a962f022a3d855daa';
export const MIGRATION='classpilot-heartbeat-screenshot-evidence-v1-20261003';
export const CONTRACT='2e7ff0728fd875c151e641b506c2e5d650d818ece2e54977db4f9fe4cefed036';
export const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const json=path=>JSON.parse(readFileSync(path,'utf8').replace(/^\uFEFF/,''));
export const record=path=>({path:resolve(path),sha256:sha(readFileSync(path))});
export function checked(record_){assert.equal(typeof record_?.path,'string');assert.match(record_.sha256,/^[a-f0-9]{64}$/);const bytes=readFileSync(record_.path);assert.equal(sha(bytes),record_.sha256,'Bound file changed: '+record_.path);return bytes;}
export function assertSource(){
  assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:CLONE,encoding:'utf8',windowsHide:true}).trim(),SOURCE);
  assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=normal'],{cwd:CLONE,encoding:'utf8',windowsHide:true}).trim(),'');
}
export function artifact(preparationPath,expected){
  const preparation=record(preparationPath),value=json(preparationPath);
  assert.equal(value.source,expected);assert.equal(value.passed,true);assert.equal(value.localOnly,true);
  assert.equal(value.sourceInitiallyClean,true);assert.equal(value.sourceUnchangedAtFinish,true);assert.equal(value.inspectorCleanupPassed,true);
  assert.equal(value.productionMutations,0);assert.equal(value.registryPushes,0);assert.equal(value.dockerEndpoint,ENDPOINT);assert.equal(value.scanner,SCANNER);
  const image=value.image;for(const key of ['imageId','indexDigest','platformManifestDigest','configDigest'])assert.match(image[key],/^sha256:[a-f0-9]{64}$/);
  assert.ok([image.indexDigest,image.platformManifestDigest,image.configDigest].includes(image.imageId));
  assert.equal(value.scanCounts.HIGH,0);assert.equal(value.scanCounts.CRITICAL,0);
  const scanPath=join(dirname(preparationPath),'scan-receipt.json');
  const scan=record(scanPath),raw=json(scanPath);assert.equal(scan.sha256,value.scan.receiptSha256);
  assert.equal(raw.passed,true);assert.equal(raw.sourceSha,expected);assert.equal(raw.imageId,image.imageId);
  assert.equal(raw.configDigest,image.configDigest);assert.equal(raw.dockerHost,ENDPOINT);assert.equal(raw.scanner,SCANNER);
  assert.equal(raw.counts.HIGH,0);assert.equal(raw.counts.CRITICAL,0);assert.equal(raw.archiveSha256,value.exportSha256);assert.equal(raw.reportSha256,value.fullScanSha256);
  assert.equal(raw.os,'linux');assert.equal(raw.architecture,'amd64');
  assert.equal(value.syntheticFloor.passed,true);assert.equal(value.syntheticFloor.source,expected);assert.equal(value.syntheticFloor.imageDigest,image.imageId);
  assert.equal(value.syntheticFloor.inventoryCount,129);assert.equal(value.syntheticFloor.bothUsageModesOff,true);
  for(const key of ['writerVersion','bridgeVersion','relayVersion'])assert.equal(value.syntheticFloor[key],1);
  return {source:expected,preparation,scan,image,exportSha256:value.exportSha256,fullScanSha256:value.fullScanSha256};
}
export function validateConfig(config,here){
  assert.equal(config.schemaVersion,1);assert.equal(config.source,SOURCE);assert.equal(config.cleanClone,CLONE);
  assert.equal(config.executeMode,'local-synthetic-recovery54');assert.equal(config.capacityAccepted,false);assert.equal(config.productionMutations,0);
  assert.deepEqual(config.candidate,artifact(config.candidate.preparation.path,SOURCE));
  assert.deepEqual(config.fallback,artifact(config.fallback.preparation.path,FALLBACK));
  const rehearsal=JSON.parse(checked(config.rehearsal).toString('utf8'));
  assert.equal(rehearsal.passed,true);assert.equal(rehearsal.candidateSha,SOURCE);assert.equal(rehearsal.compatibleRollbackSha,FALLBACK);
  assert.equal(rehearsal.compatibleRollbackMigrationReentry,true);assert.equal(rehearsal.candidateExpandMigrations,54);assert.equal(rehearsal.candidateAdoptedMigrations,54);
  assert.equal(rehearsal.retainedTenantTables,129);assert.equal(rehearsal.generatedContainerRemoved,true);assert.equal(rehearsal.productionMutations,0);
  assert.equal(rehearsal.localDockerDaemon.endpoint,ENDPOINT);assert.equal(config.postgresImage,rehearsal.postgresImageId);assert.match(config.postgresImage,/^sha256:[a-f0-9]{64}$/);
  const contract=JSON.parse(checked(config.ledgerContract).toString('utf8'));
  assert.equal(rehearsal.steps.find(row=>row.name==='candidate-after-rollback-contract.json')?.sha256,config.ledgerContract.sha256);
  const ledger=contract.ledger;assert.equal(ledger.length,54);assert.equal(new Set(ledger.map(row=>row.id)).size,54);
  assert.ok(ledger.every(row=>row.status==='complete'));const migration=ledger.find(row=>row.id===MIGRATION);
  assert.equal(migration?.checksum,CONTRACT);assert.equal(migration.mode,'transactional');
  checked(config.schema);assert.equal(config.schemaSource,SOURCE);
  const schemaReceipt=JSON.parse(checked(config.schemaReceipt).toString('utf8'));
  assert.equal(schemaReceipt.source,SOURCE);assert.equal(schemaReceipt.readOnly,true);assert.equal(schemaReceipt.migrations,54);
  assert.equal(schemaReceipt.schemaDumpPrivilegesExcluded,true);assert.equal(schemaReceipt.productionMutations,0);
  assert.equal(resolve(schemaReceipt.schemaFile),resolve(config.schema.path));assert.equal(schemaReceipt.schemaSha256,config.schema.sha256);
  assert.equal(schemaReceipt.pgImage,config.postgresImage);
  assert.equal(schemaReceipt.ledgerSha256,sha(JSON.stringify(ledger)));
  assert.equal(rehearsal.steps.find(row=>row.name==='candidate-adopted-contract.json')?.sha256,schemaReceipt.adoptedContractSha256);
  const sourceCleanup=JSON.parse(checked(config.rehearsalCleanup).toString('utf8'));
  assert.equal(sourceCleanup.containerId,schemaReceipt.containerId);assert.equal(sourceCleanup.run,schemaReceipt.run);
  assert.equal(sourceCleanup.containerAbsent,true);assert.equal(sourceCleanup.volumesAbsent,true);assert.equal(sourceCleanup.listingCommandsSucceeded,true);
  assert.deepEqual(config.files.map(row=>row.name).sort(),['binding.mjs','function-retention.mjs','grant.mjs','probe.mjs','run.mjs']);
  for(const file of config.files)assert.equal(sha(readFileSync(join(here,file.name))),file.sha256,'Launcher bytes changed: '+file.name);
  assert.equal(config.packageLockSha256,sha(readFileSync(join(CLONE,'package-lock.json'))));assertSource();
  return {ledger,rehearsal};
}
