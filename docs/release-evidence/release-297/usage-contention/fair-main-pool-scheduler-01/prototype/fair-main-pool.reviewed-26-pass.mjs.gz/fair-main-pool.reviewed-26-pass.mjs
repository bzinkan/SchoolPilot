import { AsyncResource, AsyncLocalStorage } from 'node:async_hooks';
import assert from 'node:assert/strict';

// EXTERNAL PROTOTYPE. No application or production import uses this module.
// Injecting the native public Pool class keeps its query/event/client behavior.
export function createFairMainPoolClass(NativePool, { readOperation, runtime = {
  now: () => performance.now(),
  setTimer: (callback, ms) => setTimeout(callback, ms),
  clearTimer: timer => clearTimeout(timer),
} }) {
  const nativeDispatch = new AsyncLocalStorage();
  return class FairMainPool extends NativePool {
    #queues = { default: new Fifo(), usage_report: new Fifo() };
    #entries = new Set();
    #clients = new WeakMap();
    #slots = 0;
    #native = 0;
    #leased = 0;
    #closing = 0;
    #pumping = false;
    #last = 'default';
    #endRequested = false;
    #ownershipDrained;
    #resolveOwnershipDrained;

    constructor(options) {
      // Scope deliberately matches the existing API main pool only.
      assert.equal(options.max, 16);
      assert.equal(options.connectionTimeoutMillis, 5000);
      super(options);
      this.#ownershipDrained = new Promise(resolve => { this.#resolveOwnershipDrained = resolve; });
      this.on('connect', client => {
        let state = this.#clients.get(client);
        if (!state) {
          state = { closing: false, removed: false, onRemoved: new Set() };
          this.#clients.set(client, state);
          const originalEnd = client.end;
          // Preserve the real client's identity and every public end overload.
          client.end = function (...args) {
            state.closing = true;
            return Reflect.apply(originalEnd, this, args);
          };
        }
        const entry = nativeDispatch.getStore();
        if (entry) entry.nativeClient = client;
      });
      this.on('remove', client => {
        const state = this.#clients.get(client);
        if (!state) return;
        state.removed = true;
        for (const done of [...state.onRemoved]) done();
        state.onRemoved.clear();
      });
    }

    get waitingCount() {
      return this.#queues.default.size + this.#queues.usage_report.size + super.waitingCount;
    }

    schedulingSnapshot() {
      return { max: this.options.max, callerBudgetMs: 5000,
        queuedDefault: this.#queues.default.size, queuedUsageReports: this.#queues.usage_report.size,
        ownedSlots: this.#slots, nativeInFlight: this.#native, leased: this.#leased,
        closing: this.#closing, ending: this.#endRequested, waitingCount: this.waitingCount };
    }

    connect(callback) {
      if (this.#endRequested) return callback
        ? callback(new Error('Cannot use a pool after calling end on the pool'))
        : this.Promise.reject(new Error('Cannot use a pool after calling end on the pool'));
      if (!callback) {
        return new this.Promise((resolve, reject) => this.connect((error, client) => error ? reject(error) : resolve(client)))
          .catch(error => { Error.captureStackTrace(error); throw error; });
      }
      const entry = {
        kind: readOperation() === 'usage_report' ? 'usage_report' : 'default',
        deadline: runtime.now() + 5000, callback, resource: new AsyncResource('fair-main-pool-checkout'),
        state: 'queued', callerSettled: false, timer: undefined, previous: null, next: null,
      };
      entry.timer = runtime.setTimer(() => this.#expire(entry), 5000);
      entry.timer?.unref?.();
      this.#entries.add(entry);
      this.#queues[entry.kind].push(entry);
      this.#pump();
      return undefined;
    }

    #settle(entry, error, client, release) {
      if (entry.callerSettled) return;
      entry.callerSettled = true;
      runtime.clearTimer(entry.timer);
      try { entry.resource.runInAsyncScope(entry.callback, undefined, error, client, release); }
      finally { entry.resource.emitDestroy(); }
    }

    #expire(entry) {
      if (entry.callerSettled) return;
      if (entry.state === 'queued') {
        this.#queues[entry.kind].remove(entry);
        entry.state = 'done';
        this.#entries.delete(entry);
      }
      // Native-in-flight ownership survives this rejection until settlement.
      try { this.#settle(entry, new Error('timeout exceeded when trying to connect')); }
      finally { this.#pump(); }
    }

    #pump() {
      if (this.#pumping || this.#endRequested) return;
      this.#pumping = true;
      try {
        while (this.#slots < this.options.max) {
          const a = this.#queues.default.size, b = this.#queues.usage_report.size;
          if (!a && !b) break;
          const kind = a && b ? (this.#last === 'default' ? 'usage_report' : 'default') : b ? 'usage_report' : 'default';
          const entry = this.#queues[kind].shift();
          if (runtime.now() >= entry.deadline) {
            entry.state = 'done'; this.#entries.delete(entry);
            this.#settle(entry, new Error('timeout exceeded when trying to connect'));
            continue;
          }
          this.#last = kind;
          entry.state = 'native'; this.#slots++; this.#native++;
          let callbackEntered = false;
          const complete = (error, client, release) => {
            callbackEntered = true;
            this.#native--;
            if (error || !client) {
              this.#finishWhenRemoved(entry, entry.nativeClient);
              this.#settle(entry, error ?? new Error('Native pool returned no client'));
              return;
            }
            entry.nativeClient = client;
            const nativeRelease = release ?? client.release;
            let released = false;
            const wrappedRelease = error => {
              if (released) throw new Error('Release called on client which has already been released to the pool.');
              released = true;
              // Do not admit replacement work until synchronous release and any
              // resulting public remove event have completed. Unexpected release
              // throws retain ownership rather than guessing the client is safe.
              Reflect.apply(nativeRelease, client, [error]);
              this.#finishWhenRemoved(entry, client);
            };
            client.release = wrappedRelease;
            entry.state = 'leased'; this.#leased++;
            if (entry.callerSettled || this.#endRequested || runtime.now() >= entry.deadline) {
              wrappedRelease();
              if (!entry.callerSettled) this.#settle(entry, new Error(this.#endRequested
                ? 'Cannot use a pool after calling end on the pool' : 'timeout exceeded when trying to connect'));
              return;
            }
            this.#settle(entry, undefined, client, wrappedRelease);
          };
          try {
            entry.resource.runInAsyncScope(() => nativeDispatch.run(entry, () => super.connect(complete)));
          } catch (error) {
            if (callbackEntered) throw error; // Never reinterpret a caller callback throw as a connect failure.
            complete(error);
          }
        }
      } finally { this.#pumping = false; }
    }

    #finishWhenRemoved(entry, client) {
      const state = client && this.#clients.get(client);
      if (state?.closing && !state.removed) {
        entry.beforeClosing = entry.state;
        entry.state = 'closing'; this.#closing++;
        state.onRemoved.add(() => this.#finish(entry));
      } else this.#finish(entry);
    }

    #finish(entry) {
      if (entry.state === 'done') return;
      if (entry.state === 'leased' || entry.beforeClosing === 'leased') this.#leased--;
      if (entry.state === 'closing') this.#closing--;
      entry.state = 'done'; this.#slots--; this.#entries.delete(entry);
      if (this.#endRequested && this.#slots === 0) this.#resolveOwnershipDrained();
      this.#pump();
    }

    end(callback) {
      if (this.#endRequested) return callback
        ? callback(new Error('Called end on pool more than once'))
        : this.Promise.reject(new Error('Called end on pool more than once'));
      this.#endRequested = true;
      let callbackThrew = false, callbackError;
      // Rejections are delivered in the original ALS context; live leases still
      // belong to their callers and native-in-flight leases remain owned here.
      for (const entry of [...this.#entries]) {
        if (entry.state === 'queued') {
          this.#queues[entry.kind].remove(entry); entry.state = 'done'; this.#entries.delete(entry);
        }
        if (!entry.callerSettled) {
          try { this.#settle(entry, new Error('Cannot use a pool after calling end on the pool')); }
          catch (error) { if (!callbackThrew) { callbackThrew = true; callbackError = error; } }
        }
      }
      if (this.#slots === 0) this.#resolveOwnershipDrained();
      const nativeEnded = new this.Promise((resolve, reject) => super.end(error => error ? reject(error) : resolve()));
      const result = this.Promise.all([nativeEnded, this.#ownershipDrained]).then(() => undefined);
      // A caller's thrown callback must remain a throw without preventing
      // already-owned cleanup or generating an orphaned rejection later.
      if (callbackThrew) { void result.catch(() => {}); throw callbackError; }
      if (callback) { result.then(() => callback(), error => callback(error)); return undefined; }
      return result;
    }
  };
}

class Fifo {
  head = null; tail = null; size = 0;
  push(entry) { entry.previous = this.tail; if (this.tail) this.tail.next = entry; else this.head = entry; this.tail = entry; this.size++; }
  shift() { const entry = this.head; this.remove(entry); return entry; }
  remove(entry) {
    if (entry.previous) entry.previous.next = entry.next; else this.head = entry.next;
    if (entry.next) entry.next.previous = entry.previous; else this.tail = entry.previous;
    entry.previous = entry.next = null; this.size--;
  }
}
