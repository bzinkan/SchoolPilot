import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {restoreWorkloadEnvironment,cleanupWorkloadResources,combinedCleanupReceipt} from './run.mjs';
const configuration={appUrl:'<REDACTED_LOCAL_URL>',adminUrl:'<REDACTED_LOCAL_URL>'};
const options={configuration,source:'a'.repeat(40),run:'123456abcdef',registry:{inventories:{classpilotPrivateChatLifecyclePostExpand:{tables:Array.from({length:129},(_,i)=>'table_'+i)}}},preparedStateSha256:'b'.repeat(64),phase:'ingest',secret:()=> 'synthetic-secret'};
test('restored environment is closed ingest CPU with exact local tenant endpoints',()=>{
 const env=restoreWorkloadEnvironment(options);assert.equal(env.USAGE_RELEASE_CPU_PROFILE,'true');assert.equal(env.USAGE_RELEASE_PHASE,'ingest');assert.equal(env.DATABASE_URL,configuration.appUrl);assert.equal(env.ADMIN_DATABASE_URL,configuration.adminUrl);assert.equal(env.RLS_ENABLED_TABLES.split(',').length,129);
 assert.throws(()=>restoreWorkloadEnvironment({...options,phase:'combined'}));assert.throws(()=>restoreWorkloadEnvironment({...options,configuration:{...configuration,adminUrl:'<REDACTED_LOCAL_URL>'}}));
});
test('both independent cleanup owners settle even when role capture cleanup fails',async()=>{
 const events=[];const result=await cleanupWorkloadResources({roles:async()=>{events.push('role');throw Error('synthetic');},redis:async()=>{events.push('redis');return {cleanupPassed:true,confirmedAbsent:true};}});
 assert.deepEqual(events,['role','redis']);assert.equal(result.cleanupPassed,false);assert.equal(result.roles.failureCode,'ROLE_CLEANUP_THREW');assert.equal(result.redis.cleanupPassed,true);
});
test('fixture cleanup cannot convert nonzero workload into accepted capacity',()=>{
 const receipt=combinedCleanupReceipt({run:options.run,roles:{cleanupPassed:true},redis:{cleanupPassed:true,confirmedAbsent:true},postgres:{cleanupPassed:true,confirmedAbsent:true},finishedAt:new Date().toISOString()});assert.equal(receipt.cleanupPassed,true);assert.equal(receipt.capacityAccepted,false);
 const source=readFileSync(new URL('./run.mjs',import.meta.url),'utf8');assert.ok(source.includes('exitCode=hostResult.passed?0:1'));assert.ok(source.indexOf('await waitForRelease')<source.indexOf('await restartAfterRelease'));assert.ok(source.indexOf('await restartAfterRelease')<source.indexOf('hostResult=await launch'));
 assert.equal(source.includes('sealRunReceipts'),false);assert.equal(source.includes('validateCandidateRun'),false);
});
