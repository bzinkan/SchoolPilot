// No application or database work.
