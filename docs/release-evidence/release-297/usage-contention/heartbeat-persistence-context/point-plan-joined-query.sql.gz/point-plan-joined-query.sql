
    SELECT school.status AS "heartbeatSchoolStatus",
      school.plan_status AS "heartbeatSchoolPlanStatus",
      school.domain AS "heartbeatSchoolDomain",
      policy.classpilot_sso_policy AS "classpilotSsoPolicy",
      policy.classpilot_sso_policy_revision AS "classpilotSsoPolicyRevision",
      control.id, control.school_id AS "schoolId", control.student_id AS "studentId",
      control.teaching_session_id AS "teachingSessionId",
      control.supervision_context_id AS "supervisionContextId", control.revision,
      control.desired_state AS "desiredState", control.source_command_id AS "sourceCommandId",
      control.scheduled_end_at AS "scheduledEndAt", control.hard_expires_at AS "hardExpiresAt",
      control.enforcement_health AS "enforcementHealth", control.applied_revision AS "appliedRevision",
      control.last_outcome AS "lastOutcome", control.last_error AS "lastError",
      control.last_acknowledged_at AS "lastAcknowledgedAt",
      control.created_at AS "createdAt", control.updated_at AS "updatedAt"
    FROM schools AS school
    LEFT JOIN settings AS policy ON policy.school_id = school.id
    LEFT JOIN classpilot_student_control_states AS control
      ON control.school_id = school.id AND control.student_id = $1
    WHERE school.id = $2
    LIMIT 1
  
