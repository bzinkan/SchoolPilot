import assert from 'node:assert/strict';
import {readFileSync,readdirSync,statSync,mkdirSync,writeFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp=process.env.TEMP,repo='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot';
const out='C:/Users/zinka/.codex/artifacts/release297-restored-owner-evidence-01';
const native=join(temp,'release297-e95-restore-restart-9bfd1925e36c'),snapshot='C:/Users/zinka/.codex/artifacts/release297-synthetic-prepared-e95-75d8f6205c5c';
const sha=b=>createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const files=[],hashOnly=[];mkdirSync(out,{recursive:false});
const scrubText=s=>s.replace(/(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi,'<REDACTED_LOCAL_CONNECTION_URL>').replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_SYNTHETIC_TOKEN>').replace(/C:[\\/]Users[\\/]zinka[\\/]AppData[\\/]Local[\\/]Temp/gi,'<TEMP>');
function scrub(v,k=''){if(/(?:password|secret|cookie|authorization|^nonce$|^token$|Token$|_URL$)/i.test(k))return'<REDACTED>';if(typeof v==='string')return scrubText(v);if(Array.isArray(v))return v.map(x=>scrub(x));if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([key,x])=>[key,scrub(x,key)]));return v;}
function add(path,name){const raw=readFileSync(path),safe=Buffer.from(path.endsWith('.json')?JSON.stringify(scrub(JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''))),null,2)+'\n':scrubText(raw.toString('utf8'))),gz=gzipSync(safe,{level:6});mkdirSync(dirname(join(out,name+'.gz')),{recursive:true});writeFileSync(join(out,name+'.gz'),gz,{flag:'wx'});files.push({path:name+'.gz',originalPath:path.replace(temp,'<TEMP>'),originalBytes:raw.length,originalSha256:sha(raw),sanitizedSha256:sha(safe),gzipSha256:sha(gz)});}
function exclude(path,reason){const raw=readFileSync(path);hashOnly.push({path:path.replace(temp,'<TEMP>'),bytes:raw.length,sha256:sha(raw),reason});}
const cleanup=read(join(native,'cleanup.json'));assert.equal(cleanup.cleanupPassed,true);assert.equal(cleanup.handoffPassed,true);assert.equal(cleanup.volumes.length,1);assert.equal(cleanup.volumes[0].confirmedAbsent,true);
const sourceHashes=read(join(native,'restore-sources.json'));for(const[name,expected]of Object.entries(sourceHashes.files))assert.equal(sha(readFileSync(join(repo,'scripts/load/usage/roles',name))),expected);
for(const name of readdirSync(native)){const path=join(native,name);assert.ok(statSync(path).isFile());add(path,'native-e95/'+name);}
for(const name of readdirSync(native+'-private'))exclude(join(native+'-private',name),'Private fresh synthetic credentials; excluded contents.');
for(const name of readdirSync(join(repo,'scripts/load/usage/roles'))){const path=join(repo,'scripts/load/usage/roles',name);if(statSync(path).isFile())add(path,'source/'+name);}
for(const name of ['release297-e95-restore-restart-proof-01.mjs','release297-e95-restore-restart-proof-01-config.json','release297-e95-restore-restart-proof-01.log','release297-preserve-prepared-e95-01.log','release297-preserve-prepared-b112-01.mjs','release297-restored-cleanup-horizon-01.log','release297-campaign-owner-validation-01.log','release297-restored-receipt-order-01.log','release297-role-aggregate-03.log'])add(join(temp,name),'proof/'+name);
for(const name of ['tests-01.log','tests-02.log'])add(join(temp,'release297-campaign-journal-01',name),'journal-proof/'+name);
add(join(snapshot,'manifest.json'),'snapshot/original-e95-manifest.json');
const old=join(temp,'release297-snapshot-restore-b112-21d021cbb765');assert.equal(read(join(old,'cleanup.json')).cleanupPassed,true);
for(const name of readdirSync(old)){const path=join(old,name);assert.ok(statSync(path).isFile());if(name.includes('.private.'))exclude(path,'Historical private synthetic restore credentials.');else add(path,'historical-restore04/'+name);}
for(const name of ['release297-restore-b112-snapshot-04.mjs','release297-restore-b112-snapshot-04-runner.log','release297-snapshot-horizon-native-04.log'])add(join(temp,name),'historical-restore04/'+name);
add(fileURLToPath(import.meta.url),'archive-script.mjs');
const manifest={schemaVersion:1,recordedAt:new Date().toISOString(),source:sourceHashes.source,scope:'Same-source e95 synthetic snapshot restore, no-workload cold restart, strict cleanup and pure owner/campaign proof. Historical b112 restore04 retained separately.',capacityAccepted:false,acceptedRunCount:0,
  snapshot:{path:snapshot,manifestSha256:sha(readFileSync(join(snapshot,'manifest.json'))),immutable:true,originalManifestUnchanged:true,restoreProofSeparate:true},
  native:{run:cleanup.run,passed:true,offeredRequests:0,sourceModulesVerified:true,fullNativeSchemaEqual:true,migrations:53,admittedTables:129,restrictedNonOwnerRole:true,standardAnalyze:true,readOnlyCurrentClockHorizon:true,sameIdColdRestart:true,allClientsClosed:true,containerRemoved:true,recordedAnonymousVolumeRemoved:true},
  tests:{cleanupAndHorizon:25,journalAndStrictValidator:132,receiptChronologyFollowup:125,aggregate:308,allPassed:true,aggregatePrecedesFinalReceiptChronologyFollowup:true},
  limitations:['No actual restored full workload or13-receipt integration executed yet. Candidate execution remains disabled.','No production operations or capacity acceptance; no host cache flush.','Historical restore04 confirms container absence only; its old runner did not record/remove anonymous volume. No unknown historical volume was deleted.','The e95 snapshot remains immutable; every later use needs fresh source/date/control/authority checks.','Dump, populated state and role verifier contents remain private outside this packet.'],
  sanitization:'Original hashes retained; credentials/private config contents excluded. Connection URLs, tokens and nonces redacted from safe records.',files,hashOnly};
for(const f of files){const b=readFileSync(join(out,f.path));assert.equal(sha(b),f.gzipSha256);assert.equal(sha(gunzipSync(b)),f.sanitizedSha256);assert.equal(sha(readFileSync(f.originalPath.replace('<TEMP>',temp))),f.originalSha256);}
writeFileSync(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
writeFileSync(join(out,'README.md'),'# Restored fixture owner proof\n\nExact e95 snapshot restored and fully validated under a fresh restricted role; native schema equality,53 migrations,129 admitted FORCE RLS tables,data/control/clock checks and standard ANALYZE passed. Read-only revalidation preceded a same-ID PostgreSQL restart. Zero workload requests were offered. Final clients closed; exact container and recorded anonymous volume absence passed.\n\nThe full restored workload and13-receipt producer have not run yet. Candidate mode is disabled; accepted capacity runs remain zero. Historical b112 restore04 is separately retained with its original container-only cleanup limitation.\n',{flag:'wx'});
process.stdout.write(JSON.stringify({out,files:files.length,hashOnly:hashOnly.length,manifestSha256:sha(readFileSync(join(out,'manifest.json')))})+'\n');
