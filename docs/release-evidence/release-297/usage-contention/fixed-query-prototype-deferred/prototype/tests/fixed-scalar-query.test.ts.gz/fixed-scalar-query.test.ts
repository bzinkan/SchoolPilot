import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { eq, Param, SQL, sql } from "drizzle-orm";
import { integer, numeric, pgTable, PgDialect, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { compileFixedScalarQuery } from "../src/lib/fixedScalarQuery.js";

const table = pgTable("fixed_query_fixture", {
  id: uuid("id"), name: text("name"), revision: integer("revision"),
  amount: numeric("amount"), at: timestamp("at"),
});
const dialect = new PgDialect();

describe("fixed scalar SQL structure", () => {
  it("preserves exact SQL, parameter order and per-occurrence UUID typing", () => {
    const build = (id: string | ReturnType<typeof sql.placeholder>, name: string | ReturnType<typeof sql.placeholder>) =>
      sql`select ${table.id} from ${table} where ${eq(table.id, new Param<unknown, unknown>(id, table.id))} and ${eq(table.name, new Param<unknown, unknown>(name, table.name))} or ${eq(table.id, new Param<unknown, unknown>(id, table.id))} limit ${1} for share`;
    const fixed = compileFixedScalarQuery(build(sql.placeholder("id"), sql.placeholder("name")));
    for (const [id, name] of [["a0000000-0000-0000-0000-000000000001", "a' $1"], ["b0000000-0000-0000-0000-000000000002", ""]]) {
      assert.deepEqual(dialect.sqlToQuery(fixed({ id: id!, name: name! })), dialect.sqlToQuery(build(id!, name!)));
    }
  });

  it("preserves literals containing PostgreSQL parameter-like text and SQL metacharacters", () => {
    const fixed = compileFixedScalarQuery(sql`select '$1', '$99', $$literal $2$$, ${sql.placeholder("value")}, ${false}, ${0}, ${null}`);
    const value = "'; drop table ignored; -- $2";
    assert.deepEqual(dialect.sqlToQuery(fixed({ value })), dialect.sqlToQuery(sql`select '$1', '$99', $$literal $2$$, ${value}, ${false}, ${0}, ${null}`));
  });

  it("keeps null, false, zero and empty string distinct", () => {
    const fixed = compileFixedScalarQuery(sql`select ${sql.placeholder("value")}`);
    for (const value of [null, false, 0, ""]) assert.deepEqual(dialect.sqlToQuery(fixed({ value })), dialect.sqlToQuery(sql`select ${value}`));
  });

  it("preserves different identity encoders on repeated names, including typed null", () => {
    const fixed = compileFixedScalarQuery(sql`select ${new Param<unknown, unknown>(sql.placeholder("value"), table.id)}, ${new Param<unknown, unknown>(sql.placeholder("value"), table.name)}, ${sql.placeholder("value")}`);
    for (const value of [null, "a0000000-0000-0000-0000-000000000001"]) {
      assert.deepEqual(dialect.sqlToQuery(fixed({ value })), dialect.sqlToQuery(sql`select ${new Param<unknown, unknown>(value, table.id)}, ${new Param<unknown, unknown>(value, table.name)}, ${value}`));
    }
  });

  it("isolates returned query/parameter chunks and snapshots the canonical template", () => {
    const template = sql`select ${sql.placeholder("value")}`;
    const fixed = compileFixedScalarQuery(template);
    const first = fixed({ value: "first" });
    const second = fixed({ value: "second" });
    template.append(sql` unexpected`);
    first.append(sql` changed`);
    assert.equal(dialect.sqlToQuery(second).sql, "select $1");
    assert.deepEqual(dialect.sqlToQuery(second).params, ["second"]);
    assert.deepEqual(dialect.sqlToQuery(fixed({ value: "third" })).params, ["third"]);
    assert.notEqual(first.queryChunks[1], second.queryChunks[1]);
  });

  it("rejects missing, inherited, accessor and non-scalar bindings", () => {
    const fixed = compileFixedScalarQuery(sql`select ${sql.placeholder("value")}`);
    assert.throws(() => fixed({}), /Missing or non-scalar/);
    assert.throws(() => fixed(Object.create({ value: "inherited" })), /Missing or non-scalar/);
    let reads = 0;
    assert.throws(() => fixed({ get value() { reads++; return "getter"; } }), /Missing or non-scalar/);
    assert.equal(reads, 0);
    for (const value of [undefined, NaN, Infinity, new Date(), [1], {}, sql`bad`, 1n]) {
      // Exercise the untyped runtime boundary without casting production types.
      assert.throws(() => Reflect.apply(fixed, undefined, [{ value }]), /Missing or non-scalar/);
    }
  });

  it("rejects non-scalar constants, inline mode, result decoders and dynamic wrappers", () => {
    for (const value of [new Date(), [1], {}, 1n, NaN, Infinity]) assert.throws(() => compileFixedScalarQuery(sql`select ${value}`), /Unsupported|non-scalar/);
    assert.throws(() => compileFixedScalarQuery(sql`select ${1}`.inlineParams()), /inline parameters/);
    assert.throws(() => compileFixedScalarQuery(sql`select 1`.mapWith(Number)), /result decoders/);
    let called = false;
    assert.throws(() => compileFixedScalarQuery(sql`select ${{ getSQL() { called = true; return sql`1`; } }}`), /Unsupported/);
    assert.equal(called, false);
    const cyclic = sql.empty(); cyclic.queryChunks.push(cyclic);
    assert.throws(() => compileFixedScalarQuery(cyclic), /Cyclic/);
  });

  it("rejects custom and conversion encoders before calling them, including scalar-returning ones", () => {
    for (const output of ["converted", sql`arbitrary`, new Date()]) {
      let calls = 0;
      const encoder = { mapToDriverValue() { calls++; return output; } };
      assert.throws(() => compileFixedScalarQuery(sql`select ${new Param(sql.placeholder("value"), encoder)}`), /identity parameter encoder/);
      assert.throws(() => compileFixedScalarQuery(sql`select ${new Param("constant", encoder)}`), /identity parameter encoder/);
      assert.equal(calls, 0);
    }
    assert.throws(() => compileFixedScalarQuery(sql`select ${new Param(sql.placeholder("value"), table.at)}`), /identity parameter encoder/);
    assert.throws(() => compileFixedScalarQuery(sql`select ${new Param("1", table.amount)}`), /untyped scalar constants/);
    assert.throws(() => compileFixedScalarQuery(sql`select ${new Param("a0000000-0000-0000-0000-000000000001", table.id)}`), /untyped scalar constants/);
  });

  it("rejects a schema encoder changed after compilation without invoking it", () => {
    const local = pgTable("fixed_query_mutated", { id: uuid("id") });
    const fixed = compileFixedScalarQuery(sql`select ${new Param(sql.placeholder("value"), local.id)}`);
    let calls = 0;
    local.id.mapToDriverValue = value => { calls++; return value; };
    assert.throws(() => fixed({ value: "test" }), /identity parameter encoder/);
    assert.equal(calls, 0);
  });

  it("supports a parameter-free template without sharing a mutable SQL value", () => {
    const fixed = compileFixedScalarQuery(sql`select 1 for share`);
    const a = fixed({}), b = fixed({});
    assert.ok(a instanceof SQL); assert.notEqual(a, b);
    assert.deepEqual(dialect.sqlToQuery(a), dialect.sqlToQuery(sql`select 1 for share`));
  });
});
