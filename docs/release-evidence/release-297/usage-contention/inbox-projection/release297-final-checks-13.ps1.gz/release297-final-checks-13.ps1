$ErrorActionPreference = 'Stop'
$repository = '<WORKTREE>'
$output = '<TEMP>\release297-contention-final-checks-13'
if (Test-Path -LiteralPath $output) { throw 'Evidence directory already exists' }
New-Item -ItemType Directory -Path $output | Out-Null
Set-Location -LiteralPath $repository
$env:NODE_ENV = 'test'; $env:SCHEDULER_ENABLED = 'false'; $env:REDIS_URL = ''
Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
$env:DOTENV_CONFIG_PATH = Join-Path $output 'absent-dotenv'; $env:DOTENV_CONFIG_QUIET = 'true'
$names = @(git ls-files --cached --others --exclude-standard -- src tests scripts package.json package-lock.json tsconfig.json | Sort-Object -Unique)
function Snapshot { @($names | ForEach-Object { [ordered]@{ path=$_; sha256=(Get-FileHash -LiteralPath (Join-Path $repository $_) -Algorithm SHA256).Hash.ToLower() } }) }
$before = Snapshot
$before | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-before.json')
$start=[DateTime]::UtcNow.ToString('o')
$checks = @()
foreach ($scriptName in @('build', 'check:tests', 'check:test-casts', 'test:unit')) {
  $logName = $scriptName.Replace(':','-') + '.log'
  $checkStart = [DateTime]::UtcNow.ToString('o')
  & npm.cmd run $scriptName *> (Join-Path $output $logName)
  $checks += [ordered]@{ command=('npm run ' + $scriptName); startedAt=$checkStart; finishedAt=[DateTime]::UtcNow.ToString('o'); exitCode=$LASTEXITCODE; log=$logName }
  $checks | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'checks.json')
}
$after = Snapshot
$after | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-after.json')
$result=[ordered]@{sourceHead=(git rev-parse HEAD).Trim(); startedAt=$start; finishedAt=[DateTime]::UtcNow.ToString('o'); checks=$checks; sourceFileCount=$before.Count; sourceUnchanged=(@(Compare-Object ($before | ConvertTo-Json -Depth 6) ($after | ConvertTo-Json -Depth 6)).Count -eq 0); configuration='DATABASE_URL absent, matching ordinary unit CI; individual unit fixtures configure their own imports'; purpose='Fresh production build, type/cast ratchets and full unit suite after heartbeat teaching inbox5to2 discovery; native owner/restricted21each separate; infrastructure699 proof unchanged and not rerun'; output=$output}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'result.json')
$result | ConvertTo-Json -Depth 6
if (@($checks | Where-Object { $_.exitCode -ne 0 }).Count -gt 0 -or -not $result.sourceUnchanged) { exit 1 }



