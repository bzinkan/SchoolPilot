import assert from 'node:assert/strict';
import {readFileSync,createReadStream,existsSync,realpathSync,linkSync,unlinkSync,openSync,writeFileSync,fsyncSync,closeSync} from 'node:fs';
import {resolve,join,relative,isAbsolute} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';

const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
async function fileHash(file){const h=createHash('sha256');for await(const bytes of createReadStream(file))h.update(bytes);return h.digest('hex');}

/** Publish abort only after independently checking the newly captured snapshot. */
export async function publishSnapshotAbort({output,snapshotDirectory,snapshotSha256,readySha256,bindingFile,sourceDirectory}){
  for(const value of[snapshotSha256,readySha256])assert.match(value,/^[a-f0-9]{64}$/);
  const readyPath=join(output,'measurement-ready.json'),readyBytes=readFileSync(readyPath),ready=JSON.parse(readyBytes);
  assert.equal(digest(readyBytes),readySha256);assert.equal(ready.mode,'diagnostic');assert.equal(ready.phase,'combined');assert.equal(ready.diagnosticOnly,true);assert.equal(ready.capacityAccepted,false);
  const bindingBytes=readFileSync(bindingFile),binding=JSON.parse(bindingBytes);assert.equal(digest(bindingBytes),ready.bindingSha256);
  assert.equal(binding.applicationSource,ready.source);assert.equal(binding.roleImageId,ready.imageId);assert.equal(binding.harnessIdentity,ready.harnessSha256);
  const manifestBytes=readFileSync(join(snapshotDirectory,'manifest.json'));assert.equal(digest(manifestBytes),snapshotSha256);const manifest=JSON.parse(manifestBytes);
  assert.equal(manifest.source,ready.source);assert.equal(manifest.run,ready.run);assert.equal(manifest.helperImage,ready.imageId);assert.equal(manifest.migrations,54);
  for(const field of['timingHeld','measurementGoAbsent','readOnlyExport','sourceUnchanged'])assert.equal(manifest[field],true);
  assert.equal(manifest.otherClientsBefore,0);assert.equal(manifest.otherClientsAfter,0);assert.equal(manifest.heartbeatRows,2000002);
  const expected=['prepared-database.private.dump','synthetic-roles.private.sql','cold-fixture-state.json','release-control-preparation.json','preparation-fixture-contract.json','preparation-metrics.json','schema-fingerprint.json','post-convergence-schema.sql','measurement-ready.json'];
  assert.deepEqual(manifest.records.map(r=>r.file).sort(),expected.sort());
  const directory=realpathSync(snapshotDirectory);
  for(const record of manifest.records){const file=realpathSync(join(directory,record.file)),rel=relative(directory,file);assert.ok(rel&&!rel.startsWith('..')&&!isAbsolute(rel));assert.equal(await fileHash(file),record.sha256);}
  assert.equal(digest(readFileSync(join(directory,'measurement-ready.json'))),readySha256);
  const source=execFileSync('git',['-C',sourceDirectory,'rev-parse','HEAD'],{encoding:'utf8'}).trim();assert.equal(source,ready.source);
  assert.equal(execFileSync('git',['-C',sourceDirectory,'status','--porcelain'],{encoding:'utf8'}).trim(),'');
  // Validate using the exact source-bound gate, not an independently copied contract.
  const gate=join(sourceDirectory,'scripts/load/usage/roles/measurement-gate.mjs');
  assert.equal(await fileHash(gate),binding.roleHarnessSha256['measurement-gate.mjs']);
  const {validateAbort}=await import(pathToFileURL(gate));
  const request={...ready,action:'abort-before-measurement',intent:'preserve-prepared-snapshot'};validateAbort(ready,request);
  assert.equal(digest(readFileSync(readyPath)),readySha256);assert.equal(digest(readFileSync(bindingFile)),ready.bindingSha256);
  const target=join(output,'measurement-abort.json'),temporary=join(output,`measurement-abort-${randomUUID()}.partial`);
  for(const file of['measurement-go.json','measurement-abort.json','measurement-release-receipt.json','measurement-abort-receipt.json'])assert.equal(existsSync(join(output,file)),false);
  // Hard-link publication is atomic and exclusive on the same filesystem: a
  // reader never observes partial JSON and an existing control is not replaced.
  const descriptor=openSync(temporary,'wx');
  try{writeFileSync(descriptor,JSON.stringify(request,null,2)+'\n');fsyncSync(descriptor);}finally{closeSync(descriptor);}
  try{assert.equal(existsSync(join(output,'measurement-go.json')),false);linkSync(temporary,target);}finally{unlinkSync(temporary);}
  return{abortFile:target,abortSha256:digest(readFileSync(target)),readySha256,snapshotSha256,source:ready.source,run:ready.run,capacityAccepted:false};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const[output,snapshotDirectory,snapshotSha256,readySha256,bindingFile,sourceDirectory]=process.argv.slice(2);
  console.log(JSON.stringify(await publishSnapshotAbort({output,snapshotDirectory,snapshotSha256,readySha256,bindingFile,sourceDirectory})));
}
