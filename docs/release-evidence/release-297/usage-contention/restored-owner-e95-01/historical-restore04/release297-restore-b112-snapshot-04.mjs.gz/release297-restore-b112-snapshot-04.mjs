import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {randomBytes,createHash} from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot';
const {loadSnapshot,normalizeSnapshotSchema,snapshotHash}=await import(pathToFileURL(join(repo,'scripts/load/usage/roles/snapshot-contract.mjs')));
const temp=process.env.TEMP,run=randomBytes(6).toString('hex'),output=join(temp,`release297-snapshot-restore-b112-${run}`),name=`schoolpilot-snapshot-restore-${run}`,db=`schoolpilot_redesign_usage_restore_${run}`;
const owner=`restore_owner_${run}`,role=`restore_app_${run}`,ownerPass=randomBytes(24).toString('hex'),appPass=randomBytes(24).toString('hex');
const sourceDirectory=join(temp,'release297-role-b112-host-02'),snapshotDirectory='C:/Users/zinka/.codex/artifacts/release297-synthetic-prepared-b112-4c037ef4cde5',source='b11202fc305198d76e73c5e6d711b7dc9ed2d938',snapshotManifestSha256='f66cddd44109c105aa9cb43cf16f493f3777a6c1d1f5c6c1def70a0a4802d749';
const today=new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const snapshot=loadSnapshot(snapshotDirectory,snapshotManifestSha256,{source,today}),image=snapshot.manifest.pgImage;
mkdirSync(output,{recursive:false});
const env={...process.env};for(const key of Object.keys(env))if(/^DOCKER_|^BUILDX_BUILDER$/.test(key))delete env[key];
const docker='docker',host='npipe:////./pipe/dockerDesktopLinuxEngine';
const save=(n,v)=>writeFileSync(join(output,n),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
function call(args,{input,log,timeout=120000}={}){const r=spawnSync(docker,['--host',host,...args],{env,input,encoding:'utf8',maxBuffer:16*1024*1024,timeout});if(log)writeFileSync(join(output,log),(r.stdout||'')+(r.stderr||''),{flag:'wx'});if(r.status!==0)throw Object.assign(Error('DOCKER_STEP_FAILED'),{code:'DOCKER_STEP_FAILED'});return r.stdout;}
function find(){const ids=call(['container','ls','--all','--filter','name=^/'+name+'$','--format','{{.ID}}'],{timeout:30000}).trim().split(/\r?\n/).filter(Boolean);if(ids.length===0)return null;assert.equal(ids.length,1);return JSON.parse(call(['inspect',ids[0]],{timeout:30000}))[0];}
const imageInspect=JSON.parse(call(['image','inspect',image]))[0];
function verify(found){assert.equal(found.Name,'/'+name);assert.equal(found.Config.Labels['codex.usage-snapshot-restore'],run);assert.equal(found.Config.Image,image);const actual=JSON.parse(call(['image','inspect',found.Image]))[0];assert.deepEqual(actual.RootFS,imageInspect.RootFS);assert.deepEqual(actual.Config,imageInspect.Config);assert.equal(found.HostConfig.NanoCpus,4e9);assert.equal(found.HostConfig.Memory,4*1024**3);assert.equal(found.HostConfig.MemorySwap,4*1024**3);return found;}
const sourceFiles=[new URL(import.meta.url),...['snapshot-contract.mjs','validate-snapshot-database.mjs'].map(n=>join(repo,'scripts/load/usage/roles',n))]; const sourceHashes=sourceFiles.map(p=>({path:String(p),sha256:snapshotHash(readFileSync(p))})); save('restore-sources.json',{source,files:sourceHashes});
let created=false,passed=false,stage='create',failure=null;
const adminUrl=`<REDACTED_LOCAL_CONNECTION_URL>
try{
  assert.equal(find(),null);writeFileSync(join(output,'postgres.private.env'),`POSTGRES_DB=${db}\nPOSTGRES_USER=${owner}\nPOSTGRES_PASSWORD=${ownerPass}\nPGPORT=5437\n`,{flag:'wx'});
  try{call(['run','--detach','--name',name,'--label',`codex.usage-snapshot-restore=${run}`,'--cpus','4','--memory','4g','--memory-swap','4g','--publish','127.0.0.1:5437:5437','--env-file',join(output,'postgres.private.env'),image,'postgres','-p','5437'],{log:'create.log'});}finally{const found=find();if(found){verify(found);created=true;}}
  stage='readiness';let ready=false;for(let i=0;i<60;i++){const r=spawnSync(docker,['--host',host,'exec',name,'pg_isready','-h','127.0.0.1','-p','5437','-U',owner,'-d',db],{env,encoding:'utf8',timeout:10000});if(r.status===0){ready=true;break;}await new Promise(r=>setTimeout(r,500));}assert.equal(ready,true);
  const before=verify(find());save('owned-pg.json',{run,name,id:before.Id,imageRequested:image,imageActual:before.Image,caps:{cpu:4,memoryBytes:4*1024**3,memorySwapBytes:4*1024**3},port:before.NetworkSettings.Ports['5437/tcp']});
  stage='restore';call(['cp',join(snapshotDirectory,'prepared-database.private.dump'),`${name}:/tmp/prepared.private.dump`],{log:'copy.log'});
  call(['exec',name,'pg_restore','--exit-on-error','--no-owner','--no-privileges','-U',owner,'-d',db,'/tmp/prepared.private.dump'],{log:'restore.log',timeout:300000});
  stage='fresh-role';call(['exec','-i',name,'psql','-U',owner,'-d',db,'-v','ON_ERROR_STOP=1'],{input:`CREATE ROLE ${role} LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '${appPass}'; GRANT USAGE ON SCHEMA public TO ${role}; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO ${role}; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO ${role};`,log:'fresh-role.log'});
  stage='schema';const ddl=call(['exec',name,'pg_dump','-U',owner,'-d',db,'--schema-only','--no-owner','--no-privileges']);writeFileSync(join(output,'restored-schema.sql'),ddl,{flag:'wx'});
  // pg_restore reparses CHECK expressions, so compare full native renderings
  // against a separate empty database built from the immutable source DDL.
  const referenceDb='schoolpilot_snapshot_reference_'+run;
  call(['exec',name,'createdb','-U',owner,referenceDb],{log:'reference-create.log'});
  call(['exec','-i',name,'psql','-U',owner,'-d',referenceDb,'-v','ON_ERROR_STOP=1'],{input:readFileSync(join(snapshotDirectory,'post-convergence-schema.sql'),'utf8'),log:'reference-restore.log'});
  const referenceDdl=call(['exec',name,'pg_dump','-U',owner,'-d',referenceDb,'--schema-only','--no-owner','--no-privileges']);
  writeFileSync(join(output,'reference-rendered-schema.sql'),referenceDdl,{flag:'wx'});
  assert.equal(normalizeSnapshotSchema(ddl),normalizeSnapshotSchema(referenceDdl));
  call(['exec',name,'dropdb','-U',owner,referenceDb],{log:'reference-drop.log'});
  save('schema-comparison.json',{passed:true,normalization:'Both full schemas rendered by the same native PostgreSQL parser; only LF and pg_dump restrict nonce directives removed',referenceRenderedSha256:snapshotHash(Buffer.from(referenceDdl)),originalSha256:snapshotHash(readFileSync(join(snapshotDirectory,'post-convergence-schema.sql'))),restoredSha256:snapshotHash(Buffer.from(ddl)),normalizedSha256:snapshotHash(normalizeSnapshotSchema(ddl))});
  stage='data-validation';const config={sourceDirectory,snapshotDirectory,snapshotManifestSha256,adminUrl,appUrl,resultFile:join(output,'database-validation.json')};writeFileSync(join(output,'validation.private.json'),JSON.stringify(config,null,2)+'\n',{flag:'wx'});
  const result=spawnSync(process.execPath,[join(repo,'scripts/load/usage/roles/validate-snapshot-database.mjs'),join(output,'validation.private.json')],{env:{...env,NODE_ENV:'test',SCHEDULER_ENABLED:'false',DATABASE_URL:appUrl,DATABASE_URL_PRIVILEGED:appUrl,ADMIN_DATABASE_URL:adminUrl,DOTENV_CONFIG_QUIET:'true',DOTENV_CONFIG_PATH:join(output,'absent-dotenv')},encoding:'utf8',maxBuffer:2*1024*1024,timeout:180000});writeFileSync(join(output,'database-validation.log'),(result.stdout||'')+(result.stderr||''),{flag:'wx'});assert.equal(result.status,0);
  stage='analyze';call(['exec',name,'psql','-U',owner,'-d',db,'-v','ON_ERROR_STOP=1','-c','ANALYZE'],{log:'analyze.log',timeout:120000});
  stage='client-drain';const {Client}=createRequire(join(sourceDirectory,'package.json'))('pg'),check=new Client({connectionString:adminUrl,connectionTimeoutMillis:5000,statement_timeout:60000});await check.connect();let count;try{count=(await check.query("SELECT COUNT(*)::int AS count FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND backend_type='client backend'")).rows[0].count;assert.equal(count,0);}finally{await check.end();}
  const nonce=randomBytes(24).toString('hex'),handoff={schemaVersion:1,run,source,snapshotManifestSha256,pgContainer:name,pgContainerId:before.Id,pgImage:image,database:db,privateConfigurationFile:join(output,'validation.private.json'),freshRole:role,allValidationClientsClosed:true,otherClientsBeforeHandoff:count,nonce,readyAt:new Date().toISOString(),expiresAt:new Date(Date.now()+15*60*1000).toISOString(),purpose:'Bounded rollback-only warm ABBA distinct-URL comparison with per-grain equivalence; fixture is consumed and cannot become capacity evidence',restorationPassed:true,capacityAccepted:false};
  save('ready.json',handoff);console.log(JSON.stringify({event:'snapshot_restore_ready',output,run,readySha256:snapshotHash(readFileSync(join(output,'ready.json'))),validated:true,capacityAccepted:false}));
  stage='handoff';const deadline=Date.now()+15*60*1000;while(!existsSync(join(output,'handoff-complete.json'))&&Date.now()<deadline)await new Promise(r=>setTimeout(r,500));assert.ok(existsSync(join(output,'handoff-complete.json')),'Bounded handoff completion missing');const complete=JSON.parse(readFileSync(join(output,'handoff-complete.json'),'utf8'));assert.equal(complete.run,run);assert.equal(complete.nonce,nonce);assert.equal(complete.clientsClosed,true);passed=true;
}catch(e){failure={stage,name:e.name,code:e.code||'RESTORE_ASSERTION'};save('failure.json',failure);console.error(JSON.stringify({event:'snapshot_restore_failed',output,...failure}));process.exitCode=1;}
finally{let cleanup=false;try{const found=find();if(found){verify(found);call(['rm','--force',found.Id],{log:'remove.log'});}assert.equal(find(),null);cleanup=true;}catch{process.exitCode=1;}save('cleanup.json',{run,name,created,cleanupPassed:cleanup,handoffPassed:passed,failure});console.log(JSON.stringify({event:'snapshot_restore_finished',output,passed,cleanupPassed:cleanup}));}




