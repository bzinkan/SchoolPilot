import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import fs from 'node:fs';
const root=process.argv[2];const require=createRequire(root+'/package.json');
const {drizzle}=require('drizzle-orm/node-postgres');const {sql,and,eq,getTableColumns}=require('drizzle-orm');const {PgDialect}=require('drizzle-orm/pg-core');
const {schools}=await import(pathToFileURL(root+'/dist/schema/core.js'));const {classpilotStudentControlStates}=await import(pathToFileURL(root+'/dist/schema/classpilot.js'));
const {settings}=await import(pathToFileURL(root+'/dist/schema/shared.js'));
const db=drizzle({query:()=>{throw Error('no SQL allowed')}});const dialect=new PgDialect();
const sid='fixture-school',student='fixture-student';const controlColumns=getTableColumns(classpilotStudentControlStates);const schoolColumns=getTableColumns(schools);
const fixedControlSelect=sql.raw('SELECT '+Object.entries(controlColumns).map(([k,c])=>'"'+c.name+'" AS "'+k+'"').join(',')+' FROM classpilot_student_control_states WHERE school_id = ');
const queries={
 schoolFull:()=>db.select().from(schools).where(eq(schools.id,sid)).limit(1)._prepare(),
 schoolNarrow:()=>db.select({status:schools.status,planStatus:schools.planStatus,domain:schools.domain}).from(schools).where(eq(schools.id,sid)).limit(1)._prepare(),
 schoolNarrowRaw:()=>dialect.sqlToQuery(sql`SELECT status,plan_status AS "planStatus",domain FROM schools WHERE id=${sid} LIMIT 1`),
 sso:()=>db.select({classpilotSsoPolicy:settings.classpilotSsoPolicy,classpilotSsoPolicyRevision:settings.classpilotSsoPolicyRevision}).from(settings).where(eq(settings.schoolId,sid)).limit(1)._prepare(),
 ssoRaw:()=>dialect.sqlToQuery(sql`SELECT classpilot_sso_policy AS "classpilotSsoPolicy",classpilot_sso_policy_revision AS "classpilotSsoPolicyRevision" FROM settings WHERE school_id=${sid} LIMIT 1`),
 control:()=>db.select().from(classpilotStudentControlStates).where(and(eq(classpilotStudentControlStates.schoolId,sid),eq(classpilotStudentControlStates.studentId,student))).limit(1)._prepare(),
 controlRaw:()=>dialect.sqlToQuery(sql`${fixedControlSelect}${sid} AND student_id = ${student} LIMIT 1`),
};
for(const fn of Object.values(queries))for(let n=0;n<500;n++)fn();const rounds=[];for(let i=0;i<3;i++){const r={};for(const [name,fn]of Object.entries(queries)){const start=performance.now();for(let n=0;n<10000;n++)fn();r[name]=+(performance.now()-start).toFixed(3);}rounds.push(r);}
const result={diagnosticOnly:true,noDatabase:true,iterationsPerRound:10000,schoolColumnCount:Object.keys(schoolColumns).length,controlColumnCount:Object.keys(controlColumns).length,rounds,caveats:'Construction/prepare only; raw benchmarks omit row mapping. Broad control raw requires explicit timestamp decoder parity before production use. No client/tenant/authority result cache.'};fs.writeFileSync(process.env.TEMP+'/release297-hot-helper-build-benchmark.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));


