param([Parameter(Mandatory=$true)][ValidateSet('unit','infrastructure')][string]$Lane)
$ErrorActionPreference = 'Stop'
$repository = '<LOCAL_USER_PROFILE>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$output = Join-Path '<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-test-lane-listing-01' ('full-' + $Lane)
if (Test-Path -LiteralPath $output) { throw 'Evidence directory already exists' }
New-Item -ItemType Directory -Path $output | Out-Null
Set-Location -LiteralPath $repository
$env:NODE_ENV = 'test'; $env:SCHEDULER_ENABLED = 'false'; $env:REDIS_URL = ''
Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
$env:DOTENV_CONFIG_PATH = Join-Path $output 'absent-dotenv'; $env:DOTENV_CONFIG_QUIET = 'true'
$names = @(git ls-files --cached --others --exclude-standard -- src tests scripts package.json package-lock.json tsconfig.json | Sort-Object -Unique)
function Snapshot { @($names | ForEach-Object { [ordered]@{ path=$_; sha256=(Get-FileHash -LiteralPath (Join-Path $repository $_) -Algorithm SHA256).Hash.ToLower() } }) }
$before = Snapshot
$before | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-before.json')
$start = [DateTime]::UtcNow.ToString('o')
& npm.cmd run "test:$Lane" *> (Join-Path $output 'test.log')
$code = $LASTEXITCODE
$after = Snapshot
$after | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'source-after.json')
$result = [ordered]@{ command="npm run test:$Lane"; exitCode=$code; sourceHead=(git rev-parse HEAD).Trim(); startedAt=$start; finishedAt=[DateTime]::UtcNow.ToString('o'); sourceFileCount=$before.Count; sourceUnchanged=(@(Compare-Object ($before | ConvertTo-Json -Depth 6) ($after | ConvertTo-Json -Depth 6)).Count -eq 0); configuration='DATABASE_URL absent; production/app unchanged; original lane concurrency retained' }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'result.json')
$result | ConvertTo-Json -Depth 6
if ($code -ne 0 -or -not $result.sourceUnchanged) { exit 1 }
