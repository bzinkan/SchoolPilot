import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const files={writer:'/app/dist/services/classpilotPrivateChatLifecycle.js',relay:'/app/dist/realtime/websocket.js',storage:'/app/dist/services/storage.js',migration:'/app/dist/db/classpilotPrivateChatLifecycleMigration.js',protocol:'/app/dist/services/classpilotProtocol.js',registry:'/app/dist/config/rlsRegistry.json',tenant:'/app/dist/middleware/tenantContext.js',monitoring:'/app/dist/services/classpilotMonitoringPolicy.js'};
const text=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,readFileSync(p,'utf8')]));
assert.match(text.writer,/export const PRIVATE_CHAT_LIFECYCLE_WRITER_VERSION = 1;/);
assert.match(text.writer,/export const PRIVATE_CHAT_BRIDGE_VERSION = 1;/);
assert.match(text.relay,/export const PRIVATE_CHAT_RELAY_VERSION = 1;/);
assert.match(text.migration,/OLD\.private_chat_lifecycle_required\s+AND\s+NOT\s+NEW\.private_chat_lifecycle_required/);
assert.ok(text.protocol.includes('privateChatLifecycleV1'));
const registry=JSON.parse(text.registry), tables=registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables;
assert.equal(tables.length,129);assert.equal(new Set(tables).size,129);assert.equal(tables[128],'classpilot_private_chat_threads');
const delivery=text.storage.slice(text.storage.indexOf('export async function withClasspilotStudentControlDeliveryAuthority'),text.storage.indexOf('export async function withClasspilotStudentWebSocketBootstrapAuthority'));
assert.match(delivery,/if \(options\.freezeSsoPolicy\)/);
assert.ok(delivery.indexOf('lockClasspilotSsoPolicyDeliveryAuthority')>0);
assert.ok(delivery.indexOf('lockClasspilotSsoPolicyDeliveryAuthority')<delivery.indexOf('lockPrivateChatChannel'));
const start=text.relay.indexOf('const authority = await withClasspilotStudentWebSocketBootstrapAuthority');
const bootstrap=text.relay.slice(start,text.relay.indexOf('const fab = await buildStudentFabState',start));
assert.ok(start>=0);assert.match(bootstrap,/freezeSsoPolicy: true/);
assert.doesNotMatch(bootstrap,/await lockClasspilotSsoPolicyDeliveryAuthority/);
assert.ok(!text.tenant.includes('tenantClientDatabases'));
assert.ok(text.tenant.includes('ownedTenantStores.delete(client)'));
assert.ok(text.monitoring.includes('getOwnedTenantStore'));
assert.ok(text.monitoring.includes('owned?.schoolId === schoolId'));
assert.ok(text.monitoring.includes('bypassCache: true'));
assert.ok(!existsSync('/app/dist/services/classpilotUsageExecution.js'));
const dependencyVersions = {};
const expectedDependencyVersions = { express:'4.22.3', 'body-parser':'1.20.8', qs:'6.16.0', 'ip-address':'10.7.3', 'side-channel':'1.1.1', 'side-channel-list':'1.0.1' };
for (const [name, expected] of Object.entries(expectedDependencyVersions)) {
  dependencyVersions[name] = JSON.parse(readFileSync(`/app/node_modules/${name}/package.json`, 'utf8')).version;
  assert.equal(dependencyVersions[name], expected, name);
}
console.log(JSON.stringify({passed:true,dependencyVersions,writerVersion:1,bridgeVersion:1,relayVersion:1,inventoryCount:129,stickyMigration:true,ssoLockOrderCorrection:true,monitoringOwnedLeaseCorrection:true,metadataReuseAbsent:true,usageContentionCorrectionAbsent:true,usageModesRequired:'both off',hashes:Object.fromEntries(Object.entries(text).map(([k,v])=>[k,sha(v)])),scope:'Embedded file/marker/order validation only; no API/worker application process started or database connected.'},null,2));



