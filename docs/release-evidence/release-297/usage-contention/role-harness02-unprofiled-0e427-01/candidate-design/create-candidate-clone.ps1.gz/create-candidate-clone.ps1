$ErrorActionPreference='Stop'
$source='0e427e3ca9b82125e0bb8692176accad21f4f699'
$repository='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot'
$target=Join-Path $env:TEMP 'release297-linux-0e427-candidate-source-01'
if(Test-Path -LiteralPath $target){throw 'Fresh clone path required; preserve existing attempts.'}
if((& git -C $repository rev-parse "$source^{commit}").Trim() -cne $source){throw 'Exact committed source unavailable.'}
git init $target | Out-Null
if($LASTEXITCODE -ne 0){throw 'Clone init failed.'}
git -C $target config core.autocrlf false
if($LASTEXITCODE -ne 0){throw 'LF checkout setting failed.'}
git -C $target config core.longpaths true
if($LASTEXITCODE -ne 0){throw 'Long path setting failed.'}
$localUri=[Uri]::new(([IO.Path]::GetFullPath($repository)+[IO.Path]::DirectorySeparatorChar)).AbsoluteUri
git -C $target fetch --depth 1 --no-tags $localUri $source | Out-Null
if($LASTEXITCODE -ne 0){throw 'Exact self-contained source fetch failed.'}
git -C $target checkout --detach $source | Out-Null
if($LASTEXITCODE -ne 0){throw 'Exact source checkout failed.'}
if(Test-Path -LiteralPath (Join-Path $target '.git/objects/info/alternates')){throw 'No alternate Git object stores allowed.'}
if(((& git -C $target status --porcelain)-join "`n").Length -ne 0){throw 'Clean candidate clone required.'}
if((& git -C $target rev-parse HEAD).Trim() -cne $source){throw 'Clone source mismatch.'}
[ordered]@{source=$source;sourceTree=(& git -C $target rev-parse 'HEAD^{tree}').Trim();clone=$target;clean=$true;lineEndings='LF';noAlternates=$true;originKind='local exact committed object';originalCheckoutTouched=$false;createdAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'candidate-clone-receipt.json')
