import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import ts from 'file:///<user-home>/.codex/worktrees/release297-compatible-rollback/SchoolPilot/node_modules/typescript/lib/typescript.js';
const cwd='<user-home>/.codex/worktrees/release297-compatible-rollback/SchoolPilot';
const primary='<user-home>/.codex/worktrees/release-stabilization-297/SchoolPilot';
const original=execFileSync('git',['show','ed5599de:src/services/storage.ts'],{cwd,encoding:'utf8',maxBuffer:16*1024*1024}).replaceAll('\r\n','\n');
const current=readFileSync(cwd+'/src/services/storage.ts','utf8').replaceAll('\r\n','\n');
const active=readFileSync(primary+'/src/services/storage.ts','utf8').replaceAll('\r\n','\n');
function fn(text,name){const file=ts.createSourceFile('storage.ts',text,ts.ScriptTarget.ES2022,true);const node=file.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text===name);assert.ok(node,name);return node.getText(file);}
const before=fn(original,'withClasspilotStudentControlDeliveryAuthority');
let after=fn(current,'withClasspilotStudentControlDeliveryAuthorityCore');
after=after.replace('async function withClasspilotStudentControlDeliveryAuthorityCore<','export async function withClasspilotStudentControlDeliveryAuthority<')
 .replace('  ) => T,\n  heartbeatFinalFence = false,','  ) => T')
 .replace('      if (heartbeatFinalFence) {\n        await assertClasspilotHeartbeatDeliveryCurrent(options, transactionDb);\n      } else if (!(await hasExactClasspilotTelemetryBinding(options, transactionDb))) {','      if (!(await hasExactClasspilotTelemetryBinding(options, transactionDb))) {');
assert.equal(after,before,'The generic/default core changes only at the fixed heartbeat seam');
const helper=fn(current,'assertClasspilotHeartbeatDeliveryCurrent');
assert.equal(helper,fn(active,'assertClasspilotHeartbeatDeliveryCurrent'),'Backport uses exactly the reviewed candidate final checker');
const sha=x=>createHash('sha256').update(x).digest('hex');
const result={baseline:'ed5599de0191b4b9961ed907586e1fc153ebd63b',defaultCoreEquivalentAfterReversingOnlyPrivateNameAndHeartbeatSeam:true,baselineCoreSha256:sha(before),candidateFinalHelperExactlyMatches:true,finalHelperSha256:sha(helper),rollbackStorageSha256:sha(readFileSync(cwd+'/src/services/storage.ts')),primaryStorageSha256:sha(readFileSync(primary+'/src/services/storage.ts')),preserved:['package.json','package-lock.json','CLAUDE.md'].map(file=>({file,sha256:sha(readFileSync(cwd+'/'+file)),unchanged:readFileSync(cwd+'/'+file,'utf8').replaceAll('\r\n','\n')===execFileSync('git',['show','HEAD:'+file],{cwd,encoding:'utf8',maxBuffer:16*1024*1024}).replaceAll('\r\n','\n')}))};
assert.ok(result.preserved.every(x=>x.unchanged));
writeFileSync(process.env.TEMP+'/release297-rollback-heartbeat-fence-01/source-equivalence.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));


