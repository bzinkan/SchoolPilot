import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

export const PROFILE = 'release-enabled-linux-shared-namespace-diagnostic-100rps-v1';
export const sha256 = value => createHash('sha256').update(value).digest('hex');
export function replaceOnce(text, before, after) {
  assert.equal(text.split(before).length - 1, 1, `Prototype anchor must occur once: ${before.slice(0, 100)}`);
  return text.replace(before, () => after);
}

export function patchProfile(source) {
  let text = replaceOnce(source, "name: 'release-enabled-isolated-100rps-v1',", `name: '${PROFILE}',\n  diagnosticRuntime: 'Linux candidate runtime; shared owned PostgreSQL network namespace; separate forked processes',`);
  text = replaceOnce(text, 'export function releaseTrafficOptions(env) {', `export function releaseTrafficOptions(env) {
  if (env.USAGE_RELEASE_LINUX_DIAGNOSTIC === 'true') {
    assert.equal(env.USAGE_RELEASE_DIAGNOSTIC, 'true');
    assert.equal(env.USAGE_RELEASE_CPU_PROFILE, 'false');
    assert.equal(env.USAGE_RELEASE_PHASE, 'combined');
    return {}; // Full60s/6000heartbeat/64report workload; diagnostic is never a short probe.
  }`);
  return text;
}

export function patchCoordinator(source) {
  let text = replaceOnce(source, "import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport { assertRuntime } from '/prototype-tools/verify-runtime.mjs';\nassertRuntime('/prototype-tools/base-runtime.json');");
  text = replaceOnce(text,
    "const root = fileURLToPath(new URL('../../../', import.meta.url)), output = process.env.USAGE_SCALE_OUTPUT;",
    `const harnessRoot = fileURLToPath(new URL('../../../', import.meta.url));
const root = '/app', output = process.env.USAGE_SCALE_OUTPUT;
assert.equal(process.platform, 'linux');
assert.equal(process.env.USAGE_RELEASE_LINUX_DIAGNOSTIC, 'true');
assert.equal(process.env.USAGE_RELEASE_DIAGNOSTIC, 'true');
assert.equal(process.env.USAGE_RELEASE_PHASE, 'combined');
assert.equal(process.env.USAGE_RELEASE_CPU_PROFILE, 'false');
const diagnosticBinding = JSON.parse(readFileSync('/diagnostic/binding.json', 'utf8'));
assert.equal(diagnosticBinding.applicationSource, process.env.USAGE_SOURCE_REVISION);`);
  text = replaceOnce(text, "assert.ok(sourceClean || process.env.USAGE_RELEASE_DIAGNOSTIC === 'true', 'Capacity evidence requires clean source');", "assert.equal(sourceClean, true, 'Linux diagnostic requires a clean, self-contained exact app clone');");
  text = text.replaceAll("resolve(root, 'scripts/load/usage'", "resolve(harnessRoot, 'scripts/load/usage'");
  text = replaceOnce(text, 'fork(resolve(root, `scripts/load/usage/${file}`)', 'fork(resolve(harnessRoot, `scripts/load/usage/${file}`)');
  text = replaceOnce(text, 'sourceRevision: source, sourceClean, sourceHashes,', 'sourceRevision: source, sourceClean, sourceHashes, diagnosticBinding,');
  text = replaceOnce(text,
    "Generator, API and worker use separate Node processes with512MiB heap caps; Windows process CPU and RSS are not hard-limited.",
    'Generator, API and worker use separate Linux Node processes with512MiB heap caps in one diagnostic container; per-role CPU and RSS are not hard-limited. This does not establish production task capacity.');
  text = replaceOnce(text,
    'metrics.acceptance = capacityAcceptance(metrics); metrics.capacityAccepted = Object.values(metrics.acceptance).every(Boolean);',
    `metrics.acceptance = capacityAcceptance(metrics);
    assert.equal(metrics.acceptance.acceptanceRun, false);
    metrics.diagnosticChecksPassed = Object.entries(metrics.acceptance).every(([key, value]) => key === 'acceptanceRun' || value === true);
    metrics.capacityAccepted = false;`);
  text = replaceOnce(text,
    "assert.equal(metrics.capacityAccepted, true, 'Release-enabled capacity acceptance failed; preserved full diagnostic evidence');",
    "assert.equal(metrics.diagnosticChecksPassed, true, 'Linux diagnostic requirements failed; retained all original numerical thresholds');");
  text = replaceOnce(text, 'const watchdog = setTimeout(() => owner.process.kill(), 15_000);', `const watchdog = setTimeout(() => {
      metrics.childCleanupFailure = true; process.exitCode = 1;
      owner.process.kill('SIGKILL');
    }, 15_000);`);
  text = replaceOnce(text, "try { await owner.rpc('shutdown', undefined, 15_000); } catch { owner.process.kill(); }", "try { await owner.rpc('shutdown', undefined, 15_000); } catch { metrics.childCleanupFailure = true; process.exitCode = 1; owner.process.kill('SIGTERM'); }");
  text = replaceOnce(text, 'if (!metrics.childShutdownClean) metrics.capacityAccepted = false;', `if (!metrics.childShutdownClean) metrics.diagnosticChecksPassed = false;
  metrics.capacityAccepted = false; // Never accepted capacity, including all-green diagnostics.`);
  return text;
}

// Forward only explicitly listed synthetic fixture settings. No inherited cloud,
// Docker, proxy, user home, arbitrary NODE_OPTIONS, or dotenv credentials enter.
export const FIXTURE_ENV = Object.freeze([
  'DATABASE_URL','ADMIN_DATABASE_URL','DATABASE_URL_PRIVILEGED','JWT_SECRET','SESSION_SECRET','STUDENT_TOKEN_SECRET',
  'NODE_ENV','REDIS_URL','RLS_GUC_ENABLED','RLS_ENABLED_TABLES','SCHEDULER_ENABLED','USAGE_LOCAL_SCALE',
  'USAGE_SCALE_CONTAINER','USAGE_SOURCE_REVISION','USAGE_SCALE_COLD_STATE_SHA256','USAGE_SCALE_RLS_INVENTORY',
  'CLASSPILOT_USAGE_ROLLUP_MODE','CLASSPILOT_DIGITAL_USAGE_MODE','CLASSPILOT_DAILY_USAGE_ROLLUP_MODE',
  'CLASSPILOT_SHARED_TEACHING_RESOURCES_MODE','PASSPILOT_RULES_MODE','PASSPILOT_APPOINTMENTS_MODE','PASSPILOT_REPORTS_MODE',
  'RUN_LEGACY_MIGRATIONS_ONLY','RUN_MIGRATIONS_ONLY',
]);
export function linuxPlan({ run, source, imageId, pgContainerId, evidenceDirectory, env }) {
  assert.match(run, /^[a-f0-9]{12}$/); assert.match(source, /^[a-f0-9]{40}$/);
  assert.match(imageId, /^sha256:[a-f0-9]{64}$/); assert.match(pgContainerId, /^[a-f0-9]{64}$/);
  assert.ok(evidenceDirectory && !/[\r\n,]/.test(evidenceDirectory));
  assert.equal(env.USAGE_SCALE_CONTAINER, `schoolpilot-usage-scale-${run}`);
  for (const key of ['DATABASE_URL', 'ADMIN_DATABASE_URL', 'DATABASE_URL_PRIVILEGED']) {
    const url = new URL(env[key]);
    assert.ok(['postgresql:', 'postgres:'].includes(url.protocol));
    assert.equal(url.search, ''); assert.equal(url.hash, '');
    assert.equal(url.hostname, '127.0.0.1'); assert.equal(url.port, '5437');
    assert.equal(url.pathname, `/schoolpilot_redesign_usage_scale_${run}`);
  }
  assert.equal(env.REDIS_URL, 'redis://127.0.0.1:6387');
  assert.equal(env.NODE_ENV, 'test'); assert.equal(env.USAGE_LOCAL_SCALE, '1');
  assert.equal(env.USAGE_SOURCE_REVISION, source);
  const childEnv = Object.fromEntries(FIXTURE_ENV.filter(key => typeof env[key] === 'string').map(key => [key, env[key]]));
  Object.assign(childEnv, {
    USAGE_RELEASE_LINUX_DIAGNOSTIC: 'true', USAGE_RELEASE_DIAGNOSTIC: 'true', USAGE_RELEASE_CPU_PROFILE: 'false',
    USAGE_RELEASE_PHASE: 'combined', USAGE_SCALE_OUTPUT: '/evidence/usage-scale.json',
    USAGE_SCALE_CAPS: '/evidence/resource-caps.json', USAGE_SCALE_COLD_STATE: '/evidence/cold-fixture-state.json',
    DOTENV_CONFIG_PATH: '/nonexistent-diagnostic-dotenv', DOTENV_CONFIG_QUIET: 'true', GIT_OPTIONAL_LOCKS: '0',
  });
  const name = `schoolpilot-usage-linux-${run}`;
  const args = ['create', '--name', name, '--label', `codex.usage-scale=${run}`, '--label', 'codex.usage-linux=diagnostic-only',
    '--network', `container:${pgContainerId}`, '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '--init', '--no-healthcheck', '--user', 'node', '--workdir', '/app',
    '--mount', `type=bind,source=${evidenceDirectory},target=/evidence`,
    ...Object.keys(childEnv).sort().flatMap(key => ['--env', key]),
    '--entrypoint', 'node', imageId, '--max-old-space-size=512', '/diagnostic/scripts/load/usage/release-enabled-scale.mjs'];
  return { name, args, childEnv, receipt: { profile: PROFILE, diagnosticOnly: true, capacityAccepted: false,
    applicationSource: source, imageId, pgContainerId, heapMiB: 512, hardPerRoleCpuLimit: null,
    hardPerRoleRssLimit: null, evidenceStorage: 'Windows external bind mount; filesystem crossing remains',
    environmentKeys: Object.keys(childEnv).sort() } };
}

export function assertOwned(inspect, { run, name, imageId, pgContainerId }) {
  assert.equal(inspect.Name, `/${name}`);
  assert.equal(inspect.Config?.Labels?.['codex.usage-scale'], run);
  assert.equal(inspect.Config?.Labels?.['codex.usage-linux'], 'diagnostic-only');
  assert.equal(inspect.Image, imageId);
  assert.equal(inspect.HostConfig?.NetworkMode, `container:${pgContainerId}`);
  assert.equal(inspect.HostConfig?.ReadonlyRootfs, true);
}

// The caller MUST still clean Redis and PG after a harness cleanup failure.
// A disappeared task must be confirmed absent; exceptions are never success.
export async function cleanupOwned(adapter, binding) {
  const result = { owned: false, terminated: false, removed: false, cleanupPassed: false, stages: [] };
  try {
    const found = await adapter.inspect(binding.name);
    if (found === null) { result.confirmedAbsent = true; result.cleanupPassed = true; return result; }
    assertOwned(found, binding); result.owned = true;
    if (found.State?.Running === true) {
      result.stages.push('kill'); await adapter.kill(found.Id, 'KILL');
      const stopped = await adapter.inspect(binding.name);
      if (stopped !== null) { assertOwned(stopped, binding); assert.equal(stopped.State?.Running, false); }
      result.terminated = true;
    }
    result.stages.push('remove'); await adapter.remove(found.Id);
    assert.equal(await adapter.inspect(binding.name), null); result.removed = true; result.cleanupPassed = true;
  } catch { result.failure = 'OWNED_LINUX_CLEANUP_UNCONFIRMED'; }
  return result;
}
