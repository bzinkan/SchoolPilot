import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const files={writer:'/app/dist/services/classpilotPrivateChatLifecycle.js',relay:'/app/dist/realtime/websocket.js',migration:'/app/dist/db/classpilotPrivateChatLifecycleMigration.js',protocol:'/app/dist/services/classpilotProtocol.js',registry:'/app/dist/config/rlsRegistry.json'};
const text=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,readFileSync(p,'utf8')]));
assert.match(text.writer,/export const PRIVATE_CHAT_LIFECYCLE_WRITER_VERSION = 1;/);
assert.match(text.writer,/export const PRIVATE_CHAT_BRIDGE_VERSION = 1;/);
assert.match(text.relay,/export const PRIVATE_CHAT_RELAY_VERSION = 1;/);
assert.match(text.migration,/OLD\.private_chat_lifecycle_required\s+AND\s+NOT\s+NEW\.private_chat_lifecycle_required/);
assert.ok(text.protocol.includes('privateChatLifecycleV1'));
const registry=JSON.parse(text.registry);const tables=registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables;
assert.equal(tables.length,129);assert.equal(new Set(tables).size,129);assert.equal(tables[128],'classpilot_private_chat_threads');
console.log(JSON.stringify({passed:true,writerVersion:1,bridgeVersion:1,relayVersion:1,inventoryCount:129,stickyMigration:true,hashes:Object.fromEntries(Object.entries(text).map(([k,v])=>[k,sha(v)])),scope:'Embedded file/marker validation only; no API/worker application process started or database connected.'},null,2));

