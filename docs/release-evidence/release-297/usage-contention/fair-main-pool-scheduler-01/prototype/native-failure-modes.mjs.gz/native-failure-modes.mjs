import net from 'node:net';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createFairMainPoolClass } from './fair-main-pool.mjs';
const require = createRequire('C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/package.json');
const pg = require('pg');
const attempt = process.argv[2]; assert.match(attempt, /^\d{2}$/);
const bounded = async (promise, ms) => { let timer; try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('bounded-proof-timeout')), ms); })]); } finally { clearTimeout(timer); } };
const results = [];
for (const mode of ['ssl-rejected-open-socket', 'native-connect-timeout', 'end-during-native-connect']) {
  const sockets = new Set(), clients = []; let live = 0, peak = 0, endSignals = 0;
  const server = net.createServer(socket => { sockets.add(socket); socket.on('error', () => {}); socket.on('close', () => sockets.delete(socket));
    if (mode === 'ssl-rejected-open-socket') socket.once('data', () => socket.write('N'));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  class ObservedClient extends pg.Client {
    constructor(...args) { super(...args); clients.push(this); live++; peak = Math.max(peak, live);
      this.connection.stream.once('close', () => live--); this.once('end', () => endSignals++); }
  }
  const FairPool = createFairMainPoolClass(pg.Pool, { readOperation: () => 'default', NativeClient: pg.Client });
  const pool = new FairPool({ host: '127.0.0.1', port: server.address().port, user: 'synthetic_unused', database: 'synthetic_unused',
    max: 16, connectionTimeoutMillis: 5000, idleTimeoutMillis: 0, Client: ObservedClient,
    ssl: mode === 'ssl-rejected-open-socket' ? { rejectUnauthorized: true } : false });
  pool.on('error', () => {});
  const started = performance.now(); let ending;
  const requests = Array.from({ length: 16 }, () => pool.connect().then(client => { client.release(); return { unexpectedSuccess: true }; }, error => ({ error: error.code ?? error.message, elapsedMs: performance.now() - started })));
  const result = { mode, configuredMax: 16, passed: false };
  try {
    if (mode === 'end-during-native-connect') {
      await new Promise(resolve => setTimeout(resolve, 50));
      let resolved = false; ending = pool.end().then(() => { resolved = true; });
      await new Promise(resolve => setTimeout(resolve, 30)); assert.equal(resolved, false, 'end must retain native handshake ownership');
    }
    result.outcomes = await bounded(Promise.all(requests), 6500);
    ending ??= pool.end(); await bounded(ending, mode === 'ssl-rejected-open-socket' ? 500 : 6500);
    result.liveAtEnd = live; result.ownershipAtEnd = pool.schedulingSnapshot();
    assert.equal(live, 0); assert.ok(peak <= 16); assert.equal(result.ownershipAtEnd.ownedSlots, 0);
    if (mode === 'native-connect-timeout') assert.ok(result.outcomes.every(r => r.elapsedMs >= 4900 && r.elapsedMs < 5500));
    result.passed = true;
  } catch (error) { result.failure = error.message; result.liveAtFailure = live; result.ownershipAtFailure = pool.schedulingSnapshot(); }
  finally {
    for (const client of clients) void client.end().catch(() => {});
    for (const socket of sockets) socket.destroy();
    await bounded(Promise.allSettled(requests), 6500);
    ending ??= pool.end(); await bounded(ending, 6500).catch(() => {});
    await new Promise(resolve => server.close(resolve));
    result.finalLive = live; result.endSignals = endSignals; result.peakSocketObjects = peak; result.elapsedMs = performance.now() - started;
    assert.equal(live, 0, 'owned proof sockets cleaned');
  }
  results.push(result);
}
const receipt = { schemaVersion: 1, createdAt: new Date().toISOString(), externalOnly: true,
  adapterSha256: createHash('sha256').update(readFileSync(new URL('./fair-main-pool.mjs', import.meta.url))).digest('hex'), results };
writeFileSync(new URL(`./native-failure-modes-${attempt}.json`, import.meta.url), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(receipt));
assert.ok(results.every(r => r.passed), 'Every native failure mode must settle cleanup ownership');
