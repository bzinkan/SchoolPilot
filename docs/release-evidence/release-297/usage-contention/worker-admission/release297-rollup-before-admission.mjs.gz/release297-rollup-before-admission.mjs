import { HEARTBEAT_ATTRIBUTION_LIMIT_SECONDS, serverTrackingDisabledIntervals, trackingPolicyDisabledIntervals, } from "file:///<WORKTREE>/src/services/classpilotHeartbeatCoverage.ts";
import { parseClasspilotRetentionDays } from "file:///<WORKTREE>/src/util/classpilotRetention.ts";
import { addLocalDays, localDateInTimeZone, localDateStartUtc, utcTimestampForSql, } from "file:///<WORKTREE>/src/util/schoolTime.ts";
const DAY_MS = 24 * 60 * 60 * 1000;
const HOUR_MS = 60 * 60 * 1000;
/** Probe from this far before the stored processed cutoff (late arrivals). */
const RECOMPUTE_LOOKBACK_MS = 5 * 60 * 1000;
/**
 * runHeavyJobsSerially purges retention only once an hour's UTC minute reaches
 * 30. The rollup stops taking new work at :25 so it can never push the purge
 * past its hour; one in-flight school is bounded by the pool's statement
 * timeout.
 */
export const CLASSPILOT_USAGE_ROLLUP_BUDGET_END_MINUTE = 25;
const DEFAULT_CONCURRENCY = 2;
export const CLASSPILOT_USAGE_ROLLUP_LOCK_SQL = "SELECT pg_advisory_xact_lock(hashtext('classpilot_usage_rollup'), hashtext($1))";
export const CLASSPILOT_USAGE_ROLLUP_DELETE_SQL = "DELETE FROM classpilot_usage_rollups WHERE school_id = $1 AND usage_date = $2::date";
export const CLASSPILOT_USAGE_ROLLUP_SETTINGS_SQL = `SELECT retention_hours, enable_tracking_hours, tracking_start_time,
  tracking_end_time, tracking_days, after_hours_mode
FROM settings
WHERE school_id = $1`;
// Parameterized per student through the (school_id, student_id, occurred_at)
// index; only server-authored state transitions can exclude time.
export const CLASSPILOT_USAGE_ROLLUP_TRACKING_EVENTS_SQL = `SELECT student.id AS student_id, event.event_type, event.origin,
  event.occurred_at, event.metadata
FROM students AS student
CROSS JOIN LATERAL (
  SELECT tracking.event_type, tracking.origin, tracking.occurred_at, tracking.metadata
  FROM classpilot_monitoring_events AS tracking
  WHERE tracking.school_id = $1
    AND tracking.student_id = student.id
    AND tracking.occurred_at >= $2::timestamptz
    AND tracking.occurred_at < $3::timestamptz
    AND tracking.origin = 'server'
    AND tracking.event_type = 'monitoring_state_changed'
) AS event
WHERE student.school_id = $1`;
export const CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL = `SELECT processed_through, is_final
FROM classpilot_usage_rollup_days
WHERE school_id = $1 AND usage_date = $2::date`;
export const CLASSPILOT_USAGE_ROLLUP_COMPLETE_SQL = `INSERT INTO classpilot_usage_rollup_days
  (school_id, usage_date, day_start_at, day_end_at, processed_through, is_final, computed_at)
VALUES ($1, $2::date, $3::timestamptz, $4::timestamptz, $5::timestamptz, $6, now())
ON CONFLICT (school_id, usage_date) DO UPDATE SET
  day_start_at = EXCLUDED.day_start_at, day_end_at = EXCLUDED.day_end_at,
  processed_through = EXCLUDED.processed_through, is_final = EXCLUDED.is_final, computed_at = EXCLUDED.computed_at`;
export const CLASSPILOT_USAGE_ROLLUP_CHANGED_SQL = `SELECT EXISTS (
  SELECT 1 FROM heartbeats AS heartbeat
  WHERE heartbeat.school_id = $1
    AND heartbeat.student_id IS NOT NULL
    AND heartbeat."timestamp" >= $2::timestamp
    AND heartbeat."timestamp" < $3::timestamp
) AS changed`;
/**
 * $1 school id, $2/$3 the half-open window as UTC wall-clock strings compared
 * with heartbeats."timestamp" (timestamp without time zone, never converted),
 * $4 the school-local usage date, $5 the excluded intervals as JSON.
 */
export const CLASSPILOT_USAGE_ROLLUP_INSERT_SQL = `WITH school_ai_decisions AS MATERIALIZED (
  -- Read the matching school's candidate decisions once. A per-observation
  -- newest lookup performs an index probe even for observations without AI;
  -- joining this bounded relation below preserves the same statement snapshot,
  -- lower time boundary and deterministic newest-decision tie rule.
  SELECT heartbeat_id, category, teacher_intent_source, created_at, id
  FROM classpilot_ai_decisions
  WHERE school_id = $1 AND created_at >= $2::timestamp
),
school_excluded AS MATERIALIZED (
  SELECT NULLIF(item->>'studentId', '') AS student_id,
    (item->>'start')::timestamp AS start_at,
    (item->>'end')::timestamp AS end_at
  FROM jsonb_array_elements($5::jsonb) AS item
),
school_sessions AS MATERIALIZED (
  SELECT id, start_time, end_time, scheduled_end_at
  FROM teaching_sessions
  WHERE school_id = $1
    AND start_time < $3::timestamp
    AND start_time >= $2::timestamp - interval '12 hours'
),
school_roster_window AS MATERIALIZED (
  SELECT roster.student_id, roster.group_id AS class_id, session.id AS session_id, session.start_time,
    GREATEST(session.start_time, roster.captured_at AT TIME ZONE 'UTC') AS starts_at,
    LEAST(
      COALESCE(session.end_time, 'infinity'::timestamp),
      COALESCE(session.scheduled_end_at AT TIME ZONE 'UTC', 'infinity'::timestamp),
      session.start_time + interval '12 hours'
    ) AS ends_at
  FROM school_sessions AS session
  JOIN classpilot_session_students AS roster
    ON roster.teaching_session_id = session.id AND roster.school_id = $1
  JOIN groups AS class
    ON class.id = roster.group_id AND class.school_id = $1
),
grains AS (
  -- Forced tenant RLS can substantially underestimate school cardinality.
  -- Correlating the timeline and roster to one student bounds any nested-loop
  -- plan to that student's observations and sessions instead of the school.
  SELECT student_grains.*
  FROM students AS student_scope
  CROSS JOIN LATERAL (
WITH observed AS MATERIALIZED (
  SELECT heartbeat.id, heartbeat.student_id, heartbeat."timestamp" AS observed_at,
    heartbeat.active_tab_url, heartbeat.ai_category, heartbeat.teacher_intent_source
  FROM heartbeats AS heartbeat
  WHERE heartbeat.school_id = $1
    AND heartbeat.student_id IS NOT NULL
    AND heartbeat."timestamp" >= $2::timestamp
    AND heartbeat."timestamp" < $3::timestamp
    AND heartbeat.student_id = student_scope.id
),
excluded AS MATERIALIZED (
  SELECT * FROM school_excluded
  WHERE student_id IS NULL OR student_id = student_scope.id
),
eligible AS MATERIALIZED (
  SELECT observed.* FROM observed
  WHERE (NOT EXISTS (SELECT 1 FROM excluded) OR NOT EXISTS (
    SELECT 1 FROM excluded
    WHERE (excluded.student_id IS NULL OR excluded.student_id = observed.student_id)
      AND observed.observed_at >= excluded.start_at
      AND observed.observed_at < excluded.end_at
  ))
),
deduplicated AS MATERIALIZED (
  SELECT DISTINCT ON (student_id, date_trunc('second', observed_at)) *
  FROM eligible
  ORDER BY student_id, date_trunc('second', observed_at), observed_at, id
),
ai_decision AS MATERIALIZED (
  SELECT DISTINCT ON (decision.heartbeat_id)
    decision.heartbeat_id, decision.category,
    decision.teacher_intent_source
  FROM school_ai_decisions AS decision
  JOIN deduplicated AS observation ON observation.id = decision.heartbeat_id
  ORDER BY decision.heartbeat_id, decision.created_at DESC, decision.id DESC
),
normalized AS (
  SELECT observation.id, observation.student_id, observation.observed_at,
    LEAST(
      ${HEARTBEAT_ATTRIBUTION_LIMIT_SECONDS}::numeric,
      EXTRACT(EPOCH FROM ((LEAD(observation.observed_at) OVER student_timeline) - observation.observed_at)),
      EXTRACT(EPOCH FROM ($3::timestamp - observation.observed_at)),
      CASE WHEN EXISTS (SELECT 1 FROM excluded) THEN EXTRACT(EPOCH FROM ((
        SELECT MIN(excluded.start_at) FROM excluded
        WHERE (excluded.student_id IS NULL OR excluded.student_id = observation.student_id)
          AND excluded.start_at > observation.observed_at
      ) - observation.observed_at)) END
    ) AS attributed_seconds,
    CASE WHEN observation.active_tab_url ~* '^https?://'
      THEN left(regexp_replace(lower(COALESCE(
        substring(observation.active_tab_url FROM '(?i)^https?://(?:[^/?#@]*@)?([^:/?#]*)'), ''
      )), '^www\\.', ''), 253)
      ELSE ''
    END AS domain,
    CASE WHEN COALESCE(NULLIF(ai_decision.category, ''), observation.ai_category) IN ('educational', 'non-educational')
      THEN COALESCE(NULLIF(ai_decision.category, ''), observation.ai_category)
      ELSE 'unknown'
    END AS category,
    (NULLIF(ai_decision.teacher_intent_source, '') IS NOT NULL
      OR NULLIF(observation.teacher_intent_source, '') IS NOT NULL) AS teacher_intent_exempt
  FROM deduplicated AS observation
  LEFT JOIN ai_decision ON ai_decision.heartbeat_id = observation.id
  WINDOW student_timeline AS (PARTITION BY observation.student_id ORDER BY observation.observed_at, observation.id)
),
classified AS (
  SELECT normalized.*,
    CASE
      WHEN normalized.category = 'non-educational' AND NOT normalized.teacher_intent_exempt
        AND normalized.domain <> '' THEN 'non-educational'
      WHEN normalized.category IN ('educational', 'non-educational') THEN 'educational'
      ELSE 'unknown'
    END AS classification
  FROM normalized
),
roster_window AS MATERIALIZED (
  SELECT * FROM school_roster_window
  WHERE student_id = student_scope.id
),
roster_boundaries AS (
  SELECT student_id, starts_at AS at FROM roster_window WHERE starts_at < ends_at
  UNION
  SELECT student_id, ends_at AS at FROM roster_window WHERE starts_at < ends_at
),
roster_intervals AS MATERIALIZED (
  SELECT student_id, at AS starts_at, LEAD(at) OVER (PARTITION BY student_id ORDER BY at) AS ends_at
  FROM roster_boundaries
),
winning_roster AS MATERIALIZED (
  -- Resolve overlapping frozen sessions once per roster interval instead of
  -- sorting every heartbeat by its candidate sessions. Boundaries are disjoint
  -- for each student; observations can match at most one winning interval.
  SELECT DISTINCT ON (roster_intervals.student_id, roster_intervals.starts_at)
    roster_intervals.student_id, roster_intervals.starts_at, roster_intervals.ends_at,
    roster_window.class_id, roster_window.session_id
  FROM roster_intervals
  JOIN roster_window ON roster_window.student_id = roster_intervals.student_id
    AND roster_intervals.starts_at >= roster_window.starts_at
    AND roster_intervals.starts_at < roster_window.ends_at
  WHERE roster_intervals.ends_at IS NOT NULL
  ORDER BY roster_intervals.student_id, roster_intervals.starts_at,
    roster_window.start_time DESC, roster_window.session_id DESC
),
attributed AS (
  SELECT classified.student_id, classified.attributed_seconds,
    classified.domain, classified.classification, winning_roster.class_id, winning_roster.session_id
  FROM classified
  LEFT JOIN winning_roster
    ON winning_roster.student_id = classified.student_id
    AND classified.observed_at >= winning_roster.starts_at
    AND classified.observed_at < winning_roster.ends_at
)
SELECT attributed.student_id, attributed.class_id, attributed.session_id,
  attributed.domain, attributed.classification,
  ROUND(SUM(GREATEST(attributed.attributed_seconds, 0)))::int AS seconds,
  COUNT(*)::int AS heartbeat_count
FROM attributed
GROUP BY attributed.student_id, attributed.class_id, attributed.session_id,
  attributed.domain, attributed.classification
  ) AS student_grains
  WHERE student_scope.school_id = $1
),
inserted AS (
  INSERT INTO classpilot_usage_rollups (
    school_id, usage_date, student_id, class_id, session_id, domain, classification, seconds, heartbeat_count
  )
  SELECT $1, $4::date, grains.student_id, grains.class_id, grains.session_id,
    grains.domain, grains.classification, grains.seconds, grains.heartbeat_count
  FROM grains
  RETURNING seconds, heartbeat_count
)
SELECT COUNT(*)::int AS row_count,
  COALESCE(SUM(seconds), 0)::bigint AS seconds,
  COALESCE(SUM(heartbeat_count), 0)::bigint AS heartbeat_count
FROM inserted`;
export function classpilotUsageRollupDay(date, timeZone) {
    return {
        date,
        dayStartUtc: localDateStartUtc(date, timeZone),
        dayEndUtc: localDateStartUtc(addLocalDays(date, 1), timeZone),
    };
}
/** Today and yesterday in the school's time zone (DST-safe half-open bounds). */
export function classpilotUsageRollupDays(now, timeZone) {
    const today = localDateInTimeZone(now, timeZone);
    return {
        today: classpilotUsageRollupDay(today, timeZone),
        yesterday: classpilotUsageRollupDay(addLocalDays(today, -1), timeZone),
    };
}
function floorUtcHour(value) {
    return new Date(Math.floor(value.getTime() / HOUR_MS) * HOUR_MS);
}
/** New work is not started at or after this instant (see the budget constant). */
export function classpilotUsageRollupDeadline(heavyJobStartedAt) {
    return new Date(floorUtcHour(heavyJobStartedAt).getTime() + CLASSPILOT_USAGE_ROLLUP_BUDGET_END_MINUTE * 60_000);
}
/**
 * The oldest instant the hourly retention purge cannot yet have reached.
 * purgeExpiredHeartbeats deletes heartbeats older than now - retention, and it
 * runs only once an hour's UTC minute is at least 30, so before :30 the newest
 * purge finished by the top of the hour unless it overran (lastPurgeFinishedAt).
 * A day that starts before the horizon may already be partly purged: it is
 * never rewritten, and its existing rollup rows stay until the purge removes
 * the whole day. This is what keeps a one-day-retention school's finished day
 * whole: it is finalized at the first top-of-hour after local midnight, before
 * that hour's :30 purge.
 */
export function classpilotUsageRetentionHorizon(options) {
    let bound = options.now.getUTCMinutes() < 30 ? floorUtcHour(options.now) : options.now;
    if (options.lastPurgeFinishedAt && options.lastPurgeFinishedAt > bound)
        bound = options.lastPurgeFinishedAt;
    return new Date(bound.getTime() - options.retentionDays * DAY_MS);
}
/**
 * The school's current tracking policy, shaped exactly like the frozen policy
 * a session report snapshots (limited after-hours counts as off).
 */
export function classpilotUsageTrackingPolicy(settings, timeZone) {
    const text = (value) => (typeof value === "string" && value ? value : null);
    const afterHours = text(settings?.after_hours_mode);
    return {
        enableTrackingHours: settings?.enable_tracking_hours === true,
        trackingStartTime: text(settings?.tracking_start_time),
        trackingEndTime: text(settings?.tracking_end_time),
        trackingDays: Array.isArray(settings?.tracking_days)
            ? settings.tracking_days.filter((day) => typeof day === "string")
            : [],
        schoolTimezone: timeZone,
        // Any other stored value never matched "off" in the report path either.
        afterHoursMode: afterHours === null || afterHours === "off" || afterHours === "limited" ? "off" : "full",
    };
}
/** Intervals the reports treat as not monitored: school-wide policy and per-student server state. */
export function classpilotUsageExclusions(options) {
    const exclusions = trackingPolicyDisabledIntervals(options.trackingPolicy, options.windowStart, options.windowEnd).map((interval) => ({ studentId: null, start: interval.start, end: interval.end }));
    const studentIds = [...new Set(options.trackingEvents.map((event) => event.studentId))].sort();
    for (const studentId of studentIds) {
        for (const interval of serverTrackingDisabledIntervals({ monitoringEvents: options.trackingEvents }, studentId, options.windowStart, options.windowEnd)) {
            exclusions.push({ studentId, start: interval.start, end: interval.end });
        }
    }
    return exclusions;
}
/** Millisecond UTC wall clock for comparisons with timestamp-without-time-zone columns. */
function utcWallClock(value) {
    return value.toISOString().replace("T", " ").replace("Z", "");
}
export function classpilotUsageExclusionsJson(exclusions) {
    return JSON.stringify(exclusions.map((exclusion) => ({
        studentId: exclusion.studentId ?? "",
        start: utcWallClock(exclusion.start),
        end: utcWallClock(exclusion.end),
    })));
}
function asDate(value) {
    if (value instanceof Date)
        return Number.isFinite(value.getTime()) ? value : null;
    if (typeof value !== "string" || !value)
        return null;
    const parsed = new Date(value);
    return Number.isFinite(parsed.getTime()) ? parsed : null;
}
/** Rewrite one school-local day in one transaction. The caller enforces the retention horizon. */
export async function rollupClasspilotUsageDay(pool, options) {
    const client = await pool.connect();
    let broken = false;
    try {
        await client.query("BEGIN");
        try {
            await client.query(CLASSPILOT_USAGE_ROLLUP_LOCK_SQL, [options.schoolId]);
            // Recheck under the same lock as the rewrite: stale queued work cannot
            // regress a newer snapshot or turn a finalized day back into a live day.
            const prior = await client.query(CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL, [options.schoolId, options.day.date]);
            const processedThrough = asDate(prior.rows[0]?.processed_through);
            if (processedThrough && processedThrough >= options.windowEndUtc) {
                await client.query("COMMIT");
                return { rowCount: 0, seconds: 0, heartbeatCount: 0 };
            }
            await client.query(CLASSPILOT_USAGE_ROLLUP_DELETE_SQL, [options.schoolId, options.day.date]);
            const result = await client.query(CLASSPILOT_USAGE_ROLLUP_INSERT_SQL, [
                options.schoolId,
                utcTimestampForSql(options.day.dayStartUtc),
                utcTimestampForSql(options.windowEndUtc),
                options.day.date,
                classpilotUsageExclusionsJson(options.exclusions),
            ]);
            // Aggregate-change triggers invalidate prior coverage. Restore it only
            // after a successful insert, including the successful empty-day case.
            await client.query(CLASSPILOT_USAGE_ROLLUP_COMPLETE_SQL, [
                options.schoolId, options.day.date, options.day.dayStartUtc.toISOString(),
                options.day.dayEndUtc.toISOString(), options.windowEndUtc.toISOString(),
                options.windowEndUtc >= options.day.dayEndUtc,
            ]);
            await client.query("COMMIT");
            const row = result.rows[0] ?? {};
            return {
                rowCount: Number(row.row_count ?? 0),
                seconds: Number(row.seconds ?? 0),
                heartbeatCount: Number(row.heartbeat_count ?? 0),
            };
        }
        catch (error) {
            await client.query("ROLLBACK").catch(() => { broken = true; });
            throw error;
        }
    }
    finally {
        client.release(broken);
    }
}
async function loadTrackingEvents(pool, schoolId, windowStart, windowEnd) {
    const result = await pool.query(CLASSPILOT_USAGE_ROLLUP_TRACKING_EVENTS_SQL, [
        schoolId,
        windowStart.toISOString(),
        windowEnd.toISOString(),
    ]);
    return result.rows.flatMap((row) => {
        const occurredAt = asDate(row.occurred_at);
        return occurredAt && typeof row.student_id === "string"
            ? [{
                    studentId: row.student_id,
                    eventType: String(row.event_type ?? ""),
                    origin: String(row.origin ?? ""),
                    occurredAt,
                    metadata: row.metadata,
                }]
            : [];
    });
}
async function hasHeartbeatsSinceLastRollup(pool, schoolId, day, windowEndUtc) {
    const last = await pool.query(CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL, [schoolId, day.date]);
    const processedThrough = asDate(last.rows[0]?.processed_through);
    // Absence is not a successful empty computation: establish coverage once,
    // even when no heartbeat exists. Computation time may be much later than the
    // input cutoff while a school waits behind other work.
    if (!processedThrough)
        return true;
    const since = new Date(Math.max(day.dayStartUtc.getTime(), processedThrough.getTime() - RECOMPUTE_LOOKBACK_MS));
    if (since >= windowEndUtc)
        return false;
    const changed = await pool.query(CLASSPILOT_USAGE_ROLLUP_CHANGED_SQL, [
        schoolId,
        utcTimestampForSql(since),
        utcTimestampForSql(windowEndUtc),
    ]);
    return changed.rows[0]?.changed === true;
}
/**
 * One hourly pass. Finalizations of yesterday are queued before any of
 * today's recomputes, so the time-critical work (a finished day must be
 * captured before the :30 purge reaches it) always runs first, and the budget
 * only ever defers today's refresh or a finalization that a later hour may
 * still perform while the day is inside the horizon.
 */
export async function runClasspilotUsageRollup(options) {
    const clock = options.clock ?? (() => new Date());
    const outcome = {
        schools: options.schools.length,
        finalizedDays: 0,
        recomputedDays: 0,
        unchangedDays: 0,
        retentionSkippedDays: 0,
        deferredDays: 0,
        failedSchools: 0,
        rowCount: 0,
        budgetExhausted: false,
    };
    const failed = new Set();
    const contexts = new Map();
    const contextFor = (school) => {
        let context = contexts.get(school.id);
        if (!context) {
            context = (async () => {
                const settings = await options.pool.query(CLASSPILOT_USAGE_ROLLUP_SETTINGS_SQL, [school.id]);
                const row = settings.rows[0];
                return {
                    school,
                    days: classpilotUsageRollupDays(options.now, school.timeZone),
                    horizon: classpilotUsageRetentionHorizon({
                        now: options.now,
                        retentionDays: parseClasspilotRetentionDays(row?.retention_hours),
                        lastPurgeFinishedAt: options.lastPurgeFinishedAt,
                    }),
                    trackingPolicy: classpilotUsageTrackingPolicy(row, school.timeZone),
                };
            })();
            contexts.set(school.id, context);
        }
        return context;
    };
    const rewrite = async (context, day, windowEndUtc) => {
        const trackingEvents = await loadTrackingEvents(options.pool, context.school.id, day.dayStartUtc, windowEndUtc);
        const result = await rollupClasspilotUsageDay(options.pool, {
            schoolId: context.school.id,
            day,
            windowEndUtc,
            exclusions: classpilotUsageExclusions({
                trackingPolicy: context.trackingPolicy,
                trackingEvents,
                windowStart: day.dayStartUtc,
                windowEnd: windowEndUtc,
            }),
        });
        outcome.recomputedDays += 1;
        outcome.rowCount += result.rowCount;
    };
    const tasks = [
        ...options.schools.map((school) => ({ school, kind: "finalize" })),
        ...options.schools.map((school) => ({ school, kind: "today" })),
    ];
    const runTask = async (task) => {
        const context = await contextFor(task.school);
        if (task.kind === "finalize") {
            const day = context.days.yesterday;
            // Redis is only a cache. Pre-ledger or invalidated cache entries cannot
            // assert a day was computed, and failed/skipped work is never completion.
            const coverage = await options.pool.query(CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL, [task.school.id, day.date]);
            if (coverage.rows[0]?.is_final === true)
                return;
            if (day.dayStartUtc < context.horizon) {
                // Partly purged already: keep the rows computed while it was today.
                outcome.retentionSkippedDays += 1;
                return;
            }
            await rewrite(context, day, day.dayEndUtc);
            outcome.finalizedDays += 1;
            await options.markers.markComplete(task.school.id, day.date);
            return;
        }
        const day = context.days.today;
        if (day.dayStartUtc < context.horizon) {
            outcome.retentionSkippedDays += 1;
            return;
        }
        const windowEndUtc = new Date(Math.min(day.dayEndUtc.getTime(), options.now.getTime()));
        if (!(await hasHeartbeatsSinceLastRollup(options.pool, task.school.id, day, windowEndUtc))) {
            outcome.unchangedDays += 1;
            return;
        }
        await rewrite(context, day, windowEndUtc);
    };
    let next = 0;
    const workers = Array.from({ length: Math.max(1, Math.min(options.concurrency ?? DEFAULT_CONCURRENCY, tasks.length)) }, async () => {
        while (next < tasks.length) {
            if (clock() >= options.deadline) {
                if (!outcome.budgetExhausted) {
                    outcome.budgetExhausted = true;
                    outcome.deferredDays += tasks.length - next;
                    next = tasks.length;
                }
                return;
            }
            const task = tasks[next++];
            try {
                await runTask(task);
            }
            catch (error) {
                failed.add(task.school.id);
                options.onSchoolError?.(error, task.school.id);
            }
        }
    });
    await Promise.all(workers);
    outcome.failedSchools = failed.size;
    return outcome;
}
const CLASSPILOT_USAGE_ROLLUP_METRIC_NAMES = [
    "UsageRollupFailedSchools",
    "UsageRollupDeferredDays",
];
/**
 * CloudWatch EMF record for one run, or null when there is nothing to publish.
 * Nonzero-only, like the daily rollup: the classpilot_usage_rollup log line
 * already carries every counter, zeros included.
 */
export function classpilotUsageRollupMetricRecord(counts, options) {
    const values = {};
    if (counts.failedSchools > 0)
        values.UsageRollupFailedSchools = counts.failedSchools;
    if (counts.deferredDays > 0)
        values.UsageRollupDeferredDays = counts.deferredDays;
    const names = CLASSPILOT_USAGE_ROLLUP_METRIC_NAMES.filter((name) => values[name] !== undefined);
    if (names.length === 0)
        return null;
    return {
        _aws: {
            Timestamp: options.timestamp,
            CloudWatchMetrics: [{
                    Namespace: "SchoolPilot/ClassPilot",
                    Dimensions: [["Environment"]],
                    Metrics: names.map((name) => ({ Name: name, Unit: "Count" })),
                }],
        },
        Environment: options.environment,
        ...values,
    };
}
