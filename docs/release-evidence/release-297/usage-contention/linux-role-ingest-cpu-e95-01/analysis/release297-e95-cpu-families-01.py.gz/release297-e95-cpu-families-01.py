from pathlib import Path
import json,collections,hashlib,os
root=Path(os.environ['TEMP']);raw=root/'release297-role-ingest-cpu-e95-restored-02';out=root/'release297-e95-cpu-analysis-01'
p=json.loads((raw/'api.cpuprofile').read_text());m=json.loads((raw/'usage-scale.json').read_text());phase=m['phases'][0];lo=phase['api']['measurementStartedHrtimeMicroseconds'];hi=phase['api']['snapshotHrtimeMicroseconds'];nodes={n['id']:n for n in p['nodes']};parents={c:n['id'] for n in p['nodes']for c in n.get('children',[])}
def frame(i):
 f=nodes[i]['callFrame'];return(f['functionName']or'(anonymous)',f['url'].replace('file://',''),f['lineNumber']+1)
def matches(k):
 name,url,line=k;d='/drizzle-orm/'in url;pg='/node_modules/pg' in url
 return {'ormCompilation':d and name in ['sqlToQuery','toQuery','buildQueryFromSourceParams','buildSelectQuery','orderSelectedFields','prepareFields'], 'ormAstConstruction':d and name in ['sql','SQL','StringChunk','Param','PgSelectBuilder','PgSelectBase'], 'ormMapping':d and name in ['mapResultRow','mapFromDriverValue'],'pgRowDecoding':pg and name in ['addFields','parseRow','parseDataRowMessage','parseField','handleDataRow'], 'parameterEncoding':pg and name in ['prepareValue','prepareObject','writeValues','bind','serialize'], 'asyncHooks':('async_hooks'in url or 'async_context_frame'in url), 'microtasks':name in ['runMicrotasks','processTicksAndRejections'], 'cryptoJwtAuth':('crypto'in url or any(x in url for x in ['/jsonwebtoken/','/jws/','/jwa/','/middleware/authenticate','/middleware/deviceAuth','/middleware/studentAuth'])), 'rawAuthorityFences':name in ['hasExactClasspilotTelemetryBinding','assertClasspilotHeartbeatDeliveryCurrent','publishForeground'] and '/app/dist/services/storage.js'in url, 'telemetry':any(x in url for x in ['/realtime/ws-redis.js','/services/classpilotRealtimeStatus.js','/services/heartbeatTileCache.js']), 'instrumentation':any(x in url for x in ['/services/usageCapacityDiagnostics.js','/release-enabled-instrumentation.mjs'])}
selftime=collections.Counter();union=collections.Counter();nativeparents=collections.Counter();t=p['startTime'];latest=t
for i,dt in zip(p['samples'],p['timeDeltas']):
 end=t+dt;w=max(0,min(end,hi)-max(t,latest,lo));latest=max(latest,end);t=end
 if not w:continue
 k=frame(i);stack=[];j=i
 while j:stack.append(frame(j));j=parents.get(j)
 for g,b in matches(k).items():
  if b:selftime[g]+=w
 for g in matches(k):
  if any(matches(f)[g]for f in stack):union[g]+=w
 if k[0]in['writev','writeBuffer']:
  transport=next((f for f in stack if any(x in f[1] for x in ['/node_modules/pg/','/node_modules/ioredis/','/node_modules/ws/'])),None)
  nativeparents[(k[0],transport)]+=w
ops={}
for name,v in phase['api']['operations']['operations'].items():
 times={k:{x:row[x] for x in ['count','totalMs','maxMs']}for k,row in v['timings'].items()};
 if times['holdMs']['count'] or v['counters']['checkoutFailure']:ops[name]={'counters':v['counters'],'timings':times}
waits=collections.Counter()
for s in phase['pgWaitSamples']:
 for row in s['rows']:
  if row['role']=='usage_release_api':waits[(row['state'],row['wait_type'],row['wait_event'])]+=row['count']
result={'source':m['sourceRevision'],'profileSha256':hashlib.sha256((raw/'api.cpuprofile').read_bytes()).hexdigest(),'window':{'start':lo,'end':hi,'wallMs':(hi-lo)/1000},'families':{g:{'selfMs':selftime[g]/1000,'inclusiveUnionMs':union[g]/1000}for g in sorted(union)},'nativeWritesByNearestTransport':[{'native':k[0],'transportFrame':k[1],'sampledMs':v/1000}for k,v in nativeparents.most_common()],'operations':ops,'apiWaitSampleCount':len(phase['pgWaitSamples']),'apiWaitSummedObservers':[{'state':k[0],'type':k[1],'event':k[2],'count':v}for k,v in waits.most_common()],'postgresPressureDelta':phase['postgresPressure']['delta'],'notes':['Each family union counts a sample once within that family; families overlap.','Native writes and async callbacks cannot be assumed eliminable or exclusively database/server CPU.','PG observer tallies are summed concurrent sampled waiters, not elapsed durations.','SQL timing spans driver scheduling, network and database waits; do not interpret as SQL server CPU.']}
(out/'families-and-operations.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'families':result['families'],'nativeWrites':result['nativeWritesByNearestTransport'],'waits':result['apiWaitSummedObservers']},indent=2))
