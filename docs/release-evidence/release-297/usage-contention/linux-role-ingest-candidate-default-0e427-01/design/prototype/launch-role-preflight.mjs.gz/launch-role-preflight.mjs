// Entry point is inert until the caller supplies a separately reviewed binding
// with allowLocalRolePreflight=true. It never builds/pushes images or seeds DBs.
import assert from 'node:assert/strict';import {readFileSync,writeFileSync,existsSync} from 'node:fs';import {createHash} from 'node:crypto';import {resolve,relative,isAbsolute,sep,join} from 'node:path';import {tmpdir} from 'node:os';import {pathToFileURL} from 'node:url';
import {createDockerHostAdapter} from './docker-host-adapter.mjs';import {createHostFileIo,assertDisjointControlAndEvidence} from './host-file-io.mjs';import {runRoleContainers} from './host-orchestrator.mjs';import {rolePlan} from './role-plan.mjs';
import {fileURLToPath} from 'node:url';import {makeRoleEnvironment,inheritWorkloadContract} from './role-environment.mjs';
const sha=value=>createHash('sha256').update(value).digest('hex');
export async function launch({docker,endpoint,bindingFile,run,pgContainerId,evidenceDirectory,controlDirectory,environment=process.env,mode='startup'}){
 const binding=JSON.parse(readFileSync(bindingFile,'utf8'));
 assert.equal(binding.runtimeFidelity.profile,'release-enabled-linux-role-ingest-candidate-default-v1');
 assert.equal(binding.runtimeFidelity.applicationChanges,0);
 assert.equal(binding.runtimeFidelity.harnessImageChanged,false);
 const preloader=fileURLToPath(new URL('./runtime-fidelity.mjs',import.meta.url));
 assert.equal(sha(readFileSync(preloader)),binding.runtimeFidelity.preloaderSha256);
 for(const row of binding.runtimeFidelity.hostFiles) assert.equal(sha(readFileSync(new URL(row.file,import.meta.url))),row.sha256);
assert.equal(binding.allowLocalRolePreflight,true);assert.equal(binding.resourceAcceptance,false);assert.equal(binding.prototypeChecksPassed,true);assert.ok(['startup','combined'].includes(mode));assert.ok(binding.allowedModes.includes(mode));
 assertDisjointControlAndEvidence(controlDirectory,evidenceDirectory);
 for(const path of [evidenceDirectory,controlDirectory]){const below=relative(resolve(tmpdir()),resolve(path));assert.ok(below&&below!=='..'&&!below.startsWith(`..${sep}`)&&!isAbsolute(below),'Prototype evidence/control must remain within local temp');}
 const modules={};for(const [name,entry]of Object.entries(binding.contractModules)){assert.ok(['profile','offering','postgres'].includes(name));assert.equal(sha(readFileSync(entry.path)),entry.sha256);modules[name]=await import(pathToFileURL(entry.path));}
 assert.deepEqual(Object.keys(modules).sort(),['offering','postgres','profile']);
 const adapter=createDockerHostAdapter({docker,endpoint,environment,evidenceDirectory,receiptDirectory:join(controlDirectory,'host-receipts')});
 const image=await adapter.inspectImage(binding.roleImageId);assert.equal(image.Id,binding.runtimeConfigDigest);assert.equal(image.Os,'linux');assert.equal(image.Architecture,'amd64');assert.equal(image.Config.Labels['org.opencontainers.image.revision'],binding.applicationSource);assert.equal(image.Config.Labels['codex.usage-role.prototype'],'unvalidated');
 assert.equal((image.Config.Env??[]).some(value=>value.startsWith('NODE_OPTIONS=')),false);
 const apiCpuProfile=environment.USAGE_RELEASE_CPU_PROFILE==='true';
 assert.equal(apiCpuProfile,false);assert.equal(environment.USAGE_RELEASE_PHASE,'ingest');
 if(apiCpuProfile){assert.equal(mode,'combined');assert.equal(environment.USAGE_RELEASE_PHASE,'ingest');assert.equal(environment.USAGE_RELEASE_DIAGNOSTIC,'true');writeFileSync(join(evidenceDirectory,'api.cpuprofile'),'',{flag:'wx'});}
 const plans=['coordinator','api','worker','generator'].map(role=>{const env=makeRoleEnvironment({role,run,source:binding.applicationSource,environment,enabledReleaseEnvironment:modules.profile.enabledReleaseEnvironment,pgApplicationNames:modules.postgres.RELEASE_PG_APPLICATION_NAMES});const plan=rolePlan({role,run,source:binding.applicationSource,imageId:binding.roleImageId,pgContainerId,evidenceDirectory:resolve(evidenceDirectory),controlDirectory:resolve(controlDirectory),environmentKeys:Object.keys(env),environment:env,imageEnvironment:image.Config.Env,apiCpuProfile});plan.runtimeConfigDigest=image.Id;return plan;});
 const path=join(evidenceDirectory,'role-runtime-plan.json');assert.equal(existsSync(path),false);writeFileSync(path,JSON.stringify({schemaVersion:1,mode,outerProfile:binding.runtimeFidelity.profile,runtimeFidelity:binding.runtimeFidelity,roles:plans,applicationSource:binding.applicationSource,runtimeSha256:binding.runtimeSha256,bindingSha256:sha(readFileSync(bindingFile)),workload:inheritWorkloadContract(modules.profile.RELEASE_ENABLED_PROFILE,modules.offering.OPEN_LOOP_HEARTBEATS),resourceAcceptance:false},null,2)+'\n',{flag:'wx'});
 return runRoleContainers({adapter,io:createHostFileIo({controlDirectory,evidenceDirectory}),plans,runtimeSha256:binding.runtimeSha256,harnessHashes:binding.harnessHashes,mode});
}
if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url){
 try{const[docker,endpoint,bindingFile,run,pgContainerId,evidenceDirectory,controlDirectory,mode='startup']=process.argv.slice(2);const result=await launch({docker,endpoint,bindingFile,run,pgContainerId,evidenceDirectory,controlDirectory,mode});if(!result.passed)process.exitCode=1;}catch{process.stderr.write('ROLE_PREFLIGHT_LAUNCH_FAILED\n');process.exitCode=1;}
}
