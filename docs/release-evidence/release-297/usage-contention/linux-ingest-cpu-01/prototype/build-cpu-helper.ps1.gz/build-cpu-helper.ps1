$ErrorActionPreference='Stop'
$here=$PSScriptRoot
$selectorNames=@('BUILDX_BUILDER','DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS')
$savedSelectors=@{}
foreach($selector in $selectorNames){$savedSelectors[$selector]=[Environment]::GetEnvironmentVariable($selector,'Process');[Environment]::SetEnvironmentVariable($selector,$null,'Process')}
try {
$build=Join-Path $env:TEMP 'release297-linux-helper-d649-ingest-cpu-build-01'
if(Test-Path -LiteralPath $build){throw 'Preserve prior attempt; new unique build output required.'}
New-Item -ItemType Directory -Path $build | Out-Null
$endpoint='npipe:////./pipe/dockerDesktopLinuxEngine'
$baseTag='schoolpilot-linux-diagnostic-local:d64923335206-04'
$expected='sha256:eeca91c130ddcda195f9317805ae39c4e56c3d08918fde79aadf60725a9a86f0'
$tag='schoolpilot-linux-ingest-cpu-local:d64923335206-01'
$before=(docker --host $endpoint image inspect $baseTag | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0 -or $before.Id -cne $expected){throw 'Exact local helper04 base mismatch.'}
[ordered]@{source='d6492333520608df1524c021999d9440a26149de'; base=$expected; tag=$tag; diagnosticOnly=$true; capacityAccepted=$false; buildStartedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content (Join-Path $build 'build-binding.json')
docker --host $endpoint build --builder default --pull=false --platform linux/amd64 --build-arg "DIAGNOSTIC_BASE=$baseTag@$expected" --label 'org.opencontainers.image.revision=d6492333520608df1524c021999d9440a26149de' --label 'codex.usage-linux.candidate=sha256:d4df2a07f1f92568f44de2d774b64f138d030d53af1c8055729eb79f53773c36' --label 'codex.usage-linux.profile=ingest-cpu-diagnostic-only' --tag $tag --iidfile (Join-Path $build 'image-id.txt') (Join-Path $here 'context') *> (Join-Path $build 'build.log')
$buildExit=$LASTEXITCODE
$after=(docker --host $endpoint image inspect $baseTag | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0 -or $after.Id -cne $expected){throw 'Exact base tag changed during local build.'}
if($buildExit -ne 0){throw 'CPU helper build failed; preserved log.'}
node (Join-Path $here 'bind-helper-image.mjs') (Join-Path $here 'context') $build (Join-Path $env:TEMP 'schoolpilot-image-scan-tNZuXu') (Join-Path $env:TEMP 'release297-linux-d649-host-02') *> (Join-Path $build 'runtime-proof.log')
if($LASTEXITCODE -ne 0){throw 'CPU helper runtime proof failed; preserved evidence.'}
Write-Output $build
} finally {
 foreach($selector in $selectorNames){[Environment]::SetEnvironmentVariable($selector,$savedSelectors[$selector],'Process')}
}
