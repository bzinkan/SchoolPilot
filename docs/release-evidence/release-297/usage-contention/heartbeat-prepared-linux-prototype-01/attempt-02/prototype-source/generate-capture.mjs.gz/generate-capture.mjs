import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const prior=path.join(process.env.TEMP,'release297-owned-pg-native-prototype-01');
const out=path.join(process.env.TEMP,'release297-owned-pg-linux-prototype-01');
const repo=path.join(process.env.TEMP,'release297-role-0e427-unprofiled-host-01');
const require=createRequire(repo+'/package.json'),ts=require('typescript');
const transpile=x=>ts.transpileModule(x,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
const source=fs.readFileSync(prior+'/canonical-capture.mjs','utf8');
const storage=fs.readFileSync(repo+'/src/services/storage.ts','utf8');
const entitlement=fs.readFileSync(repo+'/src/services/classpilotEntitlement.ts','utf8');
const screenshot=storage.slice(storage.indexOf('export async function getClasspilotScreenshotAuthorityProjection('),storage.indexOf('function classpilotScreenshotAuthorityMatches('));
const ent=entitlement.slice(entitlement.indexOf('export async function resolveClasspilotEntitlement('),entitlement.indexOf('export async function assertClasspilotEntitled('));
function initializer(source,name,occurrence=0){const tree=ts.createSourceFile('c.ts',source,ts.ScriptTarget.Latest,true),found=[];const visit=n=>{if(ts.isVariableDeclaration(n)&&n.name.getText(tree)===name&&n.initializer)found.push(n.initializer);ts.forEachChild(n,visit);};visit(tree);let n=found[occurrence];assert.ok(n,name);if(ts.isAwaitExpression(n))n=n.expression;return n.getText(tree);}
function func(source,name){const tree=ts.createSourceFile('c.ts',source,ts.ScriptTarget.Latest,true);let result;const visit=n=>{if(ts.isFunctionDeclaration(n)&&n.name?.text===name)result=n.getText(tree);ts.forEachChild(n,visit);};visit(tree);assert.ok(result,name);return result;}
function tagged(source,predicate=()=>true){const tree=ts.createSourceFile('c.ts',source,ts.ScriptTarget.Latest,true);let result;const visit=n=>{if(result)return;if(ts.isTaggedTemplateExpression(n)&&n.tag.getText(tree)==='sql'&&predicate(n.getText(tree))){result=n.getText(tree);return;}ts.forEachChild(n,visit);};visit(tree);assert.ok(result);return result;}
const selections={screenshot_session:initializer(screenshot,'[session]'),screenshot_control:initializer(screenshot,'[controlState]'),screenshot_candidate:initializer(screenshot,'[candidate]'),locked_school:initializer(ent,'schoolQuery')+'.for("share")',locked_license:initializer(ent,'licenseQuery')+'.for("share")',unlocked_entitlement:initializer(ent,'[school]')};
const raw={live_binding:tagged(func(storage,'hasExactClasspilotTelemetryBinding'),s=>s.includes('SELECT "student_sessions"."id"')),final_fence:tagged(func(storage,'assertClasspilotHeartbeatDeliveryCurrent')),foreground_fence:tagged(func(storage,'withClasspilotHeartbeatDeliveryAuthority'),s=>s.includes('SELECT 1 AS allowed')),owner_transaction:tagged(func(storage,'getClasspilotTelemetryOwnerProjectionAtClock'))};raw.owner_current=raw.owner_transaction;
const prelude='const bindingConditions=[eq(studentSessions.id, options.studentSessionId), eq(studentSessions.studentId, options.studentId), eq(studentSessions.deviceId, options.deviceId),currentStudentSessionAuthorityPredicate()]';
const h=x=>createHash('sha256').update(x).digest('hex');
let generated=`// Generated from exact 0e427 canonical source; extraction runs on host only.\nimport fs from 'node:fs';\nimport assert from 'node:assert/strict';\nimport {createHash} from 'node:crypto';\nimport * as orm from '/app/node_modules/drizzle-orm/index.js';\nimport * as core from '/app/node_modules/drizzle-orm/pg-core/index.js';\nimport {drizzle} from '/app/node_modules/drizzle-orm/node-postgres/index.js';\nimport * as schema from '/app/dist/schema/index.js';\nimport {currentStudentSessionAuthorityPredicate} from '/app/dist/services/classpilotStudentSessionAuthority.js';\nimport {compileFixedScalarQuery} from './fixedScalarQuery.mjs';\nconst repo='/app';\nconst sourceRepo='/source';\n`;
for(const file of ['src/services/storage.ts','src/services/classpilotEntitlement.ts'])generated+=`assert.equal(createHash('sha256').update(fs.readFileSync(sourceRepo+${JSON.stringify('/'+file)})).digest('hex'),${JSON.stringify(h(fs.readFileSync(repo+'/'+file)))});\n`;
generated+=`const bindings={...orm,...schema,currentStudentSessionAuthorityPredicate,LIVE_TEACHING_SESSION_MODE:'live'};\n`;
for(const [file,name] of [[entitlement,'classpilotEntitledSchoolPredicate'],[storage,'classpilotAuthorityClockSql']])generated+=`bindings.${name}=new Function(...Object.keys(bindings),${JSON.stringify(transpile(func(file,name).replace('export function','function'))+';return '+name)})(...Object.values(bindings));\n`;
generated+=`const builders={};\n`;
for(const [label,expression] of Object.entries(selections)){const code=transpile('const query='+expression+';')+';return query;';generated+=`{const run=new Function(...Object.keys(bindings),'dbInstance','options','schoolId','controlState',${JSON.stringify(code)});builders.${label}=(db,values)=>run(...Object.values(bindings),db,values,values.schoolId,{teachingSessionId:values.teachingSessionId});}\n`;}
generated+=source.slice(source.indexOf('const {studentSessions:ss'),source.indexOf('function functionText'));
generated+='const rawBuilders={};\n';
for(const [label,expression] of Object.entries(raw)){const code=transpile((label==='live_binding'?prelude:'')+';const result='+expression+';')+';return result;';generated+=`{const run=new Function(...Object.keys(bindings),'options','foreground','schoolId','studentId','clock',${JSON.stringify(code)});rawBuilders.${label}=values=>run(...Object.values(bindings),values,values,values.schoolId,values.studentId,values.clock);}\n`;}
generated+=source.slice(source.indexOf('for(const [label,build]'));
generated=generated.replace('placeholders, repo };','placeholders, repo, sourceRepo };');
fs.writeFileSync(out+'/canonical-capture.mjs',generated);
const helper=transpile(fs.readFileSync(out+'/fixedScalarQuery-source.ts','utf8')).replaceAll('from "drizzle-orm"','from "/app/node_modules/drizzle-orm/index.js"').replaceAll('from "drizzle-orm/pg-core"','from "/app/node_modules/drizzle-orm/pg-core/index.js"');fs.writeFileSync(out+'/fixedScalarQuery.mjs',helper);
fs.writeFileSync(out+'/capture-generation.json',JSON.stringify({source:'0e427e3ca9b82125e0bb8692176accad21f4f699',generatedSha256:h(generated),sourceBindings:['src/services/storage.ts','src/services/classpilotEntitlement.ts','dist/schema/index.js','dist/services/classpilotStudentSessionAuthority.js'].map(file=>({file,sha256:h(fs.readFileSync(repo+'/'+file))})),typescriptVersion:ts.version,generatedOnly:true,applicationChanges:0},null,2));
