import test from 'node:test';
import assert from 'node:assert/strict';
import {makeRoleEnvironment} from './role-environment.mjs';
import {rolePlan,POOL_LIMITS} from './role-plan.mjs';
const run='a'.repeat(12),source='b'.repeat(40),url=`<REDACTED_LOCAL_CONNECTION_URL>
const base={DATABASE_URL:url,ADMIN_DATABASE_URL:url,DATABASE_URL_PRIVILEGED:url,REDIS_URL:'<REDACTED_LOCAL_CONNECTION_URL>',NODE_ENV:'test',USAGE_LOCAL_SCALE:'1',USAGE_SOURCE_REVISION:source,USAGE_SCALE_CONTAINER:`schoolpilot-usage-scale-${run}`,USAGE_RELEASE_DIAGNOSTIC:'true',USAGE_RELEASE_CPU_PROFILE:'false',USAGE_RELEASE_PHASE:'ingest'};
const make=(role,extra={})=>makeRoleEnvironment({role,run,source,environment:{...base,...extra},enabledReleaseEnvironment:env=>({...env,DB_POOL_MAX:'16',SESSION_DB_POOL_MAX:'2',SCHEDULER_DB_POOL_MAX:'5',SCHEDULER_LOCK_POOL_MAX:'8'}),pgApplicationNames:{}});
test('unprofiled ingestion stays ingestion on every role; no CPU flags or writable profile file',()=>{
  for(const role of ['api','worker','generator','coordinator']){const env=make(role);assert.equal(env.USAGE_RELEASE_PHASE,'ingest');assert.equal(env.USAGE_RELEASE_CPU_PROFILE,'false');const plan=rolePlan({role,run,source,imageId:'sha256:'+'c'.repeat(64),pgContainerId:'d'.repeat(64),evidenceDirectory:'C:/owned/evidence',controlDirectory:'C:/owned/control',environmentKeys:Object.keys(env),environment:env,apiCpuProfile:false});assert.equal(plan.command.some(arg=>arg.startsWith('--cpu-prof')),false);assert.equal(plan.mounts.some(m=>m.Destination==='/evidence/api.cpuprofile'),false);if(role==='api')assert.equal(plan.mounts.find(m=>m.Destination==='/evidence').RW,false);assert.equal(plan.caps.nanoCpus,{api:1e9,worker:.5e9,generator:2e9,coordinator:.5e9}[role]);}
  assert.deepEqual(POOL_LIMITS,{api:16,session:2,worker:5,observer:2});
});
test('unsupported phases and missing/invalid explicit CPU mode fail closed',()=>{
  for(const phase of ['','reports','unknown',undefined])assert.throws(()=>make('api',{USAGE_RELEASE_PHASE:phase}));
  for(const cpu of ['','yes',undefined])assert.throws(()=>make('api',{USAGE_RELEASE_CPU_PROFILE:cpu}));
});
test('explicit combined and profiled-ingest modes retain closed historical semantics',()=>{
  assert.equal(make('api',{USAGE_RELEASE_PHASE:'combined'}).USAGE_RELEASE_PHASE,'combined');
  assert.equal(make('api',{USAGE_RELEASE_CPU_PROFILE:'true'}).USAGE_RELEASE_PHASE,'ingest');
  assert.throws(()=>make('api',{USAGE_RELEASE_PHASE:'combined',USAGE_RELEASE_CPU_PROFILE:'true'}));
});
