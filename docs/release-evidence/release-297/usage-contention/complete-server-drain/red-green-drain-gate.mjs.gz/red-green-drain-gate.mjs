import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { runInNewContext } from 'node:vm';
const root = process.cwd(), directory = dirname(process.argv[1]);
const source = readFileSync(resolve(root, 'scripts/load/usage/release-enabled-profile.test.mjs'), 'utf8');
const first = source.indexOf('function accepted() {'), last = source.indexOf("\ntest('release-enabled acceptance", first);
const fixture = runInNewContext(`(${source.slice(first, last).trim()})`, { RELEASE_DRAIN_OPERATIONS: (await import(pathToFileURL(resolve(root, 'scripts/load/usage/release-enabled-drain.mjs')))).RELEASE_DRAIN_OPERATIONS })();
fixture.phases[0].api.operations.operations.heartbeat_background.activeCheckouts = 3;
let modulePath = resolve(root, 'scripts/load/usage/release-enabled-profile.mjs');
if (process.argv[2] === 'baseline') {
  const baseline = execFileSync('git', ['show', '25ba868685fa4aa5010023b55f3705a5e525e6fd:scripts/load/usage/release-enabled-profile.mjs'], { cwd: root, encoding: 'utf8' });
  writeFileSync(resolve(directory, 'baseline-profile.original.mjs'), baseline);
  modulePath = resolve(directory, 'baseline-profile.executable.mjs');
  writeFileSync(modulePath, baseline.replace("'./cold-open-loop-profile.mjs'", JSON.stringify(pathToFileURL(resolve(root, 'scripts/load/usage/cold-open-loop-profile.mjs')).href)));
}
const { capacityAcceptance } = await import(pathToFileURL(modulePath));
const gates = capacityAcceptance(fixture), accepted = Object.values(gates).every(Boolean);
console.log(JSON.stringify({ source: process.argv[2], moduleSha256: createHash('sha256').update(readFileSync(modulePath)).digest('hex'), activeLeasesAfterHttpComplete: 3, accepted, serverDrained: gates.serverDrained }));
assert.equal(accepted, false, 'An HTTP-complete phase with three unreleased leases must fail acceptance');

