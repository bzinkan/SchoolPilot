$ErrorActionPreference='Stop'
$root='<WORKTREE>'
$out='<RAW_EVIDENCE>'
Set-Location -LiteralPath $root
function Snapshot {
  @(git ls-files src schoolpilot-app/src package.json package-lock.json tsconfig.json Dockerfile .dockerignore | ForEach-Object { [ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()} })
}
$before=Snapshot
$before | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'application-before.json') -Encoding utf8NoBOM
$beforeHead=(git rev-parse HEAD).Trim()
git apply --check (Join-Path $out 'runtime-security-clock-only.patch')
if($LASTEXITCODE -ne 0){throw 'Patch check failed'}
git apply (Join-Path $out 'runtime-security-clock-only.patch')
if($LASTEXITCODE -ne 0){throw 'Patch failed'}
$names=@('DATABASE_URL','DATABASE_URL_PRIVILEGED','ADMIN_DATABASE_URL','NODE_ENV','JWT_SECRET','SESSION_SECRET','STUDENT_TOKEN_SECRET','REDIS_URL','DOTENV_CONFIG_PATH','DOTENV_CONFIG_QUIET')
$saved=@{}; foreach($name in $names){$saved[$name]=[Environment]::GetEnvironmentVariable($name,'Process')}
$started=[DateTime]::UtcNow.ToString('o')
try {
  $env:DATABASE_URL='<REDACTED_CONNECTION_URL>'
  $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL; $env:ADMIN_DATABASE_URL=$env:DATABASE_URL
  $env:NODE_ENV='test';$env:JWT_SECRET='synthetic-runtime-clock-test-key-only';$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
  $env:REDIS_URL='';$env:DOTENV_CONFIG_PATH=Join-Path $out 'nonexistent-test-dotenv';$env:DOTENV_CONFIG_QUIET='true'
  node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-runtime-security-contract.test.ts *> (Join-Path $out 'runtime-security-after.log')
  $testExit=$LASTEXITCODE
} finally {
  foreach($name in $names){[Environment]::SetEnvironmentVariable($name,$saved[$name],'Process')}
}
$after=Snapshot
$after | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'application-after.json') -Encoding utf8NoBOM
$same=($before | ConvertTo-Json -Depth 6 -Compress) -ceq ($after | ConvertTo-Json -Depth 6 -Compress)
$result=[ordered]@{exitCode=$testExit;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');sourceHeadBefore=$beforeHead;sourceHeadAfter=(git rev-parse HEAD).Trim();applicationFiles=$before.Count;applicationBytesUnchanged=$same;command='node --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-runtime-security-contract.test.ts';configuration='Synthetic unreachable loopback DB URI for imports only; no dotenv, Redis, native fixture, or production access';testSha256=(Get-FileHash tests/classpilot-runtime-security-contract.test.ts).Hash.ToLowerInvariant();changedTrackedFiles=@(git diff --name-only)}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'runtime-security-after.json') -Encoding utf8NoBOM
$result | ConvertTo-Json -Depth 6
if(-not $same -or $testExit -ne 0){exit 1}
