import assert from 'node:assert/strict';
import {readFileSync,readdirSync,lstatSync,mkdirSync,writeFileSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp='<TEMP>',artifacts='C:/Users/zinka/.codex/artifacts';
const run=join(temp,'release297-role-diagnostic-8148-pressure-01');
const out=join(artifacts,'release297-diagnostic-8148-pressure-01-evidence');
const source='814844f344a45159152415b0fb6d7027f05b093e';
const sha=x=>createHash('sha256').update(x).digest('hex');
const read=file=>JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const metrics=read(join(run,'usage-scale.json')),plan=read(join(run,'run-plan.json'));
const validation=read(join(run,'validation-result.json')),custody=read(join(run,'receipt-manifest.json'));
const cleanup=read(join(run,'all-owned-role-fixtures-cleanup.json')),host=read(join(run,'role-host-result.json'));
const sampler=read(join(run,'resource-counter-series.json')),phase=metrics.phases[0];
assert.equal(plan.source,source);assert.equal(plan.run,'182ac78636d4');assert.equal(plan.mode,'diagnostic');assert.equal(plan.diagnosticOnly,true);
assert.equal(metrics.capacityAccepted,false);assert.equal(validation.capacityAccepted,false);assert.equal(metrics.correctness,undefined);
assert.equal(metrics.phases.length,1);assert.equal(phase.serverDrain.api.complete,false);assert.equal(phase.serverDrain.api.abortedResponses,1);
assert.equal(phase.serverDrain.api.failure,'DRAIN_UNVERIFIABLE_ABORT');assert.equal(phase.persistedAfter,undefined);
assert.equal(sampler.captureComplete,false);assert.equal(sampler.hostObserverActiveChildren,0);assert.equal(sampler.captures.length,6);
for(const row of sampler.captures)assert.equal(row.samples,0);
assert.equal(Object.keys(custody.records).length,13);for(const item of Object.values(custody.records))assert.equal(sha(readFileSync(join(run,item.file))),item.sha256);
assert.equal(validation.receiptManifestSha256,sha(readFileSync(join(run,'receipt-manifest.json'))));
assert.equal(cleanup.cleanupPassed,true);assert.equal(cleanup.roles.roles.length,4);assert.equal(cleanup.fixtures.resources.length,2);
for(const row of [...cleanup.roles.roles,...cleanup.fixtures.resources]){assert.equal(row.cleanupPassed,true);assert.equal(row.confirmedAbsent,true);}
assert.ok(cleanup.fixtures.resources.find(x=>x.role==='postgres').volumes.every(x=>x.confirmedAbsent));
assert.equal(existsSync(out),false);mkdirSync(out);
const files=[],hashOnly=[],emptyPrivateFiles=[];
const safePath=x=>x.replaceAll('\\','/').replace(temp,'<TEMP>');
const scrubText=x=>x.replace(/(?:postgres(?:ql)?|rediss?):\/\/[^\s"'<>]+/gi,'<REDACTED_CONNECTION_URL>')
 .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_TOKEN>')
 .replace(/\b(?:ghp|ghs|github_pat)_[A-Za-z0-9_]+\b/g,'<REDACTED_TOKEN>')
 .replace(/C:[\\/]+Users[\\/]+zinka[\\/]+AppData[\\/]+Local[\\/]+Temp/gi,'<TEMP>');
function scrub(value,key=''){
 if(/(?:password|secret|cookie|authorization|credentials|^nonce$|^token$|Token$|_URL$)/i.test(key))return '<REDACTED>';
 if(typeof value==='string'){if(key.endsWith('Raw')){try{return JSON.stringify(scrub(JSON.parse(value)));}catch{}}return scrubText(value);}
 if(Array.isArray(value))return value.map(x=>scrub(x));
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,scrub(v,k)]));return value;
}
function exclude(path,reason){const raw=readFileSync(path),item={path:safePath(path),bytes:raw.length,sha256:sha(raw),reason};(raw.length?hashOnly:emptyPrivateFiles).push(item);}
function add(path,name){
 assert.equal(lstatSync(path).isSymbolicLink(),false);const raw=readFileSync(path),text=raw.toString('utf8');assert.ok(Buffer.from(text).equals(raw));
 let value;try{value=JSON.parse(text.replace(/^\uFEFF/,''));}catch{}
 const safe=Buffer.from(value!==undefined?JSON.stringify(scrub(value),null,2)+'\n':scrubText(text));
 assert.equal(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b|SCRAM-SHA-256\$\d+:/.test(safe.toString()),false,name);
 const gz=gzipSync(safe,{level:6}),packetPath=name+'.gz';mkdirSync(dirname(join(out,packetPath)),{recursive:true});writeFileSync(join(out,packetPath),gz,{flag:'wx'});
 files.push({path:packetPath,originalPath:safePath(path),originalBytes:raw.length,originalSha256:sha(raw),sanitizedSha256:sha(safe),gzipSha256:sha(gz)});
}
function walk(directory,prefix,privateOnly=false){for(const e of readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){assert.equal(e.isSymbolicLink(),false);const path=join(directory,e.name);if(e.isDirectory())walk(path,prefix+'/'+e.name,privateOnly);else if(privateOnly||e.name==='cold-fixture-state.json'||/\.private\.|\.env$/.test(e.name))exclude(path,'Private synthetic data/env/credential contents excluded.');else if(['reference-rendered-schema.sql','restored-schema.sql'].includes(e.name))exclude(path,'Unchanged full schema text omitted from minimal packet; original hash retained and schema comparison receipt included.');else add(path,prefix+'/'+e.name);}}
walk(run,'diagnostic');walk(join(temp,'release297-role-diagnostic-8148-pressure-private-01'),'private',true);
walk(join(temp,'release297-role-diagnostic-8148-pressure-config-01'),'config');walk(join(temp,'release297-role-counter-sampler-02'),'sampler02');
for(const name of ['release297-publish-diagnostic-8148-pressure-01.mjs','release297-role-diagnostic-8148-pressure-01-console.log','release297-role-diagnostic-8148-pressure-01.predeclared-plan.json','release297-role-counter-sampler-182ac78636d4-console.log','release297-role-counter-sampler-config-182ac78636d4.json','release297-role-counter-sampler-syntax-failure-01.json'])add(join(temp,name),'commands/'+name);
walk(join(temp,'release297-ci-63b2-status-02'),'ci-snapshot');walk(join(temp,'release297-ci-63b2-gitleaks-rerun-01'),'ci-rerun-request');
add(join(temp,'release297-ci-63b2-gitleaks-private-01/classification.json'),'ci-original-service-failure.json');
add(join(temp,'release297-ci-63b2-gitleaks-private-01/fetch-metadata.json'),'ci-original-private-log-binding.json');
exclude(join(temp,'release297-ci-63b2-gitleaks-private-01/failed-job.private.log'),'Original private failure log retained unchanged; safe classification archived.');
add(fileURLToPath(import.meta.url),'archive-script.mjs');
const sampler03=join(temp,'release297-role-counter-sampler-03/manifest.json');const followup=read(sampler03);
const references={existingSourceHelperSnapshotPacket:{directory:join(artifacts,'release297-capacity-8148-attempt-01-evidence'),manifestSha256:'b2524712a34697b906b4efaa36413def9fbc55bc049d36125add55fc5178f3ac'},sampler03:{manifestPath:safePath(sampler03),manifestSha256:sha(readFileSync(sampler03)),sixOwnerSamplerLaunched:followup.sixOwnerSamplerLaunched,nativeProof:followup.nativeProof,notRetroactiveEvidenceForThisRun:true}};
const summary={schemaVersion:1,source,run:plan.run,mode:plan.mode,diagnosticOnly:true,capacityAccepted:false,acceptedRunCount:0,receiptManifestSha256:validation.receiptManifestSha256,all13OriginalReceiptHashesVerified:true,
 startedAt:metrics.startedAt,cleanupFinishedAt:cleanup.finishedAt,heartbeats:phase.traffic.heartbeats,heartbeatStatuses:phase.traffic.heartbeatStatuses,
 reports:{actual:phase.traffic.reports.length,successful:phase.traffic.reports.filter(x=>x.status===200&&x.correct&&x.durationMs<20000).length},workers:phase.workers,
 api:{cpuMicroseconds:phase.api.cpuMicroseconds,eventLoop:phase.api.eventLoop,acquisitions:phase.api.database.acquisitions},serverDrain:phase.serverDrain,
 failure:metrics.failure,childCleanupFailure:metrics.childCleanupFailure,postLoadCurrentDayCorrectness:'not run',postLoadCsvCorrectness:'not run',persistedAfterCount:'not collected',
 roleExits:host.roles.map(x=>({role:x.role,exit:x.exit})),cleanup,validation,
 sampler:{captureComplete:false,captures:sampler.captures.map(x=>({role:x.role,samples:x.samples,exit:x.exit})),hostObserverActiveChildren:sampler.hostObserverActiveChildren,noCounterEvidence:true},
 finalSourceReceipt:read(join(run,'final-source-receipt.json')),finalCiSnapshot:read(join(temp,'release297-ci-63b2-status-02/summary.json')),references,
 limitations:['Failed diagnostic, permanently ineligible for capacity acceptance; no campaign attempt added.','API drain was physically idle but unverifiable because one response aborted. Current-day rollup and CSV correctness were not run after that failure.','API required forced termination (exit143); other owned resources were removed, including recorded PostgreSQL volume. Cleanup success does not imply clean role exit or accepted workload.','Sampler02 produced zero numeric samples; subsequent tiny sampler03 proof cannot repair the missing counters for this run.','Synthetic4CPU/4GiB PostgreSQL differs from dated production db.t4g.medium; no production headroom claim.','Only safe evidence copies are archived; original raw receipt hashes remain binding. No application/source/helper changes, fixture retries or resource adjustments.']};
const summaryRaw=JSON.stringify(scrub(summary),null,2)+'\n';writeFileSync(join(out,'summary.json'),summaryRaw,{flag:'wx'});
const privacyRaw=JSON.stringify({schemaVersion:1,privateDumpCopied:false,environmentFilesCopied:false,privateStateCopied:false,privateTokenValuesCopied:false,privateKeyAccessKeyScramScanPassed:true,sourceOrHelperTreesDuplicated:false,records:files.length,hashOnly:hashOnly.length,emptyPrivateFiles:emptyPrivateFiles.length},null,2)+'\n';writeFileSync(join(out,'privacy-review.json'),privacyRaw,{flag:'wx'});
for(const item of files){const gz=readFileSync(join(out,item.path));assert.equal(sha(gz),item.gzipSha256);assert.equal(sha(gunzipSync(gz)),item.sanitizedSha256);assert.equal(sha(readFileSync(item.originalPath.replace('<TEMP>',temp))),item.originalSha256);}
const manifest={schemaVersion:1,createdAt:new Date().toISOString(),source,run:plan.run,diagnosticOnly:true,capacityAccepted:false,summarySha256:sha(summaryRaw),privacyReviewSha256:sha(privacyRaw),files,hashOnly,emptyPrivateFiles,references,limitations:summary.limitations};
const raw=JSON.stringify(manifest,null,2)+'\n';writeFileSync(join(out,'manifest.json'),raw,{flag:'wx'});console.log(JSON.stringify({out,records:files.length,hashOnly:hashOnly.length,manifestSha256:sha(raw),summarySha256:sha(summaryRaw)}));
