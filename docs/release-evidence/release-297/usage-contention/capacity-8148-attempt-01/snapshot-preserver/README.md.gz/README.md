# New54 snapshot capture and explicit abort (not executed)

Use only after final source, clean self-contained LF host checkout, supported candidate image and role helper are built and hash-verified. The existing e95 snapshot stays historical and untouched. All paths below must be NEW owned output/artifact paths; no credentials belong on the command line or in safe evidence.

1. Start the final-source role runner, diagnostic combined, with the clean host checkout, exact helper binding and new output directory:
   `pwsh -NoProfile -File <final-source>/scripts/load/usage/roles/run-role-scale.ps1 -SourceRepository <clean-host> -DiagnosticImageManifest <binding> -OutputDirectory <new-output> -Phase combined`
2. At measurement-ready.json, root holds measurement-go. Verify the ready source/image/binding/run and no active preparation clients. Capture with:
   `node preserve-prepared-schema54.mjs <local-docker-executable> <new-output> <NEW-permanent-private-snapshot-directory> <clean-host>`
   This is the exact reviewed capture used for e95, with its migration-count assertion changed53→54 only. It retains source cleanliness before/after, exact owned PG/caps, read-only pg_dump, full9-file hashes and private credential warnings. No source or snapshot timestamps are rewritten.
3. Independently verify manifest hash plus ready hash, then root publishes the exact abort:
   `node publish-snapshot-abort.mjs <new-output> <private-snapshot-directory> <manifest-sha256> <ready-sha256> <binding-file> <clean-host>`
   Publisher rehashes every bound private artifact without printing contents, checks same source/run/helper and new54 contract, verifies the source-bound gate module, then atomically links a fully fsync'd exclusive marker. Both go+abort are forbidden. Publication itself is not cleanup.
4. Await named ABORTED_BEFORE_MEASUREMENT and the existing owner finally. Verify the matching abort receipt, no release receipt/no roles or offered traffic, exact PG container AND original anonymous-volume absence, restored host environment and no owned process. Retain the aborted preparation/logs as failed preparation, never an accepted workload. Root must not register this diagnostic seed-only job as a successful candidate attempt.
5. A subsequent candidate restores this newly captured immutable same-source54 snapshot into fresh ownership, runs separate restricted-role/function/grant/schema/data/clock validation + ANALYZE, closes clients, and performs a fresh nonce-bound restart. The capture alone is not restore validation or capacity evidence.

The publisher was syntax-checked only in this preparation packet. Before use, root reviews exact hashes and supplies actual final-source paths. No Docker, database, capture, marker publication or workload has been executed by these preparation commands.
