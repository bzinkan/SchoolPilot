$ErrorActionPreference='Stop'
$root='<USER_HOME>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$container='schoolpilot-usage-scale-'+$run
$database='schoolpilot_redesign_usage_scale_'+$run
$owner='control_owner_'+$run;$app='control_app_'+$run
$password=[guid]::NewGuid().ToString('N');$appPassword=[guid]::NewGuid().ToString('N')
$out=Join-Path $env:TEMP ('release297-control-preparation-native-'+$run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $root
foreach($n in @('DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS')){[Environment]::SetEnvironmentVariable($n,$null,'Process')}
$created=$false
try {
 docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec schoolpilot-db pg_dump -U schoolpilot -d schoolpilot_redesign_usage_release297_20261002 --schema-only --no-owner --no-privileges | Set-Content -LiteralPath (Join-Path $out 'schema.sql') -Encoding utf8
 if($LASTEXITCODE -ne 0){throw 'Schema export failed'}
 $image=(docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect schoolpilot-db --format '{{.Image}}').Trim()
 docker --host npipe:////./pipe/dockerDesktopLinuxEngine run --detach --name $container --label "codex.control-native=$run" --cpus 2 --memory 2g --publish '127.0.0.1:5437:5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
 if($LASTEXITCODE -ne 0){throw 'Fixture create failed'};$created=$true
 $ready=$false
 for($attempt=0;$attempt -lt 40;$attempt++){docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250}
 if(-not $ready){throw 'Fixture not ready'}
 Get-Content -LiteralPath (Join-Path $out 'schema.sql') -Raw | docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
 if($LASTEXITCODE -ne 0){throw 'Schema restore failed'}
 "CREATE ROLE $app LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$appPassword'; GRANT USAGE ON SCHEMA public TO $app; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $app;" | docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'role.log')
 if($LASTEXITCODE -ne 0){throw 'Role grants failed'}
 $env:DATABASE_URL="[REDACTED_DATABASE_URL]";$env:ADMIN_DATABASE_URL="[REDACTED_DATABASE_URL]";$env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL
 $env:JWT_SECRET=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
 $env:NODE_ENV='test';$env:REDIS_URL='';$env:RLS_GUC_ENABLED='true';$env:SCHEDULER_ENABLED='false'
 $registry=Get-Content src/config/rlsRegistry.json -Raw|ConvertFrom-Json;$env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
 $env:USAGE_SCALE_RLS_INVENTORY='classpilotPrivateChatLifecyclePostExpand';$env:USAGE_LOCAL_SCALE='1';$env:USAGE_SCALE_CONTAINER=$container;$env:USAGE_SCALE_COLD_PHASE='prepare';$env:USAGE_RELEASE_PHASE='preflight';$env:USAGE_SOURCE_REVISION=(git rev-parse HEAD).Trim()
 $env:CONTROL_NATIVE_RESULT=Join-Path $out 'native-result.json';$env:DOTENV_CONFIG_PATH=Join-Path $out 'absent.env';$env:DOTENV_CONFIG_QUIET='true'
 $previousPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
 node --max-old-space-size=512 (Join-Path $env:TEMP 'release297-control-preparation-native.mjs') *> (Join-Path $out 'native.log')
 $ErrorActionPreference=$previousPreference
 $status=$LASTEXITCODE
 [ordered]@{exitCode=$status;source=(git rev-parse HEAD).Trim();applicationRole='NOSUPERUSER NOBYPASSRLS NOINHERIT';scope='minimal control-only native fixture, no workload timing';productionMutations=0}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'execution.json')
 Write-Output ([ordered]@{evidence=$out;exitCode=$status}|ConvertTo-Json -Compress)
}finally{if($created){$labels=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .Config.Labels}}'|ConvertFrom-Json;if($labels.'codex.control-native' -cne $run -or $container -cne ('schoolpilot-usage-scale-'+$run)){throw 'Cleanup ownership mismatch'};docker --host npipe:////./pipe/dockerDesktopLinuxEngine rm -f $container *> (Join-Path $out 'cleanup.log')}}
