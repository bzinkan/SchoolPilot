import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {randomBytes,createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),temp='<TEMP>';
const require=createRequire(join(temp,'release297-linux-b112-rehearsal-source-02/package.json')),pg=require('pg');
const run=randomBytes(6).toString('hex'),out=join(temp,'release297-recovery-pair-b112-6e251-'+run),privateDir=join(temp,'release297-recovery-pair-private-'+run);
mkdirSync(out);mkdirSync(privateDir);const shared=join(privateDir,'state');mkdirSync(shared);
const docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe',endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
const env={...process.env};for(const key of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','BUILDX_BUILDER'])delete env[key];
const sha=b=>createHash('sha256').update(b).digest('hex'),json=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const candidateDir='<LOCAL_USER>/.codex/artifacts/release297-candidate-b11202fc-01',fallbackDir='<LOCAL_USER>/.codex/artifacts/release297-compatible-rollback-6e251f2d-01';
const candidate=json(join(candidateDir,'candidate-preparation.json')),fallback=json(join(fallbackDir,'candidate-preparation.json'));
assert.equal(candidate.source,'b11202fc305198d76e73c5e6d711b7dc9ed2d938');assert.equal(fallback.source,'6e251f2d1eece2b98fa2325e1fa46bd2b8553420');assert.equal(candidate.passed,true);assert.equal(fallback.passed,true);
const sourceRehearsal=json(join(temp,'release297-rehearsal-b112-6e251-02/rehearsal.json'));assert.equal(sourceRehearsal.passed,true);
const ledger=json(join(temp,'release297-rehearsal-b112-6e251-02/candidate-after-rollback-contract.json')).ledger;
const owners=[],results=[];let admin,passed=false;
function command(args,options={}){const r=spawnSync(docker,['--host',endpoint,...args],{env,encoding:'utf8',windowsHide:true,timeout:options.timeout??60000,maxBuffer:20*1024*1024,input:options.input});if(options.log)writeFileSync(join(out,options.log),(r.stdout??'')+'\n'+(r.stderr??''));if(!options.allowFailure){assert.equal(r.error,undefined,'Docker operation bounded completion');assert.equal(r.status,0,'Docker stage failed: '+args[0]);}return r;}
function inspect(id){const r=command(['inspect',id],{allowFailure:true});return r.status===0?JSON.parse(r.stdout)[0]:null;}
function matches(row,owner){return row?.Id===owner.id&&row?.Name==='/'+owner.name&&row?.Config?.Labels?.['codex.recovery-pair']===run&&row?.Config?.Labels?.['codex.recovery-role']===owner.role&&row?.Config?.Image===owner.image;}
function create(role,image,args){const name='schoolpilot-recovery-'+run+'-'+role;const r=command(['create','--name',name,'--label','codex.recovery-pair='+run,'--label','codex.recovery-role='+role,...args,image],{allowFailure:true});const row=inspect(name);let owner;if(row?.Name==='/'+name&&row?.Config?.Labels?.['codex.recovery-pair']===run&&row?.Config?.Labels?.['codex.recovery-role']===role&&row?.Config?.Image===image){owner={id:row.Id,name,role,image};owners.push(owner);}assert.equal(r.error,undefined);assert.equal(r.status,0);assert.ok(owner,'Exact creation/recovery ownership required');return owner;}
const receipt={schemaVersion:1,run,startedAt:new Date().toISOString(),candidateSource:candidate.source,fallbackSource:fallback.source,candidateImage:candidate.image,fallbackImage:fallback.image,probeSha256:sha(readFileSync(join(here,'probe.mjs'))),runnerSha256:sha(readFileSync(fileURLToPath(import.meta.url))),localDockerDaemon:endpoint,actualImageFunctions:true,syntheticDataOnly:true,liveCatalogProven:false,serviceTrafficRollback:false,capacityAccepted:false,productionMutations:0,usageModes:'off/off',results,cleanup:[]};
try{
 const pgImage=command(['inspect','schoolpilot-db','--format','{{.Image}}']).stdout.trim();assert.match(pgImage,/^sha256:[a-f0-9]{64}$/);
 const password=randomBytes(24).toString('hex'),appPassword=randomBytes(24).toString('hex'),database='pair_'+run,appRole='pair_app_'+run;
 const postgres=create('postgres',pgImage,['--cpus','4','--memory','4g','--memory-swap','4g','--publish','127.0.0.1::5432','--env','POSTGRES_USER=pair_owner','--env','POSTGRES_DB='+database,'--env','POSTGRES_PASSWORD='+password]);
 command(['start',postgres.id]);let ready=false;for(let n=0;n<50;n++){if(command(['exec',postgres.id,'pg_isready','-h','127.0.0.1','-U','pair_owner','-d',database],{allowFailure:true}).status===0){ready=true;break;}await new Promise(r=>setTimeout(r,200));}assert.equal(ready,true);
 const pgInspect=inspect(postgres.id);assert.ok(matches(pgInspect,postgres));const port=pgInspect.NetworkSettings.Ports['5432/tcp'][0];assert.equal(port.HostIp,'127.0.0.1');
 const schemaPath=join(temp,'release297-role-ingest-unprofiled-0e427-01/post-convergence-schema.sql');receipt.schemaDonorSha256=sha(readFileSync(schemaPath));
 command(['exec','-i',postgres.id,'psql','-U','pair_owner','-d',database,'-v','ON_ERROR_STOP=1'],{input:readFileSync(schemaPath,'utf8'),log:'restore.log'});
 admin=new pg.Pool({connectionString:`<REDACTED_LOCAL_URL>
 await admin.query(`CREATE ROLE ${appRole} LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '${appPassword}'; GRANT USAGE ON SCHEMA public TO ${appRole}; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO ${appRole}; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO ${appRole}`);
 for(const row of ledger)await admin.query('INSERT INTO schema_migrations(id,checksum,mode,status,application_sha) VALUES($1,$2,$3,$4,$5)',[row.id,row.checksum,row.mode,row.status,row.application_sha]);
 receipt.syntheticLedgerRows=ledger.length;receipt.syntheticLedgerSourceSha256=sha(readFileSync(join(temp,'release297-rehearsal-b112-6e251-02/candidate-after-rollback-contract.json')));receipt.ledgerBootstrap='Synthetic ledger copied from completed source rehearsal into fresh schema-only fixture; not a production restore or independent migration application.';
 const secret=randomBytes(32).toString('hex'),envPath=join(privateDir,'runtime.env');
 writeFileSync(envPath,`DATABASE_URL=<REDACTED_LOCAL_URL>
 for(const [phase,artifact]of [['seed',candidate],['fallback',fallback],['return',candidate]]){
  const image=artifact.image.imageId,name='schoolpilot-recovery-'+run+'-'+phase;
  const args=['--network','container:'+postgres.id,'--cpus','1','--memory','2g','--memory-swap','2g','--cap-drop','ALL','--security-opt','no-new-privileges','--no-healthcheck','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=32m','--env-file',envPath,'--env','PROBE_SOURCE='+artifact.source,'--mount','type=bind,source='+join(here,'probe.mjs').replaceAll('\\','/')+',target=/probe.mjs,readonly','--mount','type=bind,source='+shared.replaceAll('\\','/')+',target=/proof','--entrypoint','node'];
  const created=command(['create','--name',name,'--label','codex.recovery-pair='+run,'--label','codex.recovery-role='+phase,...args,image,'/probe.mjs',phase],{allowFailure:true});
  const row=inspect(name),owner={id:row?.Id,name,role:phase,image};if(matches(row,owner))owners.push(owner);else throw Error('Phase creation ownership unconfirmed');assert.equal(created.status,0);assert.equal(created.error,undefined);
  const launch=command(['start','--attach',owner.id],{timeout:120000,log:phase+'.log',allowFailure:true});const ended=inspect(owner.id);assert.ok(matches(ended,owner));
  assert.equal(ended.Image,artifact.image.configDigest); const phaseReceipt={phase,source:artifact.source,image,runtimeConfigDigest:ended.Image,containerId:owner.id,attachExit:launch.status,daemonExit:ended.State.ExitCode,running:ended.State.Running,oomKilled:ended.State.OOMKilled};results.push(phaseReceipt);
  const resultPath=join(shared,phase+'-result.json'); if(existsSync(resultPath)){writeFileSync(join(out,phase+'-result.json'),readFileSync(resultPath));phaseReceipt.proofSha256=sha(readFileSync(resultPath));} 
  assert.equal(launch.error,undefined);assert.equal(launch.status,0);assert.equal(ended.State.Running,false);assert.equal(ended.State.OOMKilled,false);assert.equal(ended.State.ExitCode,0);
  const proof=json(join(shared,phase+'-result.json'));assert.equal(proof.passed,true);assert.equal(proof.source,artifact.source);writeFileSync(join(out,phase+'-result.json'),JSON.stringify(proof,null,2)+'\n');phaseReceipt.proofSha256=sha(readFileSync(join(out,phase+'-result.json')));
  const raw=readFileSync(join(shared,'private-state.json'));phaseReceipt.privateStateSha256=sha(raw);phaseReceipt.privateStateExcluded=true;
 }
 passed=true;
}catch(error){receipt.failure={name:error.name,message:String(error.message).slice(0,500)};process.exitCode=1;}
finally{
 await admin?.end();
 for(const owner of owners.reverse()){try{const current=inspect(owner.id);assert.ok(matches(current,owner));const wasRunning=current.State.Running;command(['rm','--force','--volumes',owner.id]);assert.equal(inspect(owner.id),null);receipt.cleanup.push({...owner,removed:true,wasRunning,forced:wasRunning});}catch(error){receipt.cleanup.push({...owner,removed:false,error:error.name});passed=false;process.exitCode=1;}}
 receipt.passed=passed;receipt.completedAt=new Date().toISOString();receipt.privateMaterialDirectory=privateDir;receipt.privateMaterialExcludedFromSafeEvidence=true;writeFileSync(join(out,'execution.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({out,passed,phases:results.length,cleanupPassed:receipt.cleanup.every(x=>x.removed),failure:receipt.failure}));
}
