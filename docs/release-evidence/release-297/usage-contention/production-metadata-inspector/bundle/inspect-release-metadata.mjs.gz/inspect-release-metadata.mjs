// External review candidate. Reads no application content and imports no application startup.
import pg from 'pg';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=value=>createHash('sha256').update(value).digest('hex');
const identifier=value=>{assert.equal(typeof value,'string');assert.match(value,/^[A-Za-z_][A-Za-z0-9_$]{0,127}$/);return value;};
const extensionName=value=>{assert.equal(typeof value,'string');assert.match(value,/^[A-Za-z_][A-Za-z0-9_$-]{0,127}$/);return value;};
const hash=value=>{assert.equal(typeof value,'string');assert.match(value,/^[a-f0-9]{64}$/);return value;};
const bool=value=>{assert.equal(typeof value,'boolean');return value;};
const oneOf=(value,choices)=>{assert.ok(choices.includes(value));return value;};
const fieldValidators={schema:identifier,name:identifier,table:identifier,
 kind:value=>oneOf(value,['r','p','v','m','S','f','c','d','e','b','u','i','x','a','t','f']),
 enabled:value=>oneOf(value,['O','D','R','A']),
 identity:value=>oneOf(value,['','a','d']),generated:value=>oneOf(value,['','s']),
 volatility:value=>oneOf(value,['i','s','v']),command:value=>oneOf(value,['r','a','w','d','*']),
 rls:bool,forced:bool,partition:bool,notNull:bool,valid:bool,ready:bool,unique:bool,primary:bool,
 validated:bool,permissive:bool,securityDefiner:bool,cycle:bool,
 definitionSha256:hash,defaultSha256:hash,typeSha256:hash,signatureSha256:hash,rolesSha256:hash,
 usingSha256:hash,checkSha256:hash,attributesSha256:hash};
const specs={
 schemas:['name'],relations:['schema','name','kind','rls','forced','partition','definitionSha256'],
 columns:['schema','table','name','typeSha256','notNull','identity','generated','defaultSha256'],
 constraints:['schema','table','name','kind','validated','definitionSha256'],
 indexes:['schema','table','name','valid','ready','unique','primary','definitionSha256'],
 policies:['schema','table','name','permissive','command','rolesSha256','usingSha256','checkSha256'],
 triggers:['schema','table','name','enabled','definitionSha256'],
 functions:['schema','name','signatureSha256','securityDefiner','volatility','kind','definitionSha256'],
 types:['schema','name','kind','definitionSha256'],sequences:['schema','name','attributesSha256'],
 views:['schema','name','kind','definitionSha256'],extensions:['name','attributesSha256']};
const caps={schemas:32,relations:512,columns:12000,constraints:4096,indexes:4096,policies:2048,triggers:2048,functions:2048,types:2048,sequences:512,views:512,extensions:128};
const scope="n.nspname NOT LIKE 'pg_%' AND n.nspname<>'information_schema'";
const digest=expression=>`encode(sha256(convert_to(coalesce((${expression})::text,''),'UTF8')),'hex')`;
const queries={
 schemas:`SELECT nspname AS name FROM pg_namespace n WHERE ${scope} ORDER BY nspname`,
 relations:`SELECT n.nspname AS schema,c.relname AS name,c.relkind AS kind,c.relrowsecurity AS rls,c.relforcerowsecurity AS forced,c.relispartition AS partition,${digest("pg_get_expr(c.relpartbound,c.oid)")} AS "definitionSha256" FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} AND c.relkind IN ('r','p','v','m','S','f') ORDER BY 1,2`,
 columns:`SELECT n.nspname AS schema,c.relname AS "table",a.attname AS name,${digest('format_type(a.atttypid,a.atttypmod)')} AS "typeSha256",a.attnotnull AS "notNull",a.attidentity AS identity,a.attgenerated AS generated,${digest('pg_get_expr(d.adbin,d.adrelid)')} AS "defaultSha256" FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid JOIN pg_namespace n ON n.oid=c.relnamespace LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum WHERE ${scope} AND c.relkind IN ('r','p','v','m','f') AND a.attnum>0 AND NOT a.attisdropped ORDER BY n.nspname,c.relname,a.attnum`,
 constraints:`SELECT n.nspname AS schema,c.relname AS "table",k.conname AS name,k.contype AS kind,k.convalidated AS validated,${digest('pg_get_constraintdef(k.oid,true)')} AS "definitionSha256" FROM pg_constraint k JOIN pg_class c ON c.oid=k.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} ORDER BY 1,2,3`,
 indexes:`SELECT n.nspname AS schema,c.relname AS "table",i.relname AS name,x.indisvalid AS valid,x.indisready AS ready,x.indisunique AS "unique",x.indisprimary AS "primary",${digest('pg_get_indexdef(x.indexrelid)')} AS "definitionSha256" FROM pg_index x JOIN pg_class c ON c.oid=x.indrelid JOIN pg_class i ON i.oid=x.indexrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} ORDER BY 1,2,3`,
 policies:`SELECT n.nspname AS schema,c.relname AS "table",p.polname AS name,p.polpermissive AS permissive,p.polcmd AS command,${digest("ARRAY(SELECT CASE WHEN role_oid=0 THEN 'public' ELSE pg_get_userbyid(role_oid) END FROM unnest(p.polroles) AS roles(role_oid) ORDER BY 1)")} AS "rolesSha256",${digest('pg_get_expr(p.polqual,p.polrelid)')} AS "usingSha256",${digest('pg_get_expr(p.polwithcheck,p.polrelid)')} AS "checkSha256" FROM pg_policy p JOIN pg_class c ON c.oid=p.polrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} ORDER BY 1,2,3`,
 triggers:`SELECT n.nspname AS schema,c.relname AS "table",t.tgname AS name,t.tgenabled AS enabled,${digest('pg_get_triggerdef(t.oid,true)')} AS "definitionSha256" FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} AND NOT t.tgisinternal ORDER BY 1,2,3`,
 functions:`SELECT n.nspname AS schema,p.proname AS name,${digest('pg_get_function_identity_arguments(p.oid)')} AS "signatureSha256",p.prosecdef AS "securityDefiner",p.provolatile AS volatility,p.prokind AS kind,${digest('pg_get_functiondef(p.oid)')} AS "definitionSha256" FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE ${scope} AND p.prokind IN ('f','p') ORDER BY n.nspname,p.proname,pg_get_function_identity_arguments(p.oid)`,
 types:`SELECT n.nspname AS schema,t.typname AS name,t.typtype AS kind,${digest("jsonb_build_object('base',format_type(t.typbasetype,t.typtypmod),'notNull',t.typnotnull,'default',t.typdefault,'enum',ARRAY(SELECT e.enumlabel FROM pg_enum e WHERE e.enumtypid=t.oid ORDER BY e.enumsortorder),'constraints',ARRAY(SELECT pg_get_constraintdef(k.oid,true) FROM pg_constraint k WHERE k.contypid=t.oid ORDER BY k.conname))")} AS "definitionSha256" FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE ${scope} AND t.typtype IN ('d','e') ORDER BY 1,2`,
 sequences:`SELECT n.nspname AS schema,c.relname AS name,${digest("jsonb_build_object('type',format_type(s.seqtypid,-1),'start',s.seqstart,'increment',s.seqincrement,'max',s.seqmax,'min',s.seqmin,'cache',s.seqcache,'cycle',s.seqcycle)")} AS "attributesSha256" FROM pg_sequence s JOIN pg_class c ON c.oid=s.seqrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} ORDER BY 1,2`,
 views:`SELECT n.nspname AS schema,c.relname AS name,c.relkind AS kind,${digest('pg_get_viewdef(c.oid,true)')} AS "definitionSha256" FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE ${scope} AND c.relkind IN ('v','m') ORDER BY 1,2`,
 extensions:`SELECT e.extname AS name,${digest("jsonb_build_object('version',e.extversion,'schema',n.nspname,'relocatable',e.extrelocatable)")} AS "attributesSha256" FROM pg_extension e JOIN pg_namespace n ON n.oid=e.extnamespace ORDER BY 1`
};
let emitted=false;
const fail=()=>{if(!emitted){emitted=true;process.stdout.write(JSON.stringify({version:1,failed:true,code:'RELEASE_METADATA_FAILED'})+'\n');}};
const wall=setTimeout(()=>{fail();process.exit(1);},45000);
let client;
try {
 const url=new URL(process.env.DATABASE_URL||'');
 assert.ok(['postgres:','postgresql:'].includes(url.protocol));
 assert.equal(url.hostname,'schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com');
 assert.ok(!url.port||url.port==='5432');assert.equal(decodeURIComponent(url.pathname),'/schoolpilot');
 // Explicit fields prevent URI ssl/query parameters from overriding TLS or host bindings.
 client=new pg.Client({host:url.hostname,port:5432,database:'schoolpilot',user:decodeURIComponent(url.username),password:decodeURIComponent(url.password),ssl:{ca:readFileSync('/app/rds-ca.pem','utf8'),rejectUnauthorized:true},connectionTimeoutMillis:10000,statement_timeout:15000,application_name:'release297-read-only-metadata'});
 client.on('error',()=>{fail();process.exit(1);});
 await client.connect();await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
 await client.query("SET LOCAL statement_timeout='15s'; SET LOCAL lock_timeout='2s'; SET LOCAL idle_in_transaction_session_timeout='15s'; SET LOCAL search_path=pg_catalog,public");
 const identity=(await client.query("SELECT current_database() AS database,current_setting('transaction_read_only') AS read_only,current_setting('server_version_num')::integer AS version,rolsuper AS superuser,rolbypassrls AS bypass_rls FROM pg_roles WHERE rolname=current_user")).rows[0];
 assert.equal(identity.database,'schoolpilot');assert.equal(identity.read_only,'on');assert.ok(identity.version>=160000&&identity.version<170000);
 const inventory={};
 for(const [kind,sql] of Object.entries(queries)) {
  const rows=(await client.query(sql+` LIMIT ${caps[kind]+1}`)).rows;assert.ok(rows.length<=caps[kind]);
  inventory[kind]=rows.map(row=>{assert.deepEqual(Object.keys(row).sort(),[...specs[kind]].sort());return Object.fromEntries(specs[kind].map(key=>[key,(kind==='extensions'&&key==='name'?extensionName:fieldValidators[key])(row[key])]));});
 }
 const ledger=(await client.query('SELECT id,checksum,mode,status,application_sha FROM public.schema_migrations ORDER BY id LIMIT 1025')).rows;
 assert.ok(ledger.length>0&&ledger.length<=1024);
 for(const row of ledger){assert.deepEqual(Object.keys(row).sort(),['application_sha','checksum','id','mode','status']);assert.match(row.id,/^[A-Za-z0-9._:-]{1,160}$/);hash(row.checksum);oneOf(row.mode,['transactional','nontransactional']);oneOf(row.status,['running','complete','failed']);assert.match(row.application_sha,/^[A-Za-z0-9._:-]{1,128}$/);}
 // Global bootstrap registries must remain unfiltered; never convert unexpected RLS into an absent-school result.
 for(const name of ['schools','product_licenses']) {const rows=inventory.relations.filter(row=>row.schema==='public'&&row.name===name);assert.equal(rows.length,1);assert.equal(rows[0].rls,false);assert.equal(rows[0].forced,false);}
 const candidates=(await client.query("SELECT id,name,status='active' AS active_status,is_active,deleted_at IS NULL AS not_deleted,disabled_at IS NULL AS not_disabled,plan_status<>'canceled' AS plan_not_canceled,(active_until IS NULL OR active_until>transaction_timestamp()) AS within_paid_through FROM public.schools WHERE lower(domain)=$1 ORDER BY id LIMIT 2",['desalescincy.org'])).rows;
 let pilot={matches:candidates.length,school:null};
 if(candidates.length===1){const row=candidates[0];assert.match(row.id,/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i);assert.equal(typeof row.name,'string');assert.ok(row.name.length<=256);
  const flags=Object.fromEntries(['active_status','is_active','not_deleted','not_disabled','plan_not_canceled','within_paid_through'].map(key=>[key,bool(row[key])]));
  const licenses=(await client.query("SELECT product,status='active' AS active_status,(expires_at IS NULL OR expires_at>transaction_timestamp()) AS unexpired FROM public.product_licenses WHERE school_id=$1 ORDER BY product LIMIT 4",[row.id])).rows;
  assert.ok(licenses.length<=3);for(const license of licenses){oneOf(license.product,['CLASSPILOT','PASSPILOT','GOPILOT']);bool(license.active_status);bool(license.unexpired);}
  pilot={matches:1,school:{id:row.id,domain:'desalescincy.org',nameSha256:sha(row.name),flags,licenses,classpilotEntitled:Object.values(flags).every(Boolean)&&licenses.some(l=>l.product==='CLASSPILOT'&&l.active_status&&l.unexpired)}};
 }
 await client.query('COMMIT');
 const payload={version:1,mode:'read_only_release_metadata',observedAt:new Date().toISOString(),serverVersionNum:identity.version,readOnly:true,role:{superuser:bool(identity.superuser),bypassRls:bool(identity.bypass_rls)},inventory,ledger,pilot};
 const bytes=Buffer.from(JSON.stringify(payload));assert.ok(bytes.length<=2097152);
 const payloadSha256=sha(bytes),count=Math.ceil(bytes.length/8192);assert.ok(count<=256);
 emitted=true;
 for(let index=0;index<count;index++)process.stdout.write(JSON.stringify({version:1,index,count,payloadSha256,data:bytes.subarray(index*8192,(index+1)*8192).toString('base64')})+'\n');
}catch{fail();process.exitCode=1;}finally{await client?.end().catch(()=>{});clearTimeout(wall);}

