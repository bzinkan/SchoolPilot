import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='<USER_HOME>/.codex/worktrees/release297-compatible-rollback/SchoolPilot';
const output=path.dirname(fileURLToPath(import.meta.url));
const source='5c01944ed1afb4241e270469c6477121bf48cd84';
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),source);
assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
const json=p=>JSON.parse(fs.readFileSync(path.join(output,p),'utf8').replace(/^\uFEFF/,''));
const digest=json('image-inspect.json')[0].Id;
const read=p=>execFileSync('git',['show',source+':'+p],{cwd:root,encoding:'utf8'});
const paths={registry:'src/config/rlsRegistry.json',writer:'src/services/classpilotPrivateChatLifecycle.ts',migration:'src/db/classpilotPrivateChatLifecycleMigration.ts',protocol:'src/services/classpilotProtocol.ts',relay:'src/realtime/websocket.ts'};
const sources=Object.fromEntries(Object.entries(paths).map(([key,p])=>[key,read(p)]));
const tables=JSON.parse(sources.registry).inventories.classpilotPrivateChatLifecyclePostExpand.tables;
const make=name=>({synthetic:true,notDeployable:true,containerDefinitions:[{name,image:'synthetic.invalid/schoolpilot-rollback@'+digest,command:['node',name==='api'?'dist/index.js':'dist/worker.js'],environment:Object.entries({GIT_SHA:source,RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:tables.join(','),CLASSPILOT_USAGE_ROLLUP_MODE:'off',CLASSPILOT_DIGITAL_USAGE_MODE:'off',CLASSPILOT_CAP_PRIVATE_CHAT_LIFECYCLE_V1:'false',CLASSPILOT_CAPABILITY_ROLLOUTS_JSON:JSON.stringify({privateChatLifecycleV1:{mode:'off'}})}).map(([name,value])=>({name,value}))}]});
const api=make('api'),worker=make('scheduler-worker');
const {assertPrivateChatReleaseFloor,verifyPrivateChatSourceImages}=await import(pathToFileURL(path.join(root,'scripts/enforce-private-chat-release-floor.mjs')));
const args={apiTaskDefinition:api,workerTaskDefinition:worker,candidateSources:sources,rollbackSourcesBySha:{[source]:sources},candidateTaskDefinitions:[{taskDefinition:api,containerName:'api'},{taskDefinition:worker,containerName:'scheduler-worker'}]};
const result=assertPrivateChatReleaseFloor(args);
assert.deepEqual(result,{required:true,writerVersion:1,inventoryCount:129});
assert.equal(verifyPrivateChatSourceImages({apiTaskDefinition:api,workerTaskDefinition:worker,expectedRepository:'synthetic.invalid/schoolpilot-rollback',lookupDigest:sha=>{assert.equal(sha,source);return digest;}}),true);
assert.throws(()=>assertPrivateChatReleaseFloor({...args,rollbackSourcesBySha:{[source]:{...sources,relay:''}}}));
const partial=structuredClone(worker);partial.containerDefinitions[0].environment.find(row=>row.name==='RLS_ENABLED_TABLES').value=tables.slice(0,128).join(',');
assert.throws(()=>assertPrivateChatReleaseFloor({...args,workerTaskDefinition:partial}));
for(const [name,value] of [['synthetic-api-task.json',api],['synthetic-worker-task.json',worker]])fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const proof={passed:true,...result,bridgeVersion:1,relayVersion:1,sourceCommit:source,imageDigest:digest,sourceHashes:Object.fromEntries(Object.entries(paths).map(([key,p])=>[p,createHash('sha256').update(sources[key]).digest('hex')])),syntheticTaskDefinitions:true,imageLookup:'Injected local identity only; no ECR query or live source binding proved.',checks:['complete129 pair accepted with capability off','missing relay rejected','partial128 worker rejected','both Usage modes explicitly off'],productionMutations:0,taskRegistrations:0};
fs.writeFileSync(path.join(output,'synthetic-release-floor-proof.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:true,source,inventoryCount:129,synthetic:true}));



