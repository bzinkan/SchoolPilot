import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {copyFile,mkdir,readFile,readdir,stat,writeFile} from 'node:fs/promises';
import {join,resolve,relative} from 'node:path';

const origin=resolve('<TEMP>/schoolpilot-image-scan-NPHqyV');
const target=resolve('C:/Users/zinka/.codex/artifacts/release297-candidate-814844f3-01');
const source='814844f344a45159152415b0fb6d7027f05b093e';
const hash=async path=>{const digest=createHash('sha256');for await(const chunk of createReadStream(path))digest.update(chunk);return digest.digest('hex');};
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const receipt=await json(join(origin,'candidate-preparation.json'));
const scan=await json(join(origin,'scan-receipt.json'));
assert.equal(receipt.source,source);assert.equal(receipt.passed,true);assert.equal(receipt.sourceUnchangedAtFinish,true);
assert.equal(receipt.inspectorCleanupPassed,true);assert.equal(scan.passed,true);
assert.equal(scan.counts.HIGH,0);assert.equal(scan.counts.CRITICAL,0);
assert.equal(scan.gate,'All HIGH and CRITICAL findings block regardless of fix availability');
assert.equal(await hash(join(origin,'input/image.tar')),receipt.exportSha256);
await mkdir(target,{recursive:false});
const files=[];
async function copyTree(path){
  for(const entry of (await readdir(path,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    if(path===origin&&entry.name==='cache')continue;
    assert.equal(entry.isSymbolicLink(),false);
    const from=join(path,entry.name),name=relative(origin,from).replaceAll('\\','/'),to=join(target,name);
    assert.ok(!name.startsWith('../'));assert.ok(!/(^|\/)\.env(?:\.|$)/.test(name));
    if(entry.isDirectory()){await mkdir(to);await copyTree(from);continue;}
    assert.equal(entry.isFile(),true);const before=await hash(from);await copyFile(from,to,1);
    assert.equal(await hash(to),before);assert.equal(await hash(from),before);
    files.push({path:name,bytes:(await stat(from)).size,sha256:before,originalPath:from,copyVerified:true});
  }
}
await copyTree(origin);
const manifest={schemaVersion:1,source,diagnosticOnly:true,finalReleaseArtifactSelected:false,passed:true,
  buildMode:receipt.buildMode,originalEvidenceDirectory:origin,immutableOriginalsPreserved:true,image:receipt.image,
  scan:{scanner:receipt.scanner,gate:receipt.gate,counts:scan.counts,receiptSha256:await hash(join(origin,'scan-receipt.json')),fullScanSha256:receipt.fullScanSha256},
  candidatePreparationSha256:await hash(join(origin,'candidate-preparation.json')),exportSha256:receipt.exportSha256,
  syntheticFloorOnly:true,productionReadiness:false,capacityAccepted:false,productionMutations:0,registryPushes:0,
  embeddedProbeScope:'129 tables, writer/bridge/relay floor and both Usage modes default-off. Function/migration 54 is covered by source/native proof and pending actual final-image rehearsal, not by this retained compatibility probe.',
  omitted:['replaceable Trivy cache'],files};
await writeFile(join(target,'artifact-manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({target,source,files:files.length,manifestSha256:await hash(join(target,'artifact-manifest.json')),candidatePreparationSha256:manifest.candidatePreparationSha256,scanReceiptSha256:manifest.scan.receiptSha256,image:manifest.image}));
