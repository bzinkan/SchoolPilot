// Pure embedded-byte proof only. No API/worker or database connection starts.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const paths={writer:'/app/dist/services/classpilotPrivateChatLifecycle.js',relay:'/app/dist/realtime/websocket.js',migration:'/app/dist/db/classpilotPrivateChatLifecycleMigration.js',protocol:'/app/dist/services/classpilotProtocol.js',registry:'/app/dist/config/rlsRegistry.json',usage:'/app/dist/config/classpilotUsageModes.js'};
const text=Object.fromEntries(Object.entries(paths).map(([key,path])=>[key,readFileSync(path,'utf8')]));
assert.match(text.writer,/export const PRIVATE_CHAT_LIFECYCLE_WRITER_VERSION = 1;/);
assert.match(text.writer,/export const PRIVATE_CHAT_BRIDGE_VERSION = 1;/);
assert.match(text.relay,/export const PRIVATE_CHAT_RELAY_VERSION = 1;/);
assert.match(text.migration,/OLD\.private_chat_lifecycle_required\s+AND\s+NOT\s+NEW\.private_chat_lifecycle_required/);
assert.ok(text.protocol.includes('privateChatLifecycleV1'));
const tables=JSON.parse(text.registry).inventories.classpilotPrivateChatLifecyclePostExpand.tables;
assert.equal(tables.length,129);assert.equal(new Set(tables).size,129);
for(const table of ['classpilot_private_chat_threads','classpilot_usage_rollups','classpilot_usage_rollup_days'])assert.ok(tables.includes(table));
const {parseClasspilotUsageModes,readClasspilotUsageModes}=await import('/app/dist/config/classpilotUsageModes.js');
assert.deepEqual(parseClasspilotUsageModes({}),{rollupMode:'off',digitalUsageMode:'off'});
assert.deepEqual(parseClasspilotUsageModes(),{rollupMode:'off',digitalUsageMode:'off'});
assert.deepEqual(readClasspilotUsageModes({RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:tables.join(','),CLASSPILOT_USAGE_ROLLUP_MODE:'off',CLASSPILOT_DIGITAL_USAGE_MODE:'off'}),{rollupMode:'off',digitalUsageMode:'off'});
console.log(JSON.stringify({passed:true,writerVersion:1,bridgeVersion:1,relayVersion:1,inventoryCount:129,stickyMigration:true,usageDefaultAndExplicitModesOff:true,
  hashes:Object.fromEntries(Object.entries(text).map(([key,value])=>[key,sha(value)])),scope:'Embedded file/marker and pure mode-parser validation only; no server process or database connection.'},null,2));
