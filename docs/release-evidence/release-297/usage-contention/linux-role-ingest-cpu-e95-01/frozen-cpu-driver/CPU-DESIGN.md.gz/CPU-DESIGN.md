# Exact e95 ingestion CPU diagnostic

One full 6,000-offer/100-per-second ingestion-only diagnostic; no concurrent reports or heavy rollups. Lifecycle, correctness, unchanged deadlines and bounded drain remain canonical. API1CPU/2GiB, worker0.5CPU/1GiB, driver2CPU, pools16/2/5/2, candidate default V8 heap. Exact candidate application/dist/dependencies stay unchanged.

Only API adds reviewed standard Node CPU-profiler flags at1,000us. A newly created api.cpuprofile file is the only additional writable API bind; parent evidence remains read-only. Runtime facts require exact role-specific arguments. Ready/release bind CPU=true, ingest phase, unique diagnostic profile, exact source/helper/run/nonce. Candidate mode, combined phase and false/missing profile mode are refused. No capacity claim.

Existing canonical collection reads/hashes the profile after actual child shutdown; actual unforced exit and flush are required for usable evidence. Profile includes startup/drain; analysis must clip reset-to-drained snapshot and never sum overlapping inclusive frames. Profiling overhead is unisolated; historical unprofiled combined is not a matched throughput control.

Tests02:7/7pass. Tests01:6pass/1fail caused by test data-URL relative import resolution, retained; correction resolves test imports to original exact-source files without changing workload. No Docker/runtime proof has yet run for this variant.
