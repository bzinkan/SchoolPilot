import fs from 'node:fs';const file=process.env.TEMP+'/release297-owned-pg-linux-prototype-01/native-proof.mjs';let s=fs.readFileSync(file,'utf8');s=s.replace("import {pathToFileURL} from 'node:url';","import {pathToFileURL} from 'node:url';\nimport {createRequire} from 'node:module';");s=s.replace(' const results=[];let a,b;',' let proofFailures=0;const check=(name,fn)=>t.test(name,async child=>{try{return await fn(child);}catch(error){proofFailures++;throw error;}});\n const results=[];let a,b;');s=s.replaceAll('await t.test(','await check(');
const from=s.indexOf("  await check('cached SELECT sees same-transaction type DDL");const to=s.indexOf("  await check('early unawaited cached read",from);
s=s.slice(0,from)+`  await check('cached SELECT survives owner DDL between restricted leases without named-plan state',async()=>{
   const {Client}=createRequire(repo+'/package.json')('pg');const admin=new Client({connectionString:process.env.ADMIN_DATABASE_URL,statement_timeout:15000});await admin.connect();let clientBefore;
   try{
    await scoped(a.school.id,()=>enter(async({read,client})=>{clientBefore=client;await read('screenshot_session',a.values,'cached');}));
    await admin.query("ALTER TABLE student_sessions ALTER COLUMN started_at TYPE timestamp(3) USING started_at::timestamp(3)");
    await scoped(a.school.id,()=>enter(async({read,client})=>{assert.equal(client,clientBefore);const cached=await read('screenshot_session',a.values,'cached');assert.deepEqual(cached,await read('screenshot_session',a.values,'canonical'));assert.ok(cached[0].startedAt instanceof Date&&Number.isFinite(cached[0].startedAt.getTime()));}));
   }finally{try{await admin.query("ALTER TABLE student_sessions ALTER COLUMN started_at TYPE timestamp USING started_at::timestamp");}finally{await admin.end();}}
   await scoped(a.school.id,()=>enter(async({read})=>assert.deepEqual(await read('screenshot_session',a.values,'cached'),await read('screenshot_session',a.values,'canonical'))));
  });
`+s.slice(to);
s=s.replace("}),/injected_cached_read_failure/);", "}),error=>error.cause?.message==='injected_cached_read_failure');");
s=s.replace('  await waitForTimingRelease();',"  assert.equal(proofFailures,0,'All native correctness cases must pass before the ready gate');\n  await waitForTimingRelease();");fs.writeFileSync(file,s);
