import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import * as schema from '/app/dist/schema/index.js';
import * as orm from '/app/node_modules/drizzle-orm/index.js';
import {PgDialect,QueryBuilder} from '/app/node_modules/drizzle-orm/pg-core/index.js';
import {heartbeatSessionQuery,heartbeatControlQuery,heartbeatCandidateQuery} from '/app/dist/services/classpilotHeartbeatReadQueries.js';
import {readHeartbeatSession,readHeartbeatControl,readHeartbeatCandidate,trackHeartbeatPreparedReadTask} from '/app/dist/services/classpilotHeartbeatPreparedReads.js';
const {sql}=orm;
const source=JSON.parse(readFileSync(new URL('./source.json',import.meta.url)));
export const dialect=new PgDialect();
const clock=()=>sql`now()`;
const owner=new Function(...Object.keys(schema),'sql','schoolId','studentId','LIVE_TEACHING_SESSION_MODE','classpilotAuthorityClockSql','clock',source.ownerBody);
export const ownerQuery=(schoolId,studentId)=>owner(...Object.values(schema),sql,schoolId,studentId,'live',clock,'transaction');
const parameters={schoolId:sql.raw('p_school_id'),studentId:sql.raw('p_student_id'),studentSessionId:sql.raw('p_session_id'),deviceId:sql.raw('p_device_id')};
// Output aliases replace only Drizzle's client-side positional field names.
// Canonical FROM/JOIN/WHERE/LIMIT/FOR SHARE remain supplied by the actual builders.
const aliased=()=>({select:fields=>new QueryBuilder().select(Object.fromEntries(Object.entries(fields).map(([key,column])=>[key,sql`${column}`.as(key)])))});
const queries={session:heartbeatSessionQuery(aliased(),parameters).getSQL(),control:heartbeatControlQuery(aliased(),parameters).getSQL(),candidate:heartbeatCandidateQuery(aliased(),{...parameters,teachingSessionId:sql.raw('v_control."teachingSessionId"')}).getSQL(),owner:ownerQuery(parameters.schoolId,parameters.studentId)};
function inline(query){
 const markers=new PgDialect();markers.escapeParam=i=>'__fixed_constant_'+i+'__';
 const compiled=markers.sqlToQuery(query);let text=compiled.sql;
 for(let i=0;i<compiled.params.length;i++){const value=compiled.params[i];assert.ok(typeof value==='string'||typeof value==='number'||typeof value==='boolean'||value===null);const literal=value===null?'NULL':typeof value==='string'?markers.escapeString(value):String(value);text=text.replaceAll('__fixed_constant_'+i+'__',literal);}
 assert.equal(/__fixed_constant_/.test(text),false);
 // Only relation positions are qualified; column aliases and predicates stay canonical.
 return text.replace(/\b(FROM|JOIN)\s+"([a-z_]+)"/gi,'$1 public."$2"');
}
export const statements=Object.fromEntries(Object.entries(queries).map(([key,query])=>[key,inline(query)]));
export const functionSql=`CREATE FUNCTION public.external_screenshot_evidence(p_school_id text,p_student_id text,p_session_id text,p_device_id text)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY INVOKER PARALLEL UNSAFE SET search_path=pg_catalog AS $body$
DECLARE v_session record; v_control record; v_candidate record; v_owners jsonb; v_result jsonb;
BEGIN
 SELECT * INTO v_session FROM (${statements.session}) evidence_session;
 IF NOT FOUND THEN RETURN jsonb_build_object('stage','session_missing'); END IF;
 v_result := jsonb_build_object('stage','control','session',to_jsonb(v_session));
 SELECT * INTO v_control FROM (${statements.control}) evidence_control;
 IF NOT FOUND THEN RETURN v_result || jsonb_build_object('control',NULL); END IF;
 v_result := v_result || jsonb_build_object('control',to_jsonb(v_control));
 IF v_control."teachingSessionId" IS NULL OR v_control."supervisionContextId" IS NOT NULL OR v_control."hardExpiresAt" IS NULL THEN RETURN v_result; END IF;
 SELECT * INTO v_candidate FROM (${statements.candidate}) evidence_candidate;
 IF NOT FOUND THEN RETURN v_result || jsonb_build_object('stage','candidate_missing'); END IF;
 SELECT jsonb_agg(to_jsonb(evidence_owner)) INTO v_owners FROM (${statements.owner}) evidence_owner;
 RETURN v_result || jsonb_build_object('stage','owner','candidate',to_jsonb(v_candidate),'owners',v_owners);
END $body$;`;
export const functionHash=createHash('sha256').update(functionSql).digest('hex');
const fields={session:{id:schema.studentSessions.id,startedAt:schema.studentSessions.startedAt,authKind:schema.studentSessions.authKind,manualLeaseExpiresAt:schema.studentSessions.manualLeaseExpiresAt},control:{teachingSessionId:schema.classpilotStudentControlStates.teachingSessionId,supervisionContextId:schema.classpilotStudentControlStates.supervisionContextId,revision:schema.classpilotStudentControlStates.revision,scheduledEndAt:schema.classpilotStudentControlStates.scheduledEndAt,hardExpiresAt:schema.classpilotStudentControlStates.hardExpiresAt,updatedAt:schema.classpilotStudentControlStates.updatedAt},candidate:{teachingSessionId:schema.teachingSessions.id,startTime:schema.teachingSessions.startTime,rosterSnapshotCompletedAt:schema.teachingSessions.rosterSnapshotCompletedAt,teachingScheduledEndAt:schema.teachingSessions.scheduledEndAt,controlRevision:schema.classpilotStudentControlStates.revision,controlUpdatedAt:schema.classpilotStudentControlStates.updatedAt,controlScheduledEndAt:schema.classpilotStudentControlStates.scheduledEndAt,controlHardExpiresAt:schema.classpilotStudentControlStates.hardExpiresAt}};
function decode(kind,row){if(!row)return row;return Object.fromEntries(Object.entries(fields[kind]).map(([key,column])=>[key,row[key]===null?null:column.mapFromDriverValue(row[key])]));}
export function decodeEvidence(raw){return {...raw,...(raw.session?{session:decode('session',raw.session)}:{}),...('control'in raw?{control:decode('control',raw.control)}:{}),...(raw.candidate?{candidate:decode('candidate',raw.candidate)}:{})};}
export async function sequential(tx,options){
 const [session]=await readHeartbeatSession(tx,options);if(!session)return{stage:'session_missing'};
 const [control]=await readHeartbeatControl(tx,options);const base={stage:'control',session,control:control??null};
 if(!control?.teachingSessionId||control.supervisionContextId!==null||!control.hardExpiresAt)return base;
 const [candidate]=await readHeartbeatCandidate(tx,{...options,teachingSessionId:control.teachingSessionId});if(!candidate)return{...base,stage:'candidate_missing'};
 const owners=(await tx.execute(ownerQuery(options.schoolId,options.studentId))).rows;
 return{...base,stage:'owner',candidate,owners};
}
const prototypeRoots=new WeakMap();
export function registerPrototypeRoot(tx,schoolId){assert.equal(prototypeRoots.has(tx),false);const token={schoolId,open:true};prototypeRoots.set(tx,token);return()=>{token.open=false;};}
export async function rawFunction(tx,options){const rows=(await tx.execute(sql`SELECT public.external_screenshot_evidence(${options.schoolId}::text,${options.studentId}::text,${options.studentSessionId}::text,${options.deviceId}::text) AS evidence`)).rows;return decodeEvidence(rows[0].evidence);}
export function combined(tx,options){return trackHeartbeatPreparedReadTask(tx,async()=>{const token=prototypeRoots.get(tx);assert.ok(token?.open,'Prototype requires an open registered root');assert.equal(options.schoolId,token.schoolId,'Heartbeat prepared-read tenant mismatch');return rawFunction(tx,options);});}
export function comparableEvidence(e){const result=structuredClone(e);if(result.owners)result.owners=result.owners.map(row=>({...row,controlUpdatedAt:row.controlUpdatedAt===null?null:schema.teachingSessions.controlUpdatedAt.mapFromDriverValue(row.controlUpdatedAt),startTime:row.startTime===null?null:schema.teachingSessions.startTime.mapFromDriverValue(row.startTime),createdAt:row.createdAt===null?null:schema.teachingSessions.createdAt.mapFromDriverValue(row.createdAt)})).sort((a,b)=>String(a.id).localeCompare(String(b.id)));return result;}
