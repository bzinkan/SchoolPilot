import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const files={focus:'/app/dist/services/classpilotFocus.js',writer:'/app/dist/services/classpilotPrivateChatLifecycle.js',relay:'/app/dist/realtime/websocket.js',storage:'/app/dist/services/storage.js',migration:'/app/dist/db/classpilotPrivateChatLifecycleMigration.js',protocol:'/app/dist/services/classpilotProtocol.js',registry:'/app/dist/config/rlsRegistry.json',tenant:'/app/dist/middleware/tenantContext.js',monitoring:'/app/dist/services/classpilotMonitoringPolicy.js',dispatcher:'/app/dist/services/classpilotCommandDispatcher.js',heartbeat:'/app/dist/routes/classpilot/devices.js',entitlement:'/app/dist/services/classpilotEntitlement.js',usage:'/app/dist/config/classpilotUsageModes.js'};
const text=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,readFileSync(p,'utf8')]));
assert.match(text.writer,/export const PRIVATE_CHAT_LIFECYCLE_WRITER_VERSION = 1;/);
assert.match(text.writer,/export const PRIVATE_CHAT_BRIDGE_VERSION = 1;/);
assert.match(text.relay,/export const PRIVATE_CHAT_RELAY_VERSION = 1;/);
assert.match(text.migration,/OLD\.private_chat_lifecycle_required\s+AND\s+NOT\s+NEW\.private_chat_lifecycle_required/);
assert.ok(text.protocol.includes('privateChatLifecycleV1'));
const registry=JSON.parse(text.registry), tables=registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables;
assert.equal(tables.length,129);assert.equal(new Set(tables).size,129);assert.equal(tables[128],'classpilot_private_chat_threads');
const delivery=text.storage.slice(text.storage.indexOf('async function withClasspilotStudentControlDeliveryAuthorityCore'),text.storage.indexOf('export async function withClasspilotStudentWebSocketBootstrapAuthority'));
assert.match(delivery,/if \(options\.freezeSsoPolicy\)/);
assert.ok(delivery.indexOf('lockClasspilotSsoPolicyDeliveryAuthority')>0);
assert.ok(delivery.indexOf('lockClasspilotSsoPolicyDeliveryAuthority')<delivery.indexOf('lockPrivateChatChannel'));
const start=text.relay.indexOf('const authority = await withClasspilotStudentWebSocketBootstrapAuthority');
const bootstrap=text.relay.slice(start,text.relay.indexOf('const fab = await buildStudentFabState',start));
assert.ok(start>=0);assert.match(bootstrap,/freezeSsoPolicy: true/);
assert.doesNotMatch(bootstrap,/await lockClasspilotSsoPolicyDeliveryAuthority/);
assert.ok(!text.tenant.includes('tenantClientDatabases'));
assert.ok(text.tenant.includes('ownedTenantStores.delete(client)'));
assert.ok(text.monitoring.includes('getOwnedTenantStore'));
assert.ok(text.monitoring.includes('owned?.schoolId === schoolId'));
assert.ok(text.monitoring.includes('bypassCache: true'));
assert.ok(!existsSync('/app/dist/services/classpilotUsageExecution.js'));

const stopGuard=text.dispatcher.slice(text.dispatcher.indexOf('if (commandType === "stop-focus" &&'),text.dispatcher.indexOf('if (commandType === "activate-tab"'));
assert.ok(stopGuard.includes('target.studentId, target.studentSessionId, target.deviceId'));
assert.ok(stopGuard.includes('Number.isSafeInteger(exactBindingControlRevision)'));
assert.ok(stopGuard.includes('exactBindingControlRevision < 0'));
assert.match(stopGuard,/const deferredExactBindingEnvelope = \(commandType === "stop-focus"/);
assert.ok(stopGuard.includes('exactBinding: classpilotControlStateExactBinding'));
const fenceStart=text.storage.indexOf('async function assertClasspilotHeartbeatDeliveryCurrent');
const fenceEnd=text.storage.indexOf('export async function withClasspilotStudentControlDeliveryAuthority',fenceStart);
assert.ok(fenceStart>0&&fenceEnd>fenceStart);
const fence=text.storage.slice(fenceStart,fenceEnd);
assert.match(fence,/classpilotEntitledSchoolPredicate/);
assert.match(fence,/currentStudentSessionAuthorityPredicate/);
assert.match(fence,/INNER JOIN .*students/s);
assert.match(fence,/INNER JOIN .*devices/s);
for(const binding of ['options.schoolId','options.studentId','options.studentSessionId','options.deviceId']) assert.ok(fence.includes(binding));
assert.match(fence,/LIMIT 1 FOR SHARE/);
assert.match(fence,/status: 403, code: "CLASSPILOT_NOT_ENTITLED"/);
assert.match(fence,/current\.bound !== true[\s\S]*ClasspilotTeacherChatBindingLostError/);
assert.match(text.entitlement,/expiresAt} IS NULL OR .*expiresAt}>clock_timestamp\(\)/);
assert.match(delivery,/heartbeatFinalFence = false/);
assert.match(delivery,/const prepared = await prepareAuthorized\(transactionDb\);[\s\S]*if \(heartbeatFinalFence\) \{[\s\S]*await assertClasspilotHeartbeatDeliveryCurrent\(options, transactionDb\);[\s\S]*else if \(!\(await hasExactClasspilotTelemetryBinding[\s\S]*const value = onAuthorized\(claimed, prepared\)/);
const generic=text.storage.slice(fenceEnd,text.storage.indexOf('export async function withClasspilotHeartbeatDeliveryAuthority',fenceEnd));
assert.match(generic,/return withClasspilotStudentControlDeliveryAuthorityCore\(options, prepareAuthorized, onAuthorized\)/);
const heartbeatWrapper=text.storage.slice(text.storage.indexOf('export async function withClasspilotHeartbeatDeliveryAuthority'),text.storage.indexOf('export async function withClasspilotStudentWebSocketBootstrapAuthority'));
assert.match(heartbeatWrapper,/return withClasspilotStudentControlDeliveryAuthorityCore\(\{ \.\.\.options \}, prepareAuthorized, onAuthorized, true\)/);
const finalStart=text.heartbeat.indexOf('const finalDelivery = await runWithTenantContext');
const finalEnd=text.heartbeat.indexOf('return finalDelivery.value;',finalStart);
assert.ok(finalStart>0&&finalEnd>finalStart);
assert.ok(text.heartbeat.slice(finalStart,finalEnd).includes('withClasspilotHeartbeatDeliveryAuthority('));
assert.ok(!text.storage.includes('classpilot_heartbeat_foreground'));
assert.ok(!text.storage.includes('getClasspilotStudentControlDeliveryContext'));
const {parseClasspilotUsageModes,readClasspilotUsageModes}=await import('/app/dist/config/classpilotUsageModes.js');
assert.deepEqual(parseClasspilotUsageModes({}),{rollupMode:'off',digitalUsageMode:'off'});
assert.deepEqual(parseClasspilotUsageModes(),{rollupMode:'off',digitalUsageMode:'off'});
assert.deepEqual(readClasspilotUsageModes({RLS_GUC_ENABLED:'true',RLS_ENABLED_TABLES:tables.join(','),CLASSPILOT_USAGE_ROLLUP_MODE:'off',CLASSPILOT_DIGITAL_USAGE_MODE:'off'}),{rollupMode:'off',digitalUsageMode:'off'});

const classifyStart=text.heartbeat.indexOf('const realtimeSnapshot = realtimeStatusMutation.snapshot;');
const classifyEnd=text.heartbeat.indexOf('// --- Deliver any missed messages',classifyStart);
assert.ok(classifyStart>=0&&classifyEnd>classifyStart);
const classify=text.heartbeat.slice(classifyStart,classifyEnd);
assert.ok(classify.indexOf('registerHeartbeatClassificationWork();')<classify.indexOf('if (!realtimeSnapshot)'));
assert.equal((classify.match(/await foregroundTelemetrySettled/g)||[]).length,2);
assert.equal((classify.match(/heartbeatOptionalTelemetryFailures/g)||[]).length,3);
assert.match(classify,/finally\s*\{\s*(?:\/\/[^\n]*\n\s*)*finishForegroundTelemetry\(\);/);
assert.ok(!text.heartbeat.includes('classifyImmediateEducationalUrl'));

const dependencyVersions = {};
const expectedDependencyVersions = { express:'4.22.3', 'body-parser':'1.20.8', qs:'6.16.0', 'ip-address':'10.7.3', 'side-channel':'1.1.1', 'side-channel-list':'1.0.1' };
for (const [name, expected] of Object.entries(expectedDependencyVersions)) {
  dependencyVersions[name] = JSON.parse(readFileSync(`/app/node_modules/${name}/package.json`, 'utf8')).version;
  assert.equal(dependencyVersions[name], expected, name);
}
const {readClasspilotFocusStatusEnvelope,focusStatusChanged}=await import('/app/dist/services/classpilotFocus.js');
const active={state:'active',assignmentId:'synthetic-assignment'};
const reordered={assignmentId:'synthetic-assignment',state:'active'};
assert.deepEqual(readClasspilotFocusStatusEnvelope({focusStatus:active}),active);
assert.deepEqual(readClasspilotFocusStatusEnvelope({focus:active}),active);
assert.deepEqual(readClasspilotFocusStatusEnvelope({focusStatus:active,focus:reordered}),active);
assert.equal(readClasspilotFocusStatusEnvelope({focusStatus:{state:'bad'},focus:active}),undefined);
assert.equal(readClasspilotFocusStatusEnvelope({focusStatus:active,focus:{state:'active',assignmentId:'other'}}),undefined);
assert.equal(focusStatusChanged({focusStatusV1:reordered},active),false);
assert.equal(focusStatusChanged({focusStatusV1:active},{state:'active',assignmentId:'other'}),true);
assert.ok(text.heartbeat.includes('readClasspilotFocusStatusEnvelope(req.body)'));
assert.ok(text.relay.includes('readClasspilotFocusStatusEnvelope(message)'));
console.log(JSON.stringify({passed:true,focusCanonicalWireAndSemanticEquality:true,dependencyVersions,writerVersion:1,bridgeVersion:1,relayVersion:1,inventoryCount:129,stickyMigration:true,ssoLockOrderCorrection:true,monitoringOwnedLeaseCorrection:true,stopFocusExactV2Cleanup:true,classificationHistoryForegroundBarrier:true,heartbeatFinalClockFence:true,genericAndWsSemanticsPreserved:true,usageDefaultAndExplicitModesOff:true,metadataReuseAbsent:true,usageContentionCorrectionAbsent:true,usageModesRequired:'both off',hashes:Object.fromEntries(Object.entries(text).map(([k,v])=>[k,sha(v)])),scope:'Embedded file/marker/order validation only; no API/worker application process started or database connected.'},null,2));




