import { and, eq, sql } from "drizzle-orm";
import { classpilotStudentControlStates, classpilotSupervisionContexts, classpilotSupervisionStudents, devices, schools, studentSessions, students, teachingSessions } from "../schema/index.js";
import { compileFixedScalarQuery } from "../lib/fixedScalarQuery.js";
import { classpilotEntitledSchoolPredicate } from "./classpilotEntitlement.js";
import { currentStudentSessionAuthorityPredicate } from "./classpilotStudentSessionAuthority.js";

export type ClasspilotFixedQueryBinding = {
  schoolId: string; studentId: string; studentSessionId: string; deviceId: string;
};

// Compile only fixed SQL structure at initialization. Every invocation below
// binds the current exact tuple and executes through its caller's transaction.
// Canonical predicates remain the source of session and entitlement policy;
// neither authority, results, database clients nor transaction state is cached.
const options = {
  schoolId: sql.placeholder("schoolId"), studentId: sql.placeholder("studentId"),
  studentSessionId: sql.placeholder("studentSessionId"), deviceId: sql.placeholder("deviceId"),
};
const foreground = {
  teachingSessionId: sql.placeholder("teachingSessionId"),
  controlRevision: sql.placeholder("controlRevision"),
};
const bindingConditions = [
  eq(studentSessions.id, sql.param(options.studentSessionId, studentSessions.id)),
  eq(studentSessions.studentId, sql.param(options.studentId, studentSessions.studentId)),
  eq(studentSessions.deviceId, sql.param(options.deviceId, studentSessions.deviceId)),
  currentStudentSessionAuthorityPredicate(),
];

const liveBinding = compileFixedScalarQuery(sql`
      SELECT "student_sessions"."id"
      FROM "student_sessions"
      INNER JOIN "students" ON (
        "students"."id" = "student_sessions"."student_id"
        AND "students"."school_id" = ${options.schoolId}
        AND "students"."status" = ${"active"}
      )
      INNER JOIN "devices" ON (
        "devices"."device_id" = "student_sessions"."device_id"
        AND "devices"."school_id" = ${options.schoolId}
      )
      WHERE ${and(...bindingConditions)}
      LIMIT ${1} FOR SHARE
    `);

const heartbeatCurrent = compileFixedScalarQuery(sql`
    SELECT ${classpilotEntitledSchoolPredicate(sql`${options.schoolId}`)} AS entitled,
      EXISTS (SELECT 1 FROM ${studentSessions}
        INNER JOIN ${students} ON ${students.id}=${studentSessions.studentId}
          AND ${students.schoolId}=${options.schoolId} AND ${students.status}='active'
        INNER JOIN ${devices} ON ${devices.deviceId}=${studentSessions.deviceId}
          AND ${devices.schoolId}=${options.schoolId}
        WHERE ${studentSessions.id}=${options.studentSessionId}
          AND ${studentSessions.studentId}=${options.studentId}
          AND ${studentSessions.deviceId}=${options.deviceId}
          AND ${currentStudentSessionAuthorityPredicate()}
        LIMIT 1 FOR SHARE) AS bound,
      CASE WHEN NOT EXISTS (SELECT 1 FROM ${schools} WHERE ${schools.id}=${options.schoolId}) THEN 'school_missing'
        WHEN EXISTS (SELECT 1 FROM ${schools} WHERE ${schools.id}=${options.schoolId}
          AND ${schools.status}='active' AND ${schools.isActive}=true
          AND ${schools.disabledAt} IS NULL AND ${schools.deletedAt} IS NULL
          AND ${schools.planStatus}<>'canceled'
          AND (${schools.activeUntil} IS NULL OR ${schools.activeUntil}>clock_timestamp())) THEN 'license_inactive'
        ELSE 'school_inactive' END AS "denialReason"
  `);

const heartbeatForeground = compileFixedScalarQuery(sql`
          SELECT 1 AS allowed
          FROM ${classpilotStudentControlStates} control
          INNER JOIN ${teachingSessions} teaching ON teaching.id=control.teaching_session_id
            AND teaching.school_id=${options.schoolId}
          WHERE control.school_id=${options.schoolId} AND control.student_id=${options.studentId}
            AND control.teaching_session_id=${foreground.teachingSessionId}
            AND control.revision=${foreground.controlRevision} AND control.supervision_context_id IS NULL
            AND control.hard_expires_at>clock_timestamp()
            AND (control.scheduled_end_at IS NULL OR control.scheduled_end_at>clock_timestamp())
            AND teaching.session_mode='live' AND teaching.end_time IS NULL
            AND teaching.roster_snapshot_completed_at IS NOT NULL
            AND (teaching.scheduled_end_at IS NULL OR teaching.scheduled_end_at>clock_timestamp())
            AND ${classpilotEntitledSchoolPredicate(sql`${options.schoolId}`)}
            AND EXISTS (
              SELECT 1 FROM ${studentSessions}
              WHERE ${studentSessions.id}=${options.studentSessionId}
                AND ${studentSessions.studentId}=${options.studentId}
                AND ${studentSessions.deviceId}=${options.deviceId}
                AND ${currentStudentSessionAuthorityPredicate()}
            )
            AND NOT EXISTS (
              SELECT 1 FROM ${classpilotSupervisionStudents} assigned
              INNER JOIN ${classpilotSupervisionContexts} context ON context.id=assigned.context_id
                AND context.school_id=${options.schoolId} AND context.status='active'
                AND context.starts_at<=clock_timestamp() AND context.ends_at>clock_timestamp()
              WHERE assigned.school_id=${options.schoolId} AND assigned.student_id=${options.studentId}
                AND assigned.released_at IS NULL
            ) LIMIT 1
        `);

export function classpilotFixedLiveBindingQuery(binding: ClasspilotFixedQueryBinding) {
  return liveBinding(binding);
}

export function classpilotFixedHeartbeatCurrentQuery(binding: ClasspilotFixedQueryBinding) {
  return heartbeatCurrent(binding);
}

export function classpilotFixedHeartbeatForegroundQuery(
  binding: ClasspilotFixedQueryBinding, focus: { teachingSessionId: string; controlRevision: number },
) {
  return heartbeatForeground({ ...binding, teachingSessionId: focus.teachingSessionId, controlRevision: focus.controlRevision });
}
