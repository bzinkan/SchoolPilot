# Bounded production metadata inspection — external review candidate

This bundle is **prepared and locally validated; no AWS execution or production
query has occurred**. PowerShell and Node syntax checks passed, along with nine
Node control-flow cases, ten PowerShell function cases, seven full wrapper
orchestration/recovery scenarios and six native PostgreSQL 16 fixture cases.
The exact already-cached serving image passed offline Node/pg/CA and complete argv
checks. Independent read-only review found no additional blocker after the
recovery-filter correction. This external bundle changes no application source
or endpoint. Exact-plan execution still requires separate operational approval.
The current repository has only a six-table/three-migration My Desk inspector.
That cannot satisfy the release-wide catalog/ledger requirement. This wrapper
reuses its existing task-clone and private-file helpers, and the governed runtime
tool's AWS transport, service-stability and canonical-hash helpers. It uses the
already-published, exactly observed serving image, so inspection does not require
the future release image to be published first.

## Exact observed binding

- Account `135775632425`, region `us-east-1`, cluster
  `schoolpilot-production-cluster`.
- API task `schoolpilot-production-api-emergency:163`, freshly observed one instance.
- Worker task `schoolpilot-production-scheduler-worker:179`, observed one instance,
  512 CPU units / 1024 MiB.
- Both definitions reference source
  `7af9d0dd5bc2bd3e13b96d35a577725e07f8b678` and
  `135775632425.dkr.ecr.us-east-1.amazonaws.com/schoolpilot-production-api@sha256:c87433cdf3d88e0c291a50d1ae74fbc116f167048f7db9d6c2d1d0ebfc52b9e8`.
- Existing network and secret references only. The source network is re-read and
  hash-bound in the plan; its one security group must remain
  `sg-08af33c99e705a4b7`, with the observed public-IP/no-NAT posture. No ingress,
  service, autoscaling, TURN, ECS Exec or database configuration is changed.
- Database `schoolpilot-production-db`, database name `schoolpilot`, PostgreSQL
  16.4, endpoint
  `schoolpilot-production-db.cm7qgym2ufr2.us-east-1.rds.amazonaws.com:5432`, VPC
  `vpc-0e286e71a65c73ecb`.

Task definitions, service counts and RDS metadata were freshly read while preparing this bundle;
that refresh did not establish current service health or fetch credentials.
Plan and Execute re-read exact source/service/network/database bindings and fail
on drift. Future changes require a newly reviewed plan, not substitution of
these old observations as current health.

## What the task does

The wrapper registers one unique inspector task definition and runs one Fargate
task on the existing worker network. The registered command runs plain Node with
the reviewed external source passed as an argv string; no server, scheduler,
migration, storage or provider module is imported. Runtime overrides stay small.

The clone retains the existing execution role and logging channel, removes the
application task IAM role, drops every secret except the existing `DATABASE_URL`
reference, and replaces application environment/command values. Its root
filesystem is read-only. Database credentials are never fetched to the operator
machine or included in output. Connection fields are parsed in task memory and
the exact RDS hostname/database are checked. Explicit TLS settings verify the
server using the image's RDS CA bundle; URI parameters cannot weaken verification.

There is one database client, a 10-second connection deadline, a 45-second process
deadline, and a `REPEATABLE READ READ ONLY` transaction with 15-second statement,
two-second lock and 15-second idle deadlines. The wrapper bounds task observation
to four minutes, verifies exact task ownership, and cleans up only that task and
unique definition. A lost RunTask response retries the identical client token.
Ambiguous registration/cleanup remains a failed receipt, never success. A failed
task stop that has not reached `STOPPED` requires explicit terminal verification
before closing the operation.

The output is allowlisted and bounded to 2 MiB. It contains:

- Schema/relation/column, constraint/index, policy/trigger, function, enum/domain,
  sequence-option, view and extension metadata, with definitions/literals hashed.
  Sequence values, table rows, comments and function source are not exported.
- All migration ledger IDs, checksums, modes, statuses and application source
  identifiers, bounded to 1,024 rows.
- Current database-role superuser/bypass flags, without its role name.
- The unique `desalescincy.org` school UUID, school-name hash, eligibility flags
  and product-license status/expiry flags. No student/staff rows, names, email,
  chat content, settings payloads or contact/billing fields are read. Ambiguous
  school matches return no binding and cannot select a pilot.

Node emits independently indexed, whole-payload-hashed transport parts. The
wrapper validates complete transport, hashes, expected keys, row bounds and
scalar formats before saving the private receipt; unvalidated raw CloudWatch
messages are not persisted locally.

This is a catalog fingerprint and ledger inspection, **not a restorable schema
dump or production-data restore**. Compare its supported catalog fingerprints
and full ledger against the reconstructed local baseline before accepting that
baseline as representative. Unexpected schemas/object types or mismatches
require review. The inspector does not prove all PostgreSQL DDL attributes,
runtime RLS enforcement, grants/ownership equivalence, sequence values or data
compatibility. An actual-schema restore remains dependent on an approved
schema-only operator export or an additional separately reviewed export path.
Keep the existing rehearsal labeled reconstructed until that evidence exists.

## Local preparation evidence and remaining execution boundary

- `local-node-validation.json`: nine control-flow cases including absent and
  ambiguous pilot, strict explicit TLS options, eligibility, schema overflow,
  invalid checksum and unexpected global RLS rejection.
- `local-powershell-validation.json`: ten validator/task-clone cases, including
  tampering, missing/duplicate transport, exact keys and retained command identity.
- `local-orchestration-validation.json`: seven complete copied-wrapper scenarios
  with every AWS call intercepted: successful metadata, lost registration, an
  idempotently retried RunTask response, unknown RunTask already STOPPED, unresolved
  RunTask outcome, wrong ownership and invalid logs. The source wrapper is
  unchanged except for one documented test-adapter injection in a temporary copy.
- `local-native-sql-validation.json`: six cases running the original SQL through
  a test-only PostgreSQL adapter on an owned local PostgreSQL 16 fixture, including
  a NOSUPERUSER/NOBYPASSRLS reader, catalog functions/policies/types/triggers and
  `uuid-ossp`. The uniquely labelled fixture was removed. A READ ONLY transaction
  rejected writes even for the owner role.
- `serving-image-validation.json`: the exact serving image, offline and with a
  read-only filesystem, has `/app`, native Node ESM/pg and `/app/rds-ca.pem`. The
  full source argv executes and fails safely with no DATABASE_URL. No secret or
  production database connection was used; this does not prove native RDS TLS or
  actual application-role privileges.

Recovery follows the [ECS ListTasks contract](https://docs.aws.amazon.com/AmazonECS/latest/APIReference/API_ListTasks.html):
`startedBy` is used without another filter. When its default-running result is
empty after an unknown RunTask outcome, a separate unique-family STOPPED lookup
is followed by exact task-definition/startedBy validation. An unresolved outcome
remains a failed receipt and never implies that no task exists.

Before execution, review the final bundle hash and generated plan, confirm the
operational window, and obtain explicit authorization for this one bounded ECS
task. Recheck source/service/network/RDS bindings; drift requires a fresh plan.
No preparation test establishes actual production catalog or pilot identity.
The source binds a concrete existing image; **no final release digest is needed
for this inspection**. Remaining bindings are the freshly generated plan hash,
its actual existing subnet/secret/execution-role references, the reviewed
external/helper file hashes and the separately approved execution window. No
school UUID is invented; acquiring it is one of the operation's outputs.

## Concrete command sequence, after those checks

Plan performs AWS reads and private local file writes only:

```powershell
pwsh -NoProfile -File [USERPROFILE]/AppData/Local/Temp/release297-production-metadata-inspector-01/run-release-metadata-inspector.ps1 -Mode Plan -RepositoryRoot [USERPROFILE]/.codex/worktrees/release-stabilization-297/SchoolPilot -OutDir [USERPROFILE]/.codex/artifacts/release297-production-metadata-plan-01
```

Review `plan.json`, including source/image/network/121-table admission bindings,
the single database secret reference, the exact Node command and bounded task
resources. Record its printed SHA-256. **Plan is not execution authorization.**

Only after explicit authorization for this exact one-off task, use that hash:

```powershell
pwsh -NoProfile -File [USERPROFILE]/AppData/Local/Temp/release297-production-metadata-inspector-01/run-release-metadata-inspector.ps1 -Mode Execute -RepositoryRoot [USERPROFILE]/.codex/worktrees/release-stabilization-297/SchoolPilot -OutDir [USERPROFILE]/.codex/artifacts/release297-production-metadata-plan-01 -ApprovedPlanSha256 <exact-reviewed-plan-SHA256>
```

Do not rerun an execution with an existing receipt. Inspect/recover that recorded
run first. Require `status=inventoried`, `taskStopped=true`, successful owned
definition cleanup and an exact unique active DeSales binding before using the
result. Compare the UUID/name hash with the user's named school through the
authorized school interface; live authority and capabilities are rechecked during
actual actions. Bind this UUID consistently to all pilot plans and receipts.

The operation does not merge, deploy, apply migrations, change runtime flags,
publish the extension, or create a new database/network/paid media resource.
It does create a separately authorized ephemeral ECS task/definition and writes
its bounded metadata to the existing CloudWatch channel and private receipt.
