# Exact 8148 campaign configuration

This external helper prepares configuration only. It has no Docker or database calls, no campaign registration, no measurement release, no retries, and no capacity verdict. Application and harness files are unchanged. The implementation uses the checked-in `run-campaign.mjs`, journal, restored owner, snapshot loader and validator; it does not add an execution framework.

## Required real inputs

- Clean, self-contained LF source/host clone at `814844f344a45159152415b0fb6d7027f05b093e`.
- Final candidate preparation receipt and its exact hash, pinned scan receipt, helper binding and network-none runtime proof.
- Helper built with the **explicit `capacity-candidate` trailing argument** to `build-role-helper.mjs`. A default diagnostic helper is rejected. Candidate-mode helper permits diagnostic snapshot-only preparation as well as registered candidate attempts; the two modes remain distinct.
- Exact same-source schema-54 snapshot, exported while held before traffic, with all nine bound files, 2,000,002 heartbeat rows, 54 complete migration entries, 129-table registry, and the current America/New_York school-local date. Old e95/schema53 snapshots cannot be relabeled.
- Actual immutable local Redis image and pinned local Docker endpoint/executable. The generator does not inspect images itself; the existing owner verifies them before use.
- New, mutually disjoint campaign, evidence, private and config paths. Source/snapshot/receipts remain separate. Only config output is created by this helper.

`input-template.json` is deliberately not executable until all REPLACE values are replaced with real paths/hashes. The candidate receipt is already pinned from the completed 8148 build. The helper reads and hashes private snapshot files without printing/copying their contents.

## Manual sequence

1. Save one completed input JSON outside the source and artifact directories.
2. Run `node prepare-campaign-config.mjs <absolute-input-file>`.
3. Independently retain `generation-receipt.json` and its config hashes/trusted campaign hash. Review every argument before running the commands printed as structured arrays.
4. For a new campaign, invoke the exact bound `run-campaign.mjs declare <declare.json>`. This writes the immutable declaration, without launching anything. Its returned campaign hash must equal the generated trusted hash.
5. Separately invoke `run-campaign.mjs attempt <attempt.json>`. This registers exactly one attempt before fixture creation, then invokes the existing owner. Do not call `run-restored-role-scale.mjs` directly for candidate mode.
6. At `measurement-ready.json`, root inspects source/image/binding/run/nonce/mode/phase and the fresh authority horizon, obtains host quiet, and manually publishes the existing schema-2 gate. This helper never creates measurement-go or abort files.
7. Await complete receipts and actual exit/cleanup. A subsequent attempt requires a new config/evidence/private path and a separate explicit command; the journal rejects unfinished or unconfirmed prior ownership. Failed/setup/aborted attempts remain recorded and interrupt a successful streak.

For an existing campaign the generator compares its immutable declaration exactly and omits `declare.json`; it never edits the journal. It does not choose runs, close the journal/campaign, manufacture original-comparison evidence or claim acceptance. Three consecutive passing eligible attempts plus the separately bound original full comparison and explicit closure remain required by the existing contract.

## Unchanged workload and cold requirements

The generated mode is only `capacity-candidate`, phase `combined`, profiling off. Resources and limits come from the committed harness: API 1 CPU/2 GiB, worker .5 CPU/1 GiB, generator 2 CPU/1 GiB, coordinator .5 CPU/1 GiB, PG 4 CPU/4 GiB, Redis 1 CPU/256 MiB, pools 16/2/5/2 and default role heaps. All 6,000 HTTP200 offers, zero204/refusal/lateness, 64 reports, 2-million-row correctness/rollups, lifecycle, deadlines and drain checks remain unchanged.

The snapshot is a reusable immutable data input, not a warm database. Every attempt uses fresh role credentials and owned containers, validates complete native schema/data/RLS/function grants, performs standard ANALYZE, closes validation clients, holds the manual nonce gate, checks at least 15 minutes of authority horizon, restarts the same PG container, creates Redis in the restarted namespace, and runs the unchanged required preflights/workload. Host filesystem caches are not flushed and that limitation remains explicit. Exact role/container/PG volume cleanup and all 13 owner receipts are required.

The original comparison declaration uses the **complete sourceHashes inventory selected by release-enabled-scale.mjs**, not only its five required filenames. It binds the original 512 MiB process-heap topology separately; this is not a claim that role candidate processes use that heap cap.

## Validation scope

Pure tests cover the pinned source, closed override rejection, Windows path boundaries, and full original-comparison inventory. Actual generation must still pass against the future real helper/snapshot receipts. No native fixture, workload, automatic release or capacity claim is part of this preparation.
