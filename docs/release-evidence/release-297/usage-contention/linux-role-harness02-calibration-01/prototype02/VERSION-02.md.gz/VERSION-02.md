# Version02: diagnostic driver resources and API profile capture

This separate version preserves version01 and its failed9630 result. Production-role budgets remain API1CPU/2GiB, worker0.5CPU/1GiB, PostgreSQL4CPU/4GiB and unchanged pools/deadlines. Only the test generator budget changes to2CPU/1GiB; coordinator remains0.5CPU/1GiB. Stress calibration is explanatory and is not an added release prerequisite.

The host exit monitor waits for attach/log closure before Docker wait and final inspection, avoiding Docker wait's created-container zero status race. Nonzero exits remain unclean. The red regression,22-case follow-up and native exact exit1 proof are retained. The extended module suite passes36cases.

An explicitly requested ingest CPU profile adds the standard Node profiler flags only to the API role. Its whole evidence tree remains read-only, with exactly one precreated file mounted writable at /evidence/api.cpuprofile. No server implementation or actual generator module changes. A zero-traffic native check proved the mount produces a real sampled profile and exact clean API exit/cleanup; this is output-path proof, not application capacity.

This version remains diagnostic and unqualified for capacity acceptance. Its closed CPU variant requires ingestion, CPU profiling and diagnostic=true together. All6000 actual offers,100rps,1000in-flight,20s request deadlines and100ms lateness limits remain unchanged. All original current-day correctness, final authority and drain checks remain. Source5d54 helper/runtime binding is required before actual use. The inherited version01 design and old generated examples are historical context; final run plans come from these version02 modules and exact source/image binding.
