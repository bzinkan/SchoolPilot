& node 'C:/Users/zinka/.codex/artifacts/release297-role-host-814844f3-01/scripts/load/usage/roles/run-restored-role-scale.mjs' '<TEMP>/release297-role-diagnostic-8148-pressure-config-01/diagnostic.json'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
