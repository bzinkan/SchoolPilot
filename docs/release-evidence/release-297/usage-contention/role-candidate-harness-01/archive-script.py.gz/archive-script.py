import gzip,hashlib,json,re
from pathlib import Path
BASE=Path(r'C:/Users/zinka/AppData/Local/Temp')
OUTPUT=Path(r'C:/Users/zinka/.codex/artifacts/release297-role-candidate-harness-evidence-01')
SOURCES=[('integration',BASE/'release297-role-candidate-integration-01','2aa10b4f2b9f68200baaaadf18f56d0f5fcfba5a8607624e45ccc099025c960e'),('strict-counts',BASE/'release297-campaign-strict-counts-01','5578407e47aac28376a92294ed4046b70920043a3d41581e35f1a694d81517bc')]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def text(raw):
 try:return raw.decode('utf-8')
 except UnicodeDecodeError:return raw.decode('utf-16')
rows=[];verified=[]
for label,root,expected in SOURCES:
 raw=(root/'manifest.json').read_bytes();assert sha(raw)==expected
 m=json.loads(raw);declared=m.get('files',m.get('records',[]));assert declared
 for item in declared:
  relative=item.get('path',item.get('file'));p=Path(relative)
  assert not p.is_absolute() and '..' not in p.parts
  assert not any(part.lower().endswith(('.env','.dump','.backup','.tar','.sql')) for part in p.parts)
  assert not any(part.lower() in ['private','runtime.env','cold-fixture-state.json','secrets.json','credentials.json'] for part in p.parts)
  payload=(root/p).read_bytes();assert len(payload)==item['bytes'];assert sha(payload)==item['sha256']
  readable=text(payload)
  for pattern in [r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',r'\beyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}']:
   assert not re.search(pattern,readable)
  rows.append((label+'/'+relative,payload))
 rows.append((label+'/manifest.json',raw));verified.append({'packet':label,'manifestSha256':expected,'declaredFiles':len(declared),'allDeclaredHashesVerified':True})
rows.append(('archive-script.py',Path(__file__).read_bytes()))
OUTPUT.mkdir(exist_ok=False)
records=[]
for relative,payload in rows:
 target=OUTPUT/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(payload,compresslevel=9,mtime=0);target.write_bytes(packed)
 restored=gzip.decompress(target.read_bytes());assert restored==payload
 records.append({'path':relative+'.gz','logicalPath':relative,'bytes':len(payload),'gzipBytes':len(packed),'originalSha256':sha(payload),'safeSha256':sha(payload),'gzipSha256':sha(packed),'decompressedHashVerified':True,'redacted':False})
summary={'schemaVersion':1,'applicationSource':'e95a2b56476b1225434c1b0f3907db46c9d84fe3','scope':'Frozen candidate harness and pure strict-count/ownership regression evidence; no application changes or native candidate execution','sourceFileCount':56,'rolesFiles':55,'aggregate':{'passed':378,'failed':0,'skipped':0},'focusedFinal':{'passed':230,'failed':0},'failedAttemptsRetained':[{'name':'preflight gauges on prior validator','failed':12,'expectedRed':True},{'name':'initial candidate integration','passed':227,'failed':3,'cause':'CRLF-sensitive generator anchor and synthetic fixture nonce mismatch; repaired without weaker assertions'},{'name':'strict-counts old validator','failed':4,'expectedRed':True}],'strictCountsFinal':{'passed':145,'failed':0,'skipped':0},'schemaMigrations':53,'applicationChanges':0,'capacityAccepted':False,'acceptedRuns':0,'candidateExecutionNativeVerified':False,'historicalDiagnosticRelabeled':False,'productionActions':0,'limitations':['New candidate mode/attempt owner was verified with pure and real filesystem receipts, not a candidate workload.','Historical full restored e95 diagnostic remains numerically failed and permanently diagnostic.','Production readiness and deployed observation remain separate from the synthetic topology.']}
review={'schemaVersion':1,'selection':'Only exact source-manifest-listed files plus those manifests and this archive script; no recursive fixture directory capture','privateDumpEnvironmentCredentialsIncluded':False,'capturedRequestPayloadsIncluded':False,'credentialLikeMaterialReview':['Source templates interpolate future generated local credentials but include no values.','Fixed synthetic:synthetic localhost URLs in two pure test files are fabricated fixtures.','not-forwarded marker in a test is not an AWS credential.'],'sourceOrEvidenceRedacted':False,'highConfidenceCredentialPatternMatches':0,'gzipReadbackVerified':True,'originalManifestsUnchanged':True}
for name,value in [('summary.json',summary),('privacy-review.json',review)]:
 raw=(json.dumps(value,indent=2)+'\n').encode();(OUTPUT/name).write_bytes(raw)
manifest={'schemaVersion':1,'packet':'release297-role-candidate-harness-evidence-01','sourcePackets':verified,'summarySha256':sha((OUTPUT/'summary.json').read_bytes()),'privacyReviewSha256':sha((OUTPUT/'privacy-review.json').read_bytes()),'gzipFiles':len(records),'files':records,'applicationChanges':0,'capacityAccepted':False,'acceptedRuns':0,'candidateExecutionNativeVerified':False}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(OUTPUT/'manifest.json').write_bytes(raw)
for label,root,expected in SOURCES:assert sha((root/'manifest.json').read_bytes())==expected
print(json.dumps({'path':str(OUTPUT),'manifestSha256':sha(raw),'summarySha256':manifest['summarySha256'],'privacyReviewSha256':manifest['privacyReviewSha256'],'gzipFiles':len(records),'allVerified':True}))
