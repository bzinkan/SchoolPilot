import ts from 'file:///<WORKTREE>/node_modules/typescript/lib/typescript.js';
import { resolve } from 'node:path';
const root=process.cwd(), configPath=resolve(root,'tsconfig.tests.json');
const cf=ts.readConfigFile(configPath,ts.sys.readFile), c=ts.parseJsonConfigFileContent(cf.config,ts.sys,root,undefined,configPath);
const p=ts.createProgram({rootNames:c.fileNames,options:c.options});
for(const name of ['tests/ai-chat-flight-path-scope.test.ts','tests/passpilot-overdue-lifecycle.test.ts']){
 const f=p.getSourceFile(resolve(root,name));
 for(const d of p.getSemanticDiagnostics(f)){
 const at=d.file.getLineAndCharacterOfPosition(d.start);
 console.log(`${name}:${at.line+1} TS${d.code}: ${ts.flattenDiagnosticMessageText(d.messageText,'\n')}`);
 }
}
