import assert from 'node:assert/strict';import{execFileSync}from'node:child_process';import{readFileSync,writeFileSync}from'node:fs';import{join}from'node:path';import{randomBytes}from'node:crypto';import{verifyBinding}from'./verify-binding.mjs';
const [base,docker]=process.argv.slice(2),endpoint='npipe:////./pipe/dockerDesktopLinuxEngine',binding=JSON.parse(readFileSync(join(base,'runtime-image-binding.json'))),proof=verifyBinding(join(base,'runtime-image-binding.json'));
const env={...process.env};for(const k of ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS','BUILDX_BUILDER'])delete env[k];
const invoke=args=>execFileSync(docker,['--host',endpoint,...args],{env,encoding:'utf8',timeout:60000,maxBuffer:1024*1024,windowsHide:true});
const run=randomBytes(6).toString('hex'),name='schoolpilot-v8-default-probe-'+run;let id,cleanup=false,failed;
const save=(name,x)=>writeFileSync(join(base,name),JSON.stringify(x,null,2)+'\n',{flag:'wx'});
const inspect=()=>JSON.parse(invoke(['inspect',id]))[0];const owned=v=>{assert.equal(v.Id,id);assert.equal(v.Name,'/'+name);assert.equal(v.Config.Image,binding.roleImageId);assert.equal(v.Image,binding.runtimeConfigDigest);assert.equal(v.Config.Labels['codex.v8-default-probe'],run);};
try {
 const image=JSON.parse(invoke(['image','inspect',binding.roleImageId]))[0];assert.equal(image.Id,binding.runtimeConfigDigest);assert.ok(!image.Config.Env.some(x=>x.startsWith('NODE_OPTIONS=')));
 const args=['create','--name',name,'--label','codex.v8-default-probe='+run,'--network','none','--cpus','1','--memory','2147483648','--memory-swap','2147483648','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--user','node','--init','--no-healthcheck',
 '--mount','type=bind,source='+join(base,'prototype/runtime-fidelity.mjs')+',target=/runtime-fidelity.mjs,readonly','--mount','type=bind,source='+join(base,'probe-noop.mjs')+',target=/probe-noop.mjs,readonly',
 '--env','USAGE_SOURCE_REVISION='+binding.applicationSource,'--env','USAGE_RELEASE_ROLE=api','--env','USAGE_RELEASE_PHASE=ingest','--env','USAGE_RELEASE_DIAGNOSTIC=true','--env','USAGE_RELEASE_CPU_PROFILE=false',
 '--entrypoint','node',binding.roleImageId,'--import','/runtime-fidelity.mjs','/probe-noop.mjs'];
 id=invoke(args).trim();assert.match(id,/^[a-f0-9]{64}$/);owned(inspect());
 const raw=invoke(['start','--attach',id]);writeFileSync(join(base,'native-preloader-01.log'),raw,{flag:'wx'});
 const code=Number(invoke(['wait',id]).trim()),after=inspect();owned(after);assert.equal(code,0);assert.equal(after.State.ExitCode,0);assert.equal(after.State.Running,false);assert.equal(after.State.OOMKilled,false);
 // stderr from docker start is inherited by execFileSync unless explicitly piped;
 // receipt existence/real snapshots are captured by the command's combined log.
 save('native-preloader-01.json',{...proof,imageId:binding.roleImageId,containerId:id,source:binding.applicationSource,network:'none',cpu:1,memoryBytes:2147483648,exitCode:code,workloadOffers:0,applicationChanged:false});
} catch(e){failed=e;save('native-preloader-failure-01.json',{code:'NATIVE_PRELOADER_PROOF_FAILED',message:e.message});}
finally {if(id){try{const v=inspect();owned(v);if(v.State.Running)invoke(['kill',id]);invoke(['rm','--volumes',id]);const ids=invoke(['container','ls','--all','--no-trunc','--filter','id='+id,'--format','{{.ID}}']).trim();assert.equal(ids,'');cleanup=true;}catch(e){save('native-preloader-cleanup-failure-01.json',{message:e.message});}}save('native-preloader-cleanup-01.json',{containerId:id??null,cleanupPassed:cleanup});}
if(failed)throw failed;assert.equal(cleanup,true);console.log(JSON.stringify({nativePreloaderPassed:true,cleanupPassed:cleanup}));
