$script:LiveHarnessLeases = [ordered]@{}

function Start-OwnedLiveHarness {
    param(
        [Parameter(Mandatory = $true)][Collections.IDictionary]$Registry,
        [Parameter(Mandatory = $true)][ValidatePattern('^[a-z0-9-]+$')][string]$Name,
        [Parameter(Mandatory = $true)][string]$Directory
    )
    $resolvedDirectory = [IO.Path]::GetFullPath($Directory)
    $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $resolvedDirectory.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Live harness fixture must remain inside the owned temporary tree.' }
    if ($script:LiveHarnessLeases.Contains($Name)) { throw 'Live harness name is already owned.' }
    $fixtureScript = Join-Path $resolvedDirectory "$Name-live-harness.ps1"
    $readyPath = Join-Path $resolvedDirectory "$Name-harness-lifecycle.json"
    $releasePath = Join-Path $resolvedDirectory "$Name-harness-release.txt"
    foreach ($path in @($fixtureScript, $readyPath, $releasePath)) {
        if (Test-Path -LiteralPath $path) { throw 'Live harness fixture paths must be fresh.' }
    }
    $nonce = [Guid]::NewGuid().ToString('N')
    # Cover the existing fixture/monitor startup and completion budgets. This
    # ceiling only prevents an abandoned test child from living indefinitely.
    $maximumLifetimeSeconds = 2 * $script:MonitorStartupDeadlineSeconds + [math]::Ceiling($script:MonitorCompletionWatchdogMilliseconds / 1000)
    $childSource = @'
param([string]$ReadyPath, [string]$ReleasePath, [string]$Nonce, [int]$MaximumLifetimeSeconds)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$clock = [Diagnostics.Stopwatch]::StartNew()
$self = Get-Process -Id $PID
$ready = [ordered]@{ nonce=$Nonce; id=$PID; startedAtUtc=$self.StartTime.ToUniversalTime().ToString('o'); path=[IO.Path]::GetFullPath([string]$self.Path); maximumLifetimeSeconds=$MaximumLifetimeSeconds }
[IO.File]::WriteAllText("$ReadyPath.pending", ($ready | ConvertTo-Json -Compress), [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath "$ReadyPath.pending" -Destination $ReadyPath
while (-not (Test-Path -LiteralPath $ReleasePath)) {
    if ($clock.Elapsed.TotalSeconds -ge $MaximumLifetimeSeconds) { throw 'Owned live harness reached its test safety ceiling before release.' }
    Start-Sleep -Milliseconds 50
}
if ([IO.File]::ReadAllText($ReleasePath) -cne $Nonce) { throw 'Owned live harness release nonce does not match.' }
'@
    [IO.File]::WriteAllText($fixtureScript, $childSource, [Text.UTF8Encoding]::new($false))
    $lease = [pscustomobject]@{ name=$Name; nonce=$nonce; readyPath=$readyPath; releasePath=$releasePath; identity=$null }
    $script:LiveHarnessLeases.Add($Name, $lease)
    Start-OwnedTestProcess -Registry $Registry -Name $Name `
        -FilePath (Get-Process -Id $PID).Path `
        -ArgumentList @('-NoProfile','-File',$fixtureScript,'-ReadyPath',$readyPath,'-ReleasePath',$releasePath,'-Nonce',$nonce,'-MaximumLifetimeSeconds',[string]$maximumLifetimeSeconds) `
        -StandardOutputPath (Join-Path $resolvedDirectory "$Name.out") `
        -StandardErrorPath (Join-Path $resolvedDirectory "$Name.err")
    $lease.identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($script:MonitorStartupDeadlineSeconds)
    while (-not (Test-Path -LiteralPath $readyPath) -and [DateTimeOffset]::UtcNow -lt $deadline) {
        if ((Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name).hasExited) { break }
        Start-Sleep -Milliseconds 50
    }
    Assert-Condition (Test-Path -LiteralPath $readyPath) "Owned live harness '$Name' did not publish readiness."
    $ready = Get-Content -LiteralPath $readyPath -Raw | ConvertFrom-Json -DateKind String
    $identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    Assert-Condition (-not $identity.hasExited -and $ready.nonce -ceq $nonce -and $ready.id -eq $identity.id -and
        $ready.startedAtUtc -ceq $identity.startedAtUtc.ToUniversalTime().ToString('o') -and
        [string]::Equals($ready.path, [IO.Path]::GetFullPath($identity.path), [StringComparison]::OrdinalIgnoreCase)) `
        "Owned live harness '$Name' readiness must match its actual PID, start time, path and nonce."
    return $identity
}

function Release-OwnedLiveHarness {
    param([Collections.IDictionary]$Registry, [string]$Name)
    $lease = $script:LiveHarnessLeases[$Name]
    if ($null -eq $lease) { throw 'Live harness release has no owned lease.' }
    if (-not $Registry.Contains($Name)) { $script:LiveHarnessLeases.Remove($Name); return }
    $identity = Get-OwnedTestProcessSnapshot -Registry $Registry -Name $Name
    if ($null -ne $lease.identity -and ($identity.id -ne $lease.identity.id -or
        $identity.startedAtUtc -ne $lease.identity.startedAtUtc -or
        -not [string]::Equals($identity.path, $lease.identity.path, [StringComparison]::OrdinalIgnoreCase))) {
        throw 'Live harness release identity changed.'
    }
    [IO.File]::WriteAllText($lease.releasePath, $lease.nonce, [Text.UTF8Encoding]::new($false))
}

function Complete-OwnedLiveHarness {
    param([Collections.IDictionary]$Registry, [string]$Name)
    Release-OwnedLiveHarness -Registry $Registry -Name $Name
    $result = Complete-OwnedTestProcess -Registry $Registry -Name $Name -TimeoutMilliseconds $script:MonitorCompletionWatchdogMilliseconds
    Assert-Condition ($result.exitCode -eq 0) "Owned live harness '$Name' must exit successfully after release."
    $script:LiveHarnessLeases.Remove($Name)
}

function Release-AllOwnedLiveHarnesses {
    param([Collections.IDictionary]$Registry)
    $failures = [Collections.Generic.List[Exception]]::new()
    foreach ($name in @($script:LiveHarnessLeases.Keys)) {
        try { Release-OwnedLiveHarness -Registry $Registry -Name $name }
        catch { $failures.Add($_.Exception) }
    }
    if ($failures.Count -gt 0) { throw [AggregateException]::new('Live harness release failed.', $failures.ToArray()) }
}

if ($LiveHarnessLifecycleOnly) {
    $fixtureRoot = Join-Path ([IO.Path]::GetTempPath()) ('rollout-live-harness-proof-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($fixtureRoot)
    try {
        $normal = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'normal-release' -Directory $fixtureRoot
        Start-Sleep -Milliseconds 300
        Assert-Condition (-not (Get-OwnedTestProcessSnapshot -Registry $ownedTestProcesses -Name 'normal-release').hasExited) 'A ready harness must remain alive until its owner releases it.'
        Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'normal-release'
        Assert-Condition (-not $ownedTestProcesses.Contains('normal-release') -and -not $script:LiveHarnessLeases.Contains('normal-release')) 'Successful release must drain and forget only the owned child.'
        [void](Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name 'failed-case' -Directory $fixtureRoot)
        try { throw 'synthetic monitor case failure' }
        catch { Assert-Condition ($_.Exception.Message -ceq 'synthetic monitor case failure') 'Cleanup must retain the original case failure.' }
        finally {
            Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses
            Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses
            Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses
        }
        Assert-Condition ($ownedTestProcesses.Count -eq 0 -and $script:LiveHarnessLeases.Count -eq 0) 'Failed case cleanup must leave no owned process or lease.'
        Write-Host "Live harness lifecycle: PASS ($script:AssertionCount assertions)"
    }
    finally {
        try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses }
        finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses }
        $resolvedFixture = [IO.Path]::GetFullPath($fixtureRoot)
        $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if (-not $resolvedFixture.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected live harness proof cleanup path.' }
        Remove-Item -LiteralPath $resolvedFixture -Recurse -Force
        if ($null -ne $previousRolloutTestSentinel) { $env:SCHOOLPILOT_ROLLOUT_TEST_MODE=$previousRolloutTestSentinel } else { Remove-Item Env:SCHOOLPILOT_ROLLOUT_TEST_MODE -ErrorAction SilentlyContinue }
    }
    return
}
