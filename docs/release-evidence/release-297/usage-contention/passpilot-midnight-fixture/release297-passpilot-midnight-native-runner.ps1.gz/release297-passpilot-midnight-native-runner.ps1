param()
$ErrorActionPreference = 'Stop'
$repo = 'C:\Users\zinka\.codex\worktrees\release-stabilization-297\SchoolPilot'
$run = [guid]::NewGuid().ToString('N').Substring(0,12)
$container = 'schoolpilot-passpilot-rules-' + $run
$database = 'rules_native_' + $run
$owner = 'fixture_' + $run
$password = [REDACTED]
$out = Join-Path $env:TEMP ('release297-passpilot-midnight-native-' + $run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $repo
$native = $null
$results = @()
$files=@('tests/passpilot-rules.integration.test.ts','src/services/passpilotRules.ts','src/services/storage.ts','src/routes/passpilot/passes.ts','src/app.ts')
function Snapshot {
  return @($files | ForEach-Object { [ordered]@{file=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLower()} })
}
function Run-Suite([string]$Name,[string[]]$Arguments) {
  $before=Snapshot
  $psi=[System.Diagnostics.ProcessStartInfo]::new()
  $psi.FileName=(Get-Command node -CommandType Application | Select-Object -First 1).Source
  $psi.WorkingDirectory=$repo; $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true
  $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true
  foreach($arg in $Arguments){$psi.ArgumentList.Add($arg)}
  $script:native=[System.Diagnostics.Process]::new(); $script:native.StartInfo=$psi
  if(-not $script:native.Start()){throw 'Native process failed to start'}
  $stdout=$script:native.StandardOutput.ReadToEndAsync(); $stderr=$script:native.StandardError.ReadToEndAsync()
  $finished=$script:native.WaitForExit(120000)
  if(-not $finished){$script:native.Kill($true); $script:native.WaitForExit(10000) | Out-Null}
  [System.IO.File]::WriteAllText((Join-Path $out ($Name+'.log')), $stdout.GetAwaiter().GetResult()+$stderr.GetAwaiter().GetResult())
  $code=if($finished){$script:native.ExitCode}else{124}
  $script:native.Dispose();$script:native=$null
  return [ordered]@{name=$Name;arguments=$Arguments;exitCode=$code;timedOut=(-not $finished);before=$before;after=(Snapshot)}
}
try {
  $schema=Join-Path $out 'schema.sql'
  docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec schoolpilot-db pg_dump -U schoolpilot -d schoolpilot_redesign_usage_release297_20261002 --schema-only --no-owner --no-privileges | Set-Content -LiteralPath $schema -Encoding utf8
  if($LASTEXITCODE -ne 0){throw 'Read-only schema export failed'}
  $image=(docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect schoolpilot-db --format '{{.Image}}').Trim()
  docker --host npipe:////./pipe/dockerDesktopLinuxEngine run --detach --name $container --label "codex.passpilot-rules=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
  if($LASTEXITCODE -ne 0){throw 'Fixture create failed'}
  $ready=$false
  for($attempt=0;$attempt -lt 40;$attempt++){
    docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null
    if($LASTEXITCODE -eq 0){$ready=$true;break}
    Start-Sleep -Milliseconds 250
  }
  if(-not $ready){throw 'Fixture not ready'}
  $ports=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
  if($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1'){throw 'Fixture must stay local'}
  $port=$ports.'5432/tcp'[0].HostPort
  Get-Content -LiteralPath $schema -Raw | docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
  if($LASTEXITCODE -ne 0){throw 'Restore failed'}
  docker --host npipe:////./pipe/dockerDesktopLinuxEngine exec $container psql -U $owner -d $database -Atc 'SELECT current_user,rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user' *> (Join-Path $out 'owner-role.log')
  $env:JWT_SECRET=[REDACTED]
  $env:NODE_ENV='test';$env:REDIS_URL='';$env:SCHEDULER_ENABLED='false'
  $env:DATABASE_URL="postgresql://[REDACTED]@127.0.0.1:${port}/$database"
  $env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL;$env:ADMIN_DATABASE_URL=$env:DATABASE_URL
  Remove-Item Env:RLS_TEST_ROLE -ErrorAction SilentlyContinue
  $results+=Run-Suite 'full-real-clock' @('--import','./tests/test-environment.mjs','--import','tsx','--test','--test-concurrency=1','tests/passpilot-rules.integration.test.ts')
  $clock=Join-Path $out 'midnight-clock.mjs'
  [System.IO.File]::WriteAllText($clock,"import { mock } from 'node:test'; mock.timers.enable({ apis: ['Date'], now: new Date('2026-10-03T07:00:15.000Z') });`n")
  $clockUrl=([System.Uri]$clock).AbsoluteUri
  $results+=Run-Suite 'original-midnight-selection' @('--import',$clockUrl,'--import','./tests/test-environment.mjs','--import','tsx','--test','--test-concurrency=1','--test-name-pattern','keeps intended current-day|denies PASSPILOT_RULE_DESTINATION_CAPACITY|denies PASSPILOT_RULE_ENCOUNTER|lets only administrators override|exports one student','tests/passpilot-rules.integration.test.ts')
} finally {
  if($null -ne $native -and -not $native.HasExited){$native.Kill($true);$native.WaitForExit(10000)|Out-Null}
  $inspection=docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect $container --format '{{json .Config.Labels}}' 2>$null
  if($LASTEXITCODE -eq 0){
    $labels=$inspection|ConvertFrom-Json
    if($container -cne ('schoolpilot-passpilot-rules-'+$run) -or $labels.'codex.passpilot-rules' -cne $run){throw 'Cleanup ownership mismatch'}
    docker --host npipe:////./pipe/dockerDesktopLinuxEngine rm -f $container *> (Join-Path $out 'cleanup.log')
    if($LASTEXITCODE -ne 0){throw 'Owned fixture cleanup failed'}
  }
  $remaining=docker --host npipe:////./pipe/dockerDesktopLinuxEngine ps -a --filter "name=^/$container$" --format '{{.Names}}'
  $cleaned=$LASTEXITCODE -eq 0 -and [string]::IsNullOrWhiteSpace(($remaining -join ''))
  [ordered]@{source=(git rev-parse HEAD).Trim();scope='Owner-role DB suite; not restricted-role RLS proof';schemaDonor='schoolpilot_redesign_usage_release297_20261002';schemaSha256=(Get-FileHash -LiteralPath (Join-Path $out 'schema.sql')).Hash.ToLower();container=$container;database=$database;databaseImage=$image;results=$results;ownedCleanupComplete=$cleaned;productionMutations=0} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
  Write-Output ([ordered]@{evidence=$out;results=@($results|ForEach-Object{[ordered]@{name=$_.name;exitCode=$_.exitCode}});ownedCleanupComplete=$cleaned}|ConvertTo-Json -Depth 4 -Compress)
  if(-not $cleaned){throw 'Owned fixture removal unconfirmed'}
}
if(@($results|Where-Object{$_.exitCode -ne 0}).Count -gt 0){exit 1}
