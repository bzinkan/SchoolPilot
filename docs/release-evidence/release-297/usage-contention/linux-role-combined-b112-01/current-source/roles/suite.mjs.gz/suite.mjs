// Pure CI entry point: no Docker, database, image build or offered workload.
import './prototype.test.mjs';
import './adapters.test.mjs';
import './orchestrator.test.mjs';
import './runtime-contract.test.mjs';
import './image-probe.test.mjs';
