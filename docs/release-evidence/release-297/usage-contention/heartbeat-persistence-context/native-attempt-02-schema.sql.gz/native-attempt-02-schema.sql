--
-- PostgreSQL database dump
--

\restrict SFMAFkgkkKySIkXHCtlkoLCHW8nK7zTLLUWeojHWE0XFRF0rR7I4xo0cY1gf6ld

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: check_classpilot_teacher_preferences_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_classpilot_teacher_preferences_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.teacher_id) THEN
    RAISE EXCEPTION 'Teacher preference owner must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_mydesk_author_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_mydesk_author_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.author_id) THEN
    RAISE EXCEPTION 'My Desk author must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_mydesk_import_author_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_mydesk_import_author_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.author_id) THEN
    RAISE EXCEPTION 'My Desk import author must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_mydesk_preferences_author_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_mydesk_preferences_author_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.author_id) THEN
    RAISE EXCEPTION 'My Desk preference author must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_mydesk_seating_author_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_mydesk_seating_author_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.author_id) THEN
    RAISE EXCEPTION 'My Desk seating author must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_passpilot_kiosk_activity_parent(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_passpilot_kiosk_activity_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.supervision_context_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM classpilot_supervision_contexts WHERE id=NEW.supervision_context_id AND school_id=NEW.school_id
  ) THEN RAISE EXCEPTION 'Pass activity must belong to the same school' USING ERRCODE='23514'; END IF;
  IF NEW.issuing_kiosk_session_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM passpilot_kiosk_sessions WHERE id=NEW.issuing_kiosk_session_id AND school_id=NEW.school_id
  ) THEN RAISE EXCEPTION 'Pass kiosk must belong to the same school' USING ERRCODE='23514'; END IF;
  RETURN NEW;
END $$;


--
-- Name: check_passpilot_kiosk_teacher_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_passpilot_kiosk_teacher_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.teacher_id) THEN
    RAISE EXCEPTION 'Kiosk teacher must belong to the same school' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: check_roster_integration_target_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_roster_integration_target_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME='roster_integration_identities' THEN
  IF NEW.entity_type='student' AND NOT EXISTS(SELECT 1 FROM students WHERE school_id=NEW.school_id AND id=NEW.internal_id) THEN RAISE EXCEPTION 'Roster student target must belong to school' USING ERRCODE='23514'; END IF;
  IF NEW.entity_type='class' AND NOT EXISTS(SELECT 1 FROM groups WHERE school_id=NEW.school_id AND id=NEW.internal_id) THEN RAISE EXCEPTION 'Roster class target must belong to school' USING ERRCODE='23514'; END IF;
  IF NEW.entity_type='teacher' AND NOT EXISTS(SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.internal_id AND status='active' AND role IN ('teacher','admin','school_admin')) THEN RAISE EXCEPTION 'Roster teacher target must be active school teaching staff' USING ERRCODE='23514'; END IF;
 ELSE
  IF NEW.member_type='student' AND NOT EXISTS(SELECT 1 FROM students WHERE school_id=NEW.school_id AND id=NEW.member_id) THEN RAISE EXCEPTION 'Roster membership student must belong to school' USING ERRCODE='23514'; END IF;
  IF NEW.member_type='teacher' AND NOT EXISTS(SELECT 1 FROM school_memberships WHERE school_id=NEW.school_id AND user_id=NEW.member_id) THEN RAISE EXCEPTION 'Roster membership teacher must belong to school' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: classpilot_bind_poll_response_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_bind_poll_response_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE expected_school TEXT;
      BEGIN
        SELECT school_id INTO expected_school FROM polls WHERE id = NEW.poll_id;
        IF expected_school IS NULL OR (NEW.school_id IS NOT NULL AND NEW.school_id <> expected_school) THEN
          RAISE EXCEPTION 'poll response tenant does not match poll' USING ERRCODE = '23514';
        END IF;
        NEW.school_id := expected_school;
        IF NOT EXISTS (
          SELECT 1 FROM students student
          WHERE student.id = NEW.student_id AND student.school_id = expected_school
        ) THEN
          RAISE EXCEPTION 'poll response student does not belong to the poll school' USING ERRCODE = '23514';
        END IF;
        IF NEW.device_id IS NOT NULL AND NOT EXISTS (
          SELECT 1 FROM devices device
          WHERE device.device_id = NEW.device_id AND device.school_id = expected_school
        ) THEN
          RAISE EXCEPTION 'poll response device does not belong to the poll school' USING ERRCODE = '23514';
        END IF;
        NEW.updated_at := COALESCE(NEW.updated_at, clock_timestamp());
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_bind_poll_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_bind_poll_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE
        expected_school TEXT;
        start_command_matches BOOLEAN;
        close_command_matches BOOLEAN;
      BEGIN
        -- Expanded rows remain guarded during legacy bootstrap convergence.
        IF to_jsonb(NEW)->>'supervision_context_id' IS NOT NULL THEN
          PERFORM classpilot_validate_activity_record(to_jsonb(NEW), 'session_id', TG_TABLE_NAME, TG_OP, to_jsonb(OLD));
          RETURN NEW;
        END IF;
        SELECT school_id INTO expected_school FROM teaching_sessions WHERE id = NEW.session_id;
        IF expected_school IS NULL OR (NEW.school_id IS NOT NULL AND NEW.school_id <> expected_school) THEN
          RAISE EXCEPTION 'poll tenant does not match teaching session' USING ERRCODE = '23514';
        END IF;
        NEW.school_id := expected_school;
        IF NEW.is_active AND NEW.start_command_id IS NULL THEN
          RAISE EXCEPTION 'active poll requires start command authority' USING ERRCODE = '23514';
        END IF;
        IF NEW.start_command_id IS NOT NULL THEN
          SELECT EXISTS (
            SELECT 1 FROM classpilot_commands command
            WHERE command.id = NEW.start_command_id
              AND command.school_id = expected_school
              AND command.teaching_session_id = NEW.session_id
              AND command.supervision_context_id IS NULL
              AND command.teacher_id = NEW.teacher_id
              AND command.command_type = 'poll'
              AND command.command_payload->>'action' = 'start'
          ) INTO start_command_matches;
          IF NOT start_command_matches THEN
            RAISE EXCEPTION 'poll command authority does not match its session' USING ERRCODE = '23514';
          END IF;
        END IF;
        IF NEW.close_command_id IS NOT NULL THEN
          SELECT EXISTS (
            SELECT 1 FROM classpilot_commands command
            WHERE command.id = NEW.close_command_id
              AND command.school_id = expected_school
              AND command.teaching_session_id = NEW.session_id
              AND command.supervision_context_id IS NULL
              AND command.command_type = 'poll'
              AND command.command_payload->>'action' = 'close'
          ) INTO close_command_matches;
          IF NOT close_command_matches THEN
            RAISE EXCEPTION 'poll command authority does not match its session' USING ERRCODE = '23514';
          END IF;
        END IF;
        NEW.updated_at := COALESCE(NEW.updated_at, clock_timestamp());
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_bind_session_setting_school(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_bind_session_setting_school() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE expected_school TEXT;
      BEGIN
        -- Expanded rows remain guarded during legacy bootstrap convergence.
        IF to_jsonb(NEW)->>'supervision_context_id' IS NOT NULL THEN
          PERFORM classpilot_validate_activity_record(to_jsonb(NEW), 'session_id', TG_TABLE_NAME, TG_OP, to_jsonb(OLD));
          RETURN NEW;
        END IF;
        SELECT school_id INTO expected_school FROM teaching_sessions WHERE id = NEW.session_id;
        IF expected_school IS NULL OR (NEW.school_id IS NOT NULL AND NEW.school_id <> expected_school) THEN
          RAISE EXCEPTION 'session setting tenant does not match teaching session' USING ERRCODE = '23514';
        END IF;
        NEW.school_id := expected_school;
        NEW.lifecycle_revision := GREATEST(COALESCE(NEW.lifecycle_revision, 1), 1);
        NEW.updated_at := COALESCE(NEW.updated_at, clock_timestamp());
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_bump_help_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_bump_help_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
  INSERT INTO session_settings(school_id,session_id,supervision_context_id) VALUES(NEW.school_id,NEW.teaching_session_id,NEW.supervision_context_id) ON CONFLICT DO NOTHING;
  UPDATE session_settings SET tools_revision=tools_revision+1 WHERE school_id=NEW.school_id
    AND session_id IS NOT DISTINCT FROM NEW.teaching_session_id AND supervision_context_id IS NOT DISTINCT FROM NEW.supervision_context_id;
  RETURN NEW;
END $$;


--
-- Name: classpilot_end_reassigned_routines(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_end_reassigned_routines() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
  UPDATE classpilot_routine_runs SET ended_at=now(),updated_at=now(),revision=revision+1
    WHERE school_id=NEW.school_id AND supervision_context_id=NEW.id AND ended_at IS NULL;
  RETURN NEW;
END $$;


--
-- Name: classpilot_preserve_classroom_authority_revision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_preserve_classroom_authority_revision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.classroom_authority_revision := CASE WHEN NEW.assigned_staff_id IS DISTINCT FROM OLD.assigned_staff_id
    THEN OLD.classroom_authority_revision + 1 ELSE OLD.classroom_authority_revision END;
  RETURN NEW;
END $$;


--
-- Name: classpilot_protect_schedule_change_leg_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_protect_schedule_change_leg_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    BEGIN
      IF NEW.school_id IS DISTINCT FROM OLD.school_id
        OR NEW.schedule_change_id IS DISTINCT FROM OLD.schedule_change_id
        OR NEW.scheduled_date IS DISTINCT FROM OLD.scheduled_date
        OR NEW.leg_order IS DISTINCT FROM OLD.leg_order
        OR NEW.group_id IS DISTINCT FROM OLD.group_id
        OR NEW.primary_teacher_id_snapshot IS DISTINCT FROM OLD.primary_teacher_id_snapshot
        OR NEW.class_name_snapshot IS DISTINCT FROM OLD.class_name_snapshot
        OR NEW.original_start_time IS DISTINCT FROM OLD.original_start_time
        OR NEW.original_end_time IS DISTINCT FROM OLD.original_end_time
        OR NEW.effective_start_time IS DISTINCT FROM OLD.effective_start_time
        OR NEW.effective_end_time IS DISTINCT FROM OLD.effective_end_time
        OR NEW.created_at IS DISTINCT FROM OLD.created_at
        OR (
          NEW.reservation_active IS DISTINCT FROM OLD.reservation_active
          AND NOT (OLD.reservation_active = true AND NEW.reservation_active = false)
        )
      THEN
        RAISE EXCEPTION 'ClassPilot schedule change legs are immutable'
          USING ERRCODE = '23514';
      END IF;
      RETURN NEW;
    END
    $$;


--
-- Name: classpilot_set_report_authorization_marker(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_set_report_authorization_marker() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
      marker_salt TEXT;
      marker_digests JSONB;
    BEGIN
      IF NEW.authorization_marker IS NULL THEN
        marker_salt := gen_random_uuid()::text;
        SELECT COALESCE(
          jsonb_agg(
            to_jsonb(rtrim(translate(encode(sha256(convert_to(concat_ws('|',
              'classpilot-report-staff-v1', marker_salt, NEW.school_id,
              NEW.teaching_session_id, staff.staff_id
            ), 'UTF8')), 'base64'), '+/', '-_'), '='))
            ORDER BY staff.staff_id
          ),
          '[]'::jsonb
        )
        INTO marker_digests
        FROM classpilot_session_staff AS staff
        WHERE staff.school_id = NEW.school_id
          AND staff.teaching_session_id = NEW.teaching_session_id;
        NEW.authorization_marker := jsonb_build_object(
          'version', 1,
          'salt', marker_salt,
          'digests', marker_digests
        );
      END IF;
      RETURN NEW;
    END
    $$;


--
-- Name: classpilot_validate_active_hand_parents(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_active_hand_parents() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        -- Expanded rows remain guarded during legacy bootstrap convergence.
        IF to_jsonb(NEW)->>'supervision_context_id' IS NOT NULL THEN
          PERFORM classpilot_validate_activity_record(to_jsonb(NEW), 'teaching_session_id', TG_TABLE_NAME, TG_OP, to_jsonb(OLD));
          RETURN NEW;
        END IF;
        IF NOT EXISTS (
          SELECT 1
          FROM teaching_sessions session
          JOIN students student
            ON student.id = NEW.student_id AND student.school_id = NEW.school_id
          WHERE session.id = NEW.teaching_session_id
            AND session.school_id = NEW.school_id
        ) THEN
          RAISE EXCEPTION 'active hand session and student must belong to the same school'
            USING ERRCODE = '23514';
        END IF;
        IF (
          TG_OP = 'INSERT'
          OR NEW.cleared_at IS NULL
          OR NEW.device_id IS DISTINCT FROM OLD.device_id
          OR NEW.school_id IS DISTINCT FROM OLD.school_id
        ) AND NOT EXISTS (
          SELECT 1 FROM devices device
          WHERE device.device_id = NEW.device_id AND device.school_id = NEW.school_id
        ) THEN
          RAISE EXCEPTION 'active hand device must belong to the same school'
            USING ERRCODE = '23514';
        END IF;
        IF NEW.cleared_at IS NOT NULL
           AND EXISTS (SELECT 1 FROM devices any_device WHERE any_device.device_id = NEW.device_id)
           AND NOT EXISTS (
             SELECT 1 FROM devices device
             WHERE device.device_id = NEW.device_id AND device.school_id = NEW.school_id
           ) THEN
          RAISE EXCEPTION 'cleared hand device cannot belong to another school'
            USING ERRCODE = '23514';
        END IF;
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_validate_activity_parent(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_activity_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM classpilot_validate_activity_record(to_jsonb(NEW), TG_ARGV[0], TG_TABLE_NAME, TG_OP, to_jsonb(OLD));
  RETURN NEW;
END $$;


--
-- Name: classpilot_validate_activity_record(jsonb, text, text, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_activity_record(body jsonb, parent_column text, relation_name text, operation text, old_body jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE session_ref TEXT; context_ref TEXT; expected_school TEXT;
BEGIN
  session_ref := body->>parent_column; context_ref := body->>'supervision_context_id';
  IF num_nonnulls(session_ref,context_ref) <> 1 THEN
    RAISE EXCEPTION 'classroom activity requires exactly one parent' USING ERRCODE='23514';
  END IF;
  IF session_ref IS NOT NULL THEN SELECT school_id INTO expected_school FROM teaching_sessions WHERE id=session_ref;
  ELSE SELECT school_id INTO expected_school FROM classpilot_supervision_contexts WHERE id=context_ref; END IF;
  IF expected_school IS NULL OR body->>'school_id' IS DISTINCT FROM expected_school THEN
    RAISE EXCEPTION 'classroom activity parent belongs to another school' USING ERRCODE='23514';
  END IF;
  IF body->>'student_id' IS NOT NULL AND NOT EXISTS(SELECT 1 FROM students WHERE id=body->>'student_id' AND school_id=expected_school) THEN
    RAISE EXCEPTION 'classroom activity student belongs to another school' USING ERRCODE='23514';
  END IF;
  IF body->>'device_id' IS NOT NULL AND EXISTS(SELECT 1 FROM devices WHERE device_id=body->>'device_id' AND school_id<>expected_school) THEN
    RAISE EXCEPTION 'classroom activity device belongs to another school' USING ERRCODE='23514';
  END IF;
  IF relation_name='classpilot_active_hands' AND (operation='INSERT' OR body->>'cleared_at' IS NULL
    OR body->>'device_id' IS DISTINCT FROM old_body->>'device_id')
    AND NOT EXISTS(SELECT 1 FROM devices WHERE device_id=body->>'device_id' AND school_id=expected_school) THEN
    RAISE EXCEPTION 'active hand requires a same-school device' USING ERRCODE='23514';
  END IF;
  IF relation_name='classpilot_chat_deliveries' AND NOT EXISTS(
    SELECT 1 FROM chat_messages message WHERE message.id=body->>'chat_message_id' AND message.school_id=expected_school
      AND message.session_id IS NOT DISTINCT FROM session_ref
      AND message.supervision_context_id IS NOT DISTINCT FROM context_ref
      AND message.student_id=body->>'student_id') THEN
    RAISE EXCEPTION 'chat delivery must match the exact message activity and student' USING ERRCODE='23514';
  END IF;
  IF relation_name='polls' THEN
    IF (body->>'is_active')::boolean AND body->>'start_command_id' IS NULL THEN
      RAISE EXCEPTION 'active poll requires start command authority' USING ERRCODE='23514';
    END IF;
    IF body->>'start_command_id' IS NOT NULL AND NOT EXISTS(
      SELECT 1 FROM classpilot_commands command WHERE command.id=body->>'start_command_id' AND command.school_id=expected_school
        AND command.teaching_session_id IS NOT DISTINCT FROM session_ref AND command.supervision_context_id IS NOT DISTINCT FROM context_ref
        AND command.teacher_id=body->>'teacher_id' AND command.command_type='poll' AND command.command_payload->>'action'='start') THEN
      RAISE EXCEPTION 'poll start command must match its activity' USING ERRCODE='23514';
    END IF;
    IF body->>'close_command_id' IS NOT NULL AND NOT EXISTS(
      SELECT 1 FROM classpilot_commands command WHERE command.id=body->>'close_command_id' AND command.school_id=expected_school
        AND command.teaching_session_id IS NOT DISTINCT FROM session_ref AND command.supervision_context_id IS NOT DISTINCT FROM context_ref
        AND command.command_type='poll' AND command.command_payload->>'action'='close') THEN
      RAISE EXCEPTION 'poll close command must match its activity' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN;
END $$;


--
-- Name: classpilot_validate_chat_delivery_parents(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_chat_delivery_parents() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        -- Expanded rows remain guarded during legacy bootstrap convergence.
        IF to_jsonb(NEW)->>'supervision_context_id' IS NOT NULL THEN
          PERFORM classpilot_validate_activity_record(to_jsonb(NEW), 'teaching_session_id', TG_TABLE_NAME, TG_OP, to_jsonb(OLD));
          RETURN NEW;
        END IF;
        IF NOT EXISTS (
          SELECT 1
          FROM chat_messages message
          JOIN teaching_sessions session
            ON session.id = NEW.teaching_session_id AND session.school_id = NEW.school_id
          JOIN students student
            ON student.id = NEW.student_id AND student.school_id = NEW.school_id
          WHERE message.id = NEW.chat_message_id
            AND message.school_id = NEW.school_id
            AND message.session_id = NEW.teaching_session_id
            AND message.student_id = NEW.student_id
        ) THEN
          RAISE EXCEPTION 'chat delivery parents must belong to the same school and binding'
            USING ERRCODE = '23514';
        END IF;
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_validate_command_message_parents(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_command_message_parents() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        IF NEW.command_id IS NOT NULL AND NOT EXISTS (
          SELECT 1
          FROM classpilot_commands command
          JOIN classpilot_command_targets target
            ON target.command_id = command.id
           AND target.school_id = command.school_id
           AND target.student_id = NEW.to_student_id
          WHERE command.id = NEW.command_id
            AND command.school_id = NEW.school_id
            AND command.command_type = 'teacher-message'
            AND command.teaching_session_id IS NOT DISTINCT FROM NEW.teaching_session_id
            AND command.supervision_context_id IS NOT DISTINCT FROM NEW.supervision_context_id
        ) THEN
          RAISE EXCEPTION 'teacher message must match its command target and authority'
            USING ERRCODE = '23514';
        END IF;
        RETURN NEW;
      END
      $$;


--
-- Name: classpilot_validate_lesson_progress(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_lesson_progress() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
  IF NOT EXISTS(SELECT 1 FROM classpilot_lesson_activities WHERE id=NEW.lesson_activity_id AND school_id=NEW.school_id
    AND teaching_session_id IS NOT DISTINCT FROM NEW.teaching_session_id AND supervision_context_id IS NOT DISTINCT FROM NEW.supervision_context_id) THEN
    RAISE EXCEPTION 'lesson progress parent mismatch' USING ERRCODE='23514';
  END IF; RETURN NEW; END $$;


--
-- Name: classpilot_validate_schedule_change_leg_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_schedule_change_leg_count() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
    DECLARE
      target_change_id TEXT;
      leg_count INTEGER;
    BEGIN
      IF TG_TABLE_NAME = 'classpilot_schedule_changes' THEN
        target_change_id := COALESCE(NEW.id, OLD.id);
      ELSE
        target_change_id := COALESCE(NEW.schedule_change_id, OLD.schedule_change_id);
      END IF;
      IF EXISTS (SELECT 1 FROM classpilot_schedule_changes WHERE id = target_change_id) THEN
        SELECT count(*)::integer INTO leg_count
        FROM classpilot_schedule_change_legs
        WHERE schedule_change_id = target_change_id;
        IF leg_count <> 2 THEN
          RAISE EXCEPTION 'ClassPilot schedule change must contain exactly two legs'
            USING ERRCODE = '23514';
        END IF;
      END IF;
      RETURN COALESCE(NEW, OLD);
    END
    $$;


--
-- Name: classpilot_validate_tool_links(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classpilot_validate_tool_links() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE body JSONB:=to_jsonb(NEW); prior JSONB; target_id TEXT; targets JSONB;
BEGIN
  IF TG_OP='UPDATE' THEN
    prior:=to_jsonb(OLD);
    IF body->>'school_id' IS DISTINCT FROM prior->>'school_id'
      OR body->>'teaching_session_id' IS DISTINCT FROM prior->>'teaching_session_id'
      OR body->>'supervision_context_id' IS DISTINCT FROM prior->>'supervision_context_id'
      OR body->>'teacher_id' IS DISTINCT FROM prior->>'teacher_id'
      OR body->>'student_id' IS DISTINCT FROM prior->>'student_id'
      OR body->>'start_command_id' IS DISTINCT FROM prior->>'start_command_id' THEN
      RAISE EXCEPTION 'Class tools ownership is immutable' USING ERRCODE='23514';
    END IF;
  END IF;
  IF body->>'start_command_id' IS NOT NULL AND NOT EXISTS(SELECT 1 FROM classpilot_commands c
    WHERE c.id=body->>'start_command_id' AND c.school_id=NEW.school_id
      AND c.teaching_session_id IS NOT DISTINCT FROM body->>'teaching_session_id'
      AND c.supervision_context_id IS NOT DISTINCT FROM body->>'supervision_context_id'
      AND c.command_type=CASE WHEN TG_TABLE_NAME='classpilot_timers' THEN 'timer' ELSE 'lesson-activity' END
      AND c.command_payload->>'action'='start') THEN
    RAISE EXCEPTION 'Class tools start command parent mismatch' USING ERRCODE='23514';
  END IF;
  IF body->>'teacher_id' IS NOT NULL AND TG_OP='INSERT' AND NOT EXISTS(SELECT 1 FROM school_memberships m
    WHERE m.school_id=NEW.school_id AND m.user_id=body->>'teacher_id' AND m.status='active' AND m.role IN ('teacher','admin','school_admin','office_staff')) THEN
    RAISE EXCEPTION 'Class tools teacher must belong to the school' USING ERRCODE='23514';
  END IF;
  targets:=COALESCE(body->'excluded_student_ids','[]') || COALESCE(body->'used_student_ids','[]') || COALESCE(body->'target_student_ids','[]');
  IF body->>'selected_student_id' IS NOT NULL THEN targets:=targets || jsonb_build_array(body->>'selected_student_id'); END IF;
  IF jsonb_typeof(targets)<>'array' OR jsonb_array_length(targets)>2000 THEN RAISE EXCEPTION 'Invalid tool recipients' USING ERRCODE='23514'; END IF;
  FOR target_id IN SELECT jsonb_array_elements_text(targets) LOOP
    IF NOT EXISTS(SELECT 1 FROM students WHERE id=target_id AND school_id=NEW.school_id) THEN
      RAISE EXCEPTION 'Class tools recipient school mismatch' USING ERRCODE='23514';
    END IF;
  END LOOP;
  RETURN NEW;
END $$;


--
-- Name: complete_passpilot_appointment_from_pass(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.complete_passpilot_appointment_from_pass() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.status='active' AND NEW.status IN ('returned','canceled') THEN
  -- Pre-activation expansion compatibility only: an old restricted pass writer
  -- may not yet have the new table's grants. Governed activation requires all
  -- writers/grants to be compatible; after activation rollback retains them.
  -- PostgreSQL comma-separated privileges mean ANY, so check each separately.
  IF NOT has_table_privilege(current_user,'public.passpilot_appointments','SELECT')
     OR NOT has_table_privilege(current_user,'public.passpilot_appointments','UPDATE') THEN
   RETURN NEW;
  END IF;
  UPDATE passpilot_appointments SET
   status=CASE WHEN NEW.status='returned' THEN 'completed' ELSE 'cancelled' END,
   completed_at=CASE WHEN NEW.status='returned' THEN COALESCE(NEW.returned_at AT TIME ZONE 'UTC',clock_timestamp()) ELSE completed_at END,
   cancelled_at=CASE WHEN NEW.status='canceled' THEN clock_timestamp() ELSE cancelled_at END,
   revision=revision+1, updated_at=clock_timestamp()
  WHERE school_id=NEW.school_id AND student_id=NEW.student_id AND pass_id=NEW.id AND status='activated';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: copy_mailpilot_safety_review(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.copy_mailpilot_safety_review() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE email_alerts SET reviewed_at=NEW.reviewed_at,reviewed_by=COALESCE(reviewed_by,NEW.reviewed_by)
 WHERE school_id=NEW.school_id AND student_id=NEW.student_id AND reviewed_at IS NULL
   AND (safety_source_id=NEW.source_id OR id=NEW.source_id);
 RETURN NEW;
END $$;


--
-- Name: cp_private_chat_message_lifecycle(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cp_private_chat_message_lifecycle() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE required BOOLEAN; valid BOOLEAN;
BEGIN
 IF TG_OP = 'UPDATE' THEN
   IF (NEW.private_chat_thread_id,NEW.private_chat_school_epoch,NEW.private_chat_activity_epoch,NEW.private_chat_generation)
     IS DISTINCT FROM (OLD.private_chat_thread_id,OLD.private_chat_school_epoch,OLD.private_chat_activity_epoch,OLD.private_chat_generation) THEN
     RAISE EXCEPTION 'Private chat message lifecycle is immutable' USING ERRCODE='23514';
   END IF;
   RETURN NEW;
 END IF;
 SELECT private_chat_lifecycle_required INTO required FROM settings WHERE school_id=NEW.school_id FOR SHARE;
 IF NEW.private_chat_thread_id IS NULL THEN
   IF COALESCE(required,false) AND NEW.student_id IS NOT NULL THEN
     RAISE EXCEPTION 'Private chat writer requires lifecycle metadata' USING ERRCODE='23514';
   END IF;
   IF num_nonnulls(NEW.private_chat_school_epoch,NEW.private_chat_activity_epoch,NEW.private_chat_generation) <> 0 THEN
     RAISE EXCEPTION 'Incomplete private chat lifecycle' USING ERRCODE='23514';
   END IF;
   RETURN NEW;
 END IF;
 PERFORM 1 FROM session_settings a WHERE a.school_id=NEW.school_id
   AND a.session_id IS NOT DISTINCT FROM NEW.session_id AND a.supervision_context_id IS NOT DISTINCT FROM NEW.supervision_context_id FOR SHARE;
 PERFORM 1 FROM classpilot_private_chat_threads t WHERE t.school_id=NEW.school_id AND t.id=NEW.private_chat_thread_id FOR SHARE;
 SELECT EXISTS (SELECT 1 FROM classpilot_private_chat_threads t JOIN settings s ON s.school_id=t.school_id
   JOIN session_settings a ON a.school_id=t.school_id AND a.session_id IS NOT DISTINCT FROM t.teaching_session_id
     AND a.supervision_context_id IS NOT DISTINCT FROM t.supervision_context_id
   WHERE t.id=NEW.private_chat_thread_id AND t.school_id=NEW.school_id AND t.student_id=NEW.student_id
     AND t.teaching_session_id IS NOT DISTINCT FROM NEW.session_id AND t.supervision_context_id IS NOT DISTINCT FROM NEW.supervision_context_id
     AND t.generation=NEW.private_chat_generation AND s.private_chat_epoch=NEW.private_chat_school_epoch
     AND a.private_chat_epoch=NEW.private_chat_activity_epoch AND s.student_messaging_enabled IS DISTINCT FROM false
     AND a.chat_enabled IS DISTINCT FROM false
     AND (t.teaching_session_id IS NOT NULL OR EXISTS (
       SELECT 1 FROM classpilot_supervision_students assignment WHERE assignment.school_id=t.school_id
         AND assignment.id=t.authority_assignment_id AND assignment.student_id=t.student_id
         AND assignment.context_id=t.supervision_context_id AND assignment.released_at IS NULL))) INTO valid;
 IF NOT valid THEN RAISE EXCEPTION 'Private chat lifecycle is stale' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: cp_private_chat_settings_epoch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cp_private_chat_settings_epoch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME = 'settings' THEN
   IF OLD.private_chat_lifecycle_required AND NOT NEW.private_chat_lifecycle_required THEN
     RAISE EXCEPTION 'Private chat lifecycle enforcement cannot be rolled back' USING ERRCODE='23514';
   END IF;
   NEW.private_chat_epoch := OLD.private_chat_epoch + CASE WHEN OLD.student_messaging_enabled IS DISTINCT FROM false AND NEW.student_messaging_enabled = false THEN 1 ELSE 0 END;
 ELSE
   NEW.private_chat_epoch := OLD.private_chat_epoch + CASE WHEN OLD.chat_enabled IS DISTINCT FROM false AND NEW.chat_enabled = false THEN 1 ELSE 0 END;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: cp_private_chat_thread_parent(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cp_private_chat_thread_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP = 'UPDATE' AND (NEW.school_id,NEW.student_id,NEW.teaching_session_id,NEW.supervision_context_id,NEW.authority_assignment_id)
   IS DISTINCT FROM (OLD.school_id,OLD.student_id,OLD.teaching_session_id,OLD.supervision_context_id,OLD.authority_assignment_id) THEN
   RAISE EXCEPTION 'Private chat thread authority is immutable' USING ERRCODE='23514';
 END IF;
 IF TG_OP = 'UPDATE' AND (NEW.generation < OLD.generation OR NEW.generation > OLD.generation + 1) THEN
   RAISE EXCEPTION 'Private chat generation must advance monotonically' USING ERRCODE='23514';
 END IF;
 IF NEW.teaching_session_id IS NOT NULL THEN
   IF NOT EXISTS (SELECT 1 FROM classpilot_session_students a WHERE a.school_id=NEW.school_id AND a.id=NEW.authority_assignment_id
     AND a.student_id=NEW.student_id AND a.teaching_session_id=NEW.teaching_session_id) THEN
     RAISE EXCEPTION 'Private chat assignment mismatch' USING ERRCODE='23514';
   END IF;
 ELSE
   IF NOT EXISTS (SELECT 1 FROM classpilot_supervision_students a WHERE a.school_id=NEW.school_id AND a.id=NEW.authority_assignment_id
     AND a.student_id=NEW.student_id AND a.context_id=NEW.supervision_context_id AND a.released_at IS NULL) THEN
     RAISE EXCEPTION 'Private chat assignment mismatch' USING ERRCODE='23514';
   END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: cp_supervision_report_student_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cp_supervision_report_student_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP='UPDATE' AND NEW.school_id=OLD.school_id AND NEW.student_id=OLD.student_id THEN RETURN NEW; END IF;
  IF NOT EXISTS(SELECT 1 FROM students WHERE school_id=NEW.school_id AND id=NEW.student_id) THEN
    RAISE EXCEPTION 'Supervision report student must belong to the report school' USING ERRCODE='23503';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: cp_wake_schedule_boundary(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cp_wake_schedule_boundary() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE scope_id text;
BEGIN
  IF TG_TABLE_NAME = 'schools' THEN
    scope_id := COALESCE(NEW.id, OLD.id);
  ELSIF TG_TABLE_NAME = 'group_teachers' THEN
    SELECT school_id INTO scope_id FROM groups WHERE id = COALESCE(NEW.group_id, OLD.group_id);
  ELSE
    scope_id := COALESCE(NEW.school_id, OLD.school_id);
  END IF;
  UPDATE classpilot_school_schedules
    SET next_boundary_at = now(), boundary_generation = boundary_generation + 1
    WHERE school_id = scope_id;
  RETURN NULL;
END; $$;


--
-- Name: detach_safety_url_rule_provenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.detach_safety_url_rule_provenance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 UPDATE safety_url_exceptions SET created_from_alert_id=NULL WHERE school_id=OLD.school_id AND created_from_alert_id=OLD.id;
 RETURN OLD;
END $$;


--
-- Name: gopilot_valid_pickup_zones(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.gopilot_valid_pickup_zones(candidate jsonb) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
    DECLARE
      zone JSONB;
      normalized_id TEXT;
      seen_ids TEXT[] := ARRAY[]::TEXT[];
    BEGIN
      IF candidate IS NULL OR jsonb_typeof(candidate) <> 'array'
         OR jsonb_array_length(candidate) < 1 OR jsonb_array_length(candidate) > 12 THEN
        RETURN false;
      END IF;
      FOR zone IN SELECT value FROM jsonb_array_elements(candidate)
      LOOP
        IF jsonb_typeof(zone) <> 'object'
           OR NOT (zone ? 'id') OR NOT (zone ? 'name')
           OR jsonb_typeof(zone->'id') <> 'string'
           OR jsonb_typeof(zone->'name') <> 'string' THEN
          RETURN false;
        END IF;
        normalized_id := btrim(zone->>'id');
        IF length(normalized_id) < 1 OR length(normalized_id) > 16
           OR normalized_id !~ '^[A-Za-z0-9][A-Za-z0-9_-]*$'
           OR length(btrim(zone->>'name')) < 1 OR length(btrim(zone->>'name')) > 80
           OR lower(normalized_id) = ANY(seen_ids) THEN
          RETURN false;
        END IF;
        seen_ids := array_append(seen_ids, lower(normalized_id));
      END LOOP;
      RETURN true;
    EXCEPTION WHEN OTHERS THEN
      RETURN false;
    END
    $_$;


--
-- Name: gopilot_validate_homeroom_teacher(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.gopilot_validate_homeroom_teacher() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  resolved_school_id TEXT;
  homeroom_school_id TEXT;
  locked_homeroom_school_id TEXT;
  previous_is_super TEXT;
BEGIN
  IF TG_TABLE_NAME = 'homerooms' THEN
    IF NEW.teacher_id IS NULL THEN
      RETURN NEW;
    END IF;
    resolved_school_id := NEW.school_id;
  ELSE
    resolved_school_id := NEW.school_id;
  END IF;

  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  IF TG_TABLE_NAME = 'homeroom_teachers' THEN
    SELECT homeroom.school_id
    INTO homeroom_school_id
    FROM homerooms AS homeroom
    WHERE homeroom.id = NEW.homeroom_id;

    IF NOT FOUND THEN
      IF schoolpilot_staff_assignment_school_is_live(resolved_school_id) THEN
        RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
          USING
            ERRCODE = '23514',
            CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
      END IF;
      PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
      RETURN NEW;
    END IF;

    locked_homeroom_school_id := homeroom_school_id;

    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[resolved_school_id, homeroom_school_id]::TEXT[]
    );

    -- The parent may have moved while this trigger waited. Refuse the stale
    -- write instead of acquiring a newly discovered tenant lock out of order.
    SELECT homeroom.school_id
    INTO homeroom_school_id
    FROM homerooms AS homeroom
    WHERE homeroom.id = NEW.homeroom_id;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
        USING
          ERRCODE = '23514',
          CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
    END IF;
    IF homeroom_school_id IS DISTINCT FROM locked_homeroom_school_id THEN
      RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
        USING
          ERRCODE = '23514',
          CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
    END IF;

    IF homeroom_school_id <> resolved_school_id AND (
      schoolpilot_staff_assignment_school_is_live(resolved_school_id)
      OR schoolpilot_staff_assignment_school_is_live(homeroom_school_id)
    ) THEN
      RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
        USING
          ERRCODE = '23514',
          CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
    END IF;
  ELSE
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        resolved_school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
  END IF;

  IF NOT schoolpilot_staff_assignment_school_is_live(resolved_school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN NEW;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM school_memberships AS membership
    INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
    WHERE membership.school_id = resolved_school_id
      AND membership.user_id = NEW.teacher_id
      AND membership.status = 'active'
      AND COALESCE(NULLIF(BTRIM(membership.gopilot_role), ''), membership.role)
        = 'teacher'
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_TEACHER_INELIGIBLE'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'gopilot_active_homeroom_teacher_membership';
  END IF;
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: invalidate_classpilot_usage_days_new(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_classpilot_usage_days_new() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM classpilot_usage_rollup_days AS day USING (
    SELECT DISTINCT school_id, usage_date FROM new_usage_rows
  ) AS changed WHERE day.school_id = changed.school_id AND day.usage_date = changed.usage_date;
  RETURN NULL;
END $$;


--
-- Name: invalidate_classpilot_usage_days_old(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_classpilot_usage_days_old() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM classpilot_usage_rollup_days AS day USING (
    SELECT DISTINCT changed.school_id, changed.usage_date FROM old_usage_rows AS changed
    WHERE EXISTS (SELECT 1 FROM students AS student
      WHERE student.school_id = changed.school_id AND student.id = changed.student_id)
  ) AS changed WHERE day.school_id = changed.school_id AND day.usage_date = changed.usage_date;
  RETURN NULL;
END $$;


--
-- Name: invalidate_classpilot_usage_days_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_classpilot_usage_days_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  WITH retained AS (
    SELECT prior.id FROM old_usage_rows AS prior JOIN new_usage_rows AS next ON next.id = prior.id
    WHERE (to_jsonb(prior) - 'class_id' - 'session_id') = (to_jsonb(next) - 'class_id' - 'session_id')
      AND (prior.class_id IS DISTINCT FROM next.class_id OR prior.session_id IS DISTINCT FROM next.session_id)
      AND (prior.class_id IS NOT DISTINCT FROM next.class_id OR (
        prior.class_id IS NOT NULL AND next.class_id IS NULL AND NOT EXISTS (
          SELECT 1 FROM groups AS parent WHERE parent.school_id = prior.school_id AND parent.id = prior.class_id)))
      AND (prior.session_id IS NOT DISTINCT FROM next.session_id OR (
        prior.session_id IS NOT NULL AND next.session_id IS NULL AND NOT EXISTS (
          SELECT 1 FROM teaching_sessions AS parent WHERE parent.school_id = prior.school_id AND parent.id = prior.session_id)))
  ), changed AS (
    SELECT school_id, usage_date FROM old_usage_rows WHERE id NOT IN (SELECT id FROM retained)
    UNION SELECT school_id, usage_date FROM new_usage_rows WHERE id NOT IN (SELECT id FROM retained)
  )
  DELETE FROM classpilot_usage_rollup_days AS day USING changed
    WHERE day.school_id = changed.school_id AND day.usage_date = changed.usage_date;
  RETURN NULL;
END $$;


--
-- Name: preserve_mydesk_import_destination(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.preserve_mydesk_import_destination() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.destination IS DISTINCT FROM OLD.destination THEN
    RAISE EXCEPTION 'An import destination cannot change' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: reject_student_contact_history_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_student_contact_history_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
 BEGIN RAISE EXCEPTION 'Student contact history is immutable' USING ERRCODE='23514'; END $$;


--
-- Name: reject_student_session_auth_kind_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_student_session_auth_kind_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.auth_kind IS DISTINCT FROM OLD.auth_kind THEN
    RAISE EXCEPTION USING
      ERRCODE = 'CP002',
      MESSAGE = 'CLASSPILOT_SESSION_AUTH_KIND_IMMUTABLE';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: school_discipline_immutable_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.school_discipline_immutable_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.state='published' THEN RAISE EXCEPTION 'Published discipline versions are immutable' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: school_discipline_revoke_membership_access(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.school_discipline_revoke_membership_access() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE revoked_id VARCHAR; previous_school_id TEXT := current_setting('app.school_id',true);
BEGIN
 IF OLD.role IN ('admin','school_admin') AND OLD.status='active' THEN
   -- Memberships are global auth rows. Scope this fixed-target housekeeping even
   -- when its caller has no tenant GUC, then restore the caller's original scope.
   PERFORM set_config('app.school_id',OLD.school_id,true);
   -- Serialize different membership-row updates for the same grant before the
   -- next READ COMMITTED statement checks remaining memberships. Otherwise two
   -- concurrent removals could each observe the other's old active row.
   PERFORM 1 FROM school_discipline_access WHERE school_id=OLD.school_id AND user_id=OLD.user_id FOR UPDATE;
   IF NOT EXISTS(SELECT 1 FROM school_memberships WHERE school_id=OLD.school_id AND user_id=OLD.user_id AND status='active' AND role IN ('admin','school_admin')) THEN
   UPDATE school_discipline_access SET enabled=false,revision=revision+1,updated_by=NULL,mutation_receipts='[]',updated_at=now()
     WHERE school_id=OLD.school_id AND user_id=OLD.user_id AND enabled RETURNING id INTO revoked_id;
   IF revoked_id IS NOT NULL THEN INSERT INTO audit_logs(school_id,action,entity_type,entity_id,metadata)
     VALUES(OLD.school_id,'discipline.access.auto_revoked','discipline_access',revoked_id,jsonb_build_object('userId',OLD.user_id,'reason','membership_changed')); END IF;
   END IF;
 END IF;
 PERFORM set_config('app.school_id',COALESCE(previous_school_id,''),true);
 RETURN NULL;
EXCEPTION WHEN OTHERS THEN
 PERFORM set_config('app.school_id',COALESCE(previous_school_id,''),true);
 RAISE;
END $$;


--
-- Name: schoolpilot_assert_admin_class_staff_integrity(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_assert_admin_class_staff_integrity(target_group_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  class_row RECORD;
  locked_school_id TEXT;
  primary_relationship_count INTEGER;
  matching_primary_count INTEGER;
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  SELECT id, school_id
  INTO class_row
  FROM groups
  WHERE id = target_group_id;

  IF NOT FOUND THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  locked_school_id := class_row.school_id;
  PERFORM schoolpilot_lock_staff_assignment_school(locked_school_id);

  -- Re-read after a possibly-blocking advisory lock so every predicate below
  -- observes the transaction that won the school-scoped serialization race.
  SELECT id, school_id, teacher_id, group_type, status
  INTO class_row
  FROM groups
  WHERE id = target_group_id;

  IF NOT FOUND THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;
  IF class_row.school_id IS DISTINCT FROM locked_school_id THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENT_PARENT_CHANGED'
      USING ERRCODE = '40001', CONSTRAINT = 'staff_assignment_parent_school_race';
  END IF;
  IF class_row.group_type NOT IN ('admin_class', 'teacher_created', 'teacher_small_group')
    OR class_row.status <> 'active'
    OR NOT schoolpilot_staff_assignment_school_is_live(class_row.school_id)
  THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM school_memberships AS membership
    INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
    WHERE membership.school_id = class_row.school_id
      AND membership.user_id = class_row.teacher_id
      AND membership.status = 'active'
      AND membership.role IN ('teacher', 'admin', 'school_admin')
  ) THEN
    RAISE EXCEPTION 'STAFF_CLASS_ASSIGNMENT_INELIGIBLE'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'classpilot_active_primary_teacher_membership';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM group_teachers AS relationship
    WHERE relationship.group_id = class_row.id
      AND NOT EXISTS (
        SELECT 1
        FROM school_memberships AS membership
        INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
        WHERE membership.school_id = class_row.school_id
          AND membership.user_id = relationship.teacher_id
          AND membership.status = 'active'
          AND membership.role IN ('teacher', 'admin', 'school_admin')
      )
  ) THEN
    RAISE EXCEPTION 'STAFF_CLASS_ASSIGNMENT_INELIGIBLE'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'classpilot_active_group_teacher_membership';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM group_teachers AS relationship
    WHERE relationship.group_id = class_row.id
      AND (
        relationship.role NOT IN ('primary', 'co-teacher')
        OR (
          relationship.role = 'primary'
          AND relationship.teacher_id IS DISTINCT FROM class_row.teacher_id
        )
        OR (
          relationship.role = 'co-teacher'
          AND relationship.teacher_id IS NOT DISTINCT FROM class_row.teacher_id
        )
      )
  ) THEN
    RAISE EXCEPTION 'STAFF_CLASS_PRIMARY_MIRROR_MISMATCH'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'classpilot_admin_class_primary_teacher_mirror';
  END IF;

  SELECT
    count(*) FILTER (WHERE relationship.role = 'primary'),
    count(*) FILTER (
      WHERE relationship.role = 'primary'
        AND relationship.teacher_id = class_row.teacher_id
    )
  INTO primary_relationship_count, matching_primary_count
  FROM group_teachers AS relationship
  WHERE relationship.group_id = class_row.id;

  IF primary_relationship_count <> 1 OR matching_primary_count <> 1 THEN
    RAISE EXCEPTION 'STAFF_CLASS_PRIMARY_MIRROR_MISMATCH'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'classpilot_admin_class_primary_teacher_mirror';
  END IF;
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_assert_gopilot_homeroom_staff_integrity(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_assert_gopilot_homeroom_staff_integrity(target_homeroom_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  homeroom_row RECORD;
  locked_homeroom_school_id TEXT;
  touched_school_ids TEXT[];
  primary_relationship_count INTEGER;
  matching_primary_count INTEGER;
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  SELECT homeroom.id, homeroom.school_id
  INTO homeroom_row
  FROM homerooms AS homeroom
  WHERE homeroom.id = target_homeroom_id;
  IF NOT FOUND THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  locked_homeroom_school_id := homeroom_row.school_id;
  SELECT COALESCE(
    array_agg(candidate.school_id ORDER BY candidate.school_id),
    ARRAY[]::TEXT[]
  )
  INTO touched_school_ids
  FROM (
    SELECT DISTINCT school_id
    FROM (
      SELECT homeroom_row.school_id AS school_id
      UNION ALL
      SELECT relationship.school_id
      FROM homeroom_teachers AS relationship
      WHERE relationship.homeroom_id = target_homeroom_id
    ) AS raw_school
    WHERE raw_school.school_id IS NOT NULL
  ) AS candidate;
  PERFORM schoolpilot_lock_staff_assignment_schools(touched_school_ids);
  SELECT homeroom.id, homeroom.school_id, homeroom.teacher_id
  INTO homeroom_row
  FROM homerooms AS homeroom
  WHERE homeroom.id = target_homeroom_id;
  IF NOT FOUND THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;
  IF homeroom_row.school_id IS DISTINCT FROM locked_homeroom_school_id THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENT_PARENT_CHANGED'
      USING ERRCODE = '40001', CONSTRAINT = 'staff_assignment_parent_school_race';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM homeroom_teachers AS relationship
    WHERE relationship.homeroom_id = homeroom_row.id
      AND relationship.school_id <> homeroom_row.school_id
      AND (
        schoolpilot_staff_assignment_school_is_live(relationship.school_id)
        OR schoolpilot_staff_assignment_school_is_live(homeroom_row.school_id)
      )
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
  END IF;

  IF NOT schoolpilot_staff_assignment_school_is_live(homeroom_row.school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  IF homeroom_row.teacher_id IS NOT NULL AND NOT EXISTS (
    SELECT 1
    FROM school_memberships AS membership
    INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
    WHERE membership.school_id = homeroom_row.school_id
      AND membership.user_id = homeroom_row.teacher_id
      AND membership.status = 'active'
      AND COALESCE(NULLIF(BTRIM(membership.gopilot_role), ''), membership.role)
        = 'teacher'
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_TEACHER_INELIGIBLE'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_active_homeroom_teacher_membership';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM homeroom_teachers AS relationship
    WHERE relationship.homeroom_id = homeroom_row.id
      AND relationship.school_id = homeroom_row.school_id
      AND (
        relationship.role NOT IN ('primary', 'co-teacher')
        OR (
          relationship.role = 'primary'
          AND relationship.teacher_id IS DISTINCT FROM homeroom_row.teacher_id
        )
        OR (
          relationship.role = 'co-teacher'
          AND relationship.teacher_id IS NOT DISTINCT FROM homeroom_row.teacher_id
        )
      )
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_PRIMARY_MIRROR_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_homeroom_primary_teacher_mirror';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM homeroom_teachers AS relationship
    WHERE relationship.homeroom_id = homeroom_row.id
      AND NOT EXISTS (
        SELECT 1
        FROM school_memberships AS membership
        INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
        WHERE membership.school_id = homeroom_row.school_id
          AND membership.user_id = relationship.teacher_id
          AND membership.status = 'active'
          AND COALESCE(NULLIF(BTRIM(membership.gopilot_role), ''), membership.role)
            = 'teacher'
      )
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_TEACHER_INELIGIBLE'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_active_homeroom_teacher_membership';
  END IF;

  SELECT
    count(*) FILTER (WHERE relationship.role = 'primary'),
    count(*) FILTER (
      WHERE relationship.role = 'primary'
        AND relationship.teacher_id = homeroom_row.teacher_id
    )
  INTO primary_relationship_count, matching_primary_count
  FROM homeroom_teachers AS relationship
  WHERE relationship.homeroom_id = homeroom_row.id
    AND relationship.school_id = homeroom_row.school_id;

  IF (
    homeroom_row.teacher_id IS NULL
    AND primary_relationship_count <> 0
  ) OR (
    homeroom_row.teacher_id IS NOT NULL
    AND (
      primary_relationship_count <> 1
      OR matching_primary_count <> 1
    )
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_PRIMARY_MIRROR_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_homeroom_primary_teacher_mirror';
  END IF;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_assert_live_staff_dependency(text, text, text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_assert_live_staff_dependency(target_kind text, target_id text, locked_school_ids text[] DEFAULT NULL::text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  resolved_school_id TEXT;
  owner_user_id TEXT;
  required_eligibility TEXT;
  dependency_is_live BOOLEAN := false;
  tenant_scope_valid BOOLEAN := true;
  dependency_touches_live_school BOOLEAN;
  dependency_found BOOLEAN := false;
  touched_school_ids TEXT[];
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  CASE target_kind
    WHEN 'passpilot_legacy_class' THEN
      SELECT
        grade.school_id,
        relationship.teacher_id,
        COALESCE(school_settings.passpilot_class_source, 'legacy_grades') = 'legacy_grades',
        ARRAY[grade.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM teacher_grades AS relationship
      INNER JOIN grades AS grade ON grade.id = relationship.grade_id
      LEFT JOIN settings AS school_settings ON school_settings.school_id = grade.school_id
      WHERE relationship.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'teacher_student_assignment' THEN
      SELECT
        student.school_id,
        relationship.teacher_id,
        student.status = 'active',
        student.status <> 'active'
          OR relationship.school_id IS NOT DISTINCT FROM student.school_id,
        schoolpilot_staff_assignment_school_is_live(student.school_id)
          OR schoolpilot_staff_assignment_school_is_live(relationship.school_id),
        ARRAY[student.school_id, relationship.school_id]::TEXT[]
      INTO
        resolved_school_id,
        owner_user_id,
        dependency_is_live,
        tenant_scope_valid,
        dependency_touches_live_school,
        touched_school_ids
      FROM teacher_students AS relationship
      INNER JOIN students AS student ON student.id = relationship.student_id
      WHERE relationship.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'flight_path' THEN
      SELECT
        resource.school_id,
        resource.teacher_id,
        resource.teacher_id IS NOT NULL,
        ARRAY[resource.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM flight_paths AS resource
      WHERE resource.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'block_list' THEN
      SELECT
        resource.school_id,
        resource.teacher_id,
        true,
        ARRAY[resource.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM block_lists AS resource
      WHERE resource.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'student_group' THEN
      SELECT
        resource.school_id,
        resource.teacher_id,
        resource.teacher_id IS NOT NULL,
        ARRAY[resource.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM student_groups AS resource
      WHERE resource.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'coverage_assignment' THEN
      SELECT
        assignment.school_id,
        assignment.staff_id,
        assignment.active,
        ARRAY[assignment.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM classpilot_coverage_assignments AS assignment
      WHERE assignment.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'active_staff';

    WHEN 'central_email_recipient' THEN
      SELECT
        school_settings.school_id,
        school_settings.central_email_recipient_user_id,
        school_settings.central_email_recipient_user_id IS NOT NULL,
        ARRAY[school_settings.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM settings AS school_settings
      WHERE school_settings.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'active_staff';

    WHEN 'active_teaching_session' THEN
      SELECT
        class_group.school_id,
        teaching_session.teacher_id,
        teaching_session.end_time IS NULL,
        teaching_session.end_time IS NOT NULL
          OR (
            class_group.id IS NOT NULL
            AND (
              teaching_session.school_id IS NULL
              OR teaching_session.school_id = class_group.school_id
            )
          ),
        (
          class_group.id IS NULL
          AND teaching_session.school_id IS NULL
        )
          OR schoolpilot_staff_assignment_school_is_live(class_group.school_id)
          OR schoolpilot_staff_assignment_school_is_live(teaching_session.school_id),
        ARRAY[class_group.school_id, teaching_session.school_id]::TEXT[]
      INTO
        resolved_school_id,
        owner_user_id,
        dependency_is_live,
        tenant_scope_valid,
        dependency_touches_live_school,
        touched_school_ids
      FROM teaching_sessions AS teaching_session
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE teaching_session.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'active_session_staff' THEN
      SELECT
        class_group.school_id,
        session_staff.staff_id,
        teaching_session.end_time IS NULL,
        teaching_session.end_time IS NOT NULL
          OR (
            class_group.id IS NOT NULL
            AND (
              teaching_session.school_id IS NULL
              OR teaching_session.school_id = class_group.school_id
            )
            AND session_staff.school_id = class_group.school_id
          ),
        schoolpilot_staff_assignment_school_is_live(class_group.school_id)
          OR schoolpilot_staff_assignment_school_is_live(teaching_session.school_id)
          OR schoolpilot_staff_assignment_school_is_live(session_staff.school_id),
        ARRAY[
          class_group.school_id,
          teaching_session.school_id,
          session_staff.school_id
        ]::TEXT[]
      INTO
        resolved_school_id,
        owner_user_id,
        dependency_is_live,
        tenant_scope_valid,
        dependency_touches_live_school,
        touched_school_ids
      FROM classpilot_session_staff AS session_staff
      INNER JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE session_staff.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'active_supervision_context' THEN
      SELECT
        context.school_id,
        context.assigned_staff_id,
        context.status = 'active' AND context.ended_at IS NULL,
        ARRAY[context.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM classpilot_supervision_contexts AS context
      WHERE context.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'active_staff';

    WHEN 'active_kiosk_session' THEN
      SELECT
        kiosk_session.school_id,
        kiosk_session.teacher_id,
        kiosk_session.status = 'active' AND kiosk_session.teacher_id IS NOT NULL,
        ARRAY[kiosk_session.school_id]::TEXT[]
      INTO resolved_school_id, owner_user_id, dependency_is_live, touched_school_ids
      FROM passpilot_kiosk_sessions AS kiosk_session
      WHERE kiosk_session.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'active_staff';

    WHEN 'active_schedule_change' THEN
      SELECT
        schedule_leg.school_id,
        schedule_leg.primary_teacher_id_snapshot,
        schedule_change.reservation_active = true
          AND schedule_leg.reservation_active = true
          AND schedule_change.status IN ('pending_counterpart', 'pending_admin', 'approved'),
        NOT (
          schedule_change.reservation_active = true
          AND schedule_leg.reservation_active = true
          AND schedule_change.status IN ('pending_counterpart', 'pending_admin', 'approved')
        ) OR (
          schedule_change.school_id = schedule_leg.school_id
          AND class_group.id IS NOT NULL
          AND class_group.school_id = schedule_leg.school_id
        ),
        schoolpilot_staff_assignment_school_is_live(schedule_change.school_id)
          OR schoolpilot_staff_assignment_school_is_live(schedule_leg.school_id)
          OR schoolpilot_staff_assignment_school_is_live(class_group.school_id),
        ARRAY[
          schedule_change.school_id,
          schedule_leg.school_id,
          class_group.school_id
        ]::TEXT[]
      INTO
        resolved_school_id,
        owner_user_id,
        dependency_is_live,
        tenant_scope_valid,
        dependency_touches_live_school,
        touched_school_ids
      FROM classpilot_schedule_change_legs AS schedule_leg
      INNER JOIN classpilot_schedule_changes AS schedule_change
        ON schedule_change.id = schedule_leg.schedule_change_id
      LEFT JOIN groups AS class_group ON class_group.id = schedule_leg.group_id
      WHERE schedule_leg.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    WHEN 'active_scheduled_conflict' THEN
      SELECT
        conflict.school_id,
        conflict.teacher_id,
        conflict.status IN ('coverage_needed', 'claimed', 'pending'),
        conflict.status NOT IN ('coverage_needed', 'claimed', 'pending')
          OR (
            class_group.id IS NOT NULL
            AND class_group.school_id = conflict.school_id
          ),
        schoolpilot_staff_assignment_school_is_live(conflict.school_id)
          OR schoolpilot_staff_assignment_school_is_live(class_group.school_id),
        ARRAY[conflict.school_id, class_group.school_id]::TEXT[]
      INTO
        resolved_school_id,
        owner_user_id,
        dependency_is_live,
        tenant_scope_valid,
        dependency_touches_live_school,
        touched_school_ids
      FROM classpilot_scheduled_conflicts AS conflict
      LEFT JOIN groups AS class_group ON class_group.id = conflict.group_id
      WHERE conflict.id = target_id;
      dependency_found := FOUND;
      required_eligibility := 'base_teaching';

    ELSE
      RAISE EXCEPTION 'STAFF_DEPENDENCY_KIND_UNKNOWN'
        USING ERRCODE = '22023', CONSTRAINT = 'staff_live_dependency_kind';
  END CASE;

  IF NOT dependency_found THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  dependency_touches_live_school := COALESCE(
    dependency_touches_live_school,
    schoolpilot_staff_assignment_school_is_live(resolved_school_id)
  );

  SELECT COALESCE(array_agg(touched.school_id ORDER BY touched.school_id), ARRAY[]::TEXT[])
  INTO touched_school_ids
  FROM (
    SELECT DISTINCT candidate.school_id
    FROM unnest(COALESCE(touched_school_ids, ARRAY[resolved_school_id]::TEXT[]))
      AS candidate(school_id)
    WHERE candidate.school_id IS NOT NULL
  ) AS touched;

  IF resolved_school_id IS NULL THEN
    IF dependency_is_live IS TRUE THEN
      RAISE EXCEPTION 'STAFF_DEPENDENCY_SCHOOL_MISMATCH'
        USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_tenant_scope';
    END IF;
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  -- Lock even an inactive dependency before deciding that it is exempt. A
  -- parent row (student status, PassPilot source, schedule-change status, or
  -- teaching-session end state) can make it live concurrently. Re-enter after
  -- the lock so the final predicate is evaluated from a fresh READ COMMITTED
  -- statement snapshot.
  IF locked_school_ids IS NULL THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(touched_school_ids);
    PERFORM schoolpilot_assert_live_staff_dependency(
      target_kind,
      target_id,
      touched_school_ids
    );
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  IF locked_school_ids IS DISTINCT FROM touched_school_ids THEN
    RAISE EXCEPTION 'STAFF_DEPENDENCY_SCHOOL_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_tenant_scope';
  END IF;

  -- Deleted tenants are historical, but their writers still serialize with a
  -- possible restore. The recursive pass above observes the restore winner's
  -- committed state before deciding whether this dependency remains exempt.
  IF dependency_touches_live_school IS NOT TRUE THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  IF tenant_scope_valid IS NOT TRUE THEN
    RAISE EXCEPTION 'STAFF_DEPENDENCY_SCHOOL_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_tenant_scope';
  END IF;

  IF dependency_is_live IS NOT TRUE OR owner_user_id IS NULL THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  IF required_eligibility = 'base_teaching' AND NOT EXISTS (
    SELECT 1
    FROM school_memberships AS membership
    INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
    WHERE membership.school_id = resolved_school_id
      AND membership.user_id = owner_user_id
      AND membership.status = 'active'
      AND membership.role IN ('teacher', 'admin', 'school_admin')
  ) THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENT_INELIGIBLE'
      USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_teaching_membership';
  END IF;

  IF required_eligibility = 'active_staff' AND NOT EXISTS (
    SELECT 1
    FROM school_memberships AS membership
    INNER JOIN users AS membership_user ON membership_user.id = membership.user_id
    WHERE membership.school_id = resolved_school_id
      AND membership.user_id = owner_user_id
      AND membership.status = 'active'
      AND membership.role IN ('teacher', 'admin', 'school_admin', 'office_staff')
  ) THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENT_INELIGIBLE'
      USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_active_membership';
  END IF;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_assert_no_active_schedule_change_for_group(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_assert_no_active_schedule_change_for_group(target_group_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  target_school_id TEXT;
  locked_school_id TEXT;
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  SELECT class_group.school_id
  INTO target_school_id
  FROM groups AS class_group
  WHERE class_group.id = target_group_id;
  IF NOT FOUND THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  locked_school_id := target_school_id;
  PERFORM schoolpilot_lock_staff_assignment_school(target_school_id);
  SELECT class_group.school_id
  INTO target_school_id
  FROM groups AS class_group
  WHERE class_group.id = target_group_id;
  IF NOT FOUND OR target_school_id IS DISTINCT FROM locked_school_id THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENT_PARENT_CHANGED'
      USING ERRCODE = '40001', CONSTRAINT = 'staff_assignment_parent_school_race';
  END IF;
  IF NOT schoolpilot_staff_assignment_school_is_live(target_school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;
  IF EXISTS (
    SELECT 1
    FROM classpilot_schedule_change_legs AS schedule_leg
    INNER JOIN classpilot_schedule_changes AS schedule_change
      ON schedule_change.id = schedule_leg.schedule_change_id
      AND schedule_change.school_id = schedule_leg.school_id
    WHERE schedule_leg.group_id = target_group_id
      AND schedule_leg.school_id = target_school_id
      AND schedule_leg.reservation_active = true
      AND schedule_change.reservation_active = true
      AND schedule_change.status IN ('pending_counterpart', 'pending_admin', 'approved')
  ) THEN
    RAISE EXCEPTION 'STAFF_ACTIVE_SCHEDULE_CHANGE_OWNERSHIP_LOCKED'
      USING ERRCODE = '23514', CONSTRAINT = 'classpilot_active_schedule_change_ownership';
  END IF;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_assert_school_staff_integrity(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_assert_school_staff_integrity(target_school_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  dependency RECORD;
  locked_school_ids TEXT[];
  refreshed_school_ids TEXT[];
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  IF NOT schoolpilot_staff_assignment_school_is_live(target_school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  locked_school_ids := schoolpilot_staff_assignment_touched_schools(target_school_id);
  PERFORM schoolpilot_lock_staff_assignment_schools(locked_school_ids);
  IF NOT schoolpilot_staff_assignment_school_is_live(target_school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN;
  END IF;

  refreshed_school_ids := schoolpilot_staff_assignment_touched_schools(target_school_id);
  IF refreshed_school_ids IS DISTINCT FROM locked_school_ids THEN
    RAISE EXCEPTION 'SCHOOL_STAFF_ASSIGNMENT_INTEGRITY_CHANGED'
      USING ERRCODE = '40001', CONSTRAINT = 'school_staff_assignment_restore_race';
  END IF;

  -- A relationship may store one tenant while its authoritative parent stores
  -- another. Reactivating either side must surface the corruption even when
  -- the other side remains deleted.
  IF EXISTS (
    SELECT 1
    FROM homeroom_teachers AS relationship
    LEFT JOIN homerooms AS homeroom ON homeroom.id = relationship.homeroom_id
    WHERE (
        relationship.school_id = target_school_id
        OR homeroom.school_id = target_school_id
      )
      AND (
        homeroom.id IS NULL
        OR relationship.school_id <> homeroom.school_id
      )
      AND (
        schoolpilot_staff_assignment_school_is_live(relationship.school_id)
        OR schoolpilot_staff_assignment_school_is_live(homeroom.school_id)
      )
  ) THEN
    RAISE EXCEPTION 'GOPILOT_HOMEROOM_SCHOOL_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'gopilot_homeroom_teacher_same_school';
  END IF;

  FOR dependency IN
    SELECT class_group.id
    FROM groups AS class_group
    WHERE class_group.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_admin_class_staff_integrity(dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT homeroom.id
    FROM homerooms AS homeroom
    WHERE homeroom.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_gopilot_homeroom_staff_integrity(dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT relationship.id
    FROM teacher_grades AS relationship
    INNER JOIN grades AS grade ON grade.id = relationship.grade_id
    WHERE grade.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('passpilot_legacy_class', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT relationship.id
    FROM teacher_students AS relationship
    INNER JOIN students AS student ON student.id = relationship.student_id
    WHERE student.school_id = target_school_id
      OR relationship.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('teacher_student_assignment', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT resource.id FROM flight_paths AS resource
    WHERE resource.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('flight_path', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT resource.id FROM block_lists AS resource
    WHERE resource.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('block_list', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT resource.id FROM student_groups AS resource
    WHERE resource.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('student_group', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT assignment.id FROM classpilot_coverage_assignments AS assignment
    WHERE assignment.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('coverage_assignment', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT school_settings.id FROM settings AS school_settings
    WHERE school_settings.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('central_email_recipient', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT teaching_session.id
    FROM teaching_sessions AS teaching_session
    LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
    WHERE teaching_session.school_id = target_school_id
      OR class_group.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_teaching_session', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT session_staff.id
    FROM classpilot_session_staff AS session_staff
    LEFT JOIN teaching_sessions AS teaching_session
      ON teaching_session.id = session_staff.teaching_session_id
    LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
    WHERE session_staff.school_id = target_school_id
      OR teaching_session.school_id = target_school_id
      OR class_group.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_session_staff', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT context.id FROM classpilot_supervision_contexts AS context
    WHERE context.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_supervision_context', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT kiosk_session.id FROM passpilot_kiosk_sessions AS kiosk_session
    WHERE kiosk_session.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_kiosk_session', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT schedule_leg.id
    FROM classpilot_schedule_change_legs AS schedule_leg
    LEFT JOIN classpilot_schedule_changes AS schedule_change
      ON schedule_change.id = schedule_leg.schedule_change_id
    LEFT JOIN groups AS class_group ON class_group.id = schedule_leg.group_id
    WHERE schedule_leg.school_id = target_school_id
      OR schedule_change.school_id = target_school_id
      OR class_group.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_schedule_change', dependency.id);
  END LOOP;

  FOR dependency IN
    SELECT conflict.id
    FROM classpilot_scheduled_conflicts AS conflict
    LEFT JOIN groups AS class_group ON class_group.id = conflict.group_id
    WHERE conflict.school_id = target_school_id
      OR class_group.school_id = target_school_id
  LOOP
    PERFORM schoolpilot_assert_live_staff_dependency('active_scheduled_conflict', dependency.id);
  END LOOP;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_check_admin_class_staff_integrity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_admin_class_staff_integrity() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.teacher_id IS DISTINCT FROM NEW.teacher_id THEN
    PERFORM schoolpilot_assert_no_active_schedule_change_for_group(NEW.id);
  END IF;
  PERFORM schoolpilot_assert_admin_class_staff_integrity(NEW.id);
  RETURN NEW;
END;
$$;


--
-- Name: schoolpilot_check_departing_staff_assignments(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_departing_staff_assignments() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  has_base_teaching_membership BOOLEAN;
  has_gopilot_teaching_membership BOOLEAN;
  has_active_staff_membership BOOLEAN;
  loses_base_teaching_membership BOOLEAN;
  loses_gopilot_teaching_membership BOOLEAN;
  loses_active_staff_membership BOOLEAN;
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  PERFORM schoolpilot_lock_staff_assignment_schools(
    ARRAY[
      OLD.school_id,
      CASE WHEN TG_OP = 'UPDATE' THEN NEW.school_id ELSE NULL END
    ]::TEXT[]
  );

  IF NOT schoolpilot_staff_assignment_school_is_live(OLD.school_id) THEN
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    IF TG_OP = 'DELETE' THEN
      RETURN OLD;
    END IF;
    RETURN NEW;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM school_memberships AS remaining
    INNER JOIN users AS membership_user ON membership_user.id = remaining.user_id
    WHERE remaining.school_id = OLD.school_id
      AND remaining.user_id = OLD.user_id
      AND remaining.status = 'active'
      AND remaining.role IN ('teacher', 'admin', 'school_admin')
  ) INTO has_base_teaching_membership;

  loses_base_teaching_membership :=
    OLD.status = 'active'
    AND OLD.role IN ('teacher', 'admin', 'school_admin')
    AND NOT has_base_teaching_membership;

  IF loses_base_teaching_membership AND (
    EXISTS (
      SELECT 1
      FROM groups AS class_group
      WHERE class_group.school_id = OLD.school_id
        AND class_group.group_type IN ('admin_class', 'teacher_created', 'teacher_small_group')
        AND class_group.status = 'active'
        AND (
          class_group.teacher_id = OLD.user_id
          OR EXISTS (
            SELECT 1
            FROM group_teachers AS relationship
            WHERE relationship.group_id = class_group.id
              AND relationship.teacher_id = OLD.user_id
          )
        )
    )
    OR EXISTS (
      SELECT 1
      FROM teacher_grades AS relationship
      INNER JOIN grades AS grade ON grade.id = relationship.grade_id
      LEFT JOIN settings AS school_settings ON school_settings.school_id = grade.school_id
      WHERE grade.school_id = OLD.school_id
        AND relationship.teacher_id = OLD.user_id
        AND COALESCE(school_settings.passpilot_class_source, 'legacy_grades') = 'legacy_grades'
    )
    OR EXISTS (
      SELECT 1
      FROM teacher_students AS relationship
      INNER JOIN students AS student ON student.id = relationship.student_id
      WHERE student.school_id = OLD.school_id
        AND student.status = 'active'
        AND relationship.teacher_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1 FROM flight_paths AS resource
      WHERE resource.school_id = OLD.school_id
        AND resource.teacher_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1 FROM block_lists AS resource
      WHERE resource.school_id = OLD.school_id
        AND resource.teacher_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1 FROM student_groups AS resource
      WHERE resource.school_id = OLD.school_id
        AND resource.teacher_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1
      FROM teaching_sessions AS teaching_session
      INNER JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE class_group.school_id = OLD.school_id
        AND (
          teaching_session.school_id IS NULL
          OR teaching_session.school_id = class_group.school_id
        )
        AND teaching_session.teacher_id = OLD.user_id
        AND teaching_session.end_time IS NULL
    )
    OR EXISTS (
      SELECT 1
      FROM classpilot_session_staff AS session_staff
      INNER JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      INNER JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE class_group.school_id = OLD.school_id
        AND (
          teaching_session.school_id IS NULL
          OR teaching_session.school_id = class_group.school_id
        )
        AND session_staff.school_id = class_group.school_id
        AND session_staff.staff_id = OLD.user_id
        AND teaching_session.end_time IS NULL
    )
    -- A kiosk may be owned by office staff, but an existing teacher-owned
    -- kiosk is still a blocker for a teacher -> non-teaching role change.
    OR EXISTS (
      SELECT 1
      FROM passpilot_kiosk_sessions AS kiosk_session
      WHERE kiosk_session.school_id = OLD.school_id
        AND kiosk_session.teacher_id = OLD.user_id
        AND kiosk_session.status = 'active'
    )
    OR EXISTS (
      SELECT 1
      FROM classpilot_schedule_change_legs AS schedule_leg
      INNER JOIN classpilot_schedule_changes AS schedule_change
        ON schedule_change.id = schedule_leg.schedule_change_id
        AND schedule_change.school_id = schedule_leg.school_id
      WHERE schedule_leg.school_id = OLD.school_id
        AND schedule_leg.primary_teacher_id_snapshot = OLD.user_id
        AND schedule_leg.reservation_active = true
        AND schedule_change.reservation_active = true
        AND schedule_change.status IN ('pending_counterpart', 'pending_admin', 'approved')
    )
    OR EXISTS (
      SELECT 1
      FROM classpilot_scheduled_conflicts AS conflict
      WHERE conflict.school_id = OLD.school_id
        AND conflict.teacher_id = OLD.user_id
        AND conflict.status IN ('coverage_needed', 'claimed', 'pending')
    )
  ) THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENTS_REQUIRE_REASSIGNMENT'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'staff_live_teaching_dependency_membership';
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM school_memberships AS remaining
    INNER JOIN users AS membership_user ON membership_user.id = remaining.user_id
    WHERE remaining.school_id = OLD.school_id
      AND remaining.user_id = OLD.user_id
      AND remaining.status = 'active'
      AND COALESCE(NULLIF(BTRIM(remaining.gopilot_role), ''), remaining.role)
        = 'teacher'
  ) INTO has_gopilot_teaching_membership;

  loses_gopilot_teaching_membership :=
    OLD.status = 'active'
    AND COALESCE(NULLIF(BTRIM(OLD.gopilot_role), ''), OLD.role) = 'teacher'
    AND NOT has_gopilot_teaching_membership;

  IF loses_gopilot_teaching_membership AND (
    EXISTS (
      SELECT 1
      FROM homerooms AS homeroom
      WHERE homeroom.school_id = OLD.school_id
        AND homeroom.teacher_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1
      FROM homeroom_teachers AS relationship
      WHERE relationship.school_id = OLD.school_id
        AND relationship.teacher_id = OLD.user_id
    )
  ) THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENTS_REQUIRE_REASSIGNMENT'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'gopilot_active_staff_assignment_membership';
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM school_memberships AS remaining
    INNER JOIN users AS membership_user ON membership_user.id = remaining.user_id
    WHERE remaining.school_id = OLD.school_id
      AND remaining.user_id = OLD.user_id
      AND remaining.status = 'active'
      AND remaining.role IN ('teacher', 'admin', 'school_admin', 'office_staff')
  ) INTO has_active_staff_membership;

  loses_active_staff_membership :=
    OLD.status = 'active'
    AND OLD.role IN ('teacher', 'admin', 'school_admin', 'office_staff')
    AND NOT has_active_staff_membership;

  IF loses_active_staff_membership AND (
    EXISTS (
      SELECT 1
      FROM classpilot_coverage_assignments AS assignment
      WHERE assignment.school_id = OLD.school_id
        AND assignment.staff_id = OLD.user_id
        AND assignment.active = true
    )
    OR EXISTS (
      SELECT 1
      FROM settings AS school_settings
      WHERE school_settings.school_id = OLD.school_id
        AND school_settings.central_email_recipient_user_id = OLD.user_id
    )
    OR EXISTS (
      SELECT 1
      FROM classpilot_supervision_contexts AS context
      WHERE context.school_id = OLD.school_id
        AND context.assigned_staff_id = OLD.user_id
        AND context.status = 'active'
        AND context.ended_at IS NULL
    )
    OR EXISTS (
      SELECT 1
      FROM passpilot_kiosk_sessions AS kiosk_session
      WHERE kiosk_session.school_id = OLD.school_id
        AND kiosk_session.teacher_id = OLD.user_id
        AND kiosk_session.status = 'active'
    )
  ) THEN
    RAISE EXCEPTION 'STAFF_ASSIGNMENTS_REQUIRE_REASSIGNMENT'
      USING
        ERRCODE = '23514',
        CONSTRAINT = 'staff_live_active_dependency_membership';
  END IF;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_check_gopilot_homeroom_staff_integrity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_gopilot_homeroom_staff_integrity() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'homerooms' THEN
    IF TG_OP <> 'DELETE' THEN
      PERFORM schoolpilot_assert_gopilot_homeroom_staff_integrity(NEW.id);
      RETURN NEW;
    END IF;
    RETURN OLD;
  END IF;

  IF TG_OP = 'DELETE' THEN
    PERFORM schoolpilot_assert_gopilot_homeroom_staff_integrity(OLD.homeroom_id);
    RETURN OLD;
  END IF;
  PERFORM schoolpilot_assert_gopilot_homeroom_staff_integrity(NEW.homeroom_id);
  IF TG_OP = 'UPDATE' AND OLD.homeroom_id IS DISTINCT FROM NEW.homeroom_id THEN
    PERFORM schoolpilot_assert_gopilot_homeroom_staff_integrity(OLD.homeroom_id);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: schoolpilot_check_group_teacher_staff_integrity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_group_teacher_staff_integrity() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM schoolpilot_assert_no_active_schedule_change_for_group(OLD.group_id);
    PERFORM schoolpilot_assert_admin_class_staff_integrity(OLD.group_id);
    RETURN OLD;
  END IF;

  IF TG_OP = 'INSERT' OR (
    TG_OP = 'UPDATE'
    AND (
      OLD.group_id IS DISTINCT FROM NEW.group_id
      OR OLD.teacher_id IS DISTINCT FROM NEW.teacher_id
      OR OLD.role IS DISTINCT FROM NEW.role
    )
  ) THEN
    PERFORM schoolpilot_assert_no_active_schedule_change_for_group(NEW.group_id);
    IF TG_OP = 'UPDATE' AND OLD.group_id IS DISTINCT FROM NEW.group_id THEN
      PERFORM schoolpilot_assert_no_active_schedule_change_for_group(OLD.group_id);
    END IF;
  END IF;
  PERFORM schoolpilot_assert_admin_class_staff_integrity(NEW.group_id);
  IF TG_OP = 'UPDATE' AND OLD.group_id <> NEW.group_id THEN
    PERFORM schoolpilot_assert_admin_class_staff_integrity(OLD.group_id);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: schoolpilot_check_live_staff_dependency(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_live_staff_dependency() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  PERFORM schoolpilot_assert_live_staff_dependency(TG_ARGV[0], NEW.id);
  RETURN NEW;
END;
$$;


--
-- Name: schoolpilot_check_parent_staff_dependencies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_parent_staff_dependencies() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  dependency RECORD;
  old_parent_school_id TEXT;
  new_parent_school_id TEXT;
  previous_is_super TEXT;
BEGIN
  previous_is_super := current_setting('app.is_super', true);
  PERFORM set_config('app.is_super', 'on', true);

  IF TG_OP = 'DELETE' THEN
    IF TG_TABLE_NAME = 'settings' THEN
      PERFORM schoolpilot_lock_staff_assignment_schools(ARRAY[OLD.school_id]::TEXT[]);
      FOR dependency IN
        SELECT relationship.id
        FROM teacher_grades AS relationship
        INNER JOIN grades AS grade ON grade.id = relationship.grade_id
        WHERE grade.school_id = OLD.school_id
      LOOP
        PERFORM schoolpilot_assert_live_staff_dependency(
          'passpilot_legacy_class', dependency.id
        );
      END LOOP;
    ELSIF TG_TABLE_NAME = 'groups' THEN
      PERFORM schoolpilot_lock_staff_assignment_schools(ARRAY[OLD.school_id]::TEXT[]);
      FOR dependency IN
        SELECT teaching_session.id
        FROM teaching_sessions AS teaching_session
        WHERE teaching_session.group_id = OLD.id
      LOOP
        PERFORM schoolpilot_assert_live_staff_dependency(
          'active_teaching_session', dependency.id
        );
      END LOOP;
      FOR dependency IN
        SELECT session_staff.id
        FROM classpilot_session_staff AS session_staff
        INNER JOIN teaching_sessions AS teaching_session
          ON teaching_session.id = session_staff.teaching_session_id
        WHERE teaching_session.group_id = OLD.id
      LOOP
        PERFORM schoolpilot_assert_live_staff_dependency(
          'active_session_staff', dependency.id
        );
      END LOOP;
      FOR dependency IN
        SELECT conflict.id
        FROM classpilot_scheduled_conflicts AS conflict
        WHERE conflict.group_id = OLD.id
      LOOP
        PERFORM schoolpilot_assert_live_staff_dependency(
          'active_scheduled_conflict', dependency.id
        );
      END LOOP;
    END IF;
    PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
    RETURN OLD;
  END IF;

  IF TG_TABLE_NAME = 'settings' THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
    PERFORM schoolpilot_assert_live_staff_dependency('central_email_recipient', NEW.id);
    FOR dependency IN
      SELECT relationship.id
      FROM teacher_grades AS relationship
      INNER JOIN grades AS grade ON grade.id = relationship.grade_id
      WHERE grade.school_id = NEW.school_id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'passpilot_legacy_class', dependency.id
      );
    END LOOP;
    IF TG_OP = 'UPDATE' AND OLD.school_id IS DISTINCT FROM NEW.school_id THEN
      FOR dependency IN
        SELECT relationship.id
        FROM teacher_grades AS relationship
        INNER JOIN grades AS grade ON grade.id = relationship.grade_id
        WHERE grade.school_id = OLD.school_id
      LOOP
        PERFORM schoolpilot_assert_live_staff_dependency(
          'passpilot_legacy_class', dependency.id
        );
      END LOOP;
    END IF;
  ELSIF TG_TABLE_NAME = 'grades' THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
    FOR dependency IN
      SELECT relationship.id
      FROM teacher_grades AS relationship
      WHERE relationship.grade_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'passpilot_legacy_class', dependency.id
      );
    END LOOP;
  ELSIF TG_TABLE_NAME = 'students' THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
    FOR dependency IN
      SELECT relationship.id
      FROM teacher_students AS relationship
      WHERE relationship.student_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'teacher_student_assignment', dependency.id
      );
    END LOOP;
  ELSIF TG_TABLE_NAME = 'teaching_sessions' THEN
    SELECT class_group.school_id
    INTO new_parent_school_id
    FROM groups AS class_group
    WHERE class_group.id = NEW.group_id;
    IF TG_OP = 'UPDATE' THEN
      SELECT class_group.school_id
      INTO old_parent_school_id
      FROM groups AS class_group
      WHERE class_group.id = OLD.group_id;
    END IF;
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        new_parent_school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END,
        old_parent_school_id
      ]::TEXT[]
    );
    PERFORM schoolpilot_assert_live_staff_dependency('active_teaching_session', NEW.id);
    FOR dependency IN
      SELECT session_staff.id
      FROM classpilot_session_staff AS session_staff
      WHERE session_staff.teaching_session_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_session_staff', dependency.id
      );
    END LOOP;
  ELSIF TG_TABLE_NAME = 'classpilot_schedule_changes' THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
    FOR dependency IN
      SELECT schedule_leg.id
      FROM classpilot_schedule_change_legs AS schedule_leg
      WHERE schedule_leg.schedule_change_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_schedule_change', dependency.id
      );
    END LOOP;
  ELSIF TG_TABLE_NAME = 'groups' THEN
    PERFORM schoolpilot_lock_staff_assignment_schools(
      ARRAY[
        NEW.school_id,
        CASE WHEN TG_OP = 'UPDATE' THEN OLD.school_id ELSE NULL END
      ]::TEXT[]
    );
    PERFORM schoolpilot_assert_admin_class_staff_integrity(NEW.id);
    FOR dependency IN
      SELECT teaching_session.id
      FROM teaching_sessions AS teaching_session
      WHERE teaching_session.group_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_teaching_session', dependency.id
      );
    END LOOP;
    FOR dependency IN
      SELECT session_staff.id
      FROM classpilot_session_staff AS session_staff
      INNER JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      WHERE teaching_session.group_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_session_staff', dependency.id
      );
    END LOOP;
    FOR dependency IN
      SELECT schedule_leg.id
      FROM classpilot_schedule_change_legs AS schedule_leg
      WHERE schedule_leg.group_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_schedule_change', dependency.id
      );
    END LOOP;
    FOR dependency IN
      SELECT conflict.id
      FROM classpilot_scheduled_conflicts AS conflict
      WHERE conflict.group_id = NEW.id
    LOOP
      PERFORM schoolpilot_assert_live_staff_dependency(
        'active_scheduled_conflict', dependency.id
      );
    END LOOP;
  END IF;

  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  PERFORM set_config('app.is_super', COALESCE(previous_is_super, ''), true);
  RAISE;
END;
$$;


--
-- Name: schoolpilot_check_school_staff_integrity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_check_school_staff_integrity() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.deleted_at IS NULL THEN
    PERFORM schoolpilot_assert_school_staff_integrity(NEW.id);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: schoolpilot_flight_path_content_revision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_flight_path_content_revision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (to_jsonb(NEW) - 'updated_at') IS DISTINCT FROM (to_jsonb(OLD) - 'updated_at') THEN
    NEW.updated_at := greatest(date_trunc('milliseconds', clock_timestamp()),
      date_trunc('milliseconds', OLD.updated_at) + interval '1 millisecond');
  ELSE
    NEW.updated_at := OLD.updated_at;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: schoolpilot_guard_school_hard_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_guard_school_hard_delete() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  -- School records are lifecycle roots and are retained after soft deletion.
  -- An unconditional guard removes first-reference races from tables whose
  -- historical school keys intentionally do not cascade.
  RAISE EXCEPTION 'SCHOOL_STAFF_HISTORY_REQUIRES_RETENTION'
    USING ERRCODE = '23514', CONSTRAINT = 'school_staff_history_hard_delete';
  RETURN OLD;
END;
$$;


--
-- Name: schoolpilot_guard_user_hard_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_guard_user_hard_delete() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  -- Staff identities are retained records. The application has no canonical
  -- hard-delete path, and an unconditional database guard removes the
  -- otherwise unavoidable race with creation of a user's first reference.
  RAISE EXCEPTION 'STAFF_IDENTITY_HISTORY_REQUIRES_RETENTION'
    USING ERRCODE = '23514', CONSTRAINT = 'staff_identity_history_hard_delete';
  RETURN OLD;
END;
$$;


--
-- Name: schoolpilot_lock_staff_assignment_school(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_lock_staff_assignment_school(target_school_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF target_school_id IS NULL THEN
    RETURN;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM schools AS school WHERE school.id = target_school_id
  ) THEN
    RAISE EXCEPTION 'STAFF_DEPENDENCY_SCHOOL_MISMATCH'
      USING ERRCODE = '23514', CONSTRAINT = 'staff_live_dependency_tenant_scope';
  END IF;

  -- This key is shared with every canonical application writer. Taking it in
  -- each database trigger also closes write-skew for direct SQL and old code:
  -- concurrent assignment creation and membership loss cannot both commit.
  PERFORM pg_advisory_xact_lock(
    hashtextextended('staff-assignment-lifecycle:' || target_school_id, 0::bigint)
  );
END;
$$;


--
-- Name: schoolpilot_lock_staff_assignment_schools(text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_lock_staff_assignment_schools(target_school_ids text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  target_school_id TEXT;
BEGIN
  -- Multi-tenant dependency rows (and school-id moves) must acquire the same
  -- lifecycle locks in a stable order. This both closes restore/write races and
  -- avoids deadlocks when two transactions touch the same schools in reverse
  -- application order.
  FOR target_school_id IN
    SELECT DISTINCT touched.school_id
    FROM unnest(COALESCE(target_school_ids, ARRAY[]::TEXT[]))
      AS touched(school_id)
    WHERE touched.school_id IS NOT NULL
    ORDER BY touched.school_id
  LOOP
    PERFORM schoolpilot_lock_staff_assignment_school(target_school_id);
  END LOOP;
END;
$$;


--
-- Name: schoolpilot_staff_assignment_school_is_live(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_staff_assignment_school_is_live(target_school_id text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT target_school_id IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM schools AS school
      WHERE school.id = target_school_id
        AND school.deleted_at IS NOT NULL
    );
$$;


--
-- Name: schoolpilot_staff_assignment_touched_schools(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.schoolpilot_staff_assignment_touched_schools(target_school_id text) RETURNS text[]
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT COALESCE(
    array_agg(candidate.school_id ORDER BY candidate.school_id),
    ARRAY[]::TEXT[]
  )
  FROM (
    SELECT DISTINCT raw_school.school_id
    FROM (
      SELECT target_school_id AS school_id
      UNION ALL
      SELECT relationship.school_id
      FROM homeroom_teachers AS relationship
      LEFT JOIN homerooms AS homeroom ON homeroom.id = relationship.homeroom_id
      WHERE relationship.school_id = target_school_id
        OR homeroom.school_id = target_school_id
      UNION ALL
      SELECT homeroom.school_id
      FROM homeroom_teachers AS relationship
      LEFT JOIN homerooms AS homeroom ON homeroom.id = relationship.homeroom_id
      WHERE relationship.school_id = target_school_id
        OR homeroom.school_id = target_school_id
      UNION ALL
      SELECT relationship.school_id
      FROM teacher_students AS relationship
      LEFT JOIN students AS student ON student.id = relationship.student_id
      WHERE relationship.school_id = target_school_id
        OR student.school_id = target_school_id
      UNION ALL
      SELECT student.school_id
      FROM teacher_students AS relationship
      LEFT JOIN students AS student ON student.id = relationship.student_id
      WHERE relationship.school_id = target_school_id
        OR student.school_id = target_school_id
      UNION ALL
      SELECT teaching_session.school_id
      FROM teaching_sessions AS teaching_session
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE teaching_session.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT class_group.school_id
      FROM teaching_sessions AS teaching_session
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE teaching_session.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT session_staff.school_id
      FROM classpilot_session_staff AS session_staff
      LEFT JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE session_staff.school_id = target_school_id
        OR teaching_session.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT teaching_session.school_id
      FROM classpilot_session_staff AS session_staff
      LEFT JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE session_staff.school_id = target_school_id
        OR teaching_session.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT class_group.school_id
      FROM classpilot_session_staff AS session_staff
      LEFT JOIN teaching_sessions AS teaching_session
        ON teaching_session.id = session_staff.teaching_session_id
      LEFT JOIN groups AS class_group ON class_group.id = teaching_session.group_id
      WHERE session_staff.school_id = target_school_id
        OR teaching_session.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT schedule_change.school_id
      FROM classpilot_schedule_change_legs AS schedule_leg
      LEFT JOIN classpilot_schedule_changes AS schedule_change
        ON schedule_change.id = schedule_leg.schedule_change_id
      LEFT JOIN groups AS class_group ON class_group.id = schedule_leg.group_id
      WHERE schedule_leg.school_id = target_school_id
        OR schedule_change.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT schedule_leg.school_id
      FROM classpilot_schedule_change_legs AS schedule_leg
      LEFT JOIN classpilot_schedule_changes AS schedule_change
        ON schedule_change.id = schedule_leg.schedule_change_id
      LEFT JOIN groups AS class_group ON class_group.id = schedule_leg.group_id
      WHERE schedule_leg.school_id = target_school_id
        OR schedule_change.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT class_group.school_id
      FROM classpilot_schedule_change_legs AS schedule_leg
      LEFT JOIN classpilot_schedule_changes AS schedule_change
        ON schedule_change.id = schedule_leg.schedule_change_id
      LEFT JOIN groups AS class_group ON class_group.id = schedule_leg.group_id
      WHERE schedule_leg.school_id = target_school_id
        OR schedule_change.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT conflict.school_id
      FROM classpilot_scheduled_conflicts AS conflict
      LEFT JOIN groups AS class_group ON class_group.id = conflict.group_id
      WHERE conflict.school_id = target_school_id
        OR class_group.school_id = target_school_id
      UNION ALL
      SELECT class_group.school_id
      FROM classpilot_scheduled_conflicts AS conflict
      LEFT JOIN groups AS class_group ON class_group.id = conflict.group_id
      WHERE conflict.school_id = target_school_id
        OR class_group.school_id = target_school_id
    ) AS raw_school
    WHERE raw_school.school_id IS NOT NULL
  ) AS candidate;
$$;


--
-- Name: validate_classpilot_monitoring_interruption_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_classpilot_monitoring_interruption_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM student_sessions a JOIN students s ON s.id=a.student_id
   WHERE a.id=NEW.student_session_id AND a.student_id=NEW.student_id AND a.device_id=NEW.device_id AND s.school_id=NEW.school_id
   AND EXISTS(SELECT 1 FROM devices d WHERE d.school_id=NEW.school_id AND d.device_id=NEW.device_id))
 THEN RAISE EXCEPTION 'Invalid monitoring interruption binding' USING ERRCODE='23514'; END IF;
 IF NEW.scope_type='teaching_session' THEN
  IF NOT EXISTS(SELECT 1 FROM teaching_sessions c JOIN classpilot_session_students r ON r.school_id=c.school_id AND r.teaching_session_id=c.id
    WHERE c.school_id=NEW.school_id AND c.id=NEW.scope_id AND r.student_id=NEW.student_id)
  THEN RAISE EXCEPTION 'Invalid monitoring interruption class scope' USING ERRCODE='23514'; END IF;
 ELSIF NEW.scope_type='supervision_context' THEN
  IF NOT EXISTS(SELECT 1 FROM classpilot_supervision_contexts c JOIN classpilot_supervision_students r ON r.school_id=c.school_id AND r.context_id=c.id
    WHERE c.school_id=NEW.school_id AND c.id=NEW.scope_id AND r.student_id=NEW.student_id)
  THEN RAISE EXCEPTION 'Invalid monitoring interruption coverage scope' USING ERRCODE='23514'; END IF;
 ELSE RAISE EXCEPTION 'Invalid monitoring interruption scope type' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_school_website_delivery_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_school_website_delivery_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM student_sessions s JOIN students p ON p.id=s.student_id
   WHERE s.id=NEW.student_session_id AND p.school_id=NEW.school_id
   AND s.student_id=NEW.student_id AND s.device_id=NEW.device_id)
 THEN RAISE EXCEPTION 'Invalid school website delivery binding' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id text,
    school_id text NOT NULL,
    actor_id text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    details jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.activity_log FORCE ROW LEVEL SECURITY;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text,
    user_id text,
    user_email text,
    user_role text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    entity_name text,
    changes jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.audit_logs FORCE ROW LEVEL SECURITY;


--
-- Name: auth_lockouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_lockouts (
    email_lc text NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    first_fail_at timestamp without time zone DEFAULT now() NOT NULL,
    locked_until timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: authorized_pickups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authorized_pickups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    added_by text NOT NULL,
    name text NOT NULL,
    relationship text NOT NULL,
    phone text,
    photo_url text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT authorized_pickups_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'revoked'::text])))
);

ALTER TABLE ONLY public.authorized_pickups FORCE ROW LEVEL SECURITY;


--
-- Name: block_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.block_lists (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text NOT NULL,
    name text NOT NULL,
    description text,
    blocked_domains text[] DEFAULT '{}'::text[],
    is_default boolean DEFAULT false,
    visibility text DEFAULT 'private'::text NOT NULL,
    official boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    published_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT block_lists_visibility_check CHECK ((visibility = ANY (ARRAY['private'::text, 'school'::text])))
);

ALTER TABLE ONLY public.block_lists FORCE ROW LEVEL SECURITY;


--
-- Name: bus_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bus_routes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    route_number text NOT NULL,
    departure_time text,
    status text DEFAULT 'waiting'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.bus_routes FORCE ROW LEVEL SECURITY;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id character varying,
    supervision_context_id character varying,
    student_id text,
    student_session_id character varying,
    device_id text,
    client_message_id character varying(128),
    sender_id text NOT NULL,
    sender_type text NOT NULL,
    recipient_id text,
    content text NOT NULL,
    message_type text NOT NULL,
    delivery_status text DEFAULT 'sent'::text NOT NULL,
    delivered_at timestamp without time zone,
    failed_at timestamp without time zone,
    error_message text,
    seen_at timestamp with time zone,
    read_at timestamp with time zone,
    read_by text,
    deleted_at timestamp with time zone,
    deleted_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    private_chat_thread_id character varying,
    private_chat_school_epoch integer,
    private_chat_activity_epoch integer,
    private_chat_generation integer,
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(session_id, supervision_context_id) = 1))
);

ALTER TABLE ONLY public.chat_messages FORCE ROW LEVEL SECURITY;


--
-- Name: check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.check_ins (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id text NOT NULL,
    mood text NOT NULL,
    message text,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: classpilot_active_hands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_active_hands (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    student_id text NOT NULL,
    device_id text NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL,
    category text DEFAULT 'assignment'::text NOT NULL,
    explanation text DEFAULT ''::text NOT NULL,
    acknowledged_at timestamp without time zone,
    revision integer DEFAULT 1 NOT NULL,
    raised_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    cleared_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT cp_help_content CHECK (((status = ANY (ARRAY['waiting'::text, 'acknowledged'::text, 'helped'::text, 'withdrawn'::text])) AND (category = ANY (ARRAY['assignment'::text, 'blocked_website'::text, 'technical'::text])) AND (length(explanation) <= 500) AND (revision > 0)))
);

ALTER TABLE ONLY public.classpilot_active_hands FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_ai_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_ai_decisions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text,
    device_id text,
    heartbeat_id text,
    url text,
    title text,
    domain text,
    category text,
    content_category text,
    safety_alert text,
    confidence integer,
    reasoning text,
    matched_rule text,
    action_taken text,
    teacher_intent_source text,
    review_status text,
    review_note text,
    reviewed_by text,
    reviewed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_ai_decisions FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_chat_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_chat_deliveries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    chat_message_id character varying NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    student_id text NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    last_attempt_at timestamp with time zone,
    last_attempt_student_session_id character varying,
    last_attempt_device_id text,
    expires_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    failed_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_chat_deliveries_attempt_check CHECK ((attempt_count >= 0)),
    CONSTRAINT classpilot_chat_deliveries_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'leased'::text, 'attempted'::text, 'retry'::text, 'delivered'::text, 'failed'::text, 'expired'::text]))),
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1))
);

ALTER TABLE ONLY public.classpilot_chat_deliveries FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_classroom_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_classroom_states (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    student_id text,
    state_type text NOT NULL,
    state_key text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    command_id character varying,
    applied_by text NOT NULL,
    applied_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    cleared_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1))
);

ALTER TABLE ONLY public.classpilot_classroom_states FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_command_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_command_targets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    command_id character varying NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    student_id text NOT NULL,
    student_session_id character varying,
    device_id text,
    status text DEFAULT 'requested'::text NOT NULL,
    ack_state text,
    error_message text,
    result jsonb,
    sent_at timestamp without time zone,
    received_at timestamp without time zone,
    completed_at timestamp without time zone,
    failed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_command_targets FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_commands (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    teacher_id text NOT NULL,
    target_scope text NOT NULL,
    subgroup_id character varying,
    command_type text NOT NULL,
    command_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'requested'::text NOT NULL,
    requested_count integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    received_count integer DEFAULT 0 NOT NULL,
    completed_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    unavailable_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_commands FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_coverage_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_coverage_assignments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    staff_id text NOT NULL,
    scope_type text NOT NULL,
    scope_value text,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_coverage_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_coverage_group_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_coverage_group_categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_coverage_group_categories_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 80)))
);

ALTER TABLE ONLY public.classpilot_coverage_group_categories FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_coverage_scope_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_coverage_scope_group_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    coverage_group_id character varying NOT NULL,
    student_id text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_coverage_scope_group_members FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_coverage_scope_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_coverage_scope_groups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    description text,
    category_id character varying,
    active boolean DEFAULT true NOT NULL,
    created_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_coverage_scope_groups FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_evidence_capture_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_evidence_capture_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    student_session_id character varying NOT NULL,
    device_id text NOT NULL,
    teaching_session_id character varying,
    case_id text,
    heartbeat_id text NOT NULL,
    tab_ref character varying(128) NOT NULL,
    tab_snapshot_revision integer NOT NULL,
    expected_url_digest character varying(64) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    artifact_id character varying,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT cp_evidence_capture_revision_check CHECK ((tab_snapshot_revision > 0)),
    CONSTRAINT cp_evidence_capture_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'uploaded'::text, 'expired'::text, 'failed'::text]))),
    CONSTRAINT cp_evidence_capture_window_check CHECK ((expires_at > requested_at))
);

ALTER TABLE ONLY public.classpilot_evidence_capture_requests FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_lesson_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_lesson_activities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    start_command_id character varying NOT NULL,
    title text NOT NULL,
    instructions text DEFAULT ''::text NOT NULL,
    resources jsonb DEFAULT '[]'::jsonb NOT NULL,
    checklist jsonb DEFAULT '[]'::jsonb NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    CONSTRAINT classpilot_lesson_activities_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_lesson_activities_instructions_check CHECK ((length(instructions) <= 4000)),
    CONSTRAINT classpilot_lesson_activities_revision_check CHECK ((revision > 0)),
    CONSTRAINT classpilot_lesson_activities_title_check CHECK (((length(title) >= 1) AND (length(title) <= 200)))
);

ALTER TABLE ONLY public.classpilot_lesson_activities FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_lesson_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_lesson_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    lesson_activity_id character varying NOT NULL,
    student_id character varying NOT NULL,
    status text DEFAULT 'not_reported'::text NOT NULL,
    completed_item_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_lesson_progress_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_lesson_progress_revision_check CHECK ((revision > 0)),
    CONSTRAINT classpilot_lesson_progress_status_check CHECK ((status = ANY (ARRAY['not_reported'::text, 'working'::text, 'stuck'::text, 'ready_for_review'::text, 'finished'::text])))
);

ALTER TABLE ONLY public.classpilot_lesson_progress FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_monitoring_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_monitoring_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    device_id text,
    student_session_id character varying NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    source_event_id character varying(128) NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    origin text NOT NULL,
    event_type text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    normalized_domain text,
    sanitized_path text,
    title text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    retention_expires_at timestamp with time zone NOT NULL,
    CONSTRAINT cp_monitoring_events_origin_check CHECK ((origin = ANY (ARRAY['extension'::text, 'server'::text]))),
    CONSTRAINT cp_monitoring_events_schema_check CHECK ((schema_version = 1)),
    CONSTRAINT cp_monitoring_events_scope_xor_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT cp_monitoring_events_type_check CHECK ((event_type = ANY (ARRAY['tab_changed'::text, 'navigation_changed'::text, 'navigation_blocked'::text, 'monitoring_state_changed'::text, 'restriction_state_applied'::text, 'restriction_state_failed'::text, 'restriction_state_cleared'::text, 'student_session_started'::text, 'student_session_ended'::text, 'monitoring_gap'::text])))
);

ALTER TABLE ONLY public.classpilot_monitoring_events FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_monitoring_expectations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_monitoring_expectations (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    student_session_id text NOT NULL,
    device_id text NOT NULL,
    scope_type text NOT NULL,
    scope_id text NOT NULL,
    scope_name text NOT NULL,
    teaching_session_id text GENERATED ALWAYS AS (
CASE
    WHEN (scope_type = 'teaching_session'::text) THEN scope_id
    ELSE NULL::text
END) STORED,
    supervision_context_id text GENERATED ALWAYS AS (
CASE
    WHEN (scope_type = 'supervision_context'::text) THEN scope_id
    ELSE NULL::text
END) STORED,
    scope_started_at timestamp with time zone NOT NULL,
    scope_ends_at timestamp with time zone,
    last_observed_at timestamp with time zone NOT NULL,
    last_checked_at timestamp with time zone NOT NULL,
    uncertain_since timestamp with time zone,
    retention_expires_at timestamp with time zone NOT NULL,
    CONSTRAINT cp_monitoring_expectation_scope_check CHECK ((scope_type = ANY (ARRAY['teaching_session'::text, 'supervision_context'::text])))
);

ALTER TABLE ONLY public.classpilot_monitoring_expectations FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_monitoring_interruption_digests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_monitoring_interruption_digests (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    local_date text NOT NULL,
    recipient_user_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    due_at timestamp with time zone NOT NULL,
    claimed_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_code text,
    retention_expires_at timestamp with time zone NOT NULL,
    CONSTRAINT cp_monitoring_digest_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sending'::text, 'sent'::text, 'unknown'::text, 'failed'::text, 'cancelled'::text])))
);

ALTER TABLE ONLY public.classpilot_monitoring_interruption_digests FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_monitoring_interruption_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_monitoring_interruption_settings (
    school_id text NOT NULL,
    digest_enabled boolean DEFAULT false NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    updated_by text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_scanned_at timestamp with time zone,
    last_healthy_at timestamp with time zone,
    scan_status text DEFAULT 'unknown'::text NOT NULL,
    CONSTRAINT cp_monitoring_interruption_settings_revision_check CHECK ((revision >= 0)),
    CONSTRAINT cp_monitoring_interruption_settings_status_check CHECK ((scan_status = ANY (ARRAY['healthy'::text, 'uncertain'::text, 'not_expected'::text, 'unknown'::text])))
);

ALTER TABLE ONLY public.classpilot_monitoring_interruption_settings FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_monitoring_interruptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_monitoring_interruptions (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    expectation_id text NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    student_session_id text NOT NULL,
    device_id text NOT NULL,
    scope_type text NOT NULL,
    scope_id text NOT NULL,
    scope_name text NOT NULL,
    teaching_session_id text GENERATED ALWAYS AS (
CASE
    WHEN (scope_type = 'teaching_session'::text) THEN scope_id
    ELSE NULL::text
END) STORED,
    supervision_context_id text GENERATED ALWAYS AS (
CASE
    WHEN (scope_type = 'supervision_context'::text) THEN scope_id
    ELSE NULL::text
END) STORED,
    last_observed_at timestamp with time zone NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    recovered_at timestamp with time zone,
    ended_at timestamp with time zone,
    end_reason text,
    uncertain_since timestamp with time zone,
    retention_expires_at timestamp with time zone NOT NULL,
    CONSTRAINT cp_monitoring_interruption_end_check CHECK ((((ended_at IS NULL) AND (end_reason IS NULL)) OR ((ended_at IS NOT NULL) AND (end_reason IS NOT NULL)))),
    CONSTRAINT cp_monitoring_interruption_recovery_check CHECK (((recovered_at IS NULL) OR ((ended_at IS NOT NULL) AND (end_reason = 'telemetry_resumed'::text)))),
    CONSTRAINT cp_monitoring_interruption_scope_check CHECK ((scope_type = ANY (ARRAY['teaching_session'::text, 'supervision_context'::text])))
);

ALTER TABLE ONLY public.classpilot_monitoring_interruptions FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_picker_rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_picker_rounds (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    excluded_student_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    used_student_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    selected_student_id character varying,
    CONSTRAINT classpilot_picker_rounds_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_picker_rounds_revision_check CHECK ((revision > 0))
);

ALTER TABLE ONLY public.classpilot_picker_rounds FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_private_chat_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_private_chat_threads (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    authority_assignment_id character varying NOT NULL,
    generation integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_private_chat_threads_generation_check CHECK ((generation > 0)),
    CONSTRAINT cp_private_chat_parent_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1))
);

ALTER TABLE ONLY public.classpilot_private_chat_threads FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    student_id character varying NOT NULL,
    client_request_id character varying NOT NULL,
    question text NOT NULL,
    group_label text,
    answer text,
    CONSTRAINT classpilot_questions_answer_check CHECK ((length(answer) <= 500)),
    CONSTRAINT classpilot_questions_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_questions_group_label_check CHECK ((length(group_label) <= 100)),
    CONSTRAINT classpilot_questions_question_check CHECK (((length(question) >= 1) AND (length(question) <= 500))),
    CONSTRAINT classpilot_questions_revision_check CHECK ((revision > 0))
);

ALTER TABLE ONLY public.classpilot_questions FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_routine_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_routine_runs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    teacher_id character varying NOT NULL,
    title text NOT NULL,
    steps jsonb NOT NULL,
    current_step integer DEFAULT 0 NOT NULL,
    target_student_ids jsonb NOT NULL,
    outcomes jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT classpilot_routine_runs_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_routine_runs_current_step_check CHECK ((current_step >= 0)),
    CONSTRAINT classpilot_routine_runs_revision_check CHECK ((revision > 0)),
    CONSTRAINT classpilot_routine_runs_title_check CHECK (((length(title) >= 1) AND (length(title) <= 200)))
);

ALTER TABLE ONLY public.classpilot_routine_runs FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_schedule_change_legs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_schedule_change_legs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    schedule_change_id character varying NOT NULL,
    scheduled_date text NOT NULL,
    leg_order integer NOT NULL,
    group_id text NOT NULL,
    primary_teacher_id_snapshot text NOT NULL,
    class_name_snapshot text NOT NULL,
    original_start_time text NOT NULL,
    original_end_time text NOT NULL,
    effective_start_time text NOT NULL,
    effective_end_time text NOT NULL,
    reservation_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_schedule_change_legs_date_check CHECK ((scheduled_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'::text)),
    CONSTRAINT cp_schedule_change_legs_order_check CHECK ((leg_order = ANY (ARRAY[1, 2]))),
    CONSTRAINT cp_schedule_change_legs_window_check CHECK (((original_start_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text) AND (original_end_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text) AND (effective_start_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text) AND (effective_end_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text) AND (original_start_time < original_end_time) AND (effective_start_time < effective_end_time)))
);

ALTER TABLE ONLY public.classpilot_schedule_change_legs FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_schedule_change_pairs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_schedule_change_pairs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    first_group_id text NOT NULL,
    second_group_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    created_by text NOT NULL,
    archived_by text,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_schedule_change_pairs_group_order_check CHECK ((first_group_id < second_group_id)),
    CONSTRAINT cp_schedule_change_pairs_revision_check CHECK ((revision >= 0)),
    CONSTRAINT cp_schedule_change_pairs_status_check CHECK ((status = ANY (ARRAY['active'::text, 'archived'::text])))
);

ALTER TABLE ONLY public.classpilot_schedule_change_pairs FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_schedule_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_schedule_changes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    pair_id character varying NOT NULL,
    scheduled_date text NOT NULL,
    timezone_snapshot text NOT NULL,
    status text NOT NULL,
    reason text NOT NULL,
    requested_by_user_id text NOT NULL,
    requester_group_id text,
    counterpart_teacher_id text,
    requested_by_role text NOT NULL,
    requires_admin_approval boolean NOT NULL,
    reservation_active boolean DEFAULT true NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    accepted_by_user_id text,
    accepted_at timestamp with time zone,
    approved_by_user_id text,
    approved_at timestamp with time zone,
    terminal_by_user_id text,
    terminal_reason text,
    terminal_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_schedule_changes_date_check CHECK ((scheduled_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'::text)),
    CONSTRAINT cp_schedule_changes_reason_check CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 500))),
    CONSTRAINT cp_schedule_changes_reservation_check CHECK (((status = ANY (ARRAY['pending_counterpart'::text, 'pending_admin'::text, 'approved'::text])) = reservation_active)),
    CONSTRAINT cp_schedule_changes_revision_check CHECK ((revision >= 0)),
    CONSTRAINT cp_schedule_changes_status_check CHECK ((status = ANY (ARRAY['pending_counterpart'::text, 'pending_admin'::text, 'approved'::text, 'declined'::text, 'denied'::text, 'cancelled'::text, 'expired'::text, 'superseded'::text])))
);

ALTER TABLE ONLY public.classpilot_schedule_changes FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_scheduled_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_scheduled_conflicts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    group_id text NOT NULL,
    teacher_id text NOT NULL,
    scheduled_date text NOT NULL,
    block_start_time text NOT NULL,
    block_end_time text,
    status text DEFAULT 'coverage_needed'::text NOT NULL,
    conflict_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    scheduled_teacher_connected boolean DEFAULT false NOT NULL,
    last_checked_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by text,
    resolution text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_scheduled_conflicts FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_school_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_school_schedules (
    school_id text NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    config jsonb NOT NULL,
    profile_activation_outcomes jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    next_boundary_at timestamp with time zone DEFAULT now(),
    boundary_generation integer DEFAULT 0 NOT NULL,
    boundary_lease_owner text,
    boundary_lease_until timestamp with time zone,
    CONSTRAINT cp_schedule_profile_outcomes_object_check CHECK ((jsonb_typeof(profile_activation_outcomes) = 'object'::text))
);

ALTER TABLE ONLY public.classpilot_school_schedules FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_school_website_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_school_website_deliveries (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    policy_revision integer NOT NULL,
    student_id text NOT NULL,
    student_session_id text NOT NULL,
    device_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    closed_tab_count integer DEFAULT 0 NOT NULL,
    error_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    CONSTRAINT classpilot_school_website_deliveries_closed_tab_count_check CHECK (((closed_tab_count >= 0) AND (closed_tab_count <= 1000))),
    CONSTRAINT classpilot_school_website_deliveries_policy_revision_check CHECK ((policy_revision >= 0)),
    CONSTRAINT classpilot_school_website_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'applied'::text, 'failed'::text])))
);

ALTER TABLE ONLY public.classpilot_school_website_deliveries FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_school_website_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_school_website_policies (
    school_id text NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT classpilot_school_website_policies_revision_check CHECK ((revision >= 0))
);

ALTER TABLE ONLY public.classpilot_school_website_policies FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    timezone text NOT NULL,
    report_version integer DEFAULT 1 NOT NULL,
    coverage_algorithm_version text DEFAULT 'heartbeat-coverage-v1'::text NOT NULL,
    event_schema_version integer DEFAULT 1 NOT NULL,
    authorization_marker jsonb NOT NULL,
    tracking_policy jsonb,
    roster_count integer DEFAULT 0 NOT NULL,
    eligible_student_count integer DEFAULT 0 NOT NULL,
    complete_count integer DEFAULT 0 NOT NULL,
    partial_count integer DEFAULT 0 NOT NULL,
    none_count integer DEFAULT 0 NOT NULL,
    not_expected_count integer DEFAULT 0 NOT NULL,
    unavailable_count integer DEFAULT 0 NOT NULL,
    total_eligible_seconds integer DEFAULT 0 NOT NULL,
    total_observed_seconds integer DEFAULT 0 NOT NULL,
    total_gap_seconds integer DEFAULT 0 NOT NULL,
    total_unclassified_seconds integer DEFAULT 0 NOT NULL,
    total_off_task_seconds integer DEFAULT 0 NOT NULL,
    total_off_task_event_count integer DEFAULT 0 NOT NULL,
    total_safety_alert_count integer DEFAULT 0 NOT NULL,
    settle_at timestamp with time zone NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    next_attempt_at timestamp with time zone NOT NULL,
    last_error text,
    materialized_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    detail_expired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_session_reports_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT cp_session_reports_authorization_marker_check CHECK (((jsonb_typeof(authorization_marker) = 'object'::text) AND ((authorization_marker ->> 'version'::text) = '1'::text) AND (jsonb_typeof((authorization_marker -> 'salt'::text)) = 'string'::text) AND ((length((authorization_marker ->> 'salt'::text)) >= 16) AND (length((authorization_marker ->> 'salt'::text)) <= 128)) AND (jsonb_typeof((authorization_marker -> 'digests'::text)) = 'array'::text))),
    CONSTRAINT cp_session_reports_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'materializing'::text, 'ready'::text, 'failed'::text, 'expired'::text]))),
    CONSTRAINT cp_session_reports_window_check CHECK ((window_end >= window_start))
);

ALTER TABLE ONLY public.classpilot_session_reports FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_staff (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying NOT NULL,
    staff_id text NOT NULL,
    role text NOT NULL,
    staff_name_snapshot text,
    staff_email_snapshot text,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_session_staff_role_check CHECK ((role = ANY (ARRAY['primary'::text, 'co_teacher'::text])))
);

ALTER TABLE ONLY public.classpilot_session_staff FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_student_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_student_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    report_id character varying NOT NULL,
    teaching_session_id character varying NOT NULL,
    student_id text NOT NULL,
    student_name_snapshot text NOT NULL,
    status text NOT NULL,
    eligible_seconds integer DEFAULT 0 NOT NULL,
    observed_seconds integer DEFAULT 0 NOT NULL,
    gap_seconds integer DEFAULT 0 NOT NULL,
    coverage_percent integer,
    heartbeat_count integer DEFAULT 0 NOT NULL,
    first_observed_at timestamp with time zone,
    last_observed_at timestamp with time zone,
    gap_intervals jsonb DEFAULT '[]'::jsonb NOT NULL,
    event_counts jsonb DEFAULT '{}'::jsonb NOT NULL,
    top_domains jsonb DEFAULT '[]'::jsonb NOT NULL,
    unclassified_seconds integer DEFAULT 0 NOT NULL,
    off_task_seconds integer DEFAULT 0 NOT NULL,
    off_task_categories jsonb DEFAULT '[]'::jsonb NOT NULL,
    off_task_event_count integer DEFAULT 0 NOT NULL,
    off_task_events jsonb DEFAULT '[]'::jsonb NOT NULL,
    safety_alerts jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_student_reports_coverage_check CHECK (((coverage_percent IS NULL) OR ((coverage_percent >= 0) AND (coverage_percent <= 100)))),
    CONSTRAINT cp_student_reports_status_check CHECK ((status = ANY (ARRAY['complete'::text, 'partial'::text, 'none'::text, 'not_expected'::text, 'unavailable'::text])))
);

ALTER TABLE ONLY public.classpilot_session_student_reports FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying NOT NULL,
    group_id text NOT NULL,
    student_id text NOT NULL,
    student_name_snapshot text,
    captured_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_session_students FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_summary_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_summary_deliveries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying NOT NULL,
    recipient_kind text NOT NULL,
    recipient_email text NOT NULL,
    recipient_name text,
    state text DEFAULT 'waiting_report'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    submission_started_at timestamp with time zone,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_message_id text,
    last_error text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_summary_delivery_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT cp_summary_delivery_email_check CHECK ((btrim(recipient_email) <> ''::text)),
    CONSTRAINT cp_summary_delivery_recipient_kind_check CHECK ((recipient_kind = ANY (ARRAY['teacher'::text, 'central'::text]))),
    CONSTRAINT cp_summary_delivery_state_check CHECK ((state = ANY (ARRAY['waiting_report'::text, 'queued'::text, 'leased'::text, 'retry'::text, 'sent'::text, 'failed'::text, 'unknown'::text])))
);

ALTER TABLE ONLY public.classpilot_session_summary_deliveries FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_session_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_session_usage (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying NOT NULL,
    group_id text NOT NULL,
    student_id text NOT NULL,
    local_date text NOT NULL,
    total_seconds integer DEFAULT 0 NOT NULL,
    heartbeat_count integer DEFAULT 0 NOT NULL,
    top_domains jsonb,
    top_activities jsonb,
    first_seen timestamp with time zone,
    last_seen timestamp with time zone,
    computed_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classpilot_session_usage FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_student_control_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_student_control_states (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 0 NOT NULL,
    desired_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_command_id character varying,
    scheduled_end_at timestamp with time zone,
    hard_expires_at timestamp with time zone,
    enforcement_health text DEFAULT 'pending'::text NOT NULL,
    applied_revision integer,
    last_outcome text,
    last_error text,
    last_acknowledged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_student_control_states_applied_revision_check CHECK (((applied_revision IS NULL) OR ((applied_revision >= 0) AND (applied_revision <= revision)))),
    CONSTRAINT cp_student_control_states_health_check CHECK ((enforcement_health = ANY (ARRAY['synced'::text, 'pending'::text, 'failed'::text, 'unsupported'::text, 'expired'::text]))),
    CONSTRAINT cp_student_control_states_revision_check CHECK ((revision >= 0)),
    CONSTRAINT cp_student_control_states_session_expiry_check CHECK ((((num_nonnulls(teaching_session_id, supervision_context_id) = 0) AND (scheduled_end_at IS NULL) AND (hard_expires_at IS NULL)) OR ((num_nonnulls(teaching_session_id, supervision_context_id) = 1) AND (hard_expires_at IS NOT NULL) AND ((scheduled_end_at IS NULL) OR (scheduled_end_at <= hard_expires_at)))))
);

ALTER TABLE ONLY public.classpilot_student_control_states FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_supervision_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_supervision_contexts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    context_type text NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    assigned_staff_id text NOT NULL,
    classroom_authority_revision integer DEFAULT 0 NOT NULL,
    coverage_group_id text,
    scheduled_conflict_id text,
    schedule_profile_application_id text,
    schedule_profile_block_id text,
    schedule_profile_date text,
    created_by text NOT NULL,
    note text,
    starts_at timestamp without time zone DEFAULT now() NOT NULL,
    ends_at timestamp without time zone NOT NULL,
    ended_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_context_classroom_authority_revision_check CHECK ((classroom_authority_revision >= 0)),
    CONSTRAINT cp_supervision_schedule_profile_metadata_check CHECK ((((schedule_profile_application_id IS NULL) AND (schedule_profile_block_id IS NULL) AND (schedule_profile_date IS NULL)) OR ((schedule_profile_application_id IS NOT NULL) AND ((length(schedule_profile_application_id) >= 1) AND (length(schedule_profile_application_id) <= 128)) AND (schedule_profile_block_id IS NOT NULL) AND ((length(schedule_profile_block_id) >= 1) AND (length(schedule_profile_block_id) <= 128)) AND (schedule_profile_date IS NOT NULL) AND (schedule_profile_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'::text))))
);

ALTER TABLE ONLY public.classpilot_supervision_contexts FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_supervision_report_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_supervision_report_segments (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    context_id text NOT NULL,
    staff_id text,
    staff_name_snapshot text,
    context_name_snapshot text,
    context_type text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone,
    state text DEFAULT 'active'::text NOT NULL,
    closure_reason text,
    partial_adoption boolean DEFAULT false NOT NULL,
    timezone text NOT NULL,
    tracking_policy jsonb,
    retention_hours integer DEFAULT 720 NOT NULL,
    report_version integer DEFAULT 2 NOT NULL,
    summary jsonb,
    settle_at timestamp with time zone,
    next_attempt_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    last_error text,
    materialized_at timestamp with time zone,
    expires_at timestamp with time zone,
    detail_expired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_supervision_report_attempt_check CHECK (((attempt_count >= 0) AND (report_version > 0) AND ((retention_hours >= 24) AND (retention_hours <= 8760)))),
    CONSTRAINT cp_supervision_report_closed_check CHECK (((state = 'active'::text) OR ((window_end IS NOT NULL) AND (settle_at IS NOT NULL) AND (expires_at IS NOT NULL)))),
    CONSTRAINT cp_supervision_report_state_check CHECK ((state = ANY (ARRAY['active'::text, 'pending'::text, 'materializing'::text, 'ready'::text, 'failed'::text, 'expired'::text]))),
    CONSTRAINT cp_supervision_report_window_check CHECK (((window_end IS NULL) OR (window_end >= window_start)))
);

ALTER TABLE ONLY public.classpilot_supervision_report_segments FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_supervision_student_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_supervision_student_reports (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    report_id text NOT NULL,
    student_id text NOT NULL,
    student_name_snapshot text NOT NULL,
    participation_intervals jsonb DEFAULT '[]'::jsonb NOT NULL,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_supervision_student_report_intervals_check CHECK ((jsonb_typeof(participation_intervals) = 'array'::text))
);

ALTER TABLE ONLY public.classpilot_supervision_student_reports FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_supervision_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_supervision_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    context_id character varying NOT NULL,
    student_id text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    assigned_by text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL,
    released_at timestamp without time zone,
    release_reason text
);

ALTER TABLE ONLY public.classpilot_supervision_students FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_supervision_summary_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_supervision_summary_deliveries (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    school_id text NOT NULL,
    report_id text NOT NULL,
    recipient_staff_id text,
    recipient_kind text NOT NULL,
    recipient_email text,
    recipient_name text,
    state text DEFAULT 'waiting_report'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    submission_started_at timestamp with time zone,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_message_id text,
    last_error text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_supervision_delivery_attempt_check CHECK ((attempt_count >= 0)),
    CONSTRAINT cp_supervision_delivery_kind_check CHECK ((recipient_kind = ANY (ARRAY['supervisor'::text, 'central'::text]))),
    CONSTRAINT cp_supervision_delivery_state_check CHECK ((state = ANY (ARRAY['waiting_report'::text, 'queued'::text, 'leased'::text, 'retry'::text, 'sent'::text, 'failed'::text, 'unknown'::text, 'expired'::text])))
);

ALTER TABLE ONLY public.classpilot_supervision_summary_deliveries FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_teacher_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_teacher_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text NOT NULL,
    max_tabs_per_student integer,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_teacher_preferences_bounds CHECK (((revision > 0) AND ((max_tabs_per_student IS NULL) OR ((max_tabs_per_student >= 1) AND (max_tabs_per_student <= 100)))))
);

ALTER TABLE ONLY public.classpilot_teacher_preferences FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_timers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_timers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    start_command_id character varying NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    deadline timestamp without time zone,
    paused_remaining_ms integer,
    expires_at timestamp without time zone NOT NULL,
    CONSTRAINT classpilot_timers_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1)),
    CONSTRAINT classpilot_timers_check1 CHECK (((ended_at IS NOT NULL) OR (num_nonnulls(deadline, paused_remaining_ms) = 1))),
    CONSTRAINT classpilot_timers_message_check CHECK ((length(message) <= 500)),
    CONSTRAINT classpilot_timers_paused_remaining_ms_check CHECK (((paused_remaining_ms >= 0) AND (paused_remaining_ms <= 3600000))),
    CONSTRAINT classpilot_timers_revision_check CHECK ((revision > 0))
);

ALTER TABLE ONLY public.classpilot_timers FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_tool_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_tool_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teaching_session_id character varying,
    supervision_context_id character varying,
    actor_id character varying NOT NULL,
    kind text NOT NULL,
    resource_id character varying NOT NULL,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_tool_history_check CHECK ((num_nonnulls(teaching_session_id, supervision_context_id) = 1))
);

ALTER TABLE ONLY public.classpilot_tool_history FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_tool_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_tool_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id character varying NOT NULL,
    kind text NOT NULL,
    name text NOT NULL,
    content jsonb NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT classpilot_tool_templates_kind_check CHECK ((kind = ANY (ARRAY['attention'::text, 'poll'::text, 'exit_ticket'::text, 'activity'::text, 'routine'::text]))),
    CONSTRAINT classpilot_tool_templates_name_check CHECK (((length(name) >= 1) AND (length(name) <= 100))),
    CONSTRAINT classpilot_tool_templates_revision_check CHECK ((revision > 0))
);

ALTER TABLE ONLY public.classpilot_tool_templates FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_usage_rollup_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_usage_rollup_days (
    school_id text NOT NULL,
    usage_date date NOT NULL,
    day_start_at timestamp with time zone NOT NULL,
    day_end_at timestamp with time zone NOT NULL,
    processed_through timestamp with time zone NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    is_final boolean DEFAULT false NOT NULL,
    CONSTRAINT cp_usage_days_window_check CHECK (((day_start_at < day_end_at) AND (processed_through >= day_start_at) AND (processed_through <= day_end_at) AND ((NOT is_final) OR (processed_through = day_end_at))))
);

ALTER TABLE ONLY public.classpilot_usage_rollup_days FORCE ROW LEVEL SECURITY;


--
-- Name: classpilot_usage_rollups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classpilot_usage_rollups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    usage_date date NOT NULL,
    student_id text NOT NULL,
    class_id text,
    session_id text,
    domain text DEFAULT ''::text NOT NULL,
    classification text NOT NULL,
    seconds integer NOT NULL,
    heartbeat_count integer NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_usage_rollups_classification_check CHECK ((classification = ANY (ARRAY['educational'::text, 'non-educational'::text, 'unknown'::text]))),
    CONSTRAINT cp_usage_rollups_domain_check CHECK ((char_length(domain) <= 253)),
    CONSTRAINT cp_usage_rollups_heartbeat_count_check CHECK ((heartbeat_count >= 0)),
    CONSTRAINT cp_usage_rollups_seconds_check CHECK ((seconds >= 0))
)
WITH (autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.05');

ALTER TABLE ONLY public.classpilot_usage_rollups FORCE ROW LEVEL SECURITY;


--
-- Name: classroom_course_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classroom_course_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    course_id text NOT NULL,
    student_id text NOT NULL,
    google_user_id text,
    student_email_lc text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classroom_course_students FORCE ROW LEVEL SECURITY;


--
-- Name: classroom_courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classroom_courses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    google_course_id text NOT NULL,
    name text NOT NULL,
    section text,
    room text,
    description_heading text,
    owner_id text,
    grade_id text,
    last_synced_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.classroom_courses FORCE ROW LEVEL SECURITY;


--
-- Name: custody_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custody_alerts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    person_name text NOT NULL,
    alert_type text NOT NULL,
    notes text,
    court_order text,
    created_by text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.custody_alerts FORCE ROW LEVEL SECURITY;


--
-- Name: daily_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_usage (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    date text NOT NULL,
    total_seconds integer DEFAULT 0 NOT NULL,
    heartbeat_count integer DEFAULT 0 NOT NULL,
    top_domains jsonb,
    first_seen timestamp without time zone,
    last_seen timestamp without time zone,
    computed_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.daily_usage FORCE ROW LEVEL SECURITY;


--
-- Name: dashboard_tabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_tabs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    teacher_id text NOT NULL,
    school_id text,
    label text NOT NULL,
    filter_type text NOT NULL,
    filter_value jsonb,
    "order" text DEFAULT '0'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.dashboard_tabs FORCE ROW LEVEL SECURITY;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    device_id character varying NOT NULL,
    device_name text,
    school_id text NOT NULL,
    class_id text NOT NULL,
    extension_version text,
    chrome_version text,
    last_screenshot_health jsonb,
    last_seen_at timestamp without time zone,
    registered_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.devices FORCE ROW LEVEL SECURITY;


--
-- Name: dismissal_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dismissal_changes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id text NOT NULL,
    student_id text NOT NULL,
    requested_by text NOT NULL,
    from_type text NOT NULL,
    to_type text NOT NULL,
    bus_route text,
    note text,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by text,
    acknowledged_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp without time zone,
    acknowledged_at timestamp without time zone,
    CONSTRAINT dismissal_changes_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);

ALTER TABLE ONLY public.dismissal_changes FORCE ROW LEVEL SECURITY;


--
-- Name: dismissal_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dismissal_overrides (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id text NOT NULL,
    student_id text NOT NULL,
    original_type text NOT NULL,
    override_type text NOT NULL,
    bus_route text,
    reason text,
    changed_by text NOT NULL,
    changed_by_role text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT dismissal_overrides_type_check CHECK (((original_type = ANY (ARRAY['car'::text, 'bus'::text, 'walker'::text, 'afterschool'::text])) AND (override_type = ANY (ARRAY['car'::text, 'bus'::text, 'walker'::text, 'afterschool'::text]))))
);

ALTER TABLE ONLY public.dismissal_overrides FORCE ROW LEVEL SECURITY;


--
-- Name: dismissal_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dismissal_queue (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id text NOT NULL,
    student_id text NOT NULL,
    guardian_id text,
    guardian_name text,
    pickup_group_id text,
    pickup_group_label text,
    check_in_time timestamp without time zone DEFAULT now(),
    check_in_method text,
    status text DEFAULT 'waiting'::text NOT NULL,
    zone text,
    called_at timestamp without time zone,
    released_at timestamp without time zone,
    dismissed_at timestamp without time zone,
    hold_reason text,
    delayed_until timestamp without time zone,
    "position" integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT dismissal_queue_status_check CHECK ((status = ANY (ARRAY['waiting'::text, 'called'::text, 'released'::text, 'dismissed'::text, 'held'::text, 'delayed'::text])))
);

ALTER TABLE ONLY public.dismissal_queue FORCE ROW LEVEL SECURITY;


--
-- Name: dismissal_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dismissal_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp without time zone,
    ended_at timestamp without time zone,
    stats jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT dismissal_sessions_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'paused'::text, 'completed'::text])))
);

ALTER TABLE ONLY public.dismissal_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: email_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_alerts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    student_email text NOT NULL,
    gmail_message_id text NOT NULL,
    safety_source_id text,
    gmail_thread_id text,
    direction text NOT NULL,
    sender text,
    recipients jsonb,
    subject text,
    snippet text,
    category text,
    safety_alert text,
    bullying text,
    confidence integer,
    severity text DEFAULT 'medium'::text NOT NULL,
    reasoning text,
    message_date timestamp without time zone,
    alerted_at timestamp without time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp without time zone,
    reviewed_by text,
    review_status text,
    review_note text
);

ALTER TABLE ONLY public.email_alerts FORCE ROW LEVEL SECURITY;


--
-- Name: email_scan_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_scan_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    date text NOT NULL,
    messages_scanned integer DEFAULT 0 NOT NULL,
    alerts_raised integer DEFAULT 0 NOT NULL,
    errors integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.email_scan_log FORCE ROW LEVEL SECURITY;


--
-- Name: error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    message text NOT NULL,
    stack text,
    request_id text,
    method text,
    path text,
    status_code integer,
    school_id text,
    user_id text,
    context jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.error_logs FORCE ROW LEVEL SECURITY;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    device_id text NOT NULL,
    student_id text,
    event_type text NOT NULL,
    metadata jsonb,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: evidence_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_artifacts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    device_id text,
    student_session_id character varying,
    binding_version text,
    case_id text,
    source_type text NOT NULL,
    source_id text,
    artifact_type text NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    label text,
    content_type text,
    content text,
    metadata jsonb,
    captured_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text,
    CONSTRAINT evidence_artifacts_screenshot_exact_authority_check CHECK (((artifact_type <> 'screenshot'::text) OR ((device_id IS NOT NULL) AND (student_session_id IS NOT NULL) AND (binding_version IS NOT NULL) AND (captured_at IS NOT NULL))))
);

ALTER TABLE ONLY public.evidence_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: family_group_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_group_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    family_group_id text NOT NULL,
    student_id text NOT NULL
);

ALTER TABLE ONLY public.family_group_students FORCE ROW LEVEL SECURITY;


--
-- Name: family_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_groups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    car_number text NOT NULL,
    family_name text,
    invite_token text,
    claimed_by_user_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.family_groups FORCE ROW LEVEL SECURITY;


--
-- Name: flight_paths; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flight_paths (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text,
    flight_path_name text NOT NULL,
    description text,
    allowed_domains text[] DEFAULT '{}'::text[],
    resources jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocked_domains text[] DEFAULT '{}'::text[],
    is_default boolean DEFAULT false,
    source_type text,
    source_course_id text,
    source_resource_ids text[] DEFAULT '{}'::text[],
    source_updated_at timestamp without time zone,
    visibility text DEFAULT 'private'::text NOT NULL,
    official boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    published_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT date_trunc('milliseconds'::text, clock_timestamp()) NOT NULL,
    CONSTRAINT flight_paths_resources_check CHECK (
CASE
    WHEN (jsonb_typeof(resources) = 'array'::text) THEN ((jsonb_array_length(resources) <= 200) AND (octet_length((resources)::text) <= 65536))
    ELSE false
END),
    CONSTRAINT flight_paths_visibility_check CHECK ((visibility = ANY (ARRAY['private'::text, 'school'::text])))
);

ALTER TABLE ONLY public.flight_paths FORCE ROW LEVEL SECURITY;


--
-- Name: google_oauth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.google_oauth_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    refresh_token text NOT NULL,
    scope text,
    token_type text,
    connected_email text,
    connected_domain text,
    expiry_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: google_roster_connectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.google_roster_connectors (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    domain text NOT NULL,
    delegated_admin_email text,
    service_account_client_id text,
    approved_scopes text[] DEFAULT '{}'::text[] NOT NULL,
    auth_mode text DEFAULT 'service_account_key'::text NOT NULL,
    status text DEFAULT 'unverified'::text NOT NULL,
    verified_at timestamp without time zone,
    last_sync_at timestamp without time zone,
    disabled_at timestamp without time zone,
    last_error text,
    connected_by_user_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.google_roster_connectors FORCE ROW LEVEL SECURITY;


--
-- Name: grades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grades (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    classpilot_group_id text,
    migration_state text DEFAULT 'pending'::text NOT NULL,
    mapping_revision integer DEFAULT 0 NOT NULL,
    mapping_method text,
    mapping_reviewer_id text,
    mapped_at timestamp with time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT grades_mapping_revision_check CHECK ((mapping_revision >= 0)),
    CONSTRAINT grades_migration_state_check CHECK ((migration_state = ANY (ARRAY['pending'::text, 'auto_linked'::text, 'confirmed'::text, 'history_only'::text])))
);

ALTER TABLE ONLY public.grades FORCE ROW LEVEL SECURITY;


--
-- Name: group_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    group_id text NOT NULL,
    student_id text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: group_teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_teachers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    group_id text NOT NULL,
    teacher_id text NOT NULL,
    role text DEFAULT 'primary'::text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text NOT NULL,
    name text NOT NULL,
    description text,
    period_label text,
    grade_level text,
    group_type text DEFAULT 'teacher_created'::text NOT NULL,
    parent_group_id text,
    status text DEFAULT 'active'::text NOT NULL,
    archived_at timestamp without time zone,
    school_year text,
    term text,
    google_classroom_course_id text,
    schedule_enabled boolean DEFAULT false NOT NULL,
    block_start_time text,
    block_end_time text,
    schedule_skipped_date text,
    schedule_rule jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.groups FORCE ROW LEVEL SECURITY;


--
-- Name: heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heartbeats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    device_id text NOT NULL,
    student_id text,
    student_email text,
    school_id text,
    active_tab_title text NOT NULL,
    active_tab_url text,
    favicon text,
    screen_locked boolean DEFAULT false,
    flight_path_active boolean DEFAULT false,
    active_flight_path_name text,
    is_sharing boolean DEFAULT false,
    camera_active boolean DEFAULT false,
    ai_category text,
    content_category text,
    teacher_intent_source text,
    safety_alert text,
    extension_version text,
    chrome_version text,
    screenshot_health jsonb,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.heartbeats FORCE ROW LEVEL SECURITY;


--
-- Name: homeroom_teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.homeroom_teachers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    homeroom_id text NOT NULL,
    teacher_id text NOT NULL,
    role text DEFAULT 'primary'::text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.homeroom_teachers FORCE ROW LEVEL SECURITY;


--
-- Name: homerooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.homerooms (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text,
    name text NOT NULL,
    grade text NOT NULL,
    room text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.homerooms FORCE ROW LEVEL SECURITY;


--
-- Name: import_processing_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_processing_stages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    kind text NOT NULL,
    import_id character varying NOT NULL,
    paperwork_import_id character varying,
    information_import_id character varying,
    stage_key text NOT NULL,
    generation integer NOT NULL,
    provider boolean NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    lease_id uuid,
    parent_lease_id uuid,
    lease_until timestamp with time zone,
    request_deadline timestamp with time zone,
    last_error_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT import_processing_stages_bounds CHECK (((generation > 0) AND ((attempts >= 0) AND (attempts <= 3)) AND ((char_length(stage_key) >= 1) AND (char_length(stage_key) <= 200)) AND (stage_key ~ '^[A-Za-z0-9:_-]+$'::text) AND (status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'retry'::text, 'failed'::text, 'cancelled'::text])) AND ((last_error_code IS NULL) OR (last_error_code ~ '^[A-Za-z0-9_]{1,64}$'::text)) AND ((lease_id IS NULL) = (lease_until IS NULL)) AND ((status <> 'running'::text) OR ((lease_id IS NOT NULL) AND (parent_lease_id IS NOT NULL) AND (request_deadline IS NOT NULL))))),
    CONSTRAINT import_processing_stages_parent CHECK ((((kind = 'paperwork'::text) AND (paperwork_import_id IS NOT NULL) AND ((paperwork_import_id)::text = (import_id)::text) AND (information_import_id IS NULL)) OR ((kind = 'student-information'::text) AND (information_import_id IS NOT NULL) AND ((information_import_id)::text = (import_id)::text) AND (paperwork_import_id IS NULL))))
);

ALTER TABLE ONLY public.import_processing_stages FORCE ROW LEVEL SECURITY;


--
-- Name: import_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_runs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    user_id text,
    request_id text,
    source text NOT NULL,
    scope text,
    total_found integer DEFAULT 0 NOT NULL,
    imported integer DEFAULT 0 NOT NULL,
    updated integer DEFAULT 0 NOT NULL,
    skipped integer DEFAULT 0 NOT NULL,
    failures jsonb,
    warnings jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.import_runs FORCE ROW LEVEL SECURITY;


--
-- Name: mailpilot_watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mailpilot_watches (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    student_email text NOT NULL,
    history_id text,
    expires_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    last_renewed_at timestamp without time zone DEFAULT now() NOT NULL,
    last_poll_at timestamp without time zone,
    status text DEFAULT 'active'::text NOT NULL,
    last_error text
);

ALTER TABLE ONLY public.mailpilot_watches FORCE ROW LEVEL SECURITY;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    from_user_id text,
    to_student_id text,
    school_id text,
    command_id character varying,
    teaching_session_id character varying,
    supervision_context_id character varying,
    message text NOT NULL,
    is_announcement boolean DEFAULT false,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.messages FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_attachments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    client_request_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    note_id character varying NOT NULL,
    request_fingerprint text NOT NULL,
    storage_key text NOT NULL,
    original_filename text DEFAULT ''::text NOT NULL,
    content_type text,
    input_sha256 text,
    sha256 text,
    byte_size integer,
    committed_at timestamp with time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    upload_lease_id uuid,
    upload_lease_until timestamp with time zone,
    next_cleanup_at timestamp with time zone,
    cleanup_attempts integer DEFAULT 0 NOT NULL,
    last_error_code text,
    CONSTRAINT mydesk_attachments_attempts CHECK ((cleanup_attempts >= 0)),
    CONSTRAINT mydesk_attachments_content_type CHECK ((content_type = ANY (ARRAY['image/jpeg'::text, 'image/png'::text, 'image/webp'::text, 'application/pdf'::text]))),
    CONSTRAINT mydesk_attachments_fingerprint CHECK ((request_fingerprint ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT mydesk_attachments_hash CHECK ((sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT mydesk_attachments_input_hash CHECK ((input_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT mydesk_attachments_ready CHECK (((status <> 'ready'::text) OR ((content_type IS NOT NULL) AND (byte_size IS NOT NULL) AND (sha256 IS NOT NULL) AND (input_sha256 IS NOT NULL)))),
    CONSTRAINT mydesk_attachments_size CHECK (((byte_size >= 1) AND (byte_size <= 10485760))),
    CONSTRAINT mydesk_attachments_status CHECK ((status = ANY (ARRAY['pending'::text, 'uploading'::text, 'ready'::text, 'delete_pending'::text, 'deleted'::text])))
);

ALTER TABLE ONLY public.mydesk_attachments FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_import_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_import_assets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    import_id character varying NOT NULL,
    kind text NOT NULL,
    parent_asset_id character varying,
    page_number integer,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    storage_key text NOT NULL,
    original_filename text DEFAULT ''::text NOT NULL,
    content_type text,
    input_sha256 text,
    sha256 text,
    byte_size integer,
    width integer,
    height integer,
    page_count integer,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_id uuid,
    lease_until timestamp with time zone,
    next_cleanup_at timestamp with time zone,
    cleanup_attempts integer DEFAULT 0 NOT NULL,
    last_error_code text,
    attachment_id character varying,
    processed_at timestamp with time zone,
    CONSTRAINT mydesk_import_assets_bounds CHECK (((request_fingerprint ~ '^[0-9a-f]{64}$'::text) AND (char_length(original_filename) <= 255) AND ((input_sha256 IS NULL) OR (input_sha256 ~ '^[0-9a-f]{64}$'::text)) AND ((sha256 IS NULL) OR (sha256 ~ '^[0-9a-f]{64}$'::text)) AND ((byte_size IS NULL) OR ((byte_size >= 1) AND (byte_size <= 10485760))) AND ((content_type IS NULL) OR (content_type = ANY (ARRAY['image/jpeg'::text, 'image/png'::text, 'image/webp'::text, 'application/pdf'::text]))) AND ((width IS NULL) OR ((width >= 1) AND (width <= 4096))) AND ((height IS NULL) OR ((height >= 1) AND (height <= 4096))) AND ((page_number IS NULL) OR ((page_number >= 1) AND (page_number <= 20))) AND ((page_count IS NULL) OR ((page_count >= 1) AND (page_count <= 20))) AND (cleanup_attempts >= 0) AND ((last_error_code IS NULL) OR (last_error_code ~ '^[A-Za-z0-9_]{1,64}$'::text)) AND ((lease_id IS NULL) = (lease_until IS NULL)) AND ((status <> ALL (ARRAY['ready'::text, 'promoted'::text])) OR ((content_type IS NOT NULL) AND (byte_size IS NOT NULL) AND (sha256 IS NOT NULL))) AND ((status <> 'promoted'::text) OR ((kind = 'approved'::text) AND (attachment_id IS NOT NULL) AND (lease_id IS NULL))))),
    CONSTRAINT mydesk_import_assets_state CHECK (((kind = ANY (ARRAY['source'::text, 'page'::text, 'approved'::text])) AND (status = ANY (ARRAY['pending'::text, 'uploading'::text, 'ready'::text, 'promoted'::text, 'delete_pending'::text, 'deleted'::text]))))
);

ALTER TABLE ONLY public.mydesk_import_assets FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_import_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_import_items (
    document_order integer,
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    import_id character varying NOT NULL,
    client_request_id uuid NOT NULL,
    ordinal integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    regions jsonb DEFAULT '[]'::jsonb NOT NULL,
    subject_names jsonb DEFAULT '[]'::jsonb NOT NULL,
    discipline_fields jsonb,
    duplicate_decision jsonb,
    discipline_record_id character varying,
    group_id character varying,
    student_id character varying,
    roster_revision text,
    category text DEFAULT 'note'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    entry_date date,
    warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    reviewed boolean DEFAULT false NOT NULL,
    excluded boolean DEFAULT false NOT NULL,
    review_fingerprint text,
    approved_asset_id character varying,
    extraction_status text DEFAULT 'pending'::text NOT NULL,
    extract_requested boolean DEFAULT true NOT NULL,
    note_id character varying,
    CONSTRAINT mydesk_import_discipline_bounds CHECK ((((discipline_fields IS NULL) OR ((jsonb_typeof(discipline_fields) = 'object'::text) AND (octet_length((discipline_fields)::text) <= 8192))) AND ((duplicate_decision IS NULL) OR ((jsonb_typeof(duplicate_decision) = 'object'::text) AND (octet_length((duplicate_decision)::text) <= 4096))) AND ((discipline_record_id IS NULL) OR ((char_length((discipline_record_id)::text) >= 1) AND (char_length((discipline_record_id)::text) <= 128))))),
    CONSTRAINT mydesk_import_items_bounds CHECK ((((ordinal >= 0) AND (ordinal <= 49)) AND (revision > 0) AND (char_length(title) <= 160) AND (char_length(body) <= 5000) AND (category = ANY (ARRAY['note'::text, 'detention'::text, 'referral'::text, 'uniform'::text, 'positive'::text, 'parent_contact'::text, 'other'::text])) AND ((group_id IS NULL) OR ((char_length((group_id)::text) >= 1) AND (char_length((group_id)::text) <= 128))) AND ((student_id IS NULL) OR ((char_length((student_id)::text) >= 1) AND (char_length((student_id)::text) <= 128))) AND ((roster_revision IS NULL) OR (roster_revision ~ '^[0-9a-f]{64}$'::text)) AND ((review_fingerprint IS NULL) OR (review_fingerprint ~ '^[0-9a-f]{64}$'::text)) AND (extraction_status = ANY (ARRAY['pending'::text, 'ready'::text, 'failed'::text])))),
    CONSTRAINT mydesk_import_items_document_order CHECK (((document_order IS NULL) OR ((document_order >= 0) AND (document_order <= 999)))),
    CONSTRAINT mydesk_import_items_json CHECK ((
CASE
    WHEN (jsonb_typeof(regions) = 'array'::text) THEN ((jsonb_array_length(regions) <= 20) AND (octet_length((regions)::text) <= 65536))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(subject_names) = 'array'::text) THEN ((jsonb_array_length(subject_names) <= 20) AND (octet_length((subject_names)::text) <= 16384))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(warnings) = 'array'::text) THEN ((jsonb_array_length(warnings) <= 20) AND (octet_length((warnings)::text) <= 16384))
    ELSE false
END))
);

ALTER TABLE ONLY public.mydesk_import_items FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_imports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    status text DEFAULT 'uploading'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    destination text DEFAULT 'notes'::text NOT NULL,
    processing_version integer DEFAULT 1 NOT NULL,
    progress_revision integer DEFAULT 1 NOT NULL,
    expected_source_count integer NOT NULL,
    selected_group_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    preferences_snapshot jsonb DEFAULT '{"revision": 0, "preferredClasses": {}}'::jsonb NOT NULL,
    source_note_id character varying,
    source_attachment_id character varying,
    page_decisions jsonb DEFAULT '[]'::jsonb NOT NULL,
    mutation_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    commit_receipt jsonb,
    expires_at timestamp with time zone NOT NULL,
    upload_expires_at timestamp with time zone NOT NULL,
    lease_id uuid,
    lease_until timestamp with time zone,
    next_attempt_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    page_count integer DEFAULT 0 NOT NULL,
    quota_date date,
    last_error_code text,
    quota_usage jsonb DEFAULT '[]'::jsonb NOT NULL,
    model_version text,
    prompt_version text,
    CONSTRAINT mydesk_import_destination CHECK ((destination = ANY (ARRAY['notes'::text, 'discipline'::text]))),
    CONSTRAINT mydesk_imports_bounds CHECK (((revision > 0) AND ((expected_source_count >= 1) AND (expected_source_count <= 5)) AND (attempts >= 0) AND ((page_count >= 0) AND (page_count <= 20)) AND (request_fingerprint ~ '^[0-9a-f]{64}$'::text) AND ((last_error_code IS NULL) OR (last_error_code ~ '^[A-Za-z0-9_]{1,64}$'::text)) AND ((lease_id IS NULL) = (lease_until IS NULL)))),
    CONSTRAINT mydesk_imports_json CHECK ((
CASE
    WHEN (jsonb_typeof(selected_group_ids) = 'array'::text) THEN ((jsonb_array_length(selected_group_ids) <= 20) AND (octet_length((selected_group_ids)::text) <= 8192))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(page_decisions) = 'array'::text) THEN ((jsonb_array_length(page_decisions) <= 20) AND (octet_length((page_decisions)::text) <= 8192))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(mutation_receipts) = 'array'::text) THEN ((jsonb_array_length(mutation_receipts) <= 100) AND (octet_length((mutation_receipts)::text) <= 32768))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(quota_usage) = 'array'::text) THEN ((jsonb_array_length(quota_usage) <= 8) AND (octet_length((quota_usage)::text) <= 4096))
    ELSE false
END AND ((commit_receipt IS NULL) OR ((jsonb_typeof(commit_receipt) = 'object'::text) AND (octet_length((commit_receipt)::text) <= 16384))))),
    CONSTRAINT mydesk_imports_processing_protocol CHECK (((processing_version = ANY (ARRAY[1, 2])) AND (progress_revision > 0))),
    CONSTRAINT mydesk_imports_provenance CHECK ((((model_version IS NULL) OR (model_version ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$'::text)) AND ((prompt_version IS NULL) OR (prompt_version ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$'::text)))),
    CONSTRAINT mydesk_imports_state CHECK ((status = ANY (ARRAY['uploading'::text, 'queued'::text, 'processing'::text, 'review'::text, 'failed'::text, 'completed'::text, 'cancelled'::text, 'expired'::text]))),
    CONSTRAINT mydesk_imports_workspace_snapshot CHECK (((jsonb_typeof(preferences_snapshot) = 'object'::text) AND (octet_length((preferences_snapshot)::text) <= 12288) AND ((source_note_id IS NULL) = (source_attachment_id IS NULL)) AND ((source_note_id IS NULL) OR ((char_length((source_note_id)::text) >= 1) AND (char_length((source_note_id)::text) <= 128))) AND ((source_attachment_id IS NULL) OR ((char_length((source_attachment_id)::text) >= 1) AND (char_length((source_attachment_id)::text) <= 128)))))
);

ALTER TABLE ONLY public.mydesk_imports FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    client_request_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    request_fingerprint text NOT NULL,
    target_kind text DEFAULT 'general'::text NOT NULL,
    group_id character varying,
    filing_group_id character varying,
    group_name text,
    filing_grade_level text,
    filing_school_year text,
    student_id character varying,
    filing_student_id character varying,
    student_name text,
    category text DEFAULT 'note'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    entry_date date NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT mydesk_notes_category CHECK ((category ~ '^[a-z][a-z0-9_]{0,31}$'::text)),
    CONSTRAINT mydesk_notes_fingerprint CHECK ((request_fingerprint ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT mydesk_notes_grade_bounds CHECK ((((filing_grade_level IS NULL) OR ((char_length(filing_grade_level) >= 1) AND (char_length(filing_grade_level) <= 40))) AND ((filing_school_year IS NULL) OR ((char_length(filing_school_year) >= 1) AND (char_length(filing_school_year) <= 100))))),
    CONSTRAINT mydesk_notes_revision CHECK ((revision > 0)),
    CONSTRAINT mydesk_notes_status CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'deleted'::text]))),
    CONSTRAINT mydesk_notes_target_kind CHECK ((target_kind = ANY (ARRAY['general'::text, 'grade'::text, 'class'::text, 'student'::text]))),
    CONSTRAINT mydesk_notes_target_shape CHECK ((((target_kind = 'general'::text) AND (filing_group_id IS NULL) AND (filing_student_id IS NULL) AND (group_id IS NULL) AND (student_id IS NULL) AND (filing_grade_level IS NULL)) OR ((target_kind = 'grade'::text) AND (filing_grade_level IS NOT NULL) AND (filing_group_id IS NULL) AND (group_id IS NULL) AND (filing_student_id IS NULL) AND (student_id IS NULL)) OR ((target_kind = 'class'::text) AND (filing_group_id IS NOT NULL) AND (group_name IS NOT NULL) AND (filing_student_id IS NULL) AND (student_id IS NULL)) OR ((target_kind = 'student'::text) AND (filing_student_id IS NOT NULL) AND (student_name IS NOT NULL) AND (((filing_group_id IS NOT NULL) AND (group_name IS NOT NULL)) OR ((filing_group_id IS NULL) AND (group_id IS NULL) AND (filing_grade_level IS NOT NULL))))))
);

ALTER TABLE ONLY public.mydesk_notes FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    preferred_classes jsonb DEFAULT '{}'::jsonb NOT NULL,
    view_by text DEFAULT 'grades'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mydesk_preferences_bounds CHECK (((revision > 0) AND (jsonb_typeof(preferred_classes) = 'object'::text) AND (octet_length((preferred_classes)::text) <= 8192))),
    CONSTRAINT mydesk_preferences_view_by CHECK ((view_by = ANY (ARRAY['grades'::text, 'classes'::text])))
);

ALTER TABLE ONLY public.mydesk_preferences FORCE ROW LEVEL SECURITY;


--
-- Name: mydesk_seating_charts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mydesk_seating_charts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    group_id character varying,
    filing_group_id character varying NOT NULL,
    group_name text NOT NULL,
    name text NOT NULL,
    layout jsonb DEFAULT '{"seats": [], "version": 1}'::jsonb NOT NULL,
    roster_snapshot jsonb DEFAULT '[]'::jsonb NOT NULL,
    roster_revision text NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    mutation_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT mydesk_seating_charts_deleted CHECK (((deleted_at IS NULL) OR ((NOT is_current) AND (group_id IS NULL) AND (name = ''::text) AND (group_name = ''::text) AND (roster_revision = ''::text) AND (layout = '{"seats": [], "version": 1}'::jsonb) AND (roster_snapshot = '[]'::jsonb)))),
    CONSTRAINT mydesk_seating_charts_fingerprint CHECK ((request_fingerprint ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT mydesk_seating_charts_group_name CHECK ((char_length(group_name) <= 500)),
    CONSTRAINT mydesk_seating_charts_layout CHECK (((jsonb_typeof(layout) = 'object'::text) AND (octet_length((layout)::text) <= 262144) AND (((layout -> 'version'::text) = ANY (ARRAY['1'::jsonb, '2'::jsonb])) IS TRUE) AND
CASE
    WHEN (jsonb_typeof((layout -> 'seats'::text)) = 'array'::text) THEN (jsonb_array_length((layout -> 'seats'::text)) <= 100)
    ELSE false
END AND ((((layout -> 'version'::text) = '1'::jsonb) OR (((layout ->> 'units'::text) = 'mm'::text) AND ((layout ->> 'displayUnit'::text) = ANY (ARRAY['imperial'::text, 'metric'::text])) AND
CASE
    WHEN (jsonb_typeof(((layout -> 'room'::text) -> 'vertices'::text)) = 'array'::text) THEN ((jsonb_array_length(((layout -> 'room'::text) -> 'vertices'::text)) >= 3) AND (jsonb_array_length(((layout -> 'room'::text) -> 'vertices'::text)) <= 24))
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof((layout -> 'features'::text)) = 'array'::text) THEN (jsonb_array_length((layout -> 'features'::text)) <= 100)
    ELSE false
END)) IS TRUE))),
    CONSTRAINT mydesk_seating_charts_name CHECK (((deleted_at IS NOT NULL) OR ((char_length(btrim(name)) >= 1) AND (char_length(btrim(name)) <= 120)))),
    CONSTRAINT mydesk_seating_charts_receipts CHECK (
CASE
    WHEN (jsonb_typeof(mutation_receipts) = 'array'::text) THEN (jsonb_array_length(mutation_receipts) <= 100)
    ELSE false
END),
    CONSTRAINT mydesk_seating_charts_revision CHECK ((revision > 0)),
    CONSTRAINT mydesk_seating_charts_roster CHECK (((octet_length((roster_snapshot)::text) <= 1048576) AND
CASE
    WHEN (jsonb_typeof(roster_snapshot) = 'array'::text) THEN (jsonb_array_length(roster_snapshot) <= 1000)
    ELSE false
END)),
    CONSTRAINT mydesk_seating_charts_roster_revision CHECK (((deleted_at IS NOT NULL) OR (roster_revision ~ '^[0-9a-f]{64}$'::text)))
);

ALTER TABLE ONLY public.mydesk_seating_charts FORCE ROW LEVEL SECURITY;


--
-- Name: parent_student; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parent_student (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    parent_id text NOT NULL,
    student_id text NOT NULL,
    school_id text NOT NULL,
    relationship text NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    status text DEFAULT 'approved'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.parent_student FORCE ROW LEVEL SECURITY;


--
-- Name: passes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    teacher_id text,
    grade_id text,
    classpilot_group_id text,
    class_name_snapshot text,
    supervision_context_id text,
    activity_kind text,
    activity_name_snapshot text,
    issuing_kiosk_session_id text,
    destination text NOT NULL,
    custom_destination text,
    status text DEFAULT 'active'::text NOT NULL,
    issued_at timestamp without time zone DEFAULT now() NOT NULL,
    duration integer DEFAULT 5 NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    returned_at timestamp without time zone,
    issued_via text DEFAULT 'teacher'::text NOT NULL,
    notes text,
    rule_override_code text,
    CONSTRAINT passes_activity_shape_check CHECK ((((supervision_context_id IS NULL) AND (activity_kind IS NULL) AND (activity_name_snapshot IS NULL)) OR ((supervision_context_id IS NOT NULL) AND (activity_kind IS NOT NULL) AND (activity_kind = ANY (ARRAY['testing'::text, 'coverage'::text])) AND (activity_name_snapshot IS NOT NULL) AND (grade_id IS NULL) AND (classpilot_group_id IS NULL)))),
    CONSTRAINT passes_rule_override_code_check CHECK (((rule_override_code IS NULL) OR (rule_override_code = ANY (ARRAY['PASSPILOT_RULE_DAILY_LIMIT'::text, 'PASSPILOT_RULE_PERIOD_LIMIT'::text, 'PASSPILOT_RULE_DESTINATION_CAPACITY'::text, 'PASSPILOT_RULE_ENCOUNTER'::text])))),
    CONSTRAINT passes_single_class_source_check CHECK ((NOT ((grade_id IS NOT NULL) AND (classpilot_group_id IS NOT NULL))))
);

ALTER TABLE ONLY public.passes FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_appointments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id character varying NOT NULL,
    created_by character varying,
    updated_by character varying,
    activated_by character varying,
    create_request_id uuid NOT NULL,
    create_fingerprint text NOT NULL,
    destination text NOT NULL,
    custom_destination text,
    staff_notes text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    school_timezone text NOT NULL,
    retained_until timestamp with time zone NOT NULL,
    duration integer DEFAULT 5 NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    pass_id character varying,
    activated_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    missed_at timestamp with time zone,
    notes_scrubbed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pp_appointments_bounds_check CHECK (((revision > 0) AND ((duration >= 1) AND (duration <= 120)) AND (starts_at < ends_at) AND (ends_at <= retained_until) AND ((char_length(school_timezone) >= 1) AND (char_length(school_timezone) <= 128)) AND (create_fingerprint ~ '^[a-f0-9]{64}$'::text) AND ((staff_notes IS NULL) OR (char_length(staff_notes) <= 2000)))),
    CONSTRAINT pp_appointments_destination_check CHECK (((destination = ANY (ARRAY['bathroom'::text, 'nurse'::text, 'office'::text, 'counselor'::text, 'other_classroom'::text, 'custom'::text])) AND (((destination = 'custom'::text) AND (custom_destination IS NOT NULL) AND ((char_length(custom_destination) >= 1) AND (char_length(custom_destination) <= 200))) OR ((destination <> 'custom'::text) AND (custom_destination IS NULL))))),
    CONSTRAINT pp_appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'activated'::text, 'completed'::text, 'cancelled'::text, 'missed'::text])))
);

ALTER TABLE ONLY public.passpilot_appointments FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_destination_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_destination_policies (
    school_id text NOT NULL,
    destination text NOT NULL,
    max_concurrent integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT pp_destination_policies_destination_check CHECK ((destination = ANY (ARRAY['bathroom'::text, 'nurse'::text, 'office'::text, 'counselor'::text, 'other_classroom'::text]))),
    CONSTRAINT pp_destination_policies_max_concurrent_check CHECK (((max_concurrent >= 1) AND (max_concurrent <= 500)))
);

ALTER TABLE ONLY public.passpilot_destination_policies FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_encounter_restrictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_encounter_restrictions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_a_id text NOT NULL,
    student_b_id text NOT NULL,
    reason_note text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    CONSTRAINT pp_encounter_restrictions_note_check CHECK (((reason_note IS NULL) OR (char_length(reason_note) <= 500))),
    CONSTRAINT pp_encounter_restrictions_pair_order_check CHECK (((student_a_id COLLATE "C") < (student_b_id COLLATE "C")))
);

ALTER TABLE ONLY public.passpilot_encounter_restrictions FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_grade_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_grade_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    grade_id text NOT NULL,
    student_id text NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.passpilot_grade_students FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_kiosk_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_kiosk_devices (
    id character varying NOT NULL,
    school_id text NOT NULL,
    teacher_id text NOT NULL,
    class_source text,
    grade_id text,
    classpilot_group_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pp_kiosk_devices_class_shape_check CHECK ((((class_source IS NULL) AND (grade_id IS NULL) AND (classpilot_group_id IS NULL)) OR ((class_source = 'legacy_grades'::text) AND (grade_id IS NOT NULL) AND (classpilot_group_id IS NULL)) OR ((class_source = 'classpilot_groups'::text) AND (classpilot_group_id IS NOT NULL) AND (grade_id IS NULL)))),
    CONSTRAINT pp_kiosk_devices_class_source_check CHECK (((class_source IS NULL) OR (class_source = ANY (ARRAY['legacy_grades'::text, 'classpilot_groups'::text]))))
);

ALTER TABLE ONLY public.passpilot_kiosk_devices FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_kiosk_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_kiosk_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    claim_code text NOT NULL,
    teacher_id text,
    class_source text,
    grade_id text,
    classpilot_group_id text,
    status text DEFAULT 'unclaimed'::text NOT NULL,
    device_id text,
    revision integer DEFAULT 0 NOT NULL,
    override_started_at timestamp with time zone,
    override_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    released_at timestamp with time zone,
    CONSTRAINT pp_kiosk_sessions_active_shape_check CHECK (((status <> 'active'::text) OR ((teacher_id IS NOT NULL) AND (((class_source IS NULL) AND (grade_id IS NULL) AND (classpilot_group_id IS NULL)) OR ((class_source = 'legacy_grades'::text) AND (grade_id IS NOT NULL) AND (classpilot_group_id IS NULL)) OR ((class_source = 'classpilot_groups'::text) AND (classpilot_group_id IS NOT NULL) AND (grade_id IS NULL)))))),
    CONSTRAINT pp_kiosk_sessions_class_source_check CHECK (((class_source IS NULL) OR (class_source = ANY (ARRAY['legacy_grades'::text, 'classpilot_groups'::text])))),
    CONSTRAINT pp_kiosk_sessions_revision_check CHECK ((revision >= 0)),
    CONSTRAINT pp_kiosk_sessions_single_class_check CHECK ((NOT ((grade_id IS NOT NULL) AND (classpilot_group_id IS NOT NULL)))),
    CONSTRAINT pp_kiosk_sessions_status_check CHECK ((status = ANY (ARRAY['unclaimed'::text, 'active'::text, 'released'::text]))),
    CONSTRAINT pp_kiosk_sessions_unclaimed_shape_check CHECK (((status <> 'unclaimed'::text) OR ((teacher_id IS NULL) AND (class_source IS NULL) AND (grade_id IS NULL) AND (classpilot_group_id IS NULL))))
);

ALTER TABLE ONLY public.passpilot_kiosk_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_pass_denials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_pass_denials (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    destination text NOT NULL,
    rule_code text NOT NULL,
    issued_via text NOT NULL,
    actor_user_id text,
    teacher_id text,
    class_source text,
    grade_id text,
    classpilot_group_id text,
    supervision_context_id text,
    issuing_kiosk_session_id text,
    window_kind text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    overridden boolean DEFAULT false NOT NULL,
    denied_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pp_pass_denials_class_source_check CHECK (((class_source IS NULL) OR (class_source = ANY (ARRAY['legacy_grades'::text, 'classpilot_groups'::text])))),
    CONSTRAINT pp_pass_denials_destination_check CHECK ((destination = ANY (ARRAY['bathroom'::text, 'nurse'::text, 'office'::text, 'counselor'::text, 'other_classroom'::text, 'custom'::text]))),
    CONSTRAINT pp_pass_denials_details_check CHECK ((jsonb_typeof(details) = 'object'::text)),
    CONSTRAINT pp_pass_denials_issued_via_check CHECK ((issued_via = ANY (ARRAY['teacher'::text, 'kiosk'::text, 'ai'::text]))),
    CONSTRAINT pp_pass_denials_rule_code_check CHECK ((rule_code = ANY (ARRAY['PASSPILOT_RULE_DAILY_LIMIT'::text, 'PASSPILOT_RULE_PERIOD_LIMIT'::text, 'PASSPILOT_RULE_DESTINATION_CAPACITY'::text, 'PASSPILOT_RULE_ENCOUNTER'::text]))),
    CONSTRAINT pp_pass_denials_single_class_check CHECK ((NOT ((grade_id IS NOT NULL) AND (classpilot_group_id IS NOT NULL)))),
    CONSTRAINT pp_pass_denials_window_kind_check CHECK (((window_kind IS NULL) OR (window_kind = ANY (ARRAY['day'::text, 'bell_period'::text, 'class_window'::text, 'kiosk_block'::text]))))
);

ALTER TABLE ONLY public.passpilot_pass_denials FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_pass_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_pass_limits (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text,
    daily_limit integer,
    period_limit integer,
    enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT pp_pass_limits_any_limit_check CHECK (((daily_limit IS NOT NULL) OR (period_limit IS NOT NULL))),
    CONSTRAINT pp_pass_limits_daily_check CHECK (((daily_limit IS NULL) OR ((daily_limit >= 0) AND (daily_limit <= 50)))),
    CONSTRAINT pp_pass_limits_period_check CHECK (((period_limit IS NULL) OR ((period_limit >= 0) AND (period_limit <= 50))))
);

ALTER TABLE ONLY public.passpilot_pass_limits FORCE ROW LEVEL SECURITY;


--
-- Name: passpilot_teacher_kiosk_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passpilot_teacher_kiosk_settings (
    school_id text NOT NULL,
    teacher_id text NOT NULL,
    mode text DEFAULT 'manual'::text NOT NULL,
    schedule jsonb DEFAULT '{"blocks": [], "exceptions": []}'::jsonb NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT pp_teacher_kiosk_mode_check CHECK ((mode = ANY (ARRAY['manual'::text, 'passpilot'::text, 'classpilot'::text]))),
    CONSTRAINT pp_teacher_kiosk_revision_check CHECK ((revision >= 0)),
    CONSTRAINT pp_teacher_kiosk_schedule_check CHECK ((jsonb_typeof(schedule) = 'object'::text))
);

ALTER TABLE ONLY public.passpilot_teacher_kiosk_settings FORCE ROW LEVEL SECURITY;


--
-- Name: poll_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poll_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    poll_id character varying NOT NULL,
    student_id text NOT NULL,
    device_id text,
    selected_option integer,
    text_response text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    superseded_at timestamp with time zone,
    superseded_by_response_id character varying,
    CONSTRAINT cp_response_content CHECK (((num_nonnulls(selected_option, text_response) = 1) AND ((text_response IS NULL) OR ((length(text_response) >= 1) AND (length(text_response) <= 500)))))
);

ALTER TABLE ONLY public.poll_responses FORCE ROW LEVEL SECURITY;


--
-- Name: polls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.polls (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id character varying,
    supervision_context_id character varying,
    teacher_id text NOT NULL,
    start_command_id character varying,
    close_command_id character varying,
    purpose text DEFAULT 'poll'::text NOT NULL,
    response_type text DEFAULT 'choice'::text NOT NULL,
    question text NOT NULL,
    options text[] NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    closed_at timestamp without time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(session_id, supervision_context_id) = 1)),
    CONSTRAINT cp_prompt_type CHECK (((purpose = ANY (ARRAY['poll'::text, 'exit_ticket'::text, 'volunteer'::text])) AND (response_type = ANY (ARRAY['choice'::text, 'short_text'::text]))))
);

ALTER TABLE ONLY public.polls FORCE ROW LEVEL SECURITY;


--
-- Name: product_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_licenses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    product text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    activated_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: roster_integration_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roster_integration_connections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    provider_identity text NOT NULL,
    encrypted_token text,
    status text DEFAULT 'active'::text NOT NULL,
    mapping jsonb DEFAULT '{"organizationIds": []}'::jsonb NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    automatic_sync boolean DEFAULT false NOT NULL,
    initial_reviewed_at timestamp with time zone,
    last_attempt_local_date text,
    last_attempt_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error_code text,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.roster_integration_connections FORCE ROW LEVEL SECURITY;


--
-- Name: roster_integration_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roster_integration_identities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    connection_id text NOT NULL,
    entity_type text NOT NULL,
    external_id text NOT NULL,
    internal_id text NOT NULL,
    owned_fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_applied jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_created boolean DEFAULT false NOT NULL,
    source_present boolean DEFAULT true NOT NULL,
    last_run_id text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.roster_integration_identities FORCE ROW LEVEL SECURITY;


--
-- Name: roster_integration_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roster_integration_memberships (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    connection_id text NOT NULL,
    group_id text NOT NULL,
    member_id text NOT NULL,
    member_type text NOT NULL,
    role text NOT NULL,
    owns_membership boolean DEFAULT false NOT NULL,
    manual_preserved boolean DEFAULT false NOT NULL,
    source_present boolean DEFAULT true NOT NULL,
    physical_row_id text,
    last_run_id text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.roster_integration_memberships FORCE ROW LEVEL SECURITY;


--
-- Name: roster_integration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roster_integration_runs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    connection_id text NOT NULL,
    status text DEFAULT 'staged'::text NOT NULL,
    requested_by text,
    automatic boolean DEFAULT false NOT NULL,
    snapshot jsonb,
    mapping jsonb,
    plan jsonb,
    plan_hash text,
    base_revision integer,
    cursor integer DEFAULT 0 NOT NULL,
    total_steps integer DEFAULT 0 NOT NULL,
    summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_code text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT roster_runs_state_check CHECK ((status = ANY (ARRAY['fetching'::text, 'staged'::text, 'preview'::text, 'held'::text, 'applying'::text, 'completed'::text, 'failed'::text, 'expired'::text])))
);

ALTER TABLE ONLY public.roster_integration_runs FORCE ROW LEVEL SECURITY;


--
-- Name: rosters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rosters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    class_id text NOT NULL,
    class_name text NOT NULL,
    device_ids text[] DEFAULT '{}'::text[] NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: safety_notification_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safety_notification_outbox (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    case_id text NOT NULL,
    alert_id text NOT NULL,
    recipient text NOT NULL,
    kind text NOT NULL,
    alert_revision integer NOT NULL,
    due_at timestamp with time zone NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    claimed_at timestamp with time zone,
    submission_started_at timestamp with time zone,
    completed_at timestamp with time zone,
    provider_message_id text,
    error_code text,
    CONSTRAINT safety_outbox_kind_check CHECK ((kind = ANY (ARRAY['initial'::text, 'followup'::text]))),
    CONSTRAINT safety_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sending'::text, 'sent'::text, 'cancelled'::text, 'failed'::text, 'unknown'::text])))
);

ALTER TABLE ONLY public.safety_notification_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: safety_url_exceptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safety_url_exceptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    fingerprint text NOT NULL,
    canonicalizer_version integer DEFAULT 1 NOT NULL,
    url_ciphertext text NOT NULL,
    created_from_alert_id text,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text
);

ALTER TABLE ONLY public.safety_url_exceptions FORCE ROW LEVEL SECURITY;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    id text NOT NULL,
    checksum character(64) NOT NULL,
    mode text NOT NULL,
    status text NOT NULL,
    application_sha text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms bigint,
    error_code text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT schema_migrations_checksum_check CHECK ((checksum ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT schema_migrations_mode_check CHECK ((mode = ANY (ARRAY['transactional'::text, 'nontransactional'::text]))),
    CONSTRAINT schema_migrations_status_check CHECK ((status = ANY (ARRAY['running'::text, 'complete'::text, 'failed'::text])))
);


--
-- Name: school_discipline_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_discipline_access (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    user_id character varying NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    updated_by character varying,
    mutation_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT school_discipline_access_receipts CHECK (((jsonb_typeof(mutation_receipts) = 'array'::text) AND (jsonb_array_length(mutation_receipts) <= 100))),
    CONSTRAINT school_discipline_access_revision CHECK ((revision >= 0))
);

ALTER TABLE ONLY public.school_discipline_access FORCE ROW LEVEL SECURITY;


--
-- Name: school_discipline_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_discipline_attachments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    version_id character varying NOT NULL,
    storage_key text NOT NULL,
    source_storage_key text,
    source_attachment_id character varying,
    filename text DEFAULT ''::text NOT NULL,
    content_type text NOT NULL,
    byte_size integer NOT NULL,
    sha256 text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_until timestamp with time zone,
    client_request_id uuid,
    input_sha256 text,
    input_content_type text,
    input_byte_size integer,
    upload_lease_id uuid,
    next_cleanup_at timestamp with time zone,
    cleanup_attempts integer DEFAULT 0 NOT NULL,
    last_error_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT school_discipline_attachments_hash CHECK ((sha256 ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT school_discipline_attachments_size CHECK (((byte_size > 0) AND (byte_size <= 10485760))),
    CONSTRAINT school_discipline_attachments_status CHECK ((status = ANY (ARRAY['pending'::text, 'uploading'::text, 'ready'::text, 'committed'::text, 'delete_pending'::text, 'deleted'::text])))
);

ALTER TABLE ONLY public.school_discipline_attachments FORCE ROW LEVEL SECURITY;


--
-- Name: school_discipline_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_discipline_records (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_by_name text NOT NULL,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    source_note_id character varying,
    status text DEFAULT 'pending'::text NOT NULL,
    draft_revision integer DEFAULT 1 NOT NULL,
    draft_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    current_version_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT school_discipline_records_draft CHECK (((draft_revision > 0) AND (jsonb_typeof(draft_receipts) = 'array'::text) AND (jsonb_array_length(draft_receipts) <= 100))),
    CONSTRAINT school_discipline_records_revision CHECK ((revision >= 0)),
    CONSTRAINT school_discipline_records_status CHECK ((status = ANY (ARRAY['pending'::text, 'submitted'::text, 'withdrawn'::text, 'abandoned'::text])))
);

ALTER TABLE ONLY public.school_discipline_records FORCE ROW LEVEL SECURITY;


--
-- Name: school_discipline_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_discipline_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    record_id character varying NOT NULL,
    number integer NOT NULL,
    kind text NOT NULL,
    state text DEFAULT 'preparing'::text NOT NULL,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    reason text,
    snapshot jsonb NOT NULL,
    created_by character varying,
    source_note_id character varying,
    source_note_revision integer,
    source_fingerprint text,
    lease_id uuid,
    lease_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    CONSTRAINT school_discipline_versions_kind CHECK ((kind = ANY (ARRAY['submission'::text, 'correction'::text, 'withdrawal'::text]))),
    CONSTRAINT school_discipline_versions_number CHECK ((number > 0)),
    CONSTRAINT school_discipline_versions_snapshot CHECK (((jsonb_typeof(snapshot) = 'object'::text) AND (octet_length((snapshot)::text) <= 20000))),
    CONSTRAINT school_discipline_versions_state CHECK ((state = ANY (ARRAY['preparing'::text, 'published'::text, 'abandoned'::text])))
);

ALTER TABLE ONLY public.school_discipline_versions FORCE ROW LEVEL SECURITY;


--
-- Name: school_inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_inquiries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_name text NOT NULL,
    domain text,
    contact_name text NOT NULL,
    contact_email text NOT NULL,
    contact_phone text,
    preferred_contact_method text,
    admin_it_email text,
    billing_email text,
    estimated_students text,
    interested_products text,
    questions text,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    school_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone,
    processed_by text
);


--
-- Name: school_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_memberships (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    school_id text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    car_number text,
    kiosk_name text,
    gopilot_role text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: schools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schools (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    domain text,
    slug text,
    address text,
    phone text,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    plan_tier text DEFAULT 'basic'::text NOT NULL,
    plan_status text DEFAULT 'active'::text NOT NULL,
    active_until timestamp without time zone,
    stripe_customer_id text,
    stripe_subscription_id text,
    billing_email text,
    total_paid integer DEFAULT 0 NOT NULL,
    last_payment_amount integer,
    last_payment_date timestamp without time zone,
    tax_exempt_status text,
    tax_exempt_cert_url text,
    tax_exempt_cert_requested_at timestamp without time zone,
    tax_exempt_cert_uploaded_at timestamp without time zone,
    max_teachers integer DEFAULT 50,
    max_licenses integer DEFAULT 100,
    used_licenses integer DEFAULT 0 NOT NULL,
    kiosk_enabled boolean DEFAULT false NOT NULL,
    kiosk_requires_approval boolean DEFAULT false NOT NULL,
    default_pass_duration integer DEFAULT 5 NOT NULL,
    kiosk_grade_id character varying,
    kiosk_classpilot_group_id character varying,
    kiosk_activated_by_user_id character varying,
    kiosk_pin_hash text,
    kiosk_style text DEFAULT 'simple'::text NOT NULL,
    passpilot_settings_revision integer DEFAULT 0 NOT NULL,
    active_grade_levels text,
    dismissal_time text,
    dismissal_mode text DEFAULT 'no_app'::text NOT NULL,
    gopilot_auto_start_enabled boolean DEFAULT false NOT NULL,
    gopilot_pickup_zones jsonb DEFAULT '[{"id": "A", "name": "Zone A"}, {"id": "B", "name": "Zone B"}, {"id": "C", "name": "Zone C"}]'::jsonb NOT NULL,
    gopilot_settings_revision integer DEFAULT 0 NOT NULL,
    max_students integer,
    tracking_start_hour integer DEFAULT 7 NOT NULL,
    tracking_end_hour integer DEFAULT 17 NOT NULL,
    is_24_hour_enabled boolean DEFAULT false NOT NULL,
    staff_password_login_enabled boolean DEFAULT true NOT NULL,
    microsoft_sign_in_enabled boolean DEFAULT false NOT NULL,
    microsoft_tenant_id text,
    mailpilot_entitled boolean DEFAULT false NOT NULL,
    classpilot_email_monitoring boolean DEFAULT false NOT NULL,
    mailpilot_org_units text,
    disabled_at timestamp without time zone,
    disabled_reason text,
    last_activity_at timestamp without time zone,
    school_timezone text DEFAULT 'America/New_York'::text NOT NULL,
    school_session_version integer DEFAULT 1 NOT NULL,
    settings text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    CONSTRAINT schools_gopilot_pickup_zones_check CHECK (public.gopilot_valid_pickup_zones(gopilot_pickup_zones)),
    CONSTRAINT schools_gopilot_settings_revision_check CHECK ((gopilot_settings_revision >= 0)),
    CONSTRAINT schools_kiosk_style_check CHECK ((kiosk_style = ANY (ARRAY['simple'::text, 'badge'::text]))),
    CONSTRAINT schools_microsoft_sign_in_tenant_check CHECK (((NOT microsoft_sign_in_enabled) OR (microsoft_tenant_id IS NOT NULL))),
    CONSTRAINT schools_microsoft_tenant_id_check CHECK (((microsoft_tenant_id IS NULL) OR (microsoft_tenant_id ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'::text))),
    CONSTRAINT schools_passpilot_settings_revision_check CHECK ((passpilot_settings_revision >= 0))
);


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    detected_at timestamp without time zone DEFAULT now() NOT NULL,
    event_type text NOT NULL,
    severity text NOT NULL,
    school_id text,
    user_id text,
    user_email text,
    ip_address text,
    summary text NOT NULL,
    details jsonb,
    status text DEFAULT 'open'::text NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by text,
    resolution_notes text,
    alert_sent boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY public.security_events FORCE ROW LEVEL SECURITY;


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


--
-- Name: session_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    session_id character varying,
    supervision_context_id character varying,
    chat_enabled boolean DEFAULT true,
    raise_hand_enabled boolean DEFAULT true,
    chat_paused boolean DEFAULT false NOT NULL,
    lifecycle_revision integer DEFAULT 1 NOT NULL,
    tools_revision integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    private_chat_epoch integer DEFAULT 1 NOT NULL,
    CONSTRAINT cp_activity_parent_check CHECK ((num_nonnulls(session_id, supervision_context_id) = 1)),
    CONSTRAINT session_settings_private_chat_epoch_check CHECK ((private_chat_epoch > 0)),
    CONSTRAINT session_settings_revision_check CHECK ((lifecycle_revision > 0))
);

ALTER TABLE ONLY public.session_settings FORCE ROW LEVEL SECURITY;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    school_name text NOT NULL,
    ws_shared_key text NOT NULL,
    retention_hours text DEFAULT '720'::text NOT NULL,
    blocked_domains text[] DEFAULT '{}'::text[],
    allowed_domains text[] DEFAULT '{}'::text[],
    ip_allowlist text[] DEFAULT '{}'::text[],
    grade_levels text[] DEFAULT '{6,7,8,9,10,11,12}'::text[],
    max_tabs_per_student text,
    active_flight_path_id text,
    enable_tracking_hours boolean DEFAULT false,
    tracking_start_time text DEFAULT '08:00'::text,
    tracking_end_time text DEFAULT '15:00'::text,
    school_timezone text DEFAULT 'America/New_York'::text,
    tracking_days text[] DEFAULT '{Monday,Tuesday,Wednesday,Thursday,Friday}'::text[],
    after_hours_mode text DEFAULT 'off'::text NOT NULL,
    hand_raising_enabled boolean DEFAULT true,
    student_messaging_enabled boolean DEFAULT true,
    pause_chat_during_testing boolean DEFAULT true NOT NULL,
    ai_safety_emails_enabled boolean DEFAULT true,
    central_email_recipient_user_id text,
    auto_block_unsafe_urls boolean DEFAULT true,
    parent_transparency_enabled boolean DEFAULT false,
    parent_digest_cadence text DEFAULT 'weekly'::text NOT NULL,
    parent_digest_includes_safety boolean DEFAULT false,
    parent_digest_includes_pass_dismissal boolean DEFAULT true,
    parent_digest_last_sent_at timestamp without time zone,
    enrollment_key text,
    enrollment_key_required boolean DEFAULT false NOT NULL,
    shared_chromebook_sign_in_enabled boolean DEFAULT false NOT NULL,
    shared_chromebook_login_method text DEFAULT 'name_pin'::text NOT NULL,
    shared_chromebook_pin_login_enabled boolean DEFAULT false NOT NULL,
    auto_enroll_students boolean DEFAULT false NOT NULL,
    passpilot_class_source text DEFAULT 'legacy_grades'::text NOT NULL,
    passpilot_class_cutover_at timestamp with time zone,
    passpilot_class_migration_revision integer DEFAULT 0 NOT NULL,
    passpilot_canonical_writes_at timestamp with time zone,
    instructional_calendar jsonb DEFAULT '{}'::jsonb NOT NULL,
    classpilot_schedule_changes_teacher_requests_enabled boolean DEFAULT false NOT NULL,
    classpilot_schedule_changes_admin_approval_required boolean DEFAULT true NOT NULL,
    classpilot_schedule_changes_same_day_cutoff text DEFAULT '07:00'::text NOT NULL,
    classpilot_schedule_changes_same_day_cutoff_enforced boolean DEFAULT true NOT NULL,
    classpilot_schedule_changes_reason_required boolean DEFAULT true NOT NULL,
    classpilot_schedule_changes_revision integer DEFAULT 0 NOT NULL,
    classpilot_sso_policy jsonb DEFAULT '{"enabled": false, "profiles": [{"id": "clever", "name": "Clever", "startUrl": "https://clever.com/", "hostRules": [{"hostname": "accounts.google.com", "includeSubdomains": false}, {"hostname": "clever.com", "includeSubdomains": true}]}, {"id": "google", "name": "Google", "startUrl": "https://accounts.google.com/", "hostRules": [{"hostname": "accounts.google.com", "includeSubdomains": false}]}], "schemaVersion": 1, "defaultProfileId": "clever", "attemptTtlSeconds": 300}'::jsonb NOT NULL,
    classpilot_sso_policy_revision integer DEFAULT 0 NOT NULL,
    private_chat_epoch integer DEFAULT 1 NOT NULL,
    private_chat_lifecycle_required boolean DEFAULT false NOT NULL,
    CONSTRAINT settings_cp_schedule_change_cutoff_check CHECK ((classpilot_schedule_changes_same_day_cutoff ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text)),
    CONSTRAINT settings_cp_schedule_change_revision_check CHECK ((classpilot_schedule_changes_revision >= 0)),
    CONSTRAINT settings_cp_sso_policy_object_check CHECK ((jsonb_typeof(classpilot_sso_policy) = 'object'::text)),
    CONSTRAINT settings_cp_sso_policy_revision_check CHECK ((classpilot_sso_policy_revision >= 0)),
    CONSTRAINT settings_passpilot_class_migration_revision_check CHECK ((passpilot_class_migration_revision >= 0)),
    CONSTRAINT settings_passpilot_class_source_check CHECK ((passpilot_class_source = ANY (ARRAY['legacy_grades'::text, 'classpilot_groups'::text]))),
    CONSTRAINT settings_private_chat_epoch_check CHECK ((private_chat_epoch > 0))
);

ALTER TABLE ONLY public.settings FORCE ROW LEVEL SECURITY;


--
-- Name: student_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_attendance (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    date text NOT NULL,
    status text NOT NULL,
    reason text,
    notes text,
    marked_by text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.student_attendance FORCE ROW LEVEL SECURITY;


--
-- Name: student_contact_profile_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_contact_profile_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    profile_id character varying NOT NULL,
    revision integer NOT NULL,
    request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    data jsonb NOT NULL,
    changes jsonb NOT NULL,
    reason text NOT NULL,
    author_name text NOT NULL,
    import_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT student_contact_versions_bounds CHECK (((revision > 0) AND (request_fingerprint ~ '^[0-9a-f]{64}$'::text) AND ((char_length(reason) >= 1) AND (char_length(reason) <= 500)) AND (octet_length((data)::text) <= 65536) AND (octet_length((changes)::text) <= 65536)))
);

ALTER TABLE ONLY public.student_contact_profile_versions FORCE ROW LEVEL SECURITY;


--
-- Name: student_contact_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_contact_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id character varying,
    filing_student_id character varying NOT NULL,
    student_name text NOT NULL,
    data jsonb DEFAULT '{"contacts": []}'::jsonb NOT NULL,
    mutation_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    updated_by character varying NOT NULL,
    updated_by_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT student_contact_profiles_bounds CHECK (((revision >= 0) AND (char_length(student_name) <= 500) AND (octet_length((data)::text) <= 65536) AND (jsonb_typeof(data) = 'object'::text))),
    CONSTRAINT student_contact_profiles_json CHECK ((
CASE
    WHEN (jsonb_typeof((data -> 'contacts'::text)) = 'array'::text) THEN (jsonb_array_length((data -> 'contacts'::text)) <= 20)
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(mutation_receipts) = 'array'::text) THEN ((jsonb_array_length(mutation_receipts) <= 100) AND (octet_length((mutation_receipts)::text) <= 32768))
    ELSE false
END))
);

ALTER TABLE ONLY public.student_contact_profiles FORCE ROW LEVEL SECURITY;


--
-- Name: student_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_devices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id text NOT NULL,
    device_id text NOT NULL,
    first_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: student_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_groups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    teacher_id text,
    group_name text NOT NULL,
    description text,
    student_ids text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.student_groups FORCE ROW LEVEL SECURITY;


--
-- Name: student_information_import_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_information_import_assets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    import_id character varying NOT NULL,
    parent_id character varying,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    kind text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    storage_key text NOT NULL,
    filename text DEFAULT ''::text NOT NULL,
    content_type text NOT NULL,
    input_sha256 text NOT NULL,
    sha256 text,
    byte_size integer NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    ordinal integer DEFAULT 0 NOT NULL,
    units integer DEFAULT 0 NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    stats jsonb DEFAULT '{"rows": 0, "pages": 0, "sheets": 0, "columns": 0, "textBytes": 0}'::jsonb NOT NULL,
    processed_at timestamp with time zone,
    lease_id uuid,
    lease_until timestamp with time zone,
    next_cleanup_at timestamp with time zone,
    cleanup_attempts integer DEFAULT 0 NOT NULL,
    CONSTRAINT student_information_assets_bounds CHECK (((kind = ANY (ARRAY['source'::text, 'section'::text])) AND (status = ANY (ARRAY['pending'::text, 'uploading'::text, 'ready'::text, 'delete_pending'::text, 'deleted'::text])) AND ((byte_size >= 1) AND (byte_size <= 10485760)) AND ((units >= 0) AND (units <= 20)) AND (request_fingerprint ~ '^[a-f0-9]{64}$'::text) AND (input_sha256 ~ '^[a-f0-9]{64}$'::text) AND ((sha256 IS NULL) OR (sha256 ~ '^[a-f0-9]{64}$'::text)) AND (char_length(filename) <= 255) AND (char_length(label) <= 200) AND (octet_length((warnings)::text) <= 8192) AND ((lease_id IS NULL) = (lease_until IS NULL))))
);

ALTER TABLE ONLY public.student_information_import_assets FORCE ROW LEVEL SECURITY;


--
-- Name: student_information_import_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_information_import_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    import_id character varying NOT NULL,
    ordinal integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    source_section_id character varying NOT NULL,
    student_name text NOT NULL,
    student_identifier text,
    student_id character varying,
    base_revision integer DEFAULT 0 NOT NULL,
    proposed jsonb NOT NULL,
    changes jsonb DEFAULT '[]'::jsonb NOT NULL,
    warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    reviewed boolean DEFAULT false NOT NULL,
    excluded boolean DEFAULT false NOT NULL,
    review_fingerprint text,
    CONSTRAINT student_information_items_bounds CHECK (((ordinal >= 0) AND (ordinal <= 499) AND (revision > 0) AND (base_revision >= 0) AND (char_length(student_name) <= 200) AND (octet_length((proposed)::text) <= 65536) AND (octet_length((changes)::text) <= 65536) AND (octet_length((warnings)::text) <= 8192)))
);

ALTER TABLE ONLY public.student_information_import_items FORCE ROW LEVEL SECURITY;


--
-- Name: student_information_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_information_imports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    author_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    client_request_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    expected_source_count integer NOT NULL,
    status text DEFAULT 'uploading'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    selected_section_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    mutation_receipts jsonb DEFAULT '[]'::jsonb NOT NULL,
    commit_receipt jsonb,
    quota_usage jsonb DEFAULT '[]'::jsonb NOT NULL,
    model_version text,
    prompt_version text,
    units integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    lease_id uuid,
    lease_until timestamp with time zone,
    next_attempt_at timestamp with time zone,
    last_error_code text,
    upload_expires_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    processing_version integer DEFAULT 1 NOT NULL,
    progress_revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT student_information_imports_bounds CHECK (((expected_source_count >= 1) AND (expected_source_count <= 5) AND (revision > 0) AND ((units >= 0) AND (units <= 20)) AND ((attempts >= 0) AND (attempts <= 3)) AND (status = ANY (ARRAY['uploading'::text, 'queued'::text, 'processing'::text, 'review'::text, 'failed'::text, 'completed'::text, 'cancelled'::text, 'expired'::text])) AND (request_fingerprint ~ '^[0-9a-f]{64}$'::text) AND ((lease_id IS NULL) = (lease_until IS NULL)) AND (octet_length((selected_section_ids)::text) <= 8192) AND (octet_length((mutation_receipts)::text) <= 32768) AND (octet_length((quota_usage)::text) <= 4096) AND ((commit_receipt IS NULL) OR (octet_length((commit_receipt)::text) <= 131072)))),
    CONSTRAINT student_information_imports_json CHECK ((
CASE
    WHEN (jsonb_typeof(selected_section_ids) = 'array'::text) THEN (jsonb_array_length(selected_section_ids) <= 100)
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(mutation_receipts) = 'array'::text) THEN (jsonb_array_length(mutation_receipts) <= 100)
    ELSE false
END AND
CASE
    WHEN (jsonb_typeof(quota_usage) = 'array'::text) THEN (jsonb_array_length(quota_usage) <= 8)
    ELSE false
END AND ((model_version IS NULL) OR (model_version ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$'::text)) AND ((prompt_version IS NULL) OR (prompt_version ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$'::text)))),
    CONSTRAINT student_information_imports_processing_protocol CHECK (((processing_version = ANY (ARRAY[1, 2])) AND (progress_revision > 0)))
);

ALTER TABLE ONLY public.student_information_imports FORCE ROW LEVEL SECURITY;


--
-- Name: student_safety_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_safety_alerts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    case_id text NOT NULL,
    fingerprint text NOT NULL,
    url_fingerprint text,
    url_ciphertext text,
    source_type text NOT NULL,
    source_id text NOT NULL,
    concern text NOT NULL,
    severity text NOT NULL,
    classification_source text,
    matched_term text,
    reason text,
    ruleset_version text,
    model_version text,
    confidence integer,
    decision_id text,
    heartbeat_id text,
    teaching_session_id text,
    first_seen_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    observation_count integer DEFAULT 1 NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    acknowledged_at timestamp with time zone,
    acknowledged_by text,
    reviewed_at timestamp with time zone,
    reviewed_by text,
    review_note text
);

ALTER TABLE ONLY public.student_safety_alerts FORCE ROW LEVEL SECURITY;


--
-- Name: student_safety_case_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_safety_case_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    case_id text NOT NULL,
    alert_id text,
    actor_id text,
    kind text NOT NULL,
    note text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.student_safety_case_events FORCE ROW LEVEL SECURITY;


--
-- Name: student_safety_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_safety_cases (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    title text NOT NULL,
    severity text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    opened_by text,
    closed_by text,
    opened_at timestamp without time zone DEFAULT now() NOT NULL,
    closed_at timestamp without time zone,
    summary text,
    metadata jsonb,
    revision integer DEFAULT 0 NOT NULL,
    acknowledged_at timestamp with time zone,
    acknowledged_by text,
    assigned_to text,
    resolution_note text,
    merged_into text
);

ALTER TABLE ONLY public.student_safety_cases FORCE ROW LEVEL SECURITY;


--
-- Name: student_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id text NOT NULL,
    device_id text NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    auth_kind text DEFAULT 'legacy'::text NOT NULL,
    manual_lease_expires_at timestamp with time zone,
    session_recovery_token_hash character varying(64),
    CONSTRAINT student_sessions_active_manual_recovery_check CHECK (((auth_kind <> 'manual_shared'::text) OR (is_active = false) OR (session_recovery_token_hash IS NOT NULL))),
    CONSTRAINT student_sessions_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['legacy'::text, 'managed_profile'::text, 'manual_shared'::text]))),
    CONSTRAINT student_sessions_manual_lease_shape_check CHECK ((((auth_kind = 'manual_shared'::text) AND (manual_lease_expires_at IS NOT NULL)) OR ((auth_kind <> 'manual_shared'::text) AND (manual_lease_expires_at IS NULL) AND (session_recovery_token_hash IS NULL)))),
    CONSTRAINT student_sessions_recovery_token_hash_check CHECK (((session_recovery_token_hash IS NULL) OR ((session_recovery_token_hash)::text ~ '^[0-9a-f]{64}$'::text)))
);


--
-- Name: student_timeline_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_timeline_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    student_id text NOT NULL,
    case_id text,
    event_type text NOT NULL,
    source_type text NOT NULL,
    source_id text,
    title text NOT NULL,
    summary text,
    severity text,
    actor_user_id text,
    metadata jsonb,
    occurred_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.student_timeline_events FORCE ROW LEVEL SECURITY;


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text,
    email_lc text,
    google_user_id text,
    photo_url text,
    grade_level text,
    student_id_number text,
    grade_id text,
    homeroom_id text,
    dismissal_type text DEFAULT 'car'::text,
    afterschool_reason text,
    bus_route text,
    student_code text,
    external_id text,
    classpilot_pin_hash text,
    classpilot_pin_encrypted text,
    device_id text,
    student_status text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.students FORCE ROW LEVEL SECURITY;


--
-- Name: subgroup_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subgroup_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subgroup_id character varying NOT NULL,
    student_id text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: subgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subgroups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    group_id character varying NOT NULL,
    school_id text,
    name text NOT NULL,
    color text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.subgroups FORCE ROW LEVEL SECURITY;


--
-- Name: teacher_grades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_grades (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    teacher_id text NOT NULL,
    grade_id text NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: teacher_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    teacher_id text NOT NULL,
    max_tabs_per_student text,
    allowed_domains text[] DEFAULT '{}'::text[],
    blocked_domains text[] DEFAULT '{}'::text[],
    default_flight_path_id text,
    hand_raising_enabled boolean DEFAULT true NOT NULL,
    student_messaging_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: teacher_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    teacher_id text NOT NULL,
    student_id text NOT NULL,
    school_id text,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.teacher_students FORCE ROW LEVEL SECURITY;


--
-- Name: teaching_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teaching_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    group_id text NOT NULL,
    teacher_id text NOT NULL,
    school_id text,
    start_time timestamp without time zone DEFAULT now() NOT NULL,
    control_updated_at timestamp without time zone,
    session_mode text DEFAULT 'live'::text NOT NULL,
    scheduled_conflict_id text,
    scheduled_date text,
    scheduled_timezone text,
    scheduled_start_at timestamp with time zone,
    scheduled_end_at timestamp with time zone,
    scheduled_teacher_email text,
    scheduled_teacher_name text,
    class_name_snapshot text,
    timezone_snapshot text,
    roster_snapshot_completed_at timestamp with time zone,
    scheduled_state text,
    scheduled_finalization_reason text,
    end_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT teaching_sessions_scheduled_metadata_check CHECK ((((scheduled_date IS NULL) AND (scheduled_timezone IS NULL) AND (scheduled_start_at IS NULL) AND (scheduled_end_at IS NULL) AND (scheduled_state IS NULL)) OR ((scheduled_date IS NOT NULL) AND (scheduled_timezone IS NOT NULL) AND (scheduled_start_at IS NOT NULL) AND (scheduled_end_at IS NOT NULL) AND (scheduled_state IS NOT NULL)))),
    CONSTRAINT teaching_sessions_scheduled_state_check CHECK (((scheduled_state IS NULL) OR (scheduled_state = ANY (ARRAY['active'::text, 'finalized'::text, 'skipped'::text])))),
    CONSTRAINT teaching_sessions_scheduled_window_check CHECK (((scheduled_start_at IS NULL) OR (scheduled_end_at IS NULL) OR (scheduled_end_at > scheduled_start_at)))
);

ALTER TABLE ONLY public.teaching_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password text,
    google_id text,
    microsoft_id text,
    first_name text DEFAULT ''::text NOT NULL,
    last_name text DEFAULT ''::text NOT NULL,
    display_name text,
    phone text,
    profile_image_url text,
    is_super_admin boolean DEFAULT false NOT NULL,
    auth_version integer DEFAULT 1 NOT NULL,
    check_in_method text DEFAULT 'app'::text,
    notification_prefs text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_login_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: walker_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.walker_zones (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'closed'::text NOT NULL
);

ALTER TABLE ONLY public.walker_zones FORCE ROW LEVEL SECURITY;


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: classpilot_ai_decisions ai_decisions_content_category_values; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_ai_decisions
    ADD CONSTRAINT ai_decisions_content_category_values CHECK (((content_category IS NULL) OR (content_category = ANY (ARRAY['Gaming'::text, 'Social media'::text, 'Video'::text, 'Music'::text, 'Messaging'::text, 'Forums'::text, 'Shopping'::text, 'Sports'::text, 'News'::text, 'Entertainment'::text, 'AI tools'::text, 'Finance'::text, 'Travel'::text, 'Lifestyle'::text, 'Technology'::text, 'Health'::text, 'Education'::text, 'Reference'::text, 'Productivity'::text, 'Gambling'::text])))) NOT VALID;


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_lockouts auth_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_lockouts
    ADD CONSTRAINT auth_lockouts_pkey PRIMARY KEY (email_lc);


--
-- Name: authorized_pickups authorized_pickups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authorized_pickups
    ADD CONSTRAINT authorized_pickups_pkey PRIMARY KEY (id);


--
-- Name: block_lists block_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.block_lists
    ADD CONSTRAINT block_lists_pkey PRIMARY KEY (id);


--
-- Name: bus_routes bus_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bus_routes
    ADD CONSTRAINT bus_routes_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- Name: classpilot_active_hands classpilot_active_hands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_active_hands
    ADD CONSTRAINT classpilot_active_hands_pkey PRIMARY KEY (id);


--
-- Name: classpilot_ai_decisions classpilot_ai_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_ai_decisions
    ADD CONSTRAINT classpilot_ai_decisions_pkey PRIMARY KEY (id);


--
-- Name: classpilot_chat_deliveries classpilot_chat_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_chat_deliveries
    ADD CONSTRAINT classpilot_chat_deliveries_pkey PRIMARY KEY (id);


--
-- Name: classpilot_classroom_states classpilot_classroom_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_classroom_states
    ADD CONSTRAINT classpilot_classroom_states_pkey PRIMARY KEY (id);


--
-- Name: classpilot_command_targets classpilot_command_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_command_targets
    ADD CONSTRAINT classpilot_command_targets_pkey PRIMARY KEY (id);


--
-- Name: classpilot_commands classpilot_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_commands
    ADD CONSTRAINT classpilot_commands_pkey PRIMARY KEY (id);


--
-- Name: classpilot_coverage_assignments classpilot_coverage_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_assignments
    ADD CONSTRAINT classpilot_coverage_assignments_pkey PRIMARY KEY (id);


--
-- Name: classpilot_coverage_group_categories classpilot_coverage_categories_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_group_categories
    ADD CONSTRAINT classpilot_coverage_categories_school_id_unique UNIQUE (school_id, id);


--
-- Name: classpilot_coverage_group_categories classpilot_coverage_group_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_group_categories
    ADD CONSTRAINT classpilot_coverage_group_categories_pkey PRIMARY KEY (id);


--
-- Name: classpilot_coverage_scope_group_members classpilot_coverage_scope_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_scope_group_members
    ADD CONSTRAINT classpilot_coverage_scope_group_members_pkey PRIMARY KEY (id);


--
-- Name: classpilot_coverage_scope_groups classpilot_coverage_scope_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_scope_groups
    ADD CONSTRAINT classpilot_coverage_scope_groups_pkey PRIMARY KEY (id);


--
-- Name: classpilot_evidence_capture_requests classpilot_evidence_capture_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_evidence_capture_requests
    ADD CONSTRAINT classpilot_evidence_capture_requests_pkey PRIMARY KEY (id);


--
-- Name: classpilot_lesson_activities classpilot_lesson_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_activities
    ADD CONSTRAINT classpilot_lesson_activities_pkey PRIMARY KEY (id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_school_id_lesson_activity_id_stu_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_school_id_lesson_activity_id_stu_key UNIQUE (school_id, lesson_activity_id, student_id);


--
-- Name: classpilot_monitoring_events classpilot_monitoring_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_events
    ADD CONSTRAINT classpilot_monitoring_events_pkey PRIMARY KEY (id);


--
-- Name: classpilot_monitoring_expectations classpilot_monitoring_expectations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT classpilot_monitoring_expectations_pkey PRIMARY KEY (id);


--
-- Name: classpilot_monitoring_interruption_digests classpilot_monitoring_interruption_digests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruption_digests
    ADD CONSTRAINT classpilot_monitoring_interruption_digests_pkey PRIMARY KEY (id);


--
-- Name: classpilot_monitoring_interruption_settings classpilot_monitoring_interruption_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruption_settings
    ADD CONSTRAINT classpilot_monitoring_interruption_settings_pkey PRIMARY KEY (school_id);


--
-- Name: classpilot_monitoring_interruptions classpilot_monitoring_interruptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT classpilot_monitoring_interruptions_pkey PRIMARY KEY (id);


--
-- Name: classpilot_picker_rounds classpilot_picker_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_picker_rounds
    ADD CONSTRAINT classpilot_picker_rounds_pkey PRIMARY KEY (id);


--
-- Name: classpilot_private_chat_threads classpilot_private_chat_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT classpilot_private_chat_threads_pkey PRIMARY KEY (id);


--
-- Name: classpilot_questions classpilot_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_pkey PRIMARY KEY (id);


--
-- Name: classpilot_questions classpilot_questions_school_id_student_id_client_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_school_id_student_id_client_request_id_key UNIQUE (school_id, student_id, client_request_id);


--
-- Name: classpilot_routine_runs classpilot_routine_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_routine_runs
    ADD CONSTRAINT classpilot_routine_runs_pkey PRIMARY KEY (id);


--
-- Name: classpilot_schedule_change_legs classpilot_schedule_change_legs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_legs
    ADD CONSTRAINT classpilot_schedule_change_legs_pkey PRIMARY KEY (id);


--
-- Name: classpilot_schedule_change_pairs classpilot_schedule_change_pairs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_pairs
    ADD CONSTRAINT classpilot_schedule_change_pairs_pkey PRIMARY KEY (id);


--
-- Name: classpilot_schedule_changes classpilot_schedule_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_changes
    ADD CONSTRAINT classpilot_schedule_changes_pkey PRIMARY KEY (id);


--
-- Name: classpilot_scheduled_conflicts classpilot_scheduled_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_scheduled_conflicts
    ADD CONSTRAINT classpilot_scheduled_conflicts_pkey PRIMARY KEY (id);


--
-- Name: classpilot_school_schedules classpilot_school_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_schedules
    ADD CONSTRAINT classpilot_school_schedules_pkey PRIMARY KEY (school_id);


--
-- Name: classpilot_school_website_deliveries classpilot_school_website_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_deliveries
    ADD CONSTRAINT classpilot_school_website_deliveries_pkey PRIMARY KEY (id);


--
-- Name: classpilot_school_website_policies classpilot_school_website_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_policies
    ADD CONSTRAINT classpilot_school_website_policies_pkey PRIMARY KEY (school_id);


--
-- Name: classpilot_session_reports classpilot_session_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_reports
    ADD CONSTRAINT classpilot_session_reports_pkey PRIMARY KEY (id);


--
-- Name: classpilot_session_staff classpilot_session_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_staff
    ADD CONSTRAINT classpilot_session_staff_pkey PRIMARY KEY (id);


--
-- Name: classpilot_session_student_reports classpilot_session_student_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_student_reports
    ADD CONSTRAINT classpilot_session_student_reports_pkey PRIMARY KEY (id);


--
-- Name: classpilot_session_students classpilot_session_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_students
    ADD CONSTRAINT classpilot_session_students_pkey PRIMARY KEY (id);


--
-- Name: classpilot_session_summary_deliveries classpilot_session_summary_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_summary_deliveries
    ADD CONSTRAINT classpilot_session_summary_deliveries_pkey PRIMARY KEY (id);


--
-- Name: classpilot_session_usage classpilot_session_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_session_usage
    ADD CONSTRAINT classpilot_session_usage_pkey PRIMARY KEY (id);


--
-- Name: classpilot_student_control_states classpilot_student_control_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_student_control_states
    ADD CONSTRAINT classpilot_student_control_states_pkey PRIMARY KEY (id);


--
-- Name: classpilot_supervision_contexts classpilot_supervision_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_contexts
    ADD CONSTRAINT classpilot_supervision_contexts_pkey PRIMARY KEY (id);


--
-- Name: classpilot_supervision_report_segments classpilot_supervision_report_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_report_segments
    ADD CONSTRAINT classpilot_supervision_report_segments_pkey PRIMARY KEY (id);


--
-- Name: classpilot_supervision_student_reports classpilot_supervision_student_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_student_reports
    ADD CONSTRAINT classpilot_supervision_student_reports_pkey PRIMARY KEY (id);


--
-- Name: classpilot_supervision_students classpilot_supervision_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_students
    ADD CONSTRAINT classpilot_supervision_students_pkey PRIMARY KEY (id);


--
-- Name: classpilot_supervision_summary_deliveries classpilot_supervision_summary_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_summary_deliveries
    ADD CONSTRAINT classpilot_supervision_summary_deliveries_pkey PRIMARY KEY (id);


--
-- Name: classpilot_teacher_preferences classpilot_teacher_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_teacher_preferences
    ADD CONSTRAINT classpilot_teacher_preferences_pkey PRIMARY KEY (id);


--
-- Name: classpilot_timers classpilot_timers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_timers
    ADD CONSTRAINT classpilot_timers_pkey PRIMARY KEY (id);


--
-- Name: classpilot_tool_history classpilot_tool_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_history
    ADD CONSTRAINT classpilot_tool_history_pkey PRIMARY KEY (id);


--
-- Name: classpilot_tool_templates classpilot_tool_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_templates
    ADD CONSTRAINT classpilot_tool_templates_pkey PRIMARY KEY (id);


--
-- Name: classpilot_usage_rollups classpilot_usage_rollups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollups
    ADD CONSTRAINT classpilot_usage_rollups_pkey PRIMARY KEY (id);


--
-- Name: classroom_course_students classroom_course_students_enrollment_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classroom_course_students
    ADD CONSTRAINT classroom_course_students_enrollment_unique UNIQUE (school_id, course_id, student_id);


--
-- Name: classroom_course_students classroom_course_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classroom_course_students
    ADD CONSTRAINT classroom_course_students_pkey PRIMARY KEY (id);


--
-- Name: classroom_courses classroom_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classroom_courses
    ADD CONSTRAINT classroom_courses_pkey PRIMARY KEY (id);


--
-- Name: classpilot_evidence_capture_requests cp_evidence_capture_school_id_fk_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_evidence_capture_requests
    ADD CONSTRAINT cp_evidence_capture_school_id_fk_key UNIQUE (school_id, id);


--
-- Name: teaching_sessions cp_monitoring_class_parent_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teaching_sessions
    ADD CONSTRAINT cp_monitoring_class_parent_unique UNIQUE (school_id, id);


--
-- Name: classpilot_supervision_contexts cp_monitoring_coverage_parent_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_contexts
    ADD CONSTRAINT cp_monitoring_coverage_parent_unique UNIQUE (school_id, id);


--
-- Name: devices cp_monitoring_device_parent_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT cp_monitoring_device_parent_unique UNIQUE (school_id, device_id);


--
-- Name: student_sessions cp_monitoring_session_parent_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_sessions
    ADD CONSTRAINT cp_monitoring_session_parent_unique UNIQUE (id, student_id, device_id);


--
-- Name: classpilot_private_chat_threads cp_private_chat_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT cp_private_chat_school_id_unique UNIQUE (school_id, id);


--
-- Name: classpilot_schedule_change_pairs cp_schedule_change_pairs_school_id_fk_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_pairs
    ADD CONSTRAINT cp_schedule_change_pairs_school_id_fk_key UNIQUE (school_id, id);


--
-- Name: classpilot_schedule_changes cp_schedule_changes_school_id_date_fk_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_changes
    ADD CONSTRAINT cp_schedule_changes_school_id_date_fk_key UNIQUE (school_id, id, scheduled_date);


--
-- Name: classpilot_supervision_report_segments cp_supervision_report_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_report_segments
    ADD CONSTRAINT cp_supervision_report_school_id_unique UNIQUE (school_id, id);


--
-- Name: classpilot_usage_rollup_days cp_usage_days_school_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollup_days
    ADD CONSTRAINT cp_usage_days_school_date_unique UNIQUE (school_id, usage_date);


--
-- Name: custody_alerts custody_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custody_alerts
    ADD CONSTRAINT custody_alerts_pkey PRIMARY KEY (id);


--
-- Name: daily_usage daily_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_usage
    ADD CONSTRAINT daily_usage_pkey PRIMARY KEY (id);


--
-- Name: dashboard_tabs dashboard_tabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_tabs
    ADD CONSTRAINT dashboard_tabs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (device_id);


--
-- Name: dismissal_changes dismissal_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_changes
    ADD CONSTRAINT dismissal_changes_pkey PRIMARY KEY (id);


--
-- Name: dismissal_overrides dismissal_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_overrides
    ADD CONSTRAINT dismissal_overrides_pkey PRIMARY KEY (id);


--
-- Name: dismissal_overrides dismissal_overrides_session_student_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_overrides
    ADD CONSTRAINT dismissal_overrides_session_student_unique UNIQUE (session_id, student_id);


--
-- Name: dismissal_queue dismissal_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_queue
    ADD CONSTRAINT dismissal_queue_pkey PRIMARY KEY (id);


--
-- Name: dismissal_queue dismissal_queue_session_student_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_queue
    ADD CONSTRAINT dismissal_queue_session_student_unique UNIQUE (session_id, student_id);


--
-- Name: dismissal_sessions dismissal_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_sessions
    ADD CONSTRAINT dismissal_sessions_pkey PRIMARY KEY (id);


--
-- Name: dismissal_sessions dismissal_sessions_school_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_sessions
    ADD CONSTRAINT dismissal_sessions_school_date_unique UNIQUE (school_id, date);


--
-- Name: email_alerts email_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_alerts
    ADD CONSTRAINT email_alerts_pkey PRIMARY KEY (id);


--
-- Name: email_scan_log email_scan_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_scan_log
    ADD CONSTRAINT email_scan_log_pkey PRIMARY KEY (id);


--
-- Name: error_logs error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: evidence_artifacts evidence_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_artifacts
    ADD CONSTRAINT evidence_artifacts_pkey PRIMARY KEY (id);


--
-- Name: family_group_students family_group_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_group_students
    ADD CONSTRAINT family_group_students_pkey PRIMARY KEY (id);


--
-- Name: family_group_students family_group_students_school_student_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_group_students
    ADD CONSTRAINT family_group_students_school_student_unique UNIQUE (school_id, student_id);


--
-- Name: family_group_students family_group_students_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_group_students
    ADD CONSTRAINT family_group_students_unique UNIQUE (family_group_id, student_id);


--
-- Name: family_groups family_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_groups
    ADD CONSTRAINT family_groups_pkey PRIMARY KEY (id);


--
-- Name: family_groups family_groups_school_car_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_groups
    ADD CONSTRAINT family_groups_school_car_unique UNIQUE (school_id, car_number);


--
-- Name: flight_paths flight_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flight_paths
    ADD CONSTRAINT flight_paths_pkey PRIMARY KEY (id);


--
-- Name: google_oauth_tokens google_oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_oauth_tokens
    ADD CONSTRAINT google_oauth_tokens_pkey PRIMARY KEY (id);


--
-- Name: google_oauth_tokens google_oauth_tokens_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_oauth_tokens
    ADD CONSTRAINT google_oauth_tokens_user_id_unique UNIQUE (user_id);


--
-- Name: google_roster_connectors google_roster_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_roster_connectors
    ADD CONSTRAINT google_roster_connectors_pkey PRIMARY KEY (id);


--
-- Name: google_roster_connectors google_roster_connectors_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_roster_connectors
    ADD CONSTRAINT google_roster_connectors_school_id_unique UNIQUE (school_id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: grades grades_school_id_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_school_id_id_unique UNIQUE (school_id, id);


--
-- Name: group_students group_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_students
    ADD CONSTRAINT group_students_pkey PRIMARY KEY (id);


--
-- Name: group_teachers group_teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_teachers
    ADD CONSTRAINT group_teachers_pkey PRIMARY KEY (id);


--
-- Name: group_teachers group_teachers_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_teachers
    ADD CONSTRAINT group_teachers_unique UNIQUE (group_id, teacher_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: groups groups_school_id_id_fk_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_school_id_id_fk_key UNIQUE (school_id, id);


--
-- Name: heartbeats heartbeats_content_category_values; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.heartbeats
    ADD CONSTRAINT heartbeats_content_category_values CHECK (((content_category IS NULL) OR (content_category = ANY (ARRAY['Gaming'::text, 'Social media'::text, 'Video'::text, 'Music'::text, 'Messaging'::text, 'Forums'::text, 'Shopping'::text, 'Sports'::text, 'News'::text, 'Entertainment'::text, 'AI tools'::text, 'Finance'::text, 'Travel'::text, 'Lifestyle'::text, 'Technology'::text, 'Health'::text, 'Education'::text, 'Reference'::text, 'Productivity'::text, 'Gambling'::text])))) NOT VALID;


--
-- Name: heartbeats heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeats
    ADD CONSTRAINT heartbeats_pkey PRIMARY KEY (id);


--
-- Name: homeroom_teachers homeroom_teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homeroom_teachers
    ADD CONSTRAINT homeroom_teachers_pkey PRIMARY KEY (id);


--
-- Name: homeroom_teachers homeroom_teachers_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homeroom_teachers
    ADD CONSTRAINT homeroom_teachers_unique UNIQUE (homeroom_id, teacher_id);


--
-- Name: homerooms homerooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homerooms
    ADD CONSTRAINT homerooms_pkey PRIMARY KEY (id);


--
-- Name: import_processing_stages import_processing_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_processing_stages
    ADD CONSTRAINT import_processing_stages_pkey PRIMARY KEY (id);


--
-- Name: import_runs import_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_runs
    ADD CONSTRAINT import_runs_pkey PRIMARY KEY (id);


--
-- Name: mailpilot_watches mailpilot_watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mailpilot_watches
    ADD CONSTRAINT mailpilot_watches_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: mydesk_attachments mydesk_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_attachments
    ADD CONSTRAINT mydesk_attachments_pkey PRIMARY KEY (id);


--
-- Name: mydesk_import_assets mydesk_import_assets_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_owner_id UNIQUE (school_id, author_id, import_id, id);


--
-- Name: mydesk_import_assets mydesk_import_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_pkey PRIMARY KEY (id);


--
-- Name: mydesk_import_items mydesk_import_items_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_owner_id UNIQUE (school_id, author_id, import_id, id);


--
-- Name: mydesk_import_items mydesk_import_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_pkey PRIMARY KEY (id);


--
-- Name: mydesk_imports mydesk_imports_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_imports
    ADD CONSTRAINT mydesk_imports_owner_id UNIQUE (school_id, author_id, id);


--
-- Name: mydesk_imports mydesk_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_imports
    ADD CONSTRAINT mydesk_imports_pkey PRIMARY KEY (id);


--
-- Name: mydesk_notes mydesk_notes_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_owner_id UNIQUE (school_id, author_id, id);


--
-- Name: mydesk_notes mydesk_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_pkey PRIMARY KEY (id);


--
-- Name: mydesk_preferences mydesk_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_preferences
    ADD CONSTRAINT mydesk_preferences_pkey PRIMARY KEY (id);


--
-- Name: mydesk_seating_charts mydesk_seating_charts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_seating_charts
    ADD CONSTRAINT mydesk_seating_charts_pkey PRIMARY KEY (id);


--
-- Name: parent_student parent_student_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parent_student
    ADD CONSTRAINT parent_student_pkey PRIMARY KEY (id);


--
-- Name: parent_student parent_student_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parent_student
    ADD CONSTRAINT parent_student_unique UNIQUE (parent_id, student_id);


--
-- Name: passes passes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passes
    ADD CONSTRAINT passes_pkey PRIMARY KEY (id);


--
-- Name: passpilot_appointments passpilot_appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT passpilot_appointments_pkey PRIMARY KEY (id);


--
-- Name: passpilot_destination_policies passpilot_destination_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_destination_policies
    ADD CONSTRAINT passpilot_destination_policies_pkey PRIMARY KEY (school_id, destination);


--
-- Name: passpilot_encounter_restrictions passpilot_encounter_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_encounter_restrictions
    ADD CONSTRAINT passpilot_encounter_restrictions_pkey PRIMARY KEY (id);


--
-- Name: passpilot_grade_students passpilot_grade_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_grade_students
    ADD CONSTRAINT passpilot_grade_students_pkey PRIMARY KEY (id);


--
-- Name: passpilot_grade_students passpilot_grade_students_school_grade_student_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_grade_students
    ADD CONSTRAINT passpilot_grade_students_school_grade_student_unique UNIQUE (school_id, grade_id, student_id);


--
-- Name: passpilot_kiosk_sessions passpilot_kiosk_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_kiosk_sessions
    ADD CONSTRAINT passpilot_kiosk_sessions_pkey PRIMARY KEY (id);


--
-- Name: passpilot_pass_denials passpilot_pass_denials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_denials
    ADD CONSTRAINT passpilot_pass_denials_pkey PRIMARY KEY (id);


--
-- Name: passpilot_pass_limits passpilot_pass_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_limits
    ADD CONSTRAINT passpilot_pass_limits_pkey PRIMARY KEY (id);


--
-- Name: passpilot_teacher_kiosk_settings passpilot_teacher_kiosk_settings_school_id_teacher_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_teacher_kiosk_settings
    ADD CONSTRAINT passpilot_teacher_kiosk_settings_school_id_teacher_id_pk PRIMARY KEY (school_id, teacher_id);


--
-- Name: poll_responses poll_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_responses
    ADD CONSTRAINT poll_responses_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: passpilot_appointments pp_appointments_create_request_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT pp_appointments_create_request_unique UNIQUE (school_id, created_by, create_request_id);


--
-- Name: passpilot_appointments pp_appointments_pass_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT pp_appointments_pass_unique UNIQUE (school_id, pass_id);


--
-- Name: passpilot_appointments pp_appointments_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT pp_appointments_school_id_unique UNIQUE (school_id, id);


--
-- Name: passpilot_encounter_restrictions pp_encounter_restrictions_pair_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_encounter_restrictions
    ADD CONSTRAINT pp_encounter_restrictions_pair_unique UNIQUE (school_id, student_a_id, student_b_id);


--
-- Name: passpilot_kiosk_devices pp_kiosk_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_kiosk_devices
    ADD CONSTRAINT pp_kiosk_devices_pkey PRIMARY KEY (school_id, id);


--
-- Name: passpilot_kiosk_sessions pp_kiosk_sessions_school_id_fk_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_kiosk_sessions
    ADD CONSTRAINT pp_kiosk_sessions_school_id_fk_key UNIQUE (school_id, id);


--
-- Name: product_licenses product_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_licenses
    ADD CONSTRAINT product_licenses_pkey PRIMARY KEY (id);


--
-- Name: product_licenses product_licenses_school_product_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_licenses
    ADD CONSTRAINT product_licenses_school_product_unique UNIQUE (school_id, product);


--
-- Name: roster_integration_connections roster_connections_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_connections
    ADD CONSTRAINT roster_connections_school_id_unique UNIQUE (school_id, id);


--
-- Name: roster_integration_connections roster_integration_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_connections
    ADD CONSTRAINT roster_integration_connections_pkey PRIMARY KEY (id);


--
-- Name: roster_integration_identities roster_integration_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_identities
    ADD CONSTRAINT roster_integration_identities_pkey PRIMARY KEY (id);


--
-- Name: roster_integration_memberships roster_integration_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_memberships
    ADD CONSTRAINT roster_integration_memberships_pkey PRIMARY KEY (id);


--
-- Name: roster_integration_runs roster_integration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_runs
    ADD CONSTRAINT roster_integration_runs_pkey PRIMARY KEY (id);


--
-- Name: roster_integration_runs roster_runs_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_runs
    ADD CONSTRAINT roster_runs_school_id_unique UNIQUE (school_id, id);


--
-- Name: rosters rosters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rosters
    ADD CONSTRAINT rosters_pkey PRIMARY KEY (id);


--
-- Name: student_safety_alerts safety_alert_case_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT safety_alert_case_id_unique UNIQUE (school_id, case_id, id);


--
-- Name: student_safety_alerts safety_alert_observation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT safety_alert_observation_unique UNIQUE (school_id, case_id, fingerprint);


--
-- Name: student_safety_alerts safety_alert_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT safety_alert_school_id_unique UNIQUE (school_id, id);


--
-- Name: student_safety_cases safety_case_student_parent_idx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_cases
    ADD CONSTRAINT safety_case_student_parent_idx UNIQUE (school_id, id, student_id);


--
-- Name: safety_notification_outbox safety_notification_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_notification_outbox
    ADD CONSTRAINT safety_notification_outbox_pkey PRIMARY KEY (id);


--
-- Name: safety_notification_outbox safety_outbox_alert_recipient_kind_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_notification_outbox
    ADD CONSTRAINT safety_outbox_alert_recipient_kind_unique UNIQUE (school_id, alert_id, recipient, kind);


--
-- Name: safety_url_exceptions safety_url_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_url_exceptions
    ADD CONSTRAINT safety_url_exceptions_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: school_discipline_access school_discipline_access_owner; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_access
    ADD CONSTRAINT school_discipline_access_owner UNIQUE (school_id, user_id);


--
-- Name: school_discipline_access school_discipline_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_access
    ADD CONSTRAINT school_discipline_access_pkey PRIMARY KEY (id);


--
-- Name: school_discipline_attachments school_discipline_attachments_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_attachments
    ADD CONSTRAINT school_discipline_attachments_key UNIQUE (storage_key);


--
-- Name: school_discipline_attachments school_discipline_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_attachments
    ADD CONSTRAINT school_discipline_attachments_pkey PRIMARY KEY (id);


--
-- Name: school_discipline_attachments school_discipline_attachments_request; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_attachments
    ADD CONSTRAINT school_discipline_attachments_request UNIQUE (school_id, version_id, client_request_id);


--
-- Name: school_discipline_records school_discipline_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_records
    ADD CONSTRAINT school_discipline_records_pkey PRIMARY KEY (id);


--
-- Name: school_discipline_records school_discipline_records_request; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_records
    ADD CONSTRAINT school_discipline_records_request UNIQUE (school_id, submitted_by, client_request_id);


--
-- Name: school_discipline_records school_discipline_records_school_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_records
    ADD CONSTRAINT school_discipline_records_school_id UNIQUE (school_id, id);


--
-- Name: school_discipline_versions school_discipline_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_versions
    ADD CONSTRAINT school_discipline_versions_pkey PRIMARY KEY (id);


--
-- Name: school_discipline_versions school_discipline_versions_request; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_versions
    ADD CONSTRAINT school_discipline_versions_request UNIQUE (school_id, record_id, client_request_id);


--
-- Name: school_discipline_versions school_discipline_versions_school_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_versions
    ADD CONSTRAINT school_discipline_versions_school_id UNIQUE (school_id, id);


--
-- Name: school_inquiries school_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_inquiries
    ADD CONSTRAINT school_inquiries_pkey PRIMARY KEY (id);


--
-- Name: school_memberships school_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_memberships
    ADD CONSTRAINT school_memberships_pkey PRIMARY KEY (id);


--
-- Name: school_memberships school_memberships_user_school_role_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_memberships
    ADD CONSTRAINT school_memberships_user_school_role_unique UNIQUE (user_id, school_id, role);


--
-- Name: schools schools_domain_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_domain_name_unique UNIQUE (domain, name);


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (id);


--
-- Name: schools schools_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_slug_unique UNIQUE (slug);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: session_settings session_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_settings
    ADD CONSTRAINT session_settings_pkey PRIMARY KEY (id);


--
-- Name: session_settings session_settings_session_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_settings
    ADD CONSTRAINT session_settings_session_id_unique UNIQUE (session_id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_school_id_unique UNIQUE (school_id);


--
-- Name: student_attendance student_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_attendance
    ADD CONSTRAINT student_attendance_pkey PRIMARY KEY (id);


--
-- Name: student_contact_profile_versions student_contact_profile_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profile_versions
    ADD CONSTRAINT student_contact_profile_versions_pkey PRIMARY KEY (id);


--
-- Name: student_contact_profiles student_contact_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profiles
    ADD CONSTRAINT student_contact_profiles_pkey PRIMARY KEY (id);


--
-- Name: student_contact_profiles student_contact_profiles_school_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profiles
    ADD CONSTRAINT student_contact_profiles_school_id UNIQUE (school_id, id);


--
-- Name: student_devices student_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_devices
    ADD CONSTRAINT student_devices_pkey PRIMARY KEY (id);


--
-- Name: student_devices student_devices_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_devices
    ADD CONSTRAINT student_devices_unique UNIQUE (student_id, device_id);


--
-- Name: student_groups student_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_groups
    ADD CONSTRAINT student_groups_pkey PRIMARY KEY (id);


--
-- Name: student_information_import_assets student_information_assets_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_assets_owner_id UNIQUE (school_id, author_id, import_id, id);


--
-- Name: student_information_import_assets student_information_import_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_import_assets_pkey PRIMARY KEY (id);


--
-- Name: student_information_import_items student_information_import_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_items
    ADD CONSTRAINT student_information_import_items_pkey PRIMARY KEY (id);


--
-- Name: student_information_imports student_information_imports_owner_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_imports
    ADD CONSTRAINT student_information_imports_owner_id UNIQUE (school_id, author_id, id);


--
-- Name: student_information_imports student_information_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_imports
    ADD CONSTRAINT student_information_imports_pkey PRIMARY KEY (id);


--
-- Name: student_safety_alerts student_safety_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT student_safety_alerts_pkey PRIMARY KEY (id);


--
-- Name: student_safety_case_events student_safety_case_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_case_events
    ADD CONSTRAINT student_safety_case_events_pkey PRIMARY KEY (id);


--
-- Name: student_safety_cases student_safety_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_cases
    ADD CONSTRAINT student_safety_cases_pkey PRIMARY KEY (id);


--
-- Name: student_safety_cases student_safety_cases_school_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_cases
    ADD CONSTRAINT student_safety_cases_school_id_unique UNIQUE (school_id, id);


--
-- Name: student_sessions student_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_sessions
    ADD CONSTRAINT student_sessions_pkey PRIMARY KEY (id);


--
-- Name: student_timeline_events student_timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_timeline_events
    ADD CONSTRAINT student_timeline_events_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_school_id_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_school_id_id_unique UNIQUE (school_id, id);


--
-- Name: subgroup_members subgroup_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subgroup_members
    ADD CONSTRAINT subgroup_members_pkey PRIMARY KEY (id);


--
-- Name: subgroups subgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subgroups
    ADD CONSTRAINT subgroups_pkey PRIMARY KEY (id);


--
-- Name: teacher_grades teacher_grades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_grades
    ADD CONSTRAINT teacher_grades_pkey PRIMARY KEY (id);


--
-- Name: teacher_grades teacher_grades_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_grades
    ADD CONSTRAINT teacher_grades_unique UNIQUE (teacher_id, grade_id);


--
-- Name: teacher_settings teacher_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_settings
    ADD CONSTRAINT teacher_settings_pkey PRIMARY KEY (id);


--
-- Name: teacher_settings teacher_settings_teacher_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_settings
    ADD CONSTRAINT teacher_settings_teacher_id_unique UNIQUE (teacher_id);


--
-- Name: teacher_students teacher_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_students
    ADD CONSTRAINT teacher_students_pkey PRIMARY KEY (id);


--
-- Name: teaching_sessions teaching_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teaching_sessions
    ADD CONSTRAINT teaching_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_google_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_unique UNIQUE (google_id);


--
-- Name: users users_microsoft_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_microsoft_id_unique UNIQUE (microsoft_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: walker_zones walker_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walker_zones
    ADD CONSTRAINT walker_zones_pkey PRIMARY KEY (id);


--
-- Name: activity_log_school_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_log_school_date_idx ON public.activity_log USING btree (school_id, created_at);


--
-- Name: activity_log_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_log_session_id_idx ON public.activity_log USING btree (session_id);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_school_id_idx ON public.audit_logs USING btree (school_id);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: auth_lockouts_locked_until_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_lockouts_locked_until_idx ON public.auth_lockouts USING btree (locked_until);


--
-- Name: authorized_pickups_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authorized_pickups_school_id_idx ON public.authorized_pickups USING btree (school_id);


--
-- Name: authorized_pickups_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authorized_pickups_student_id_idx ON public.authorized_pickups USING btree (student_id);


--
-- Name: block_lists_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX block_lists_school_id_idx ON public.block_lists USING btree (school_id);


--
-- Name: block_lists_school_library_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX block_lists_school_library_idx ON public.block_lists USING btree (school_id) WHERE ((visibility = 'school'::text) OR official);


--
-- Name: block_lists_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX block_lists_teacher_id_idx ON public.block_lists USING btree (teacher_id);


--
-- Name: bus_routes_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bus_routes_school_id_idx ON public.bus_routes USING btree (school_id);


--
-- Name: chat_messages_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_school_session_idx ON public.chat_messages USING btree (school_id, session_id);


--
-- Name: chat_messages_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_school_student_idx ON public.chat_messages USING btree (school_id, student_id);


--
-- Name: chat_messages_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_session_id_idx ON public.chat_messages USING btree (session_id);


--
-- Name: chat_messages_student_client_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chat_messages_student_client_unique ON public.chat_messages USING btree (school_id, student_id, student_session_id, client_message_id) WHERE (client_message_id IS NOT NULL);


--
-- Name: chat_messages_student_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_student_created_idx ON public.chat_messages USING btree (school_id, student_id, created_at DESC, id DESC);


--
-- Name: chat_messages_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_supervision_idx ON public.chat_messages USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_active_hands_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_active_hands_active_unique ON public.classpilot_active_hands USING btree (teaching_session_id, student_id) WHERE (cleared_at IS NULL);


--
-- Name: classpilot_active_hands_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_active_hands_session_idx ON public.classpilot_active_hands USING btree (school_id, teaching_session_id);


--
-- Name: classpilot_active_hands_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_active_hands_student_idx ON public.classpilot_active_hands USING btree (school_id, student_id);


--
-- Name: classpilot_active_hands_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_active_hands_supervision_idx ON public.classpilot_active_hands USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_ai_decisions_heartbeat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_ai_decisions_heartbeat_idx ON public.classpilot_ai_decisions USING btree (heartbeat_id);


--
-- Name: classpilot_ai_decisions_review_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_ai_decisions_review_idx ON public.classpilot_ai_decisions USING btree (review_status);


--
-- Name: classpilot_ai_decisions_school_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_ai_decisions_school_created_idx ON public.classpilot_ai_decisions USING btree (school_id, created_at);


--
-- Name: classpilot_ai_decisions_student_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_ai_decisions_student_created_idx ON public.classpilot_ai_decisions USING btree (student_id, created_at);


--
-- Name: classpilot_chat_deliveries_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_chat_deliveries_due_idx ON public.classpilot_chat_deliveries USING btree (state, next_attempt_at);


--
-- Name: classpilot_chat_deliveries_message_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_chat_deliveries_message_unique ON public.classpilot_chat_deliveries USING btree (chat_message_id);


--
-- Name: classpilot_chat_deliveries_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_chat_deliveries_school_student_idx ON public.classpilot_chat_deliveries USING btree (school_id, student_id, state);


--
-- Name: classpilot_chat_deliveries_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_chat_deliveries_supervision_idx ON public.classpilot_chat_deliveries USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_classroom_states_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_classroom_states_active_unique ON public.classpilot_classroom_states USING btree (teaching_session_id, student_id, state_type, state_key) WHERE (cleared_at IS NULL);


--
-- Name: classpilot_classroom_states_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_classroom_states_session_idx ON public.classpilot_classroom_states USING btree (school_id, teaching_session_id);


--
-- Name: classpilot_classroom_states_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_classroom_states_student_idx ON public.classpilot_classroom_states USING btree (school_id, student_id);


--
-- Name: classpilot_classroom_states_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_classroom_states_supervision_idx ON public.classpilot_classroom_states USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_command_targets_command_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_command_targets_command_idx ON public.classpilot_command_targets USING btree (command_id);


--
-- Name: classpilot_command_targets_device_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_command_targets_device_idx ON public.classpilot_command_targets USING btree (device_id);


--
-- Name: classpilot_command_targets_school_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_command_targets_school_context_idx ON public.classpilot_command_targets USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_command_targets_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_command_targets_school_student_idx ON public.classpilot_command_targets USING btree (school_id, student_id);


--
-- Name: classpilot_commands_school_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_commands_school_context_idx ON public.classpilot_commands USING btree (school_id, supervision_context_id);


--
-- Name: classpilot_commands_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_commands_school_session_idx ON public.classpilot_commands USING btree (school_id, teaching_session_id);


--
-- Name: classpilot_commands_teacher_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_commands_teacher_created_idx ON public.classpilot_commands USING btree (teacher_id, created_at);


--
-- Name: classpilot_coverage_assignments_school_staff_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_coverage_assignments_school_staff_idx ON public.classpilot_coverage_assignments USING btree (school_id, staff_id);


--
-- Name: classpilot_coverage_assignments_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_coverage_assignments_scope_idx ON public.classpilot_coverage_assignments USING btree (school_id, scope_type, scope_value);


--
-- Name: classpilot_coverage_categories_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_coverage_categories_name_unique ON public.classpilot_coverage_group_categories USING btree (school_id, lower(btrim(name)));


--
-- Name: classpilot_coverage_groups_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_coverage_groups_category_idx ON public.classpilot_coverage_scope_groups USING btree (school_id, category_id);


--
-- Name: classpilot_coverage_scope_group_members_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_coverage_scope_group_members_group_idx ON public.classpilot_coverage_scope_group_members USING btree (school_id, coverage_group_id);


--
-- Name: classpilot_coverage_scope_group_members_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_coverage_scope_group_members_unique ON public.classpilot_coverage_scope_group_members USING btree (school_id, coverage_group_id, student_id);


--
-- Name: classpilot_coverage_scope_groups_school_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_coverage_scope_groups_school_idx ON public.classpilot_coverage_scope_groups USING btree (school_id, active);


--
-- Name: classpilot_hands_context_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_hands_context_active_unique ON public.classpilot_active_hands USING btree (school_id, supervision_context_id, student_id) WHERE ((supervision_context_id IS NOT NULL) AND (cleared_at IS NULL));


--
-- Name: classpilot_lesson_activities_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_lesson_activities_activity ON public.classpilot_lesson_activities USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_lesson_activities_context_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_lesson_activities_context_current ON public.classpilot_lesson_activities USING btree (school_id, supervision_context_id) WHERE ((supervision_context_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_lesson_activities_session_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_lesson_activities_session_current ON public.classpilot_lesson_activities USING btree (school_id, teaching_session_id) WHERE ((teaching_session_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_lesson_progress_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_lesson_progress_activity ON public.classpilot_lesson_progress USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_picker_rounds_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_picker_rounds_activity ON public.classpilot_picker_rounds USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_picker_rounds_context_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_picker_rounds_context_current ON public.classpilot_picker_rounds USING btree (school_id, supervision_context_id) WHERE ((supervision_context_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_picker_rounds_session_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_picker_rounds_session_current ON public.classpilot_picker_rounds USING btree (school_id, teaching_session_id) WHERE ((teaching_session_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_questions_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_questions_activity ON public.classpilot_questions USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_routine_runs_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_routine_runs_activity ON public.classpilot_routine_runs USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_routine_runs_context_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_routine_runs_context_current ON public.classpilot_routine_runs USING btree (school_id, supervision_context_id) WHERE ((supervision_context_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_routine_runs_session_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_routine_runs_session_current ON public.classpilot_routine_runs USING btree (school_id, teaching_session_id) WHERE ((teaching_session_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_scheduled_conflicts_school_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_scheduled_conflicts_school_status_idx ON public.classpilot_scheduled_conflicts USING btree (school_id, status);


--
-- Name: classpilot_scheduled_conflicts_teacher_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_scheduled_conflicts_teacher_idx ON public.classpilot_scheduled_conflicts USING btree (school_id, teacher_id);


--
-- Name: classpilot_scheduled_conflicts_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_scheduled_conflicts_unique ON public.classpilot_scheduled_conflicts USING btree (school_id, group_id, scheduled_date, block_start_time);


--
-- Name: classpilot_session_students_school_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_students_school_group_idx ON public.classpilot_session_students USING btree (school_id, group_id);


--
-- Name: classpilot_session_students_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_students_school_session_idx ON public.classpilot_session_students USING btree (school_id, teaching_session_id);


--
-- Name: classpilot_session_students_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_students_school_student_idx ON public.classpilot_session_students USING btree (school_id, student_id);


--
-- Name: classpilot_session_students_session_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_session_students_session_student_unique ON public.classpilot_session_students USING btree (teaching_session_id, student_id);


--
-- Name: classpilot_session_usage_school_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_usage_school_date_idx ON public.classpilot_session_usage USING btree (school_id, local_date);


--
-- Name: classpilot_session_usage_school_group_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_usage_school_group_date_idx ON public.classpilot_session_usage USING btree (school_id, group_id, local_date);


--
-- Name: classpilot_session_usage_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_session_usage_school_session_idx ON public.classpilot_session_usage USING btree (school_id, teaching_session_id);


--
-- Name: classpilot_session_usage_session_student_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_session_usage_session_student_date_unique ON public.classpilot_session_usage USING btree (teaching_session_id, student_id, local_date);


--
-- Name: classpilot_supervision_contexts_coverage_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_contexts_coverage_group_idx ON public.classpilot_supervision_contexts USING btree (school_id, coverage_group_id);


--
-- Name: classpilot_supervision_contexts_scheduled_conflict_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_contexts_scheduled_conflict_idx ON public.classpilot_supervision_contexts USING btree (school_id, scheduled_conflict_id);


--
-- Name: classpilot_supervision_contexts_school_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_contexts_school_status_idx ON public.classpilot_supervision_contexts USING btree (school_id, status);


--
-- Name: classpilot_supervision_contexts_staff_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_contexts_staff_idx ON public.classpilot_supervision_contexts USING btree (school_id, assigned_staff_id);


--
-- Name: classpilot_supervision_students_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_supervision_students_active_unique ON public.classpilot_supervision_students USING btree (school_id, student_id) WHERE (released_at IS NULL);


--
-- Name: classpilot_supervision_students_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_students_context_idx ON public.classpilot_supervision_students USING btree (school_id, context_id);


--
-- Name: classpilot_supervision_students_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_supervision_students_student_idx ON public.classpilot_supervision_students USING btree (school_id, student_id);


--
-- Name: classpilot_teacher_preferences_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_teacher_preferences_owner ON public.classpilot_teacher_preferences USING btree (school_id, teacher_id);


--
-- Name: classpilot_timers_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_timers_activity ON public.classpilot_timers USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classpilot_timers_context_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_timers_context_current ON public.classpilot_timers USING btree (school_id, supervision_context_id) WHERE ((supervision_context_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_timers_session_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classpilot_timers_session_current ON public.classpilot_timers USING btree (school_id, teaching_session_id) WHERE ((teaching_session_id IS NOT NULL) AND (ended_at IS NULL));


--
-- Name: classpilot_tool_history_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classpilot_tool_history_activity ON public.classpilot_tool_history USING btree (school_id, teaching_session_id, supervision_context_id);


--
-- Name: classroom_course_students_school_course_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classroom_course_students_school_course_idx ON public.classroom_course_students USING btree (school_id, course_id);


--
-- Name: classroom_course_students_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classroom_course_students_school_student_idx ON public.classroom_course_students USING btree (school_id, student_id);


--
-- Name: classroom_courses_school_google_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX classroom_courses_school_google_unique ON public.classroom_courses USING btree (school_id, google_course_id);


--
-- Name: classroom_courses_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX classroom_courses_school_id_idx ON public.classroom_courses USING btree (school_id);


--
-- Name: cp_activity_supervision_school_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_activity_supervision_school_id_unique ON public.classpilot_supervision_contexts USING btree (school_id, id);


--
-- Name: cp_chat_lifecycle_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_chat_lifecycle_idx ON public.chat_messages USING btree (school_id, private_chat_thread_id, private_chat_generation);


--
-- Name: cp_classroom_states_context_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_classroom_states_context_active_unique ON public.classpilot_classroom_states USING btree (supervision_context_id, student_id, state_type, state_key) WHERE ((supervision_context_id IS NOT NULL) AND (cleared_at IS NULL));


--
-- Name: cp_evidence_capture_exact_binding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_evidence_capture_exact_binding_idx ON public.classpilot_evidence_capture_requests USING btree (school_id, student_id, student_session_id, device_id, status);


--
-- Name: cp_evidence_capture_pending_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_evidence_capture_pending_expiry_idx ON public.classpilot_evidence_capture_requests USING btree (status, expires_at);


--
-- Name: cp_lesson_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_lesson_school_id ON public.classpilot_lesson_activities USING btree (school_id, id);


--
-- Name: cp_monitoring_digest_daily_recipient_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_monitoring_digest_daily_recipient_unique ON public.classpilot_monitoring_interruption_digests USING btree (school_id, local_date, recipient_user_id);


--
-- Name: cp_monitoring_digest_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_digest_due_idx ON public.classpilot_monitoring_interruption_digests USING btree (status, due_at);


--
-- Name: cp_monitoring_digest_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_digest_retention_idx ON public.classpilot_monitoring_interruption_digests USING btree (retention_expires_at);


--
-- Name: cp_monitoring_events_context_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_events_context_time_idx ON public.classpilot_monitoring_events USING btree (school_id, supervision_context_id, occurred_at DESC NULLS LAST, id);


--
-- Name: cp_monitoring_events_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_events_retention_idx ON public.classpilot_monitoring_events USING btree (retention_expires_at);


--
-- Name: cp_monitoring_events_session_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_events_session_time_idx ON public.classpilot_monitoring_events USING btree (school_id, teaching_session_id, occurred_at DESC NULLS LAST, id);


--
-- Name: cp_monitoring_events_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_monitoring_events_source_unique ON public.classpilot_monitoring_events USING btree (school_id, student_session_id, source_event_id);


--
-- Name: cp_monitoring_events_student_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_events_student_time_idx ON public.classpilot_monitoring_events USING btree (school_id, student_id, occurred_at DESC NULLS LAST);


--
-- Name: cp_monitoring_expectation_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_expectation_retention_idx ON public.classpilot_monitoring_expectations USING btree (retention_expires_at);


--
-- Name: cp_monitoring_expectation_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_monitoring_expectation_student_unique ON public.classpilot_monitoring_expectations USING btree (school_id, student_id);


--
-- Name: cp_monitoring_interruption_open_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_monitoring_interruption_open_unique ON public.classpilot_monitoring_interruptions USING btree (expectation_id) WHERE (ended_at IS NULL);


--
-- Name: cp_monitoring_interruption_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_interruption_retention_idx ON public.classpilot_monitoring_interruptions USING btree (retention_expires_at);


--
-- Name: cp_monitoring_interruption_school_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_monitoring_interruption_school_time_idx ON public.classpilot_monitoring_interruptions USING btree (school_id, detected_at);


--
-- Name: cp_private_chat_assignment_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_private_chat_assignment_unique ON public.classpilot_private_chat_threads USING btree (school_id, student_id, authority_assignment_id);


--
-- Name: cp_private_chat_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_private_chat_context_idx ON public.classpilot_private_chat_threads USING btree (school_id, supervision_context_id, student_id);


--
-- Name: cp_private_chat_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_private_chat_session_idx ON public.classpilot_private_chat_threads USING btree (school_id, teaching_session_id, student_id);


--
-- Name: cp_schedule_change_legs_active_group_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_change_legs_active_group_date_unique ON public.classpilot_schedule_change_legs USING btree (school_id, scheduled_date, group_id) WHERE (reservation_active = true);


--
-- Name: cp_schedule_change_legs_change_group_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_change_legs_change_group_unique ON public.classpilot_schedule_change_legs USING btree (schedule_change_id, group_id);


--
-- Name: cp_schedule_change_legs_change_order_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_change_legs_change_order_unique ON public.classpilot_schedule_change_legs USING btree (schedule_change_id, leg_order);


--
-- Name: cp_schedule_change_legs_school_change_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_change_legs_school_change_idx ON public.classpilot_schedule_change_legs USING btree (school_id, schedule_change_id);


--
-- Name: cp_schedule_change_legs_school_group_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_change_legs_school_group_date_idx ON public.classpilot_schedule_change_legs USING btree (school_id, group_id, scheduled_date);


--
-- Name: cp_schedule_change_pairs_school_groups_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_change_pairs_school_groups_unique ON public.classpilot_schedule_change_pairs USING btree (school_id, first_group_id, second_group_id);


--
-- Name: cp_schedule_change_pairs_school_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_change_pairs_school_id_unique ON public.classpilot_schedule_change_pairs USING btree (school_id, id);


--
-- Name: cp_schedule_change_pairs_school_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_change_pairs_school_status_idx ON public.classpilot_schedule_change_pairs USING btree (school_id, status);


--
-- Name: cp_schedule_changes_school_date_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_changes_school_date_status_idx ON public.classpilot_schedule_changes USING btree (school_id, scheduled_date, status);


--
-- Name: cp_schedule_changes_school_id_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_changes_school_id_date_unique ON public.classpilot_schedule_changes USING btree (school_id, id, scheduled_date);


--
-- Name: cp_schedule_changes_school_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_schedule_changes_school_id_unique ON public.classpilot_schedule_changes USING btree (school_id, id);


--
-- Name: cp_schedule_changes_school_requester_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_changes_school_requester_idx ON public.classpilot_schedule_changes USING btree (school_id, requested_by_user_id);


--
-- Name: cp_schedule_next_boundary_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_schedule_next_boundary_idx ON public.classpilot_school_schedules USING btree (next_boundary_at) WHERE (next_boundary_at IS NOT NULL);


--
-- Name: cp_school_website_delivery_exact_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_school_website_delivery_exact_idx ON public.classpilot_school_website_deliveries USING btree (school_id, policy_revision, student_session_id);


--
-- Name: cp_school_website_delivery_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_school_website_delivery_status_idx ON public.classpilot_school_website_deliveries USING btree (school_id, policy_revision, status);


--
-- Name: cp_session_reports_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_session_reports_due_idx ON public.classpilot_session_reports USING btree (state, next_attempt_at);


--
-- Name: cp_session_reports_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_session_reports_expiry_idx ON public.classpilot_session_reports USING btree (state, expires_at);


--
-- Name: cp_session_reports_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_session_reports_school_session_idx ON public.classpilot_session_reports USING btree (school_id, teaching_session_id);


--
-- Name: cp_session_reports_session_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_session_reports_session_unique ON public.classpilot_session_reports USING btree (teaching_session_id);


--
-- Name: cp_session_staff_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_session_staff_school_session_idx ON public.classpilot_session_staff USING btree (school_id, teaching_session_id);


--
-- Name: cp_session_staff_school_staff_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_session_staff_school_staff_idx ON public.classpilot_session_staff USING btree (school_id, staff_id);


--
-- Name: cp_session_staff_session_staff_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_session_staff_session_staff_unique ON public.classpilot_session_staff USING btree (teaching_session_id, staff_id);


--
-- Name: cp_student_control_states_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_student_control_states_context_idx ON public.classpilot_student_control_states USING btree (school_id, supervision_context_id);


--
-- Name: cp_student_control_states_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_student_control_states_expiry_idx ON public.classpilot_student_control_states USING btree (hard_expires_at);


--
-- Name: cp_student_control_states_school_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_student_control_states_school_student_unique ON public.classpilot_student_control_states USING btree (school_id, student_id);


--
-- Name: cp_student_control_states_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_student_control_states_session_idx ON public.classpilot_student_control_states USING btree (school_id, teaching_session_id);


--
-- Name: cp_student_reports_report_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_student_reports_report_student_unique ON public.classpilot_session_student_reports USING btree (report_id, student_id);


--
-- Name: cp_student_reports_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_student_reports_school_session_idx ON public.classpilot_session_student_reports USING btree (school_id, teaching_session_id);


--
-- Name: cp_student_reports_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_student_reports_school_student_idx ON public.classpilot_session_student_reports USING btree (school_id, student_id);


--
-- Name: cp_summary_delivery_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_summary_delivery_due_idx ON public.classpilot_session_summary_deliveries USING btree (state, next_attempt_at);


--
-- Name: cp_summary_delivery_lease_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_summary_delivery_lease_idx ON public.classpilot_session_summary_deliveries USING btree (state, lease_expires_at);


--
-- Name: cp_summary_delivery_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_summary_delivery_school_session_idx ON public.classpilot_session_summary_deliveries USING btree (school_id, teaching_session_id);


--
-- Name: cp_summary_delivery_session_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_summary_delivery_session_email_unique ON public.classpilot_session_summary_deliveries USING btree (teaching_session_id, lower(btrim(recipient_email)));


--
-- Name: cp_summary_delivery_session_kind_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_summary_delivery_session_kind_unique ON public.classpilot_session_summary_deliveries USING btree (teaching_session_id, recipient_kind);


--
-- Name: cp_supervision_delivery_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_delivery_due_idx ON public.classpilot_supervision_summary_deliveries USING btree (state, next_attempt_at);


--
-- Name: cp_supervision_delivery_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_supervision_delivery_email_unique ON public.classpilot_supervision_summary_deliveries USING btree (school_id, report_id, lower(btrim(recipient_email)));


--
-- Name: cp_supervision_delivery_kind_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_supervision_delivery_kind_unique ON public.classpilot_supervision_summary_deliveries USING btree (school_id, report_id, recipient_kind);


--
-- Name: cp_supervision_delivery_lease_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_delivery_lease_idx ON public.classpilot_supervision_summary_deliveries USING btree (state, lease_expires_at);


--
-- Name: cp_supervision_report_active_context_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_supervision_report_active_context_unique ON public.classpilot_supervision_report_segments USING btree (school_id, context_id) WHERE (state = 'active'::text);


--
-- Name: cp_supervision_report_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_report_context_idx ON public.classpilot_supervision_report_segments USING btree (school_id, context_id);


--
-- Name: cp_supervision_report_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_report_due_idx ON public.classpilot_supervision_report_segments USING btree (state, next_attempt_at);


--
-- Name: cp_supervision_report_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_report_retention_idx ON public.classpilot_supervision_report_segments USING btree (expires_at);


--
-- Name: cp_supervision_report_staff_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_report_staff_idx ON public.classpilot_supervision_report_segments USING btree (school_id, staff_id, window_start);


--
-- Name: cp_supervision_schedule_profile_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_supervision_schedule_profile_unique ON public.classpilot_supervision_contexts USING btree (school_id, schedule_profile_application_id, schedule_profile_date, schedule_profile_block_id) WHERE (schedule_profile_application_id IS NOT NULL);


--
-- Name: cp_supervision_student_report_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_supervision_student_report_student_idx ON public.classpilot_supervision_student_reports USING btree (school_id, student_id);


--
-- Name: cp_supervision_student_report_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_supervision_student_report_unique ON public.classpilot_supervision_student_reports USING btree (school_id, report_id, student_id);


--
-- Name: cp_tool_templates_teacher; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_tool_templates_teacher ON public.classpilot_tool_templates USING btree (school_id, teacher_id);


--
-- Name: cp_tools_history_retention; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_tools_history_retention ON public.classpilot_tool_history USING btree (school_id, created_at);


--
-- Name: cp_usage_rollups_grain_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cp_usage_rollups_grain_unique ON public.classpilot_usage_rollups USING btree (school_id, usage_date, student_id, COALESCE(class_id, ''::text), COALESCE(session_id, ''::text), domain, classification);


--
-- Name: cp_usage_rollups_school_class_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_usage_rollups_school_class_date_idx ON public.classpilot_usage_rollups USING btree (school_id, class_id, usage_date) WHERE (class_id IS NOT NULL);


--
-- Name: cp_usage_rollups_school_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_usage_rollups_school_date_idx ON public.classpilot_usage_rollups USING btree (school_id, usage_date);


--
-- Name: cp_usage_rollups_school_student_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cp_usage_rollups_school_student_date_idx ON public.classpilot_usage_rollups USING btree (school_id, student_id, usage_date);


--
-- Name: custody_alerts_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custody_alerts_school_id_idx ON public.custody_alerts USING btree (school_id);


--
-- Name: custody_alerts_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custody_alerts_student_id_idx ON public.custody_alerts USING btree (student_id);


--
-- Name: daily_usage_school_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_usage_school_date_idx ON public.daily_usage USING btree (school_id, date);


--
-- Name: daily_usage_school_student_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_usage_school_student_date_idx ON public.daily_usage USING btree (school_id, student_id, date);


--
-- Name: daily_usage_student_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX daily_usage_student_date_unique ON public.daily_usage USING btree (student_id, date);


--
-- Name: dashboard_tabs_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_tabs_school_id_idx ON public.dashboard_tabs USING btree (school_id);


--
-- Name: dismissal_changes_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_changes_school_id_idx ON public.dismissal_changes USING btree (school_id);


--
-- Name: dismissal_changes_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_changes_session_id_idx ON public.dismissal_changes USING btree (session_id);


--
-- Name: dismissal_changes_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_changes_student_id_idx ON public.dismissal_changes USING btree (student_id);


--
-- Name: dismissal_overrides_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_overrides_school_id_idx ON public.dismissal_overrides USING btree (school_id);


--
-- Name: dismissal_overrides_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_overrides_session_id_idx ON public.dismissal_overrides USING btree (session_id);


--
-- Name: dismissal_overrides_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_overrides_student_id_idx ON public.dismissal_overrides USING btree (student_id);


--
-- Name: dismissal_queue_pickup_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_queue_pickup_group_idx ON public.dismissal_queue USING btree (session_id, pickup_group_id);


--
-- Name: dismissal_queue_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_queue_school_id_idx ON public.dismissal_queue USING btree (school_id);


--
-- Name: dismissal_queue_session_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_queue_session_status_idx ON public.dismissal_queue USING btree (session_id, status);


--
-- Name: dismissal_queue_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_queue_student_id_idx ON public.dismissal_queue USING btree (student_id);


--
-- Name: dismissal_sessions_school_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dismissal_sessions_school_id_id_unique ON public.dismissal_sessions USING btree (school_id, id);


--
-- Name: dismissal_sessions_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dismissal_sessions_school_id_idx ON public.dismissal_sessions USING btree (school_id);


--
-- Name: email_alerts_school_alerted_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_alerts_school_alerted_idx ON public.email_alerts USING btree (school_id, alerted_at);


--
-- Name: email_alerts_school_review_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_alerts_school_review_idx ON public.email_alerts USING btree (school_id, review_status);


--
-- Name: email_alerts_school_student_message_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX email_alerts_school_student_message_unique ON public.email_alerts USING btree (school_id, student_id, gmail_message_id);


--
-- Name: email_alerts_student_alerted_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_alerts_student_alerted_idx ON public.email_alerts USING btree (student_id, alerted_at);


--
-- Name: email_scan_log_school_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX email_scan_log_school_date_unique ON public.email_scan_log USING btree (school_id, date);


--
-- Name: email_scan_log_school_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_scan_log_school_idx ON public.email_scan_log USING btree (school_id);


--
-- Name: error_logs_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_category_idx ON public.error_logs USING btree (category);


--
-- Name: error_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_created_at_idx ON public.error_logs USING btree (created_at);


--
-- Name: error_logs_request_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_request_id_idx ON public.error_logs USING btree (request_id);


--
-- Name: error_logs_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_school_id_idx ON public.error_logs USING btree (school_id);


--
-- Name: events_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_device_id_idx ON public.events USING btree (device_id);


--
-- Name: events_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_timestamp_idx ON public.events USING btree ("timestamp");


--
-- Name: evidence_artifacts_case_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_case_idx ON public.evidence_artifacts USING btree (case_id);


--
-- Name: evidence_artifacts_exact_authority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_exact_authority_idx ON public.evidence_artifacts USING btree (school_id, device_id, student_id, student_session_id, captured_at);


--
-- Name: evidence_artifacts_exact_binding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_exact_binding_idx ON public.evidence_artifacts USING btree (school_id, student_id, student_session_id, captured_at);


--
-- Name: evidence_artifacts_purge_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_purge_idx ON public.evidence_artifacts USING btree (captured_at) WHERE ((artifact_type = 'screenshot'::text) AND (content IS NOT NULL));


--
-- Name: evidence_artifacts_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_school_student_idx ON public.evidence_artifacts USING btree (school_id, student_id);


--
-- Name: evidence_artifacts_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_artifacts_source_idx ON public.evidence_artifacts USING btree (source_type, source_id);


--
-- Name: family_group_students_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX family_group_students_group_id_idx ON public.family_group_students USING btree (family_group_id);


--
-- Name: family_group_students_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX family_group_students_school_id_idx ON public.family_group_students USING btree (school_id);


--
-- Name: family_group_students_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX family_group_students_student_id_idx ON public.family_group_students USING btree (student_id);


--
-- Name: family_groups_invite_token_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX family_groups_invite_token_unique ON public.family_groups USING btree (invite_token) WHERE (invite_token IS NOT NULL);


--
-- Name: family_groups_school_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX family_groups_school_id_id_unique ON public.family_groups USING btree (school_id, id);


--
-- Name: family_groups_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX family_groups_school_id_idx ON public.family_groups USING btree (school_id);


--
-- Name: flight_paths_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flight_paths_school_id_idx ON public.flight_paths USING btree (school_id);


--
-- Name: flight_paths_school_library_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flight_paths_school_library_idx ON public.flight_paths USING btree (school_id) WHERE ((visibility = 'school'::text) OR official);


--
-- Name: flight_paths_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flight_paths_teacher_id_idx ON public.flight_paths USING btree (teacher_id);


--
-- Name: google_roster_connectors_school_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX google_roster_connectors_school_idx ON public.google_roster_connectors USING btree (school_id);


--
-- Name: google_roster_connectors_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX google_roster_connectors_status_idx ON public.google_roster_connectors USING btree (school_id, status);


--
-- Name: grades_school_classpilot_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grades_school_classpilot_group_idx ON public.grades USING btree (school_id, classpilot_group_id);


--
-- Name: grades_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grades_school_id_idx ON public.grades USING btree (school_id);


--
-- Name: grades_school_migration_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grades_school_migration_state_idx ON public.grades USING btree (school_id, migration_state);


--
-- Name: group_students_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_students_group_id_idx ON public.group_students USING btree (group_id);


--
-- Name: group_students_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_students_student_id_idx ON public.group_students USING btree (student_id);


--
-- Name: group_students_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX group_students_unique ON public.group_students USING btree (group_id, student_id);


--
-- Name: group_teachers_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_teachers_group_id_idx ON public.group_teachers USING btree (group_id);


--
-- Name: group_teachers_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_teachers_teacher_id_idx ON public.group_teachers USING btree (teacher_id);


--
-- Name: groups_school_google_course_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX groups_school_google_course_unique ON public.groups USING btree (school_id, google_classroom_course_id) WHERE (google_classroom_course_id IS NOT NULL);


--
-- Name: groups_school_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX groups_school_id_id_unique ON public.groups USING btree (school_id, id);


--
-- Name: groups_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX groups_school_id_idx ON public.groups USING btree (school_id);


--
-- Name: groups_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX groups_status_idx ON public.groups USING btree (status);


--
-- Name: groups_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX groups_teacher_id_idx ON public.groups USING btree (teacher_id);


--
-- Name: heartbeats_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_device_id_idx ON public.heartbeats USING btree (device_id);


--
-- Name: heartbeats_email_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_email_timestamp_idx ON public.heartbeats USING btree (student_email, "timestamp");


--
-- Name: heartbeats_school_device_student_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_school_device_student_timestamp_idx ON public.heartbeats USING btree (school_id, device_id, student_id, "timestamp" DESC NULLS LAST);


--
-- Name: heartbeats_school_device_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_school_device_timestamp_idx ON public.heartbeats USING btree (school_id, device_id, "timestamp" DESC NULLS LAST);


--
-- Name: heartbeats_school_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_school_email_idx ON public.heartbeats USING btree (school_id, student_email);


--
-- Name: heartbeats_school_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_school_timestamp_idx ON public.heartbeats USING btree (school_id, "timestamp" DESC);


--
-- Name: heartbeats_student_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_student_email_idx ON public.heartbeats USING btree (student_email);


--
-- Name: heartbeats_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_student_id_idx ON public.heartbeats USING btree (student_id);


--
-- Name: heartbeats_student_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_student_timestamp_idx ON public.heartbeats USING btree (student_id, "timestamp");


--
-- Name: heartbeats_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeats_timestamp_idx ON public.heartbeats USING btree ("timestamp");


--
-- Name: homeroom_teachers_homeroom_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homeroom_teachers_homeroom_id_idx ON public.homeroom_teachers USING btree (homeroom_id);


--
-- Name: homeroom_teachers_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homeroom_teachers_school_id_idx ON public.homeroom_teachers USING btree (school_id);


--
-- Name: homeroom_teachers_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homeroom_teachers_teacher_id_idx ON public.homeroom_teachers USING btree (teacher_id);


--
-- Name: homerooms_school_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX homerooms_school_id_id_unique ON public.homerooms USING btree (school_id, id);


--
-- Name: homerooms_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homerooms_school_id_idx ON public.homerooms USING btree (school_id);


--
-- Name: homerooms_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homerooms_teacher_id_idx ON public.homerooms USING btree (teacher_id);


--
-- Name: import_processing_stages_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX import_processing_stages_identity ON public.import_processing_stages USING btree (school_id, author_id, kind, import_id, stage_key, generation);


--
-- Name: import_processing_stages_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_processing_stages_provider ON public.import_processing_stages USING btree (provider, lease_until);


--
-- Name: import_processing_stages_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_processing_stages_run ON public.import_processing_stages USING btree (school_id, author_id, kind, import_id, status);


--
-- Name: import_runs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_runs_created_at_idx ON public.import_runs USING btree (created_at);


--
-- Name: import_runs_school_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_runs_school_created_idx ON public.import_runs USING btree (school_id, created_at);


--
-- Name: mailpilot_watches_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mailpilot_watches_email_unique ON public.mailpilot_watches USING btree (student_email);


--
-- Name: mailpilot_watches_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mailpilot_watches_expires_idx ON public.mailpilot_watches USING btree (expires_at);


--
-- Name: mailpilot_watches_school_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mailpilot_watches_school_idx ON public.mailpilot_watches USING btree (school_id);


--
-- Name: messages_command_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX messages_command_student_unique ON public.messages USING btree (command_id, to_student_id) WHERE ((command_id IS NOT NULL) AND (to_student_id IS NOT NULL));


--
-- Name: messages_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_school_id_idx ON public.messages USING btree (school_id);


--
-- Name: mydesk_attachments_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_attachments_cleanup ON public.mydesk_attachments USING btree (next_cleanup_at, id) WHERE (status = ANY (ARRAY['delete_pending'::text, 'deleted'::text]));


--
-- Name: mydesk_attachments_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_attachments_note ON public.mydesk_attachments USING btree (school_id, author_id, note_id, created_at, id);


--
-- Name: mydesk_attachments_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_attachments_request ON public.mydesk_attachments USING btree (school_id, author_id, note_id, client_request_id);


--
-- Name: mydesk_attachments_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_attachments_school_id ON public.mydesk_attachments USING btree (school_id, id);


--
-- Name: mydesk_attachments_staged_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_attachments_staged_expiry ON public.mydesk_attachments USING btree (created_at, id) WHERE ((committed_at IS NULL) AND (status = ANY (ARRAY['pending'::text, 'uploading'::text, 'ready'::text])));


--
-- Name: mydesk_attachments_storage_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_attachments_storage_key ON public.mydesk_attachments USING btree (storage_key);


--
-- Name: mydesk_attachments_upload_lease; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_attachments_upload_lease ON public.mydesk_attachments USING btree (upload_lease_until, id) WHERE (status = 'uploading'::text);


--
-- Name: mydesk_import_assets_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_import_assets_cleanup ON public.mydesk_import_assets USING btree (status, next_cleanup_at);


--
-- Name: mydesk_import_assets_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_import_assets_key ON public.mydesk_import_assets USING btree (storage_key);


--
-- Name: mydesk_import_assets_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_import_assets_request ON public.mydesk_import_assets USING btree (school_id, author_id, import_id, client_request_id);


--
-- Name: mydesk_import_assets_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_import_assets_run ON public.mydesk_import_assets USING btree (school_id, author_id, import_id);


--
-- Name: mydesk_import_items_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_import_items_request ON public.mydesk_import_items USING btree (school_id, author_id, import_id, client_request_id);


--
-- Name: mydesk_import_items_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_import_items_run ON public.mydesk_import_items USING btree (school_id, author_id, import_id, ordinal);


--
-- Name: mydesk_imports_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_imports_owner ON public.mydesk_imports USING btree (school_id, author_id, created_at);


--
-- Name: mydesk_imports_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_imports_queue ON public.mydesk_imports USING btree (status, next_attempt_at, lease_until);


--
-- Name: mydesk_imports_quota; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_imports_quota ON public.mydesk_imports USING btree (school_id, quota_date);


--
-- Name: mydesk_imports_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_imports_request ON public.mydesk_imports USING btree (school_id, author_id, client_request_id);


--
-- Name: mydesk_notes_class_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_notes_class_page ON public.mydesk_notes USING btree (school_id, author_id, filing_group_id, entry_date DESC NULLS LAST, id) WHERE (status = 'active'::text);


--
-- Name: mydesk_notes_grade_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_notes_grade_page ON public.mydesk_notes USING btree (school_id, author_id, filing_grade_level, entry_date DESC NULLS LAST, id) WHERE (status = 'active'::text);


--
-- Name: mydesk_notes_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_notes_page ON public.mydesk_notes USING btree (school_id, author_id, pinned, entry_date DESC NULLS LAST, created_at DESC NULLS LAST, id) WHERE (status = 'active'::text);


--
-- Name: mydesk_notes_pending_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_notes_pending_expiry ON public.mydesk_notes USING btree (expires_at, id) WHERE (status = 'pending'::text);


--
-- Name: mydesk_notes_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_notes_request ON public.mydesk_notes USING btree (school_id, author_id, client_request_id);


--
-- Name: mydesk_notes_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_notes_school_id ON public.mydesk_notes USING btree (school_id, id);


--
-- Name: mydesk_notes_student_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_notes_student_page ON public.mydesk_notes USING btree (school_id, author_id, filing_student_id, entry_date DESC NULLS LAST, id) WHERE (status = 'active'::text);


--
-- Name: mydesk_preferences_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_preferences_owner ON public.mydesk_preferences USING btree (school_id, author_id);


--
-- Name: mydesk_seating_charts_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_seating_charts_current ON public.mydesk_seating_charts USING btree (school_id, author_id, filing_group_id) WHERE (is_current AND (deleted_at IS NULL));


--
-- Name: mydesk_seating_charts_owner_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mydesk_seating_charts_owner_class ON public.mydesk_seating_charts USING btree (school_id, author_id, filing_group_id, updated_at DESC NULLS LAST, id) WHERE (deleted_at IS NULL);


--
-- Name: mydesk_seating_charts_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mydesk_seating_charts_request ON public.mydesk_seating_charts USING btree (school_id, author_id, client_request_id);


--
-- Name: parent_student_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parent_student_parent_id_idx ON public.parent_student USING btree (parent_id);


--
-- Name: parent_student_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parent_student_school_id_idx ON public.parent_student USING btree (school_id);


--
-- Name: parent_student_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parent_student_student_id_idx ON public.parent_student USING btree (student_id);


--
-- Name: passes_issued_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_issued_at_idx ON public.passes USING btree (issued_at);


--
-- Name: passes_kiosk_teacher_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_kiosk_teacher_active_idx ON public.passes USING btree (school_id, teacher_id) WHERE ((status = 'active'::text) AND (issued_via = 'kiosk'::text));


--
-- Name: passes_one_active_per_student; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX passes_one_active_per_student ON public.passes USING btree (student_id, school_id) WHERE (status = 'active'::text);


--
-- Name: passes_school_classpilot_group_issued_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_school_classpilot_group_issued_idx ON public.passes USING btree (school_id, classpilot_group_id, issued_at);


--
-- Name: passes_school_classpilot_group_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_school_classpilot_group_status_idx ON public.passes USING btree (school_id, classpilot_group_id, status);


--
-- Name: passes_school_destination_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_school_destination_active_idx ON public.passes USING btree (school_id, destination) WHERE (status = 'active'::text);


--
-- Name: passes_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_school_id_idx ON public.passes USING btree (school_id);


--
-- Name: passes_school_student_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX passes_school_student_id_unique ON public.passes USING btree (school_id, student_id, id);


--
-- Name: passes_school_student_issued_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_school_student_issued_idx ON public.passes USING btree (school_id, student_id, issued_at);


--
-- Name: passes_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_status_idx ON public.passes USING btree (status);


--
-- Name: passes_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_student_id_idx ON public.passes USING btree (student_id);


--
-- Name: passes_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passes_teacher_id_idx ON public.passes USING btree (teacher_id);


--
-- Name: passpilot_grade_students_school_grade_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passpilot_grade_students_school_grade_idx ON public.passpilot_grade_students USING btree (school_id, grade_id);


--
-- Name: passpilot_grade_students_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passpilot_grade_students_school_student_idx ON public.passpilot_grade_students USING btree (school_id, student_id);


--
-- Name: poll_responses_poll_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poll_responses_poll_id_idx ON public.poll_responses USING btree (poll_id);


--
-- Name: poll_responses_poll_student_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poll_responses_poll_student_active_unique ON public.poll_responses USING btree (poll_id, student_id) WHERE (superseded_at IS NULL);


--
-- Name: poll_responses_school_poll_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poll_responses_school_poll_idx ON public.poll_responses USING btree (school_id, poll_id);


--
-- Name: poll_responses_school_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poll_responses_school_student_idx ON public.poll_responses USING btree (school_id, student_id);


--
-- Name: polls_active_context_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX polls_active_context_unique ON public.polls USING btree (school_id, supervision_context_id) WHERE ((supervision_context_id IS NOT NULL) AND (is_active = true));


--
-- Name: polls_active_session_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX polls_active_session_unique ON public.polls USING btree (school_id, session_id) WHERE (is_active = true);


--
-- Name: polls_close_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX polls_close_command_unique ON public.polls USING btree (close_command_id) WHERE (close_command_id IS NOT NULL);


--
-- Name: polls_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polls_school_session_idx ON public.polls USING btree (school_id, session_id);


--
-- Name: polls_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polls_session_id_idx ON public.polls USING btree (session_id);


--
-- Name: polls_start_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX polls_start_command_unique ON public.polls USING btree (start_command_id) WHERE (start_command_id IS NOT NULL);


--
-- Name: polls_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polls_supervision_idx ON public.polls USING btree (school_id, supervision_context_id);


--
-- Name: pp_appointments_pending_end_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_appointments_pending_end_idx ON public.passpilot_appointments USING btree (ends_at) WHERE (status = 'scheduled'::text);


--
-- Name: pp_appointments_retention_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_appointments_retention_idx ON public.passpilot_appointments USING btree (retained_until);


--
-- Name: pp_appointments_school_student_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_appointments_school_student_window_idx ON public.passpilot_appointments USING btree (school_id, student_id, starts_at, id);


--
-- Name: pp_appointments_school_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_appointments_school_window_idx ON public.passpilot_appointments USING btree (school_id, starts_at, id);


--
-- Name: pp_encounter_restrictions_school_student_b_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_encounter_restrictions_school_student_b_idx ON public.passpilot_encounter_restrictions USING btree (school_id, student_b_id);


--
-- Name: pp_kiosk_devices_school_last_used_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_kiosk_devices_school_last_used_idx ON public.passpilot_kiosk_devices USING btree (school_id, last_used_at);


--
-- Name: pp_kiosk_sessions_school_claim_code_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pp_kiosk_sessions_school_claim_code_unique ON public.passpilot_kiosk_sessions USING btree (school_id, claim_code) WHERE (status <> 'released'::text);


--
-- Name: pp_kiosk_sessions_school_device_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_kiosk_sessions_school_device_idx ON public.passpilot_kiosk_sessions USING btree (school_id, device_id) WHERE (device_id IS NOT NULL);


--
-- Name: pp_kiosk_sessions_school_status_last_seen_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_kiosk_sessions_school_status_last_seen_idx ON public.passpilot_kiosk_sessions USING btree (school_id, status, last_seen_at);


--
-- Name: pp_kiosk_sessions_school_teacher_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_kiosk_sessions_school_teacher_status_idx ON public.passpilot_kiosk_sessions USING btree (school_id, teacher_id, status);


--
-- Name: pp_pass_denials_school_denied_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_pass_denials_school_denied_idx ON public.passpilot_pass_denials USING btree (school_id, denied_at);


--
-- Name: pp_pass_denials_school_student_denied_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pp_pass_denials_school_student_denied_idx ON public.passpilot_pass_denials USING btree (school_id, student_id, denied_at);


--
-- Name: pp_pass_limits_school_default_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pp_pass_limits_school_default_unique ON public.passpilot_pass_limits USING btree (school_id) WHERE (student_id IS NULL);


--
-- Name: pp_pass_limits_school_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pp_pass_limits_school_student_unique ON public.passpilot_pass_limits USING btree (school_id, student_id) WHERE (student_id IS NOT NULL);


--
-- Name: product_licenses_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_licenses_school_id_idx ON public.product_licenses USING btree (school_id);


--
-- Name: roster_connections_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roster_connections_due_idx ON public.roster_integration_connections USING btree (status, automatic_sync);


--
-- Name: roster_connections_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roster_connections_source_unique ON public.roster_integration_connections USING btree (school_id, provider, provider_identity);


--
-- Name: roster_identities_external_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roster_identities_external_unique ON public.roster_integration_identities USING btree (school_id, connection_id, entity_type, external_id);


--
-- Name: roster_identities_internal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roster_identities_internal_idx ON public.roster_integration_identities USING btree (school_id, entity_type, internal_id);


--
-- Name: roster_identities_internal_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roster_identities_internal_unique ON public.roster_integration_identities USING btree (school_id, connection_id, entity_type, internal_id);


--
-- Name: roster_memberships_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roster_memberships_source_unique ON public.roster_integration_memberships USING btree (school_id, connection_id, group_id, member_type, member_id);


--
-- Name: roster_memberships_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roster_memberships_target_idx ON public.roster_integration_memberships USING btree (school_id, group_id, member_type, member_id);


--
-- Name: roster_runs_connection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roster_runs_connection_idx ON public.roster_integration_runs USING btree (school_id, connection_id, created_at);


--
-- Name: roster_runs_one_applying; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roster_runs_one_applying ON public.roster_integration_runs USING btree (school_id, connection_id) WHERE (status = ANY (ARRAY['fetching'::text, 'applying'::text]));


--
-- Name: roster_runs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roster_runs_status_idx ON public.roster_integration_runs USING btree (status, updated_at);


--
-- Name: safety_active_url_exception_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX safety_active_url_exception_idx ON public.safety_url_exceptions USING btree (school_id, fingerprint) WHERE (revoked_at IS NULL);


--
-- Name: safety_alert_mailpilot_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safety_alert_mailpilot_source_idx ON public.student_safety_alerts USING btree (school_id, student_id, source_id) WHERE (source_type = 'mailpilot'::text);


--
-- Name: safety_alert_review_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safety_alert_review_idx ON public.student_safety_alerts USING btree (school_id, reviewed_at, last_seen_at, id);


--
-- Name: safety_case_events_case_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safety_case_events_case_idx ON public.student_safety_case_events USING btree (school_id, case_id, created_at, id);


--
-- Name: safety_notification_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safety_notification_due_idx ON public.safety_notification_outbox USING btree (status, due_at);


--
-- Name: safety_one_open_case_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX safety_one_open_case_idx ON public.student_safety_cases USING btree (school_id, student_id) WHERE (status = 'open'::text);


--
-- Name: school_discipline_attachments_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_attachments_cleanup ON public.school_discipline_attachments USING btree (status, next_cleanup_at);


--
-- Name: school_discipline_attachments_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_attachments_version ON public.school_discipline_attachments USING btree (school_id, version_id);


--
-- Name: school_discipline_records_owner_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_records_owner_page ON public.school_discipline_records USING btree (school_id, submitted_by, created_at DESC NULLS LAST, id);


--
-- Name: school_discipline_records_school_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_records_school_page ON public.school_discipline_records USING btree (school_id, created_at DESC NULLS LAST, id);


--
-- Name: school_discipline_records_source_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_records_source_note ON public.school_discipline_records USING btree (school_id, source_note_id) WHERE (source_note_id IS NOT NULL);


--
-- Name: school_discipline_versions_published_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX school_discipline_versions_published_number ON public.school_discipline_versions USING btree (school_id, record_id, number) WHERE (state = 'published'::text);


--
-- Name: school_discipline_versions_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_versions_record ON public.school_discipline_versions USING btree (school_id, record_id, number);


--
-- Name: school_discipline_versions_student_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_discipline_versions_student_date ON public.school_discipline_versions USING btree (school_id, ((snapshot ->> 'studentId'::text)), ((snapshot ->> 'entryDate'::text)), record_id) WHERE (state = 'published'::text);


--
-- Name: school_inquiries_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_inquiries_email_idx ON public.school_inquiries USING btree (contact_email);


--
-- Name: school_inquiries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_inquiries_status_idx ON public.school_inquiries USING btree (status);


--
-- Name: school_memberships_car_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX school_memberships_car_number_unique ON public.school_memberships USING btree (school_id, car_number) WHERE (car_number IS NOT NULL);


--
-- Name: school_memberships_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_memberships_school_id_idx ON public.school_memberships USING btree (school_id);


--
-- Name: school_memberships_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX school_memberships_user_id_idx ON public.school_memberships USING btree (user_id);


--
-- Name: schools_domain_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX schools_domain_idx ON public.schools USING btree (domain);


--
-- Name: security_events_detected_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_events_detected_at_idx ON public.security_events USING btree (detected_at);


--
-- Name: security_events_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_events_event_type_idx ON public.security_events USING btree (event_type);


--
-- Name: security_events_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_events_school_id_idx ON public.security_events USING btree (school_id);


--
-- Name: security_events_severity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_events_severity_idx ON public.security_events USING btree (severity);


--
-- Name: security_events_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_events_status_idx ON public.security_events USING btree (status);


--
-- Name: session_expire_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_expire_idx ON public.session USING btree (expire);


--
-- Name: session_settings_context_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_settings_context_unique ON public.session_settings USING btree (school_id, supervision_context_id) WHERE (supervision_context_id IS NOT NULL);


--
-- Name: session_settings_school_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_settings_school_session_idx ON public.session_settings USING btree (school_id, session_id);


--
-- Name: session_settings_supervision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_settings_supervision_idx ON public.session_settings USING btree (school_id, supervision_context_id);


--
-- Name: student_attendance_school_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_attendance_school_date_idx ON public.student_attendance USING btree (school_id, date);


--
-- Name: student_attendance_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_attendance_school_id_idx ON public.student_attendance USING btree (school_id);


--
-- Name: student_attendance_student_date_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_attendance_student_date_unique ON public.student_attendance USING btree (student_id, date);


--
-- Name: student_attendance_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_attendance_student_id_idx ON public.student_attendance USING btree (student_id);


--
-- Name: student_contact_profiles_student; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_contact_profiles_student ON public.student_contact_profiles USING btree (school_id, filing_student_id);


--
-- Name: student_contact_versions_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_contact_versions_request ON public.student_contact_profile_versions USING btree (school_id, author_id, request_id);


--
-- Name: student_contact_versions_revision; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_contact_versions_revision ON public.student_contact_profile_versions USING btree (school_id, profile_id, revision);


--
-- Name: student_devices_device_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_devices_device_student_idx ON public.student_devices USING btree (device_id, student_id);


--
-- Name: student_groups_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_groups_school_id_idx ON public.student_groups USING btree (school_id);


--
-- Name: student_information_assets_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_information_assets_cleanup ON public.student_information_import_assets USING btree (status, next_cleanup_at);


--
-- Name: student_information_assets_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_information_assets_key ON public.student_information_import_assets USING btree (storage_key);


--
-- Name: student_information_assets_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_information_assets_request ON public.student_information_import_assets USING btree (school_id, author_id, import_id, client_request_id);


--
-- Name: student_information_imports_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_information_imports_queue ON public.student_information_imports USING btree (status, next_attempt_at);


--
-- Name: student_information_imports_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_information_imports_request ON public.student_information_imports USING btree (school_id, author_id, client_request_id);


--
-- Name: student_information_items_import; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_information_items_import ON public.student_information_import_items USING btree (school_id, author_id, import_id, ordinal);


--
-- Name: student_safety_cases_opened_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_safety_cases_opened_idx ON public.student_safety_cases USING btree (opened_at);


--
-- Name: student_safety_cases_school_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_safety_cases_school_status_idx ON public.student_safety_cases USING btree (school_id, status);


--
-- Name: student_safety_cases_student_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_safety_cases_student_idx ON public.student_safety_cases USING btree (student_id);


--
-- Name: student_sessions_active_device_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_sessions_active_device_unique ON public.student_sessions USING btree (device_id) WHERE (is_active = true);


--
-- Name: student_sessions_active_student_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_sessions_active_student_unique ON public.student_sessions USING btree (student_id) WHERE (is_active = true);


--
-- Name: student_sessions_last_seen_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_sessions_last_seen_active_idx ON public.student_sessions USING btree (last_seen_at, is_active);


--
-- Name: student_sessions_manual_lease_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_sessions_manual_lease_expiry_idx ON public.student_sessions USING btree (manual_lease_expires_at) WHERE ((auth_kind = 'manual_shared'::text) AND (is_active = true) AND (ended_at IS NULL));


--
-- Name: student_sessions_recovery_token_hash_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_sessions_recovery_token_hash_unique ON public.student_sessions USING btree (session_recovery_token_hash) WHERE (session_recovery_token_hash IS NOT NULL);


--
-- Name: student_sessions_student_device_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_sessions_student_device_active_idx ON public.student_sessions USING btree (student_id, device_id, is_active);


--
-- Name: student_timeline_events_case_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_timeline_events_case_idx ON public.student_timeline_events USING btree (case_id);


--
-- Name: student_timeline_events_school_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_timeline_events_school_occurred_idx ON public.student_timeline_events USING btree (school_id, occurred_at);


--
-- Name: student_timeline_events_student_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_timeline_events_student_occurred_idx ON public.student_timeline_events USING btree (student_id, occurred_at);


--
-- Name: student_timeline_events_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_timeline_events_type_idx ON public.student_timeline_events USING btree (event_type);


--
-- Name: students_grade_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_grade_id_idx ON public.students USING btree (grade_id);


--
-- Name: students_homeroom_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_homeroom_id_idx ON public.students USING btree (homeroom_id);


--
-- Name: students_last_first_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_last_first_idx ON public.students USING btree (last_name, first_name);


--
-- Name: students_school_code_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX students_school_code_unique ON public.students USING btree (school_id, student_code) WHERE (student_code IS NOT NULL);


--
-- Name: students_school_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_school_email_idx ON public.students USING btree (school_id, email_lc);


--
-- Name: students_school_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX students_school_email_unique ON public.students USING btree (school_id, email_lc) WHERE (email_lc IS NOT NULL);


--
-- Name: students_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_school_id_idx ON public.students USING btree (school_id);


--
-- Name: students_school_id_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX students_school_id_number_unique ON public.students USING btree (school_id, student_id_number) WHERE (student_id_number IS NOT NULL);


--
-- Name: subgroups_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subgroups_school_id_idx ON public.subgroups USING btree (school_id);


--
-- Name: teacher_students_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teacher_students_school_id_idx ON public.teacher_students USING btree (school_id);


--
-- Name: teaching_sessions_control_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_control_updated_at_idx ON public.teaching_sessions USING btree (control_updated_at);


--
-- Name: teaching_sessions_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_group_id_idx ON public.teaching_sessions USING btree (group_id);


--
-- Name: teaching_sessions_scheduled_conflict_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_scheduled_conflict_idx ON public.teaching_sessions USING btree (scheduled_conflict_id);


--
-- Name: teaching_sessions_scheduled_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_scheduled_due_idx ON public.teaching_sessions USING btree (scheduled_state, scheduled_end_at);


--
-- Name: teaching_sessions_scheduled_occurrence_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX teaching_sessions_scheduled_occurrence_unique ON public.teaching_sessions USING btree (school_id, group_id, scheduled_date) WHERE (scheduled_date IS NOT NULL);


--
-- Name: teaching_sessions_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_school_id_idx ON public.teaching_sessions USING btree (school_id);


--
-- Name: teaching_sessions_session_mode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_session_mode_idx ON public.teaching_sessions USING btree (session_mode);


--
-- Name: teaching_sessions_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teaching_sessions_teacher_id_idx ON public.teaching_sessions USING btree (teacher_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_normalized_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_normalized_unique ON public.users USING btree (lower(btrim(email)));


--
-- Name: users_google_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_google_id_idx ON public.users USING btree (google_id);


--
-- Name: walker_zones_school_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX walker_zones_school_id_idx ON public.walker_zones USING btree (school_id);


--
-- Name: groups classpilot_admin_class_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_admin_class_staff_integrity AFTER INSERT OR UPDATE OF teacher_id, school_id, group_type, status ON public.groups DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_admin_class_staff_integrity();


--
-- Name: poll_responses classpilot_bind_poll_response_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_bind_poll_response_school BEFORE INSERT OR UPDATE OF school_id, poll_id, student_id, device_id ON public.poll_responses FOR EACH ROW EXECUTE FUNCTION public.classpilot_bind_poll_response_school();


--
-- Name: polls classpilot_bind_poll_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_bind_poll_school BEFORE INSERT OR UPDATE ON public.polls FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('session_id');


--
-- Name: session_settings classpilot_bind_session_setting_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_bind_session_setting_school BEFORE INSERT OR UPDATE ON public.session_settings FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('session_id');


--
-- Name: block_lists classpilot_block_list_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_block_list_staff_integrity AFTER INSERT OR UPDATE OF school_id, teacher_id ON public.block_lists DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('block_list');


--
-- Name: classpilot_coverage_assignments classpilot_coverage_assignment_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_coverage_assignment_staff_integrity AFTER INSERT OR UPDATE OF school_id, staff_id, active ON public.classpilot_coverage_assignments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('coverage_assignment');


--
-- Name: flight_paths classpilot_flight_path_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_flight_path_staff_integrity AFTER INSERT OR UPDATE OF school_id, teacher_id ON public.flight_paths DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('flight_path');


--
-- Name: groups classpilot_group_live_dependency_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_group_live_dependency_integrity AFTER DELETE OR UPDATE OF school_id ON public.groups DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: group_teachers classpilot_group_teacher_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_group_teacher_staff_integrity AFTER INSERT OR DELETE OR UPDATE ON public.group_teachers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_group_teacher_staff_integrity();


--
-- Name: classpilot_session_reports classpilot_report_authorization_marker; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_report_authorization_marker BEFORE INSERT ON public.classpilot_session_reports FOR EACH ROW EXECUTE FUNCTION public.classpilot_set_report_authorization_marker();


--
-- Name: classpilot_schedule_change_legs classpilot_schedule_change_leg_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_schedule_change_leg_staff_integrity AFTER INSERT OR UPDATE OF school_id, schedule_change_id, group_id, primary_teacher_id_snapshot, reservation_active ON public.classpilot_schedule_change_legs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('active_schedule_change');


--
-- Name: classpilot_schedule_changes classpilot_schedule_change_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_schedule_change_staff_integrity AFTER INSERT OR UPDATE OF school_id, status, reservation_active ON public.classpilot_schedule_changes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: classpilot_scheduled_conflicts classpilot_scheduled_conflict_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_scheduled_conflict_staff_integrity AFTER INSERT OR UPDATE OF school_id, group_id, teacher_id, status ON public.classpilot_scheduled_conflicts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('active_scheduled_conflict');


--
-- Name: classpilot_session_staff classpilot_session_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_session_staff_integrity AFTER INSERT OR UPDATE OF school_id, teaching_session_id, staff_id ON public.classpilot_session_staff DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('active_session_staff');


--
-- Name: school_memberships classpilot_staff_assignment_membership_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_staff_assignment_membership_delete AFTER DELETE ON public.school_memberships DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_departing_staff_assignments();


--
-- Name: school_memberships classpilot_staff_assignment_membership_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_staff_assignment_membership_update AFTER UPDATE OF user_id, school_id, role, gopilot_role, status ON public.school_memberships DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_departing_staff_assignments();


--
-- Name: students classpilot_student_dependency_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_student_dependency_integrity AFTER INSERT OR UPDATE OF school_id, status ON public.students DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: student_groups classpilot_student_group_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_student_group_staff_integrity AFTER INSERT OR UPDATE OF school_id, teacher_id ON public.student_groups DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('student_group');


--
-- Name: classpilot_supervision_contexts classpilot_supervision_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_supervision_staff_integrity AFTER INSERT OR UPDATE OF school_id, assigned_staff_id, status, ended_at ON public.classpilot_supervision_contexts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('active_supervision_context');


--
-- Name: classpilot_teacher_preferences classpilot_teacher_preferences_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_teacher_preferences_school BEFORE INSERT OR UPDATE OF school_id, teacher_id ON public.classpilot_teacher_preferences FOR EACH ROW EXECUTE FUNCTION public.check_classpilot_teacher_preferences_school();


--
-- Name: teacher_students classpilot_teacher_student_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_teacher_student_staff_integrity AFTER INSERT OR UPDATE OF teacher_id, student_id, school_id ON public.teacher_students DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('teacher_student_assignment');


--
-- Name: teaching_sessions classpilot_teaching_session_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER classpilot_teaching_session_staff_integrity AFTER INSERT OR UPDATE OF school_id, group_id, teacher_id, end_time ON public.teaching_sessions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: classpilot_active_hands classpilot_validate_active_hand_parents; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_validate_active_hand_parents BEFORE INSERT OR UPDATE ON public.classpilot_active_hands FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_chat_deliveries classpilot_validate_chat_delivery_parents; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_validate_chat_delivery_parents BEFORE INSERT OR UPDATE ON public.classpilot_chat_deliveries FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: messages classpilot_validate_command_message_parents; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classpilot_validate_command_message_parents BEFORE INSERT OR UPDATE OF school_id, command_id, to_student_id, teaching_session_id, supervision_context_id ON public.messages FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_command_message_parents();


--
-- Name: chat_messages cp_activity_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_activity_parent BEFORE INSERT OR UPDATE ON public.chat_messages FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('session_id');


--
-- Name: classpilot_classroom_states cp_activity_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_activity_parent BEFORE INSERT OR UPDATE ON public.classpilot_classroom_states FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_supervision_contexts cp_context_classroom_authority_revision; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_context_classroom_authority_revision BEFORE UPDATE OF assigned_staff_id, classroom_authority_revision ON public.classpilot_supervision_contexts FOR EACH ROW EXECUTE FUNCTION public.classpilot_preserve_classroom_authority_revision();


--
-- Name: group_teachers cp_group_teachers_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_group_teachers_boundary_wake AFTER INSERT OR DELETE OR UPDATE ON public.group_teachers FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: groups cp_groups_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_groups_boundary_wake AFTER INSERT OR DELETE OR UPDATE ON public.groups FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: classpilot_active_hands cp_help_snapshot_revision; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_help_snapshot_revision AFTER INSERT OR UPDATE ON public.classpilot_active_hands FOR EACH ROW EXECUTE FUNCTION public.classpilot_bump_help_snapshot();


--
-- Name: classpilot_lesson_progress cp_lesson_progress_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_lesson_progress_parent BEFORE INSERT OR UPDATE ON public.classpilot_lesson_progress FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_lesson_progress();


--
-- Name: product_licenses cp_license_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_license_boundary_wake AFTER INSERT OR DELETE OR UPDATE ON public.product_licenses FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: classpilot_monitoring_expectations cp_monitoring_interruption_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_monitoring_interruption_binding BEFORE INSERT OR UPDATE OF school_id, student_id, student_session_id, device_id, scope_type, scope_id ON public.classpilot_monitoring_expectations FOR EACH ROW EXECUTE FUNCTION public.validate_classpilot_monitoring_interruption_binding();


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_monitoring_interruption_binding BEFORE INSERT OR UPDATE OF school_id, student_id, student_session_id, device_id, scope_type, scope_id ON public.classpilot_monitoring_interruptions FOR EACH ROW EXECUTE FUNCTION public.validate_classpilot_monitoring_interruption_binding();


--
-- Name: chat_messages cp_private_chat_message_lifecycle; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_private_chat_message_lifecycle BEFORE INSERT OR UPDATE ON public.chat_messages FOR EACH ROW EXECUTE FUNCTION public.cp_private_chat_message_lifecycle();


--
-- Name: session_settings cp_private_chat_settings_epoch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_private_chat_settings_epoch BEFORE UPDATE ON public.session_settings FOR EACH ROW EXECUTE FUNCTION public.cp_private_chat_settings_epoch();


--
-- Name: settings cp_private_chat_settings_epoch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_private_chat_settings_epoch BEFORE UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.cp_private_chat_settings_epoch();


--
-- Name: classpilot_private_chat_threads cp_private_chat_thread_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_private_chat_thread_parent BEFORE INSERT OR UPDATE ON public.classpilot_private_chat_threads FOR EACH ROW EXECUTE FUNCTION public.cp_private_chat_thread_parent();


--
-- Name: classpilot_schedule_changes cp_schedule_change_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_schedule_change_boundary_wake AFTER INSERT OR DELETE OR UPDATE ON public.classpilot_schedule_changes FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: classpilot_schedule_change_legs cp_schedule_change_legs_exactly_two; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER cp_schedule_change_legs_exactly_two AFTER INSERT OR DELETE OR UPDATE ON public.classpilot_schedule_change_legs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_schedule_change_leg_count();


--
-- Name: classpilot_schedule_change_legs cp_schedule_change_legs_immutable_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_schedule_change_legs_immutable_snapshot BEFORE UPDATE ON public.classpilot_schedule_change_legs FOR EACH ROW EXECUTE FUNCTION public.classpilot_protect_schedule_change_leg_snapshot();


--
-- Name: classpilot_schedule_changes cp_schedule_changes_exactly_two_legs; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER cp_schedule_changes_exactly_two_legs AFTER INSERT OR UPDATE ON public.classpilot_schedule_changes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_schedule_change_leg_count();


--
-- Name: classpilot_school_schedules cp_schedule_document_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_schedule_document_boundary_wake AFTER UPDATE OF config, profile_activation_outcomes ON public.classpilot_school_schedules FOR EACH ROW WHEN (((old.config IS DISTINCT FROM new.config) OR (old.profile_activation_outcomes IS DISTINCT FROM new.profile_activation_outcomes))) EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: schools cp_school_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_school_boundary_wake AFTER UPDATE OF school_timezone, status, is_active, active_until, disabled_at, deleted_at, plan_status ON public.schools FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: teaching_sessions cp_session_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_session_boundary_wake AFTER INSERT OR UPDATE OF end_time, scheduled_start_at, scheduled_end_at, session_mode, scheduled_state ON public.teaching_sessions FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: settings cp_settings_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_settings_boundary_wake AFTER INSERT OR UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: classpilot_supervision_contexts cp_supervision_boundary_wake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_supervision_boundary_wake AFTER INSERT OR DELETE OR UPDATE ON public.classpilot_supervision_contexts FOR EACH ROW EXECUTE FUNCTION public.cp_wake_schedule_boundary();


--
-- Name: classpilot_supervision_student_reports cp_supervision_report_student_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_supervision_report_student_binding BEFORE INSERT OR UPDATE OF school_id, student_id ON public.classpilot_supervision_student_reports FOR EACH ROW EXECUTE FUNCTION public.cp_supervision_report_student_binding();


--
-- Name: classpilot_lesson_activities cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_lesson_activities FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_lesson_progress cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_lesson_progress FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_picker_rounds cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_picker_rounds FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_questions cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_questions FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_routine_runs cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_routine_runs FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_timers cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_timers FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_tool_history cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_tool_history FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_tool_templates cp_tools_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_links BEFORE INSERT OR UPDATE ON public.classpilot_tool_templates FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_tool_links();


--
-- Name: classpilot_lesson_activities cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_lesson_activities FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_lesson_progress cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_lesson_progress FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_picker_rounds cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_picker_rounds FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_questions cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_questions FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_routine_runs cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_routine_runs FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_timers cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_timers FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_tool_history cp_tools_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_parent BEFORE INSERT OR UPDATE ON public.classpilot_tool_history FOR EACH ROW EXECUTE FUNCTION public.classpilot_validate_activity_parent('teaching_session_id');


--
-- Name: classpilot_supervision_contexts cp_tools_reassigned_routines; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_tools_reassigned_routines AFTER UPDATE OF assigned_staff_id ON public.classpilot_supervision_contexts FOR EACH ROW WHEN ((new.assigned_staff_id IS DISTINCT FROM old.assigned_staff_id)) EXECUTE FUNCTION public.classpilot_end_reassigned_routines();


--
-- Name: classpilot_usage_rollups cp_usage_days_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_usage_days_delete AFTER DELETE ON public.classpilot_usage_rollups REFERENCING OLD TABLE AS old_usage_rows FOR EACH STATEMENT EXECUTE FUNCTION public.invalidate_classpilot_usage_days_old();


--
-- Name: classpilot_usage_rollups cp_usage_days_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_usage_days_insert AFTER INSERT ON public.classpilot_usage_rollups REFERENCING NEW TABLE AS new_usage_rows FOR EACH STATEMENT EXECUTE FUNCTION public.invalidate_classpilot_usage_days_new();


--
-- Name: classpilot_usage_rollups cp_usage_days_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cp_usage_days_update AFTER UPDATE ON public.classpilot_usage_rollups REFERENCING OLD TABLE AS old_usage_rows NEW TABLE AS new_usage_rows FOR EACH STATEMENT EXECUTE FUNCTION public.invalidate_classpilot_usage_days_update();


--
-- Name: student_safety_alerts detach_safety_url_rule_provenance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER detach_safety_url_rule_provenance BEFORE DELETE ON public.student_safety_alerts FOR EACH ROW EXECUTE FUNCTION public.detach_safety_url_rule_provenance();


--
-- Name: flight_paths flight_paths_content_revision; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER flight_paths_content_revision BEFORE UPDATE ON public.flight_paths FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_flight_path_content_revision();


--
-- Name: homerooms gopilot_homeroom_primary_mirror_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER gopilot_homeroom_primary_mirror_integrity AFTER INSERT OR UPDATE OF school_id, teacher_id ON public.homerooms DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_gopilot_homeroom_staff_integrity();


--
-- Name: homeroom_teachers gopilot_homeroom_teacher_mirror_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER gopilot_homeroom_teacher_mirror_integrity AFTER INSERT OR DELETE OR UPDATE ON public.homeroom_teachers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_gopilot_homeroom_staff_integrity();


--
-- Name: homeroom_teachers gopilot_validate_homeroom_co_teacher; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER gopilot_validate_homeroom_co_teacher BEFORE INSERT OR UPDATE OF school_id, homeroom_id, teacher_id ON public.homeroom_teachers FOR EACH ROW EXECUTE FUNCTION public.gopilot_validate_homeroom_teacher();


--
-- Name: homerooms gopilot_validate_homeroom_primary_teacher; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER gopilot_validate_homeroom_primary_teacher BEFORE INSERT OR UPDATE OF school_id, teacher_id ON public.homerooms FOR EACH ROW EXECUTE FUNCTION public.gopilot_validate_homeroom_teacher();


--
-- Name: student_safety_alerts mailpilot_safety_review; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mailpilot_safety_review AFTER INSERT OR UPDATE OF reviewed_at, reviewed_by ON public.student_safety_alerts FOR EACH ROW WHEN (((new.source_type = 'mailpilot'::text) AND (new.reviewed_at IS NOT NULL))) EXECUTE FUNCTION public.copy_mailpilot_safety_review();


--
-- Name: mydesk_imports mydesk_import_destination_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mydesk_import_destination_immutable BEFORE UPDATE OF destination ON public.mydesk_imports FOR EACH ROW EXECUTE FUNCTION public.preserve_mydesk_import_destination();


--
-- Name: mydesk_imports mydesk_imports_author_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mydesk_imports_author_school BEFORE INSERT OR UPDATE OF school_id, author_id ON public.mydesk_imports FOR EACH ROW EXECUTE FUNCTION public.check_mydesk_import_author_school();


--
-- Name: mydesk_notes mydesk_notes_author_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mydesk_notes_author_school BEFORE INSERT OR UPDATE OF school_id, author_id ON public.mydesk_notes FOR EACH ROW EXECUTE FUNCTION public.check_mydesk_author_school();


--
-- Name: mydesk_preferences mydesk_preferences_author_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mydesk_preferences_author_school BEFORE INSERT OR UPDATE OF school_id, author_id ON public.mydesk_preferences FOR EACH ROW EXECUTE FUNCTION public.check_mydesk_preferences_author_school();


--
-- Name: mydesk_seating_charts mydesk_seating_charts_author_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mydesk_seating_charts_author_school BEFORE INSERT OR UPDATE OF school_id, author_id ON public.mydesk_seating_charts FOR EACH ROW EXECUTE FUNCTION public.check_mydesk_seating_author_school();


--
-- Name: passes passes_kiosk_activity_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER passes_kiosk_activity_parent BEFORE INSERT OR UPDATE OF school_id, supervision_context_id, issuing_kiosk_session_id ON public.passes FOR EACH ROW EXECUTE FUNCTION public.check_passpilot_kiosk_activity_parent();


--
-- Name: grades passpilot_grade_dependency_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER passpilot_grade_dependency_integrity AFTER INSERT OR UPDATE OF school_id ON public.grades DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: passpilot_kiosk_sessions passpilot_kiosk_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER passpilot_kiosk_staff_integrity AFTER INSERT OR UPDATE OF school_id, teacher_id, status ON public.passpilot_kiosk_sessions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('active_kiosk_session');


--
-- Name: teacher_grades passpilot_teacher_grade_staff_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER passpilot_teacher_grade_staff_integrity AFTER INSERT OR UPDATE OF teacher_id, grade_id ON public.teacher_grades DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_live_staff_dependency('passpilot_legacy_class');


--
-- Name: passes pp_appointment_pass_completion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pp_appointment_pass_completion AFTER UPDATE OF status ON public.passes FOR EACH ROW EXECUTE FUNCTION public.complete_passpilot_appointment_from_pass();


--
-- Name: passpilot_teacher_kiosk_settings pp_kiosk_teacher_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pp_kiosk_teacher_school BEFORE INSERT OR UPDATE OF school_id, teacher_id ON public.passpilot_teacher_kiosk_settings FOR EACH ROW EXECUTE FUNCTION public.check_passpilot_kiosk_teacher_school();


--
-- Name: roster_integration_identities roster_identity_target_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER roster_identity_target_school BEFORE INSERT OR UPDATE ON public.roster_integration_identities FOR EACH ROW EXECUTE FUNCTION public.check_roster_integration_target_school();


--
-- Name: roster_integration_memberships roster_membership_target_school; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER roster_membership_target_school BEFORE INSERT OR UPDATE ON public.roster_integration_memberships FOR EACH ROW EXECUTE FUNCTION public.check_roster_integration_target_school();


--
-- Name: school_discipline_versions school_discipline_versions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER school_discipline_versions_immutable BEFORE UPDATE ON public.school_discipline_versions FOR EACH ROW EXECUTE FUNCTION public.school_discipline_immutable_version();


--
-- Name: schools school_staff_assignment_reactivation_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER school_staff_assignment_reactivation_integrity AFTER UPDATE OF deleted_at, status ON public.schools DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_school_staff_integrity();


--
-- Name: schools school_staff_history_hard_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER school_staff_history_hard_delete_guard BEFORE DELETE ON public.schools FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_guard_school_hard_delete();


--
-- Name: classpilot_school_website_deliveries school_website_delivery_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER school_website_delivery_binding BEFORE INSERT OR UPDATE ON public.classpilot_school_website_deliveries FOR EACH ROW EXECUTE FUNCTION public.validate_school_website_delivery_binding();


--
-- Name: users staff_identity_history_hard_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER staff_identity_history_hard_delete_guard BEFORE DELETE ON public.users FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_guard_user_hard_delete();


--
-- Name: settings staff_settings_dependency_integrity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER staff_settings_dependency_integrity AFTER INSERT OR DELETE OR UPDATE OF school_id, passpilot_class_source, central_email_recipient_user_id ON public.settings DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.schoolpilot_check_parent_staff_dependencies();


--
-- Name: student_contact_profile_versions student_contact_history_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER student_contact_history_immutable BEFORE DELETE OR UPDATE ON public.student_contact_profile_versions FOR EACH ROW EXECUTE FUNCTION public.reject_student_contact_history_mutation();


--
-- Name: student_sessions student_sessions_auth_kind_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER student_sessions_auth_kind_immutable BEFORE UPDATE OF auth_kind ON public.student_sessions FOR EACH ROW EXECUTE FUNCTION public.reject_student_session_auth_kind_change();


--
-- Name: authorized_pickups authorized_pickups_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authorized_pickups
    ADD CONSTRAINT authorized_pickups_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: classpilot_coverage_group_categories classpilot_coverage_group_categories_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_group_categories
    ADD CONSTRAINT classpilot_coverage_group_categories_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_coverage_scope_groups classpilot_coverage_groups_category_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_coverage_scope_groups
    ADD CONSTRAINT classpilot_coverage_groups_category_school_fk FOREIGN KEY (school_id, category_id) REFERENCES public.classpilot_coverage_group_categories(school_id, id) ON DELETE RESTRICT;


--
-- Name: classpilot_lesson_activities classpilot_lesson_activities_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_activities
    ADD CONSTRAINT classpilot_lesson_activities_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_lesson_activities classpilot_lesson_activities_school_id_supervision_context_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_activities
    ADD CONSTRAINT classpilot_lesson_activities_school_id_supervision_context_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_lesson_activities classpilot_lesson_activities_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_activities
    ADD CONSTRAINT classpilot_lesson_activities_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_lesson_activities classpilot_lesson_activities_start_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_activities
    ADD CONSTRAINT classpilot_lesson_activities_start_command_id_fkey FOREIGN KEY (start_command_id) REFERENCES public.classpilot_commands(id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_school_id_lesson_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_school_id_lesson_activity_id_fkey FOREIGN KEY (school_id, lesson_activity_id) REFERENCES public.classpilot_lesson_activities(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_school_id_supervision_context_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_school_id_supervision_context_i_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_lesson_progress classpilot_lesson_progress_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_lesson_progress
    ADD CONSTRAINT classpilot_lesson_progress_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: classpilot_picker_rounds classpilot_picker_rounds_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_picker_rounds
    ADD CONSTRAINT classpilot_picker_rounds_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_picker_rounds classpilot_picker_rounds_school_id_supervision_context_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_picker_rounds
    ADD CONSTRAINT classpilot_picker_rounds_school_id_supervision_context_id_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_picker_rounds classpilot_picker_rounds_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_picker_rounds
    ADD CONSTRAINT classpilot_picker_rounds_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_picker_rounds classpilot_picker_rounds_selected_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_picker_rounds
    ADD CONSTRAINT classpilot_picker_rounds_selected_student_id_fkey FOREIGN KEY (selected_student_id) REFERENCES public.students(id);


--
-- Name: classpilot_private_chat_threads classpilot_private_chat_threads_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT classpilot_private_chat_threads_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_questions classpilot_questions_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_questions classpilot_questions_school_id_supervision_context_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_school_id_supervision_context_id_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_questions classpilot_questions_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_questions classpilot_questions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_questions
    ADD CONSTRAINT classpilot_questions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: classpilot_routine_runs classpilot_routine_runs_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_routine_runs
    ADD CONSTRAINT classpilot_routine_runs_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_routine_runs classpilot_routine_runs_school_id_supervision_context_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_routine_runs
    ADD CONSTRAINT classpilot_routine_runs_school_id_supervision_context_id_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_routine_runs classpilot_routine_runs_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_routine_runs
    ADD CONSTRAINT classpilot_routine_runs_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_routine_runs classpilot_routine_runs_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_routine_runs
    ADD CONSTRAINT classpilot_routine_runs_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id);


--
-- Name: classpilot_school_schedules classpilot_school_schedules_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_schedules
    ADD CONSTRAINT classpilot_school_schedules_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_school_website_deliveries classpilot_school_website_deliveries_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_deliveries
    ADD CONSTRAINT classpilot_school_website_deliveries_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_school_website_deliveries classpilot_school_website_deliveries_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_deliveries
    ADD CONSTRAINT classpilot_school_website_deliveries_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: classpilot_school_website_deliveries classpilot_school_website_deliveries_student_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_deliveries
    ADD CONSTRAINT classpilot_school_website_deliveries_student_session_id_fkey FOREIGN KEY (student_session_id) REFERENCES public.student_sessions(id) ON DELETE CASCADE;


--
-- Name: classpilot_school_website_policies classpilot_school_website_policies_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_school_website_policies
    ADD CONSTRAINT classpilot_school_website_policies_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_supervision_report_segments classpilot_supervision_report_segments_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_report_segments
    ADD CONSTRAINT classpilot_supervision_report_segments_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_teacher_preferences classpilot_teacher_preferences_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_teacher_preferences
    ADD CONSTRAINT classpilot_teacher_preferences_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_teacher_preferences classpilot_teacher_preferences_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_teacher_preferences
    ADD CONSTRAINT classpilot_teacher_preferences_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id);


--
-- Name: classpilot_timers classpilot_timers_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_timers
    ADD CONSTRAINT classpilot_timers_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_timers classpilot_timers_school_id_supervision_context_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_timers
    ADD CONSTRAINT classpilot_timers_school_id_supervision_context_id_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_timers classpilot_timers_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_timers
    ADD CONSTRAINT classpilot_timers_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_timers classpilot_timers_start_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_timers
    ADD CONSTRAINT classpilot_timers_start_command_id_fkey FOREIGN KEY (start_command_id) REFERENCES public.classpilot_commands(id);


--
-- Name: classpilot_tool_history classpilot_tool_history_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_history
    ADD CONSTRAINT classpilot_tool_history_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_tool_history classpilot_tool_history_school_id_supervision_context_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_history
    ADD CONSTRAINT classpilot_tool_history_school_id_supervision_context_id_fkey FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_tool_history classpilot_tool_history_school_id_teaching_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_history
    ADD CONSTRAINT classpilot_tool_history_school_id_teaching_session_id_fkey FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_tool_templates classpilot_tool_templates_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_templates
    ADD CONSTRAINT classpilot_tool_templates_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_tool_templates classpilot_tool_templates_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_tool_templates
    ADD CONSTRAINT classpilot_tool_templates_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id);


--
-- Name: chat_messages cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_active_hands cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_active_hands
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_chat_deliveries cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_chat_deliveries
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: classpilot_classroom_states cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_classroom_states
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: polls cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: session_settings cp_activity_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_settings
    ADD CONSTRAINT cp_activity_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.teaching_sessions(school_id, id);


--
-- Name: chat_messages cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_active_hands cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_active_hands
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_chat_deliveries cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_chat_deliveries
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_classroom_states cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_classroom_states
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: polls cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: session_settings cp_activity_supervision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_settings
    ADD CONSTRAINT cp_activity_supervision_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id);


--
-- Name: classpilot_evidence_capture_requests cp_evidence_capture_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_evidence_capture_requests
    ADD CONSTRAINT cp_evidence_capture_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruption_digests cp_monitoring_digest_recipient_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruption_digests
    ADD CONSTRAINT cp_monitoring_digest_recipient_fk FOREIGN KEY (recipient_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruption_digests cp_monitoring_digest_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruption_digests
    ADD CONSTRAINT cp_monitoring_digest_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_class_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_class_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_coverage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_coverage_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_device_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_device_fk FOREIGN KEY (school_id, device_id) REFERENCES public.devices(school_id, device_id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_session_fk FOREIGN KEY (student_session_id, student_id, device_id) REFERENCES public.student_sessions(id, student_id, device_id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_expectations cp_monitoring_expectation_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_expectations
    ADD CONSTRAINT cp_monitoring_expectation_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_class_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_class_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_coverage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_coverage_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_device_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_device_fk FOREIGN KEY (school_id, device_id) REFERENCES public.devices(school_id, device_id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_session_fk FOREIGN KEY (student_session_id, student_id, device_id) REFERENCES public.student_sessions(id, student_id, device_id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruption_settings cp_monitoring_interruption_settings_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruption_settings
    ADD CONSTRAINT cp_monitoring_interruption_settings_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_monitoring_interruptions cp_monitoring_interruption_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_monitoring_interruptions
    ADD CONSTRAINT cp_monitoring_interruption_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_private_chat_threads cp_private_chat_context_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT cp_private_chat_context_fk FOREIGN KEY (school_id, supervision_context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_private_chat_threads cp_private_chat_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT cp_private_chat_session_fk FOREIGN KEY (school_id, teaching_session_id) REFERENCES public.teaching_sessions(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_private_chat_threads cp_private_chat_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_private_chat_threads
    ADD CONSTRAINT cp_private_chat_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_schedule_change_legs cp_schedule_change_legs_change_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_legs
    ADD CONSTRAINT cp_schedule_change_legs_change_school_fk FOREIGN KEY (school_id, schedule_change_id, scheduled_date) REFERENCES public.classpilot_schedule_changes(school_id, id, scheduled_date) ON DELETE RESTRICT;


--
-- Name: classpilot_schedule_change_legs cp_schedule_change_legs_group_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_legs
    ADD CONSTRAINT cp_schedule_change_legs_group_school_fk FOREIGN KEY (school_id, group_id) REFERENCES public.groups(school_id, id) ON DELETE RESTRICT;


--
-- Name: classpilot_schedule_change_pairs cp_schedule_change_pairs_first_group_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_pairs
    ADD CONSTRAINT cp_schedule_change_pairs_first_group_school_fk FOREIGN KEY (school_id, first_group_id) REFERENCES public.groups(school_id, id) ON DELETE RESTRICT;


--
-- Name: classpilot_schedule_change_pairs cp_schedule_change_pairs_second_group_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_change_pairs
    ADD CONSTRAINT cp_schedule_change_pairs_second_group_school_fk FOREIGN KEY (school_id, second_group_id) REFERENCES public.groups(school_id, id) ON DELETE RESTRICT;


--
-- Name: classpilot_schedule_changes cp_schedule_changes_pair_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_schedule_changes
    ADD CONSTRAINT cp_schedule_changes_pair_school_fk FOREIGN KEY (school_id, pair_id) REFERENCES public.classpilot_schedule_change_pairs(school_id, id) ON DELETE RESTRICT;


--
-- Name: classpilot_supervision_summary_deliveries cp_supervision_delivery_report_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_summary_deliveries
    ADD CONSTRAINT cp_supervision_delivery_report_fk FOREIGN KEY (school_id, report_id) REFERENCES public.classpilot_supervision_report_segments(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_supervision_report_segments cp_supervision_report_context_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_report_segments
    ADD CONSTRAINT cp_supervision_report_context_fk FOREIGN KEY (school_id, context_id) REFERENCES public.classpilot_supervision_contexts(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_supervision_student_reports cp_supervision_student_report_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_supervision_student_reports
    ADD CONSTRAINT cp_supervision_student_report_parent_fk FOREIGN KEY (school_id, report_id) REFERENCES public.classpilot_supervision_report_segments(school_id, id) ON DELETE CASCADE;


--
-- Name: classpilot_usage_rollup_days cp_usage_days_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollup_days
    ADD CONSTRAINT cp_usage_days_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: classpilot_usage_rollups cp_usage_rollups_class_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollups
    ADD CONSTRAINT cp_usage_rollups_class_school_fk FOREIGN KEY (school_id, class_id) REFERENCES public.groups(school_id, id) ON DELETE SET NULL (class_id);


--
-- Name: classpilot_usage_rollups cp_usage_rollups_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollups
    ADD CONSTRAINT cp_usage_rollups_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: classpilot_usage_rollups cp_usage_rollups_session_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollups
    ADD CONSTRAINT cp_usage_rollups_session_school_fk FOREIGN KEY (school_id, session_id) REFERENCES public.teaching_sessions(school_id, id) ON DELETE SET NULL (session_id);


--
-- Name: classpilot_usage_rollups cp_usage_rollups_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classpilot_usage_rollups
    ADD CONSTRAINT cp_usage_rollups_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: custody_alerts custody_alerts_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custody_alerts
    ADD CONSTRAINT custody_alerts_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: dismissal_changes dismissal_changes_school_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_changes
    ADD CONSTRAINT dismissal_changes_school_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.dismissal_sessions(school_id, id);


--
-- Name: dismissal_changes dismissal_changes_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_changes
    ADD CONSTRAINT dismissal_changes_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: dismissal_overrides dismissal_overrides_school_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_overrides
    ADD CONSTRAINT dismissal_overrides_school_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.dismissal_sessions(school_id, id);


--
-- Name: dismissal_overrides dismissal_overrides_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_overrides
    ADD CONSTRAINT dismissal_overrides_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: dismissal_queue dismissal_queue_school_session_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_queue
    ADD CONSTRAINT dismissal_queue_school_session_fk FOREIGN KEY (school_id, session_id) REFERENCES public.dismissal_sessions(school_id, id);


--
-- Name: dismissal_queue dismissal_queue_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dismissal_queue
    ADD CONSTRAINT dismissal_queue_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: family_group_students family_group_students_school_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_group_students
    ADD CONSTRAINT family_group_students_school_group_fk FOREIGN KEY (school_id, family_group_id) REFERENCES public.family_groups(school_id, id);


--
-- Name: family_group_students family_group_students_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_group_students
    ADD CONSTRAINT family_group_students_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: homeroom_teachers homeroom_teachers_school_homeroom_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homeroom_teachers
    ADD CONSTRAINT homeroom_teachers_school_homeroom_fk FOREIGN KEY (school_id, homeroom_id) REFERENCES public.homerooms(school_id, id);


--
-- Name: import_processing_stages import_processing_stages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_processing_stages
    ADD CONSTRAINT import_processing_stages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: import_processing_stages import_processing_stages_information_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_processing_stages
    ADD CONSTRAINT import_processing_stages_information_fk FOREIGN KEY (school_id, author_id, information_import_id) REFERENCES public.student_information_imports(school_id, author_id, id);


--
-- Name: import_processing_stages import_processing_stages_paperwork_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_processing_stages
    ADD CONSTRAINT import_processing_stages_paperwork_fk FOREIGN KEY (school_id, author_id, paperwork_import_id) REFERENCES public.mydesk_imports(school_id, author_id, id);


--
-- Name: import_processing_stages import_processing_stages_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_processing_stages
    ADD CONSTRAINT import_processing_stages_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_attachments mydesk_attachments_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_attachments
    ADD CONSTRAINT mydesk_attachments_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_attachments mydesk_attachments_owner_note_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_attachments
    ADD CONSTRAINT mydesk_attachments_owner_note_fk FOREIGN KEY (school_id, author_id, note_id) REFERENCES public.mydesk_notes(school_id, author_id, id);


--
-- Name: mydesk_attachments mydesk_attachments_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_attachments
    ADD CONSTRAINT mydesk_attachments_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_import_assets mydesk_import_assets_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_import_assets mydesk_import_assets_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_parent_fk FOREIGN KEY (school_id, author_id, import_id, parent_asset_id) REFERENCES public.mydesk_import_assets(school_id, author_id, import_id, id);


--
-- Name: mydesk_import_assets mydesk_import_assets_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_run_fk FOREIGN KEY (school_id, author_id, import_id) REFERENCES public.mydesk_imports(school_id, author_id, id);


--
-- Name: mydesk_import_assets mydesk_import_assets_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_assets
    ADD CONSTRAINT mydesk_import_assets_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_import_items mydesk_import_items_approved_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_approved_fk FOREIGN KEY (school_id, author_id, import_id, approved_asset_id) REFERENCES public.mydesk_import_assets(school_id, author_id, import_id, id);


--
-- Name: mydesk_import_items mydesk_import_items_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_import_items mydesk_import_items_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_run_fk FOREIGN KEY (school_id, author_id, import_id) REFERENCES public.mydesk_imports(school_id, author_id, id);


--
-- Name: mydesk_import_items mydesk_import_items_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_import_items
    ADD CONSTRAINT mydesk_import_items_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_imports mydesk_imports_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_imports
    ADD CONSTRAINT mydesk_imports_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_imports mydesk_imports_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_imports
    ADD CONSTRAINT mydesk_imports_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_notes mydesk_notes_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_notes mydesk_notes_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_group_fk FOREIGN KEY (school_id, group_id) REFERENCES public.groups(school_id, id) ON DELETE SET NULL (group_id);


--
-- Name: mydesk_notes mydesk_notes_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_notes mydesk_notes_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_notes
    ADD CONSTRAINT mydesk_notes_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE SET NULL (student_id);


--
-- Name: mydesk_preferences mydesk_preferences_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_preferences
    ADD CONSTRAINT mydesk_preferences_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_preferences mydesk_preferences_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_preferences
    ADD CONSTRAINT mydesk_preferences_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: mydesk_seating_charts mydesk_seating_charts_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_seating_charts
    ADD CONSTRAINT mydesk_seating_charts_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: mydesk_seating_charts mydesk_seating_charts_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_seating_charts
    ADD CONSTRAINT mydesk_seating_charts_group_fk FOREIGN KEY (school_id, group_id) REFERENCES public.groups(school_id, id) ON DELETE SET NULL (group_id);


--
-- Name: mydesk_seating_charts mydesk_seating_charts_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mydesk_seating_charts
    ADD CONSTRAINT mydesk_seating_charts_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: parent_student parent_student_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parent_student
    ADD CONSTRAINT parent_student_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id);


--
-- Name: passpilot_appointments passpilot_appointments_activated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT passpilot_appointments_activated_by_fkey FOREIGN KEY (activated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: passpilot_appointments passpilot_appointments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT passpilot_appointments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: passpilot_appointments passpilot_appointments_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT passpilot_appointments_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: passpilot_appointments passpilot_appointments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT passpilot_appointments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: passpilot_grade_students passpilot_grade_students_grade_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_grade_students
    ADD CONSTRAINT passpilot_grade_students_grade_school_fk FOREIGN KEY (school_id, grade_id) REFERENCES public.grades(school_id, id) ON DELETE RESTRICT;


--
-- Name: passpilot_grade_students passpilot_grade_students_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_grade_students
    ADD CONSTRAINT passpilot_grade_students_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: passpilot_teacher_kiosk_settings passpilot_teacher_kiosk_settings_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_teacher_kiosk_settings
    ADD CONSTRAINT passpilot_teacher_kiosk_settings_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: passpilot_teacher_kiosk_settings passpilot_teacher_kiosk_settings_teacher_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_teacher_kiosk_settings
    ADD CONSTRAINT passpilot_teacher_kiosk_settings_teacher_id_users_id_fk FOREIGN KEY (teacher_id) REFERENCES public.users(id);


--
-- Name: poll_responses poll_responses_school_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_responses
    ADD CONSTRAINT poll_responses_school_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE RESTRICT;


--
-- Name: passpilot_appointments pp_appointments_pass_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT pp_appointments_pass_student_school_fk FOREIGN KEY (school_id, student_id, pass_id) REFERENCES public.passes(school_id, student_id, id) ON DELETE SET NULL (pass_id);


--
-- Name: passpilot_appointments pp_appointments_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_appointments
    ADD CONSTRAINT pp_appointments_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: passpilot_destination_policies pp_destination_policies_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_destination_policies
    ADD CONSTRAINT pp_destination_policies_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: passpilot_encounter_restrictions pp_encounter_restrictions_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_encounter_restrictions
    ADD CONSTRAINT pp_encounter_restrictions_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: passpilot_encounter_restrictions pp_encounter_restrictions_student_a_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_encounter_restrictions
    ADD CONSTRAINT pp_encounter_restrictions_student_a_fk FOREIGN KEY (school_id, student_a_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: passpilot_encounter_restrictions pp_encounter_restrictions_student_b_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_encounter_restrictions
    ADD CONSTRAINT pp_encounter_restrictions_student_b_fk FOREIGN KEY (school_id, student_b_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: passpilot_pass_denials pp_pass_denials_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_denials
    ADD CONSTRAINT pp_pass_denials_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: passpilot_pass_denials pp_pass_denials_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_denials
    ADD CONSTRAINT pp_pass_denials_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: passpilot_pass_limits pp_pass_limits_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_limits
    ADD CONSTRAINT pp_pass_limits_school_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: passpilot_pass_limits pp_pass_limits_student_school_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passpilot_pass_limits
    ADD CONSTRAINT pp_pass_limits_student_school_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: roster_integration_identities roster_identities_connection_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_identities
    ADD CONSTRAINT roster_identities_connection_fk FOREIGN KEY (school_id, connection_id) REFERENCES public.roster_integration_connections(school_id, id);


--
-- Name: roster_integration_identities roster_identities_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_identities
    ADD CONSTRAINT roster_identities_run_fk FOREIGN KEY (school_id, last_run_id) REFERENCES public.roster_integration_runs(school_id, id);


--
-- Name: roster_integration_connections roster_integration_connections_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_connections
    ADD CONSTRAINT roster_integration_connections_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: roster_integration_memberships roster_memberships_connection_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_memberships
    ADD CONSTRAINT roster_memberships_connection_fk FOREIGN KEY (school_id, connection_id) REFERENCES public.roster_integration_connections(school_id, id);


--
-- Name: roster_integration_memberships roster_memberships_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_memberships
    ADD CONSTRAINT roster_memberships_group_fk FOREIGN KEY (school_id, group_id) REFERENCES public.groups(school_id, id);


--
-- Name: roster_integration_memberships roster_memberships_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_memberships
    ADD CONSTRAINT roster_memberships_run_fk FOREIGN KEY (school_id, last_run_id) REFERENCES public.roster_integration_runs(school_id, id);


--
-- Name: roster_integration_runs roster_runs_connection_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roster_integration_runs
    ADD CONSTRAINT roster_runs_connection_fk FOREIGN KEY (school_id, connection_id) REFERENCES public.roster_integration_connections(school_id, id);


--
-- Name: student_safety_alerts safety_alert_case_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT safety_alert_case_parent FOREIGN KEY (school_id, case_id, student_id) REFERENCES public.student_safety_cases(school_id, id, student_id) ON DELETE CASCADE;


--
-- Name: student_safety_alerts safety_alert_student_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_alerts
    ADD CONSTRAINT safety_alert_student_parent FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE CASCADE;


--
-- Name: student_safety_case_events safety_case_event_alert_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_case_events
    ADD CONSTRAINT safety_case_event_alert_parent FOREIGN KEY (school_id, case_id, alert_id) REFERENCES public.student_safety_alerts(school_id, case_id, id) ON DELETE CASCADE;


--
-- Name: student_safety_case_events safety_case_event_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_safety_case_events
    ADD CONSTRAINT safety_case_event_parent FOREIGN KEY (school_id, case_id) REFERENCES public.student_safety_cases(school_id, id) ON DELETE CASCADE;


--
-- Name: safety_notification_outbox safety_outbox_case_alert_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_notification_outbox
    ADD CONSTRAINT safety_outbox_case_alert_parent FOREIGN KEY (school_id, case_id, alert_id) REFERENCES public.student_safety_alerts(school_id, case_id, id) ON DELETE CASCADE;


--
-- Name: safety_url_exceptions safety_url_exception_alert_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_url_exceptions
    ADD CONSTRAINT safety_url_exception_alert_parent FOREIGN KEY (school_id, created_from_alert_id) REFERENCES public.student_safety_alerts(school_id, id);


--
-- Name: safety_url_exceptions safety_url_exception_school_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safety_url_exceptions
    ADD CONSTRAINT safety_url_exception_school_parent FOREIGN KEY (school_id) REFERENCES public.schools(id) ON DELETE CASCADE;


--
-- Name: school_discipline_access school_discipline_access_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_access
    ADD CONSTRAINT school_discipline_access_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: school_discipline_access school_discipline_access_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_access
    ADD CONSTRAINT school_discipline_access_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: school_discipline_attachments school_discipline_attachments_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_attachments
    ADD CONSTRAINT school_discipline_attachments_parent FOREIGN KEY (school_id, version_id) REFERENCES public.school_discipline_versions(school_id, id);


--
-- Name: school_discipline_records school_discipline_records_school_id_schools_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_records
    ADD CONSTRAINT school_discipline_records_school_id_schools_id_fk FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: school_discipline_records school_discipline_records_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_records
    ADD CONSTRAINT school_discipline_records_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: school_discipline_versions school_discipline_versions_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_discipline_versions
    ADD CONSTRAINT school_discipline_versions_parent FOREIGN KEY (school_id, record_id) REFERENCES public.school_discipline_records(school_id, id);


--
-- Name: student_contact_profile_versions student_contact_profile_versions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profile_versions
    ADD CONSTRAINT student_contact_profile_versions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: student_contact_profile_versions student_contact_profile_versions_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profile_versions
    ADD CONSTRAINT student_contact_profile_versions_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: student_contact_profiles student_contact_profiles_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profiles
    ADD CONSTRAINT student_contact_profiles_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: student_contact_profiles student_contact_profiles_student_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profiles
    ADD CONSTRAINT student_contact_profiles_student_fk FOREIGN KEY (school_id, student_id) REFERENCES public.students(school_id, id) ON DELETE SET NULL (student_id);


--
-- Name: student_contact_profiles student_contact_profiles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profiles
    ADD CONSTRAINT student_contact_profiles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: student_contact_profile_versions student_contact_versions_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_contact_profile_versions
    ADD CONSTRAINT student_contact_versions_profile_fk FOREIGN KEY (school_id, profile_id) REFERENCES public.student_contact_profiles(school_id, id);


--
-- Name: student_information_import_assets student_information_assets_import_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_assets_import_fk FOREIGN KEY (school_id, author_id, import_id) REFERENCES public.student_information_imports(school_id, author_id, id);


--
-- Name: student_information_import_assets student_information_assets_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_assets_parent_fk FOREIGN KEY (school_id, author_id, import_id, parent_id) REFERENCES public.student_information_import_assets(school_id, author_id, import_id, id);


--
-- Name: student_information_import_assets student_information_import_assets_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_import_assets_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: student_information_import_assets student_information_import_assets_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_assets
    ADD CONSTRAINT student_information_import_assets_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: student_information_import_items student_information_import_items_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_items
    ADD CONSTRAINT student_information_import_items_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: student_information_import_items student_information_import_items_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_items
    ADD CONSTRAINT student_information_import_items_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: student_information_imports student_information_imports_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_imports
    ADD CONSTRAINT student_information_imports_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: student_information_imports student_information_imports_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_imports
    ADD CONSTRAINT student_information_imports_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: student_information_import_items student_information_items_import_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_items
    ADD CONSTRAINT student_information_items_import_fk FOREIGN KEY (school_id, author_id, import_id) REFERENCES public.student_information_imports(school_id, author_id, id);


--
-- Name: student_information_import_items student_information_items_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_information_import_items
    ADD CONSTRAINT student_information_items_source_fk FOREIGN KEY (school_id, author_id, import_id, source_section_id) REFERENCES public.student_information_import_assets(school_id, author_id, import_id, id);


--
-- Name: activity_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: authorized_pickups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.authorized_pickups ENABLE ROW LEVEL SECURITY;

--
-- Name: block_lists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.block_lists ENABLE ROW LEVEL SECURITY;

--
-- Name: bus_routes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bus_routes ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_active_hands; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_active_hands ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_ai_decisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_ai_decisions ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_chat_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_chat_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_classroom_states; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_classroom_states ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_command_targets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_command_targets ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_commands; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_commands ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_coverage_assignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_coverage_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_coverage_group_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_coverage_group_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_coverage_scope_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_coverage_scope_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_coverage_scope_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_coverage_scope_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_evidence_capture_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_evidence_capture_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_lesson_activities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_lesson_activities ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_lesson_progress; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_lesson_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_monitoring_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_monitoring_events ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_monitoring_expectations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_monitoring_expectations ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_monitoring_interruption_digests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_monitoring_interruption_digests ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_monitoring_interruption_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_monitoring_interruption_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_monitoring_interruptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_monitoring_interruptions ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_picker_rounds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_picker_rounds ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_private_chat_threads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_private_chat_threads ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_questions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_questions ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_routine_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_routine_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_schedule_change_legs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_schedule_change_legs ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_schedule_change_pairs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_schedule_change_pairs ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_schedule_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_schedule_changes ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_scheduled_conflicts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_scheduled_conflicts ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_school_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_school_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_school_website_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_school_website_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_school_website_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_school_website_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_staff; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_staff ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_student_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_student_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_students ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_summary_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_summary_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_session_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_session_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_student_control_states; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_student_control_states ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_supervision_contexts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_supervision_contexts ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_supervision_report_segments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_supervision_report_segments ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_supervision_student_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_supervision_student_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_supervision_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_supervision_students ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_supervision_summary_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_supervision_summary_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_teacher_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_teacher_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_timers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_timers ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_tool_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_tool_history ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_tool_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_tool_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_usage_rollup_days; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_usage_rollup_days ENABLE ROW LEVEL SECURITY;

--
-- Name: classpilot_usage_rollups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classpilot_usage_rollups ENABLE ROW LEVEL SECURITY;

--
-- Name: classroom_course_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classroom_course_students ENABLE ROW LEVEL SECURITY;

--
-- Name: classroom_courses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classroom_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: custody_alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custody_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.daily_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_tabs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dashboard_tabs ENABLE ROW LEVEL SECURITY;

--
-- Name: devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.devices ENABLE ROW LEVEL SECURITY;

--
-- Name: dismissal_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dismissal_changes ENABLE ROW LEVEL SECURITY;

--
-- Name: dismissal_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dismissal_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: dismissal_queue; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dismissal_queue ENABLE ROW LEVEL SECURITY;

--
-- Name: dismissal_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dismissal_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: email_alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: email_scan_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_scan_log ENABLE ROW LEVEL SECURITY;

--
-- Name: error_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.error_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: evidence_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.evidence_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: family_group_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.family_group_students ENABLE ROW LEVEL SECURITY;

--
-- Name: family_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.family_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: flight_paths; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.flight_paths ENABLE ROW LEVEL SECURITY;

--
-- Name: google_roster_connectors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.google_roster_connectors ENABLE ROW LEVEL SECURITY;

--
-- Name: grades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;

--
-- Name: groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

--
-- Name: heartbeats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.heartbeats ENABLE ROW LEVEL SECURITY;

--
-- Name: homeroom_teachers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.homeroom_teachers ENABLE ROW LEVEL SECURITY;

--
-- Name: homerooms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.homerooms ENABLE ROW LEVEL SECURITY;

--
-- Name: import_processing_stages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_processing_stages ENABLE ROW LEVEL SECURITY;

--
-- Name: import_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: mailpilot_watches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mailpilot_watches ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_import_assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_import_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_import_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_import_items ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_imports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_imports ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_notes ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: mydesk_seating_charts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mydesk_seating_charts ENABLE ROW LEVEL SECURITY;

--
-- Name: parent_student; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.parent_student ENABLE ROW LEVEL SECURITY;

--
-- Name: passes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passes ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_appointments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_appointments ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_destination_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_destination_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_encounter_restrictions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_encounter_restrictions ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_grade_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_grade_students ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_kiosk_devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_kiosk_devices ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_kiosk_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_kiosk_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_pass_denials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_pass_denials ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_pass_limits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_pass_limits ENABLE ROW LEVEL SECURITY;

--
-- Name: passpilot_teacher_kiosk_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.passpilot_teacher_kiosk_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: poll_responses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.poll_responses ENABLE ROW LEVEL SECURITY;

--
-- Name: polls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.polls ENABLE ROW LEVEL SECURITY;

--
-- Name: roster_integration_connections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roster_integration_connections ENABLE ROW LEVEL SECURITY;

--
-- Name: roster_integration_identities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roster_integration_identities ENABLE ROW LEVEL SECURITY;

--
-- Name: roster_integration_memberships; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roster_integration_memberships ENABLE ROW LEVEL SECURITY;

--
-- Name: roster_integration_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roster_integration_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: safety_notification_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.safety_notification_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: safety_url_exceptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.safety_url_exceptions ENABLE ROW LEVEL SECURITY;

--
-- Name: school_discipline_access; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.school_discipline_access ENABLE ROW LEVEL SECURITY;

--
-- Name: school_discipline_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.school_discipline_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: school_discipline_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.school_discipline_records ENABLE ROW LEVEL SECURITY;

--
-- Name: school_discipline_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.school_discipline_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: security_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

--
-- Name: session_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

--
-- Name: student_attendance; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_attendance ENABLE ROW LEVEL SECURITY;

--
-- Name: student_contact_profile_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_contact_profile_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: student_contact_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_contact_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: student_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: student_information_import_assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_information_import_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: student_information_import_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_information_import_items ENABLE ROW LEVEL SECURITY;

--
-- Name: student_information_imports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_information_imports ENABLE ROW LEVEL SECURITY;

--
-- Name: student_safety_alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_safety_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: student_safety_case_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_safety_case_events ENABLE ROW LEVEL SECURITY;

--
-- Name: student_safety_cases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_safety_cases ENABLE ROW LEVEL SECURITY;

--
-- Name: student_timeline_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.student_timeline_events ENABLE ROW LEVEL SECURITY;

--
-- Name: students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

--
-- Name: subgroups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.subgroups ENABLE ROW LEVEL SECURITY;

--
-- Name: teacher_students; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teacher_students ENABLE ROW LEVEL SECURITY;

--
-- Name: teaching_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teaching_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_log tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.activity_log USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: audit_logs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.audit_logs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: authorized_pickups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.authorized_pickups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: block_lists tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.block_lists USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: bus_routes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.bus_routes USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: chat_messages tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.chat_messages USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_active_hands tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_active_hands USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_ai_decisions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_ai_decisions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_chat_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_chat_deliveries USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_classroom_states tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_classroom_states USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_command_targets tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_command_targets USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_commands tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_commands USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_coverage_assignments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_coverage_assignments USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_coverage_group_categories tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_coverage_group_categories USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_coverage_scope_group_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_coverage_scope_group_members USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_coverage_scope_groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_coverage_scope_groups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_evidence_capture_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_evidence_capture_requests USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_lesson_activities tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_lesson_activities USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_lesson_progress tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_lesson_progress USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_monitoring_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_monitoring_events USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_monitoring_expectations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_monitoring_expectations USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_monitoring_interruption_digests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_monitoring_interruption_digests USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_monitoring_interruption_settings tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_monitoring_interruption_settings USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_monitoring_interruptions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_monitoring_interruptions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_picker_rounds tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_picker_rounds USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_private_chat_threads tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_private_chat_threads USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_questions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_questions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_routine_runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_routine_runs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_schedule_change_legs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_schedule_change_legs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_schedule_change_pairs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_schedule_change_pairs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_schedule_changes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_schedule_changes USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_scheduled_conflicts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_scheduled_conflicts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_school_schedules tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_school_schedules USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_school_website_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_school_website_deliveries USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_school_website_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_school_website_policies USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_reports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_reports USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_staff tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_staff USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_student_reports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_student_reports USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_summary_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_summary_deliveries USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_session_usage tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_session_usage USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_student_control_states tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_student_control_states USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_supervision_contexts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_supervision_contexts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_supervision_report_segments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_supervision_report_segments USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_supervision_student_reports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_supervision_student_reports USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_supervision_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_supervision_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_supervision_summary_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_supervision_summary_deliveries USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_teacher_preferences tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_teacher_preferences USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_timers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_timers USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_tool_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_tool_history USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_tool_templates tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_tool_templates USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_usage_rollup_days tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_usage_rollup_days USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classpilot_usage_rollups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classpilot_usage_rollups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classroom_course_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classroom_course_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: classroom_courses tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.classroom_courses USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: custody_alerts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.custody_alerts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: daily_usage tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.daily_usage USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: dashboard_tabs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dashboard_tabs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: devices tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.devices USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: dismissal_changes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dismissal_changes USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: dismissal_overrides tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dismissal_overrides USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: dismissal_queue tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dismissal_queue USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: dismissal_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dismissal_sessions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: email_alerts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.email_alerts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: email_scan_log tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.email_scan_log USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: error_logs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.error_logs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: evidence_artifacts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.evidence_artifacts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: family_group_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.family_group_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: family_groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.family_groups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: flight_paths tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.flight_paths USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: google_roster_connectors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.google_roster_connectors USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: grades tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.grades USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.groups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: heartbeats tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.heartbeats USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: homeroom_teachers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.homeroom_teachers USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: homerooms tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.homerooms USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: import_processing_stages tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.import_processing_stages USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: import_runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.import_runs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mailpilot_watches tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mailpilot_watches USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: messages tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.messages USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_attachments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_attachments USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_import_assets tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_import_assets USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_import_items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_import_items USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_imports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_imports USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_notes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_notes USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_preferences tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_preferences USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: mydesk_seating_charts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mydesk_seating_charts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: parent_student tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.parent_student USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passes USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_appointments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_appointments USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_destination_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_destination_policies USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_encounter_restrictions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_encounter_restrictions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_grade_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_grade_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_kiosk_devices tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_kiosk_devices USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_kiosk_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_kiosk_sessions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_pass_denials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_pass_denials USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_pass_limits tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_pass_limits USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: passpilot_teacher_kiosk_settings tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.passpilot_teacher_kiosk_settings USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: poll_responses tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.poll_responses USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: polls tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.polls USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: roster_integration_connections tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.roster_integration_connections USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: roster_integration_identities tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.roster_integration_identities USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: roster_integration_memberships tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.roster_integration_memberships USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: roster_integration_runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.roster_integration_runs USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: safety_notification_outbox tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.safety_notification_outbox USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: safety_url_exceptions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.safety_url_exceptions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: school_discipline_access tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.school_discipline_access USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: school_discipline_attachments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.school_discipline_attachments USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: school_discipline_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.school_discipline_records USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: school_discipline_versions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.school_discipline_versions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: security_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.security_events USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: session_settings tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_settings USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: settings tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.settings USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_attendance tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_attendance USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_contact_profile_versions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_contact_profile_versions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_contact_profiles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_contact_profiles USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_groups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_information_import_assets tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_information_import_assets USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_information_import_items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_information_import_items USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_information_imports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_information_imports USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_safety_alerts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_safety_alerts USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_safety_case_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_safety_case_events USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_safety_cases tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_safety_cases USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: student_timeline_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.student_timeline_events USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: subgroups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.subgroups USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: teacher_students tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.teacher_students USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: teaching_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.teaching_sessions USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: walker_zones tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.walker_zones USING (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text))) WITH CHECK (((school_id = current_setting('app.school_id'::text, true)) OR (current_setting('app.is_super'::text, true) = 'on'::text)));


--
-- Name: walker_zones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.walker_zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict SFMAFkgkkKySIkXHCtlkoLCHW8nK7zTLLUWeojHWE0XFRF0rR7I4xo0cY1gf6ld

