$ErrorActionPreference='Stop'
$repo='<USER_HOME>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$docker='C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$daemon='npipe:////./pipe/dockerDesktopLinuxEngine'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$container='schoolpilot-private-binding-detectors-'+$run
$database='private_binding_'+$run
$owner='fixture_'+$run; $app='app_'+$run
$password=[guid]::NewGuid().ToString('N');$appPassword=[guid]::NewGuid().ToString('N')
$out=Join-Path $env:TEMP ('release297-private-binding-detectors-native-'+$run)
New-Item -ItemType Directory -Path $out | Out-Null
Set-Location -LiteralPath $repo
$created=$false;$ownerExit=1;$restrictedExit=1
$sourceFiles=@('src/services/storage.ts','src/routes/classpilot/devices.ts','tests/classpilot-private-chat-lifecycle.integration.test.ts','scripts/run-test-lane.mjs')
function Snapshot { $rows=@();foreach($f in $sourceFiles){$rows += [ordered]@{file=$f;sha256=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower()}};return $rows }
Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-before.json') -Encoding utf8
try {
 $schema=Join-Path $out 'schema.sql'
 Copy-Item -LiteralPath (Join-Path $env:TEMP 'release297-enabled-combined-07/post-convergence-schema.sql') -Destination $schema
 $image=(& $docker --host $daemon inspect schoolpilot-db --format '{{.Image}}').Trim()
 & $docker --host $daemon run --detach --name $container --label "codex.private-binding-detectors=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
 if($LASTEXITCODE -ne 0){throw 'Owned fixture creation failed'};$created=$true
 $ready=$false
 for($i=0;$i -lt 40;$i++) { & $docker --host $daemon exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250 }
 if(-not $ready){throw 'Owned fixture not ready'}
 $ports=& $docker --host $daemon inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
 if($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1'){throw 'Fixture must stay loopback only'}
 $port=$ports.'5432/tcp'[0].HostPort
 Get-Content -LiteralPath $schema -Raw | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
 if($LASTEXITCODE -ne 0){throw 'Exact current schema restore failed'}
 "CREATE ROLE $app LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '<REDACTED>'; GRANT USAGE ON SCHEMA public TO $app; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $app;" | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restricted-role.log')
 if($LASTEXITCODE -ne 0){throw 'Restricted role grant failed'}
 $env:JWT_SECRET=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
 Remove-Item Env:RLS_TEST_ROLE -ErrorAction SilentlyContinue
 $env:NODE_ENV='test';$env:REDIS_URL='';$env:SCHEDULER_ENABLED='false';$env:RLS_GUC_ENABLED='true'
 $registry=Get-Content src/config/rlsRegistry.json -Raw | ConvertFrom-Json
 $env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
 $env:DATABASE_URL="<REDACTED_CONNECTION_URL>";$env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL;$env:ADMIN_DATABASE_URL=$env:DATABASE_URL
 node scripts/load/usage/bounded-fixture-step.mjs 120000 --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-private-chat-lifecycle.integration.test.ts *> (Join-Path $out 'owner.log')
 $ownerExit=$LASTEXITCODE
 $env:DATABASE_URL="<REDACTED_CONNECTION_URL>";$env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL
 node scripts/load/usage/bounded-fixture-step.mjs 120000 --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-private-chat-lifecycle.integration.test.ts *> (Join-Path $out 'restricted.log')
 $restrictedExit=$LASTEXITCODE
 Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-after.json') -Encoding utf8
 [ordered]@{ownerExit=$ownerExit;restrictedExit=$restrictedExit;source=(git rev-parse HEAD).Trim();worktreeDirty=$true;container=$container;database=$database;schemaSource='Combined07 exact post-convergence schema-only dump';schemaRawSha256=(Get-FileHash -LiteralPath $schema -Algorithm SHA256).Hash.ToLower();productionMutations=0;sourceExecution='tsx';sharedDistRebuilt=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
 Write-Output ([ordered]@{evidence=$out;ownerExit=$ownerExit;restrictedExit=$restrictedExit}|ConvertTo-Json -Compress)
} finally {
 if($created){$labels=& $docker --host $daemon inspect $container --format '{{json .Config.Labels}}'|ConvertFrom-Json;if($container -cne ('schoolpilot-private-binding-detectors-'+$run) -or $labels.'codex.private-binding-detectors' -cne $run){throw 'Ownership mismatch'};& $docker --host $daemon rm -f $container *> (Join-Path $out 'cleanup.log');if($LASTEXITCODE -ne 0){throw 'Cleanup failed'}}
}
if($ownerExit -ne 0 -or $restrictedExit -ne 0){exit 1}

