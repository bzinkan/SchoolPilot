import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root = String.raw`<LOCAL_USER_PROFILE>\.codex\worktrees\release-stabilization-297\SchoolPilot`;
const output = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-live-harness-followup-01`;
const path = `${root}/tests/aws-rollout-automation.test.ps1`;
const original = readFileSync(path, 'utf8');
const hash = input => createHash('sha256').update(input).digest('hex');
let source = original.replace('    [switch]$StartGateCasesOnly,', '    [switch]$StartGateCasesOnly,\n    [switch]$LiveHarnessLifecycleOnly,\n    [switch]$LiveHarnessCasesOnly,');
assert.notEqual(source, original);
for (const variable of ['uncorrelated', 'genericRejected', 'combined', 'correlated']) {
  const matcher = new RegExp(`        Start-OwnedTestProcess -Registry \\$ownedTestProcesses -Name \\$${variable}Harness \x60\\r?\\n            -FilePath \\(Get-Process -Id \\$PID\\).Path \x60\\r?\\n            -ArgumentList @\\("-NoProfile","-Command","Start-Sleep -Seconds 30"\\)\\r?\\n        \\$${variable}HarnessIdentity = Get-OwnedTestProcessSnapshot -Registry \\$ownedTestProcesses -Name \\$${variable}Harness`);
  assert.ok(matcher.test(source), `Original ${variable} fixed-sleep fixture not found`);
  source = source.replace(matcher, `        $${variable}HarnessIdentity = Start-OwnedLiveHarness -Registry $ownedTestProcesses -Name $${variable}Harness -Directory $childRoot`);
  const stop = `Stop-OwnedTestProcess -Registry $ownedTestProcesses -Name $${variable}Harness`;
  assert.ok(source.includes(stop));
  source = source.replace(stop, `Complete-OwnedLiveHarness -Registry $ownedTestProcesses -Name $${variable}Harness`);
}
source = source.replaceAll('Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses', 'try { Release-AllOwnedLiveHarnesses -Registry $ownedTestProcesses } finally { Stop-AllOwnedTestProcesses -Registry $ownedTestProcesses }');
const afterCorrelated = '        $correlatedHarness = $null';
assert.equal(source.split(afterCorrelated).length, 2);
source = source.replace(afterCorrelated, `${afterCorrelated}\n        if ($LiveHarnessCasesOnly) {\n            Write-Host "Rollout live harness cases: PASS ($script:AssertionCount assertions)"\n            return\n        }`);
const helper = readFileSync(`${output}/helpers.ps1`, 'utf8');
source = source.replace('function Protect-MockDiagnosticText {', () => `${helper}\nfunction Protect-MockDiagnosticText {`);
// Keep the same evidence bounds; add only this fixture's non-content lifetime receipt.
source = source.replace("(?:-aws-monitor\\.jsonl|-monitor-result\\.json|\\.err)$", "(?:-aws-monitor\\.jsonl|-monitor-result\\.json|-harness-lifecycle\\.json|\\.err)$");
writeFileSync(`${output}/test.before.ps1`, original);
writeFileSync(`${output}/test.proposed.ps1`, source);
writeFileSync(`${output}/preparation.json`, JSON.stringify({ sourcePath: path, sourceBeforeSha256: hash(original), proposedSha256: hash(source), applicationChanges: false }, null, 2) + '\n');
console.log(JSON.stringify({ before: hash(original), proposed: hash(source), changeBytes: Buffer.byteLength(source) - Buffer.byteLength(original) }));
