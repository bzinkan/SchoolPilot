import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';

// External diagnostic analysis only. Never changes raw profile/run evidence.
const directory=process.argv[2];assert.ok(directory,'Pass completed profile directory');
const bytes=fs.readFileSync(path.join(directory,'api.cpuprofile'));
const profile=JSON.parse(bytes),result=JSON.parse(fs.readFileSync(path.join(directory,'usage-scale.json'),'utf8').replace(/^\uFEFF/,''));
const phase=result.phases.find(row=>row.api?.measurementStartedHrtimeMicroseconds);
assert.ok(phase,'Completed measured API snapshot is required');
const from=phase.api.measurementStartedHrtimeMicroseconds,until=phase.api.snapshotHrtimeMicroseconds;
assert.ok(Number.isFinite(from)&&Number.isFinite(until)&&from>=profile.startTime&&until<=profile.endTime&&from<until,'API hrtime reset/snapshot must fit V8 monotonic clock');
assert.equal(profile.samples.length,profile.timeDeltas.length);
const normalizeUrl=value=>{let url=String(value||'').replaceAll('\\','/').replace(/^file:\/\/\//,'/');if(url.startsWith('/app/'))return '<APP>/'+url.slice(5);if(url.startsWith('/diagnostic/'))return '<HARNESS>/'+url.slice(12);const at=url.lastIndexOf('/SchoolPilot/');if(at>=0)return '<APP>/'+url.slice(at+13);return url;};
const nodes=new Map(profile.nodes.map(node=>[node.id,node])),parents=new Map();
for(const node of profile.nodes)for(const child of node.children??[]){assert.ok(!parents.has(child),'Profile tree node has multiple parents');parents.set(child,node.id);}
const frame=node=>({name:node.callFrame.functionName||'(anonymous)',url:normalizeUrl(node.callFrame.url),line:node.callFrame.lineNumber+1});
const frameKey=node=>JSON.stringify(frame(node));
const category=node=>{const f=frame(node);if(f.name==='(idle)')return'idle';if(f.name==='(garbage collector)')return'GC';if(f.url.includes('/node_modules/drizzle-orm/'))return'Drizzle';if(/\/node_modules\/(?:pg|pg-pool|pg-protocol|pg-types|pg-int8|pgpass)\//.test(f.url))return'PostgreSQL driver';if(f.url.startsWith('<APP>/scripts/load/')||f.url.startsWith('<HARNESS>/scripts/load/'))return'harness';if(f.url.startsWith('<APP>/dist/')||f.url.startsWith('<APP>/src/'))return'application';if(f.url.includes('/node_modules/'))return'other dependencies';if(f.url.startsWith('node:'))return'Node JavaScript';return'native/V8/other';};
const exclusive=new Map(),inclusive=new Map(),categories=new Map(),callers=new Map();
const add=(map,key,us)=>{const row=map.get(key)||{microseconds:0,samples:0};row.microseconds+=us;row.samples++;map.set(key,row);};
const families=[['Drizzle entity.is',f=>f.name==='is'&&f.url.includes('/drizzle-orm/entity')],['Drizzle prepare',f=>f.name==='_prepare'&&f.url.includes('/drizzle-orm/')],['Drizzle SQL building',f=>/^(?:buildQueryFromSourceParams|prepareFields|orderSelectedFields)$/.test(f.name)&&f.url.includes('/drizzle-orm/')],['Drizzle database construction',f=>f.name==='PgDatabase'],['Node writev',f=>f.name==='writev']];
let time=profile.startTime,total=0,count=0,coveredEnd=profile.startTime;const clockAnomalies=[];
for(let i=0;i<profile.samples.length;i++){
 const delta=profile.timeDeltas[i];assert.ok(Number.isFinite(delta));
 const end=time+delta;if(delta<0)clockAnomalies.push({index:i,deltaMicroseconds:delta});const intervalStart=Math.max(time,coveredEnd);const us=Math.max(0,Math.min(end,until)-Math.max(intervalStart,from));coveredEnd=Math.max(coveredEnd,end);time=end;if(!us)continue;
 total+=us;count++;const leaf=nodes.get(profile.samples[i]);assert.ok(leaf);
 add(exclusive,frameKey(leaf),us);add(categories,category(leaf),us);
 const stack=[],seenIds=new Set(),seenFrames=new Set();let node=leaf;
 while(node){assert.ok(!seenIds.has(node.id),'Profile parent cycle');seenIds.add(node.id);stack.push(node);const key=frameKey(node);if(!seenFrames.has(key)){seenFrames.add(key);add(inclusive,key,us);}node=nodes.get(parents.get(node.id));}
 for(const[label,predicate]of families){const at=stack.findIndex(n=>predicate(frame(n)));if(at>=0)add(callers,JSON.stringify({family:label,stack:stack.slice(at,at+16).map(frame)}),us);}
}
assert.ok(total>0);assert.equal([...categories.values()].reduce((n,row)=>n+row.microseconds,0),total);
const rank=(map,decode=true)=>[...map].map(([key,row])=>({...decode?JSON.parse(key):{name:key},...row,milliseconds:row.microseconds/1000,percentOfSampledWall:100*row.microseconds/total})).sort((a,b)=>b.microseconds-a.microseconds);
const rankedExclusive=rank(exclusive),rankedInclusive=rank(inclusive),rankedCallers=rank(callers);
const analysis={schemaVersion:2,clockAnomalies,clockAnomalyTreatment:"Preserve raw cumulative timestamps; discard reversed intervals and overlapping microseconds using a monotonic union. Raw profile unchanged.",sourceRevision:result.sourceRevision,profileSha256:createHash('sha256').update(bytes).digest('hex'),analyzerSha256:createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).digest('hex'),
 window:{from,until,durationMs:(until-from)/1000,sampledMs:total/1000,uncoveredMs:((until-from)-total)/1000,acceptedSamples:count,totalProfileSamples:profile.samples.length,profileStart:profile.startTime,profileEnd:profile.endTime},
 semantics:['Weighted statistical wall-clock samples clipped to API reset through drained snapshot, excluding startup and later shutdown.','Exclusive categories partition every selected sample exactly once.','Inclusive frame and family/caller totals overlap and must never be added together.','Async continuations can omit the originating application caller; missing application ancestry is not proof the caller incurred no query construction.','Profiling changes runtime cost; this is diagnostic evidence, never capacity acceptance.','/app and Windows SchoolPilot roots normalize to<APP>; raw evidence remains unchanged.'],
 runtime:{apiCpuMicroseconds:phase.api.cpuMicroseconds,eventLoop:phase.api.eventLoop,phaseDurationMs:phase.durationMs,heartbeats:phase.traffic?.heartbeats,reports:phase.traffic?.reports?.length,drain:phase.serverDrain},
 exclusiveCategories:rank(categories,false),exclusive:rankedExclusive,inclusive:rankedInclusive,
 applicationExclusive:rankedExclusive.filter(row=>row.url.startsWith('<APP>/dist/')||row.url.startsWith('<APP>/src/')),
 applicationInclusive:rankedInclusive.filter(row=>row.url.startsWith('<APP>/dist/')||row.url.startsWith('<APP>/src/')),
 drizzleExclusive:rankedExclusive.filter(row=>row.url.includes('/node_modules/drizzle-orm/')),
 callers:rankedCallers};
const output=path.join(process.argv[3]||directory,'api-linux-clipped-analysis-02.json');assert.ok(!fs.existsSync(output),'Never replace completed analysis');fs.writeFileSync(output,JSON.stringify(analysis,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,profileSha256:analysis.profileSha256,window:analysis.window,exclusiveCategories:analysis.exclusiveCategories,topExclusive:analysis.exclusive.slice(0,15),topApplicationInclusive:analysis.applicationInclusive.slice(0,15),topDrizzleExclusive:analysis.drizzleExclusive.slice(0,12),topCallerFamilies:families.map(([family])=>({family,rows:analysis.callers.filter(row=>row.family===family).slice(0,3)}))},null,2));
