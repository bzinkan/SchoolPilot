$ErrorActionPreference='Stop'
$here=$PSScriptRoot
$selectors=@('BUILDX_BUILDER','DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS')
$saved=@{}
foreach($selector in $selectors){$saved[$selector]=[Environment]::GetEnvironmentVariable($selector,'Process');[Environment]::SetEnvironmentVariable($selector,$null,'Process')}
try {
 $source='204ae93d0869f4fe6dda33e663a4f91d5321eee7'
 $context=Join-Path $env:TEMP 'release297-linux-204-context-01'
 $hostFixture=Join-Path $env:TEMP 'release297-linux-204-host-01'
 $candidateEvidence=Join-Path $env:TEMP 'schoolpilot-image-scan-um7qsf'
 $receipt=Get-Content -LiteralPath (Join-Path $candidateEvidence 'candidate-preparation.json') -Raw | ConvertFrom-Json
 if($receipt.passed -ne $true -or $receipt.source -cne $source){throw 'Exact passing current candidate required.'}
 $expected='sha256:4066722ba79c20ca6bf26bf8a30753298a3c9af9a7432059bb7bccaa5af77278'
 if($receipt.image.imageId -cne $expected){throw 'Candidate image mismatch.'}
 $endpoint='npipe:////./pipe/dockerDesktopLinuxEngine'
 $before=(docker --host $endpoint image inspect $receipt.tag | ConvertFrom-Json)[0]
 if($LASTEXITCODE -ne 0 -or $before.Id -cne $expected){throw 'Candidate local tag changed.'}
 $build=Join-Path $env:TEMP 'release297-linux-helper-204-combined-build-01'
 if(Test-Path -LiteralPath $build){throw 'Fresh helper artifact directory required.'}
 New-Item -ItemType Directory -Path $build | Out-Null
 $tag='schoolpilot-linux-combined-local:204ae93d0869-01'
 [ordered]@{source=$source;candidate=$expected;candidateReceiptSha256=(Get-FileHash -LiteralPath (Join-Path $candidateEvidence 'candidate-preparation.json')).Hash.ToLower();tag=$tag;diagnosticOnly=$true;capacityAccepted=$false;cpuProfiler=$false;sqlShapeInstrumentation=$false;startedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $build 'build-binding.json')
 docker --host $endpoint build --builder default --pull=false --platform linux/amd64 --build-arg "CANDIDATE_IMAGE=$($receipt.tag)@$expected" --label "org.opencontainers.image.revision=$source" --label "codex.usage-linux.candidate=$expected" --label 'codex.usage-linux.profile=combined-diagnostic-only' --tag $tag --iidfile (Join-Path $build 'image-id.txt') --file (Join-Path $context 'Dockerfile.prototype') $context *> (Join-Path $build 'build.log')
 $buildExit=$LASTEXITCODE
 $after=(docker --host $endpoint image inspect $receipt.tag | ConvertFrom-Json)[0]
 if($LASTEXITCODE -ne 0 -or $after.Id -cne $expected){throw 'Candidate changed during build.'}
 if($buildExit -ne 0){throw 'Combined helper build failed; preserve artifact log.'}
 node (Join-Path $here 'bind-helper-image.mjs') $context $build $candidateEvidence $hostFixture *> (Join-Path $build 'runtime-proof.log')
 if($LASTEXITCODE -ne 0){throw 'Combined helper exact runtime/source proof failed.'}
 Write-Output $build
} finally {
 foreach($selector in $selectors){[Environment]::SetEnvironmentVariable($selector,$saved[$selector],'Process')}
}
