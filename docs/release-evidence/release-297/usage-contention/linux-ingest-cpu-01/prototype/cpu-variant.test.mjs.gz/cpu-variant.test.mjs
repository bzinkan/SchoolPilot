import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,rmSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {linuxPlan,patchProfile,PROFILE,cleanupOwned} from './prototype-core.mjs';
import {validateRelease,waitForRelease} from './measurement-gate.mjs';
const here=dirname(fileURLToPath(import.meta.url)),base=resolve(here,'../release297-linux-d649-context-02/clean-source/scripts/load/usage');
const read=p=>readFileSync(p,'utf8').replaceAll('\r\n','\n');
const source='d6492333520608df1524c021999d9440a26149de',run='123456abcdef',imageId='sha256:'+'a'.repeat(64),pgContainerId='b'.repeat(64);
const environment={NODE_ENV:'test',USAGE_LOCAL_SCALE:'1',USAGE_SOURCE_REVISION:source,USAGE_SCALE_CONTAINER:'schoolpilot-usage-scale-'+run,REDIS_URL:'redis://127.0.0.1:6387',AWS_SECRET_ACCESS_KEY:'never-forward',NODE_OPTIONS:'never-forward'};
for(const key of ['DATABASE_URL','ADMIN_DATABASE_URL','DATABASE_URL_PRIVILEGED'])environment[key]='postgresql://[REDACTED]@127.0.0.1:5437/schoolpilot_redesign_usage_scale_'+run;
test('full ingest CPU variant keeps 6000 offers and all original acceptance predicates',async()=>{
 const original=read(resolve(base,'release-enabled-profile.mjs'));
 let patched=patchProfile(original);
 const section=s=>s.slice(s.indexOf('export function capacityAcceptance'),s.indexOf('export function releaseTrafficOptions'));
 assert.equal(section(original),section(patched));
 patched=patched.replace("import { COLD_OPEN_LOOP_PROFILE } from './cold-open-loop-profile.mjs';","const COLD_OPEN_LOOP_PROFILE={httpOffering:{requestsPerSecond:100,durationMs:60000}};")
  .replace("import { releaseServerIsIdle } from './release-enabled-drain.mjs';",'const releaseServerIsIdle=()=>true;');
 const mod=await import('data:text/javascript;base64,'+Buffer.from(patched).toString('base64'));
 const env={USAGE_RELEASE_LINUX_DIAGNOSTIC:'true',USAGE_RELEASE_DIAGNOSTIC:'true',USAGE_RELEASE_CPU_PROFILE:'true',USAGE_RELEASE_PHASE:'ingest'};
 assert.deepEqual(mod.releaseTrafficOptions(env),{});
 assert.equal(mod.RELEASE_ENABLED_PROFILE.httpOffering.requestsPerSecond*mod.RELEASE_ENABLED_PROFILE.httpOffering.durationMs/1000,6000);
 assert.equal(mod.RELEASE_ENABLED_PROFILE.reportOffers.total,64);assert.equal(mod.capacityAcceptance({diagnosticOnly:true,cpuProfile:{enabled:true}}).acceptanceRun,false);
 assert.throws(()=>mod.releaseTrafficOptions({...env,USAGE_RELEASE_PHASE:'combined'}));
 assert.throws(()=>mod.releaseTrafficOptions({...env,USAGE_RELEASE_CPU_PROFILE:'false'}));
 assert.equal(mod.RELEASE_ENABLED_PROFILE.name,PROFILE);
});
test('plan enforces ingest CPU and same fixed resource and credential boundaries',()=>{
 const plan=linuxPlan({run,source,imageId,pgContainerId,evidenceDirectory:'C:/Users/Test User/Evidence',env:environment});
 assert.equal(plan.childEnv.USAGE_RELEASE_PHASE,'ingest');assert.equal(plan.childEnv.USAGE_RELEASE_CPU_PROFILE,'true');
 assert.equal(plan.childEnv.USAGE_RELEASE_DIAGNOSTIC,'true');assert.equal(plan.receipt.capacityAccepted,false);
 assert.equal(plan.childEnv.AWS_SECRET_ACCESS_KEY,undefined);assert.equal(plan.childEnv.NODE_OPTIONS,undefined);
 assert.ok(plan.args.includes('type=bind,source=C:/Users/Test User/Evidence,target=/evidence'));assert.ok(plan.args.includes('--read-only'));
 assert.ok(plan.args.includes('--max-old-space-size=512'));assert.ok(!plan.args.includes('--cpus'));
 assert.throws(()=>linuxPlan({run,source,imageId,pgContainerId,evidenceDirectory:'x',env:{...environment,DATABASE_URL:environment.DATABASE_URL+'?host=remote'}}));
});
test('fresh release validates exact run/source/image/nonce and cannot claim capacity',()=>{
 const ready={schemaVersion:1,run,source,imageId,nonce:'nonce'};
 const go={...ready,action:'release-diagnostic-measurement',diagnosticOnly:true,capacityAccepted:false};
 validateRelease(ready,go);
 for(const key of ['run','source','imageId','nonce'])assert.throws(()=>validateRelease(ready,{...go,[key]:'wrong'}));
 assert.throws(()=>validateRelease(ready,{...go,capacityAccepted:true}));
});
test('gate has no automatic elapsed-time release, preserves bounded failure',async()=>{
 const output=mkdtempSync(resolve(tmpdir(),'release297-cpu-gate-test-'));let clock=0;
 try{await assert.rejects(waitForRelease({output,run,source,imageId,timeoutMs:3,intervalMs:1,now:()=>clock,sleep:async()=>{clock++;}}),/MEASUREMENT_RELEASE_EXPIRED/);
  assert.ok(existsSync(resolve(output,'measurement-ready.json')));assert.equal(existsSync(resolve(output,'measurement-release-receipt.json')),false);
 }finally{rmSync(output,{recursive:true});}
});
test('gate accepts only fresh exact marker and retains its receipt',async()=>{
 const output=mkdtempSync(resolve(tmpdir(),'release297-cpu-gate-test-'));let clock=0;
 try{await waitForRelease({output,run,source,imageId,timeoutMs:3,intervalMs:1,now:()=>clock,sleep:async()=>{
  clock++;const ready=JSON.parse(read(resolve(output,'measurement-ready.json')));
  writeFileSync(resolve(output,'measurement-go.json'),JSON.stringify({...ready,action:'release-diagnostic-measurement'}),{flag:'wx'});
 }});assert.ok(existsSync(resolve(output,'measurement-release-receipt.json')));
 await assert.rejects(waitForRelease({output,run,source,imageId}),/Preexisting release marker refused/);
 }finally{rmSync(output,{recursive:true});}
});
test('runner gate precedes cold restart and launching; old workload runner untouched',()=>{
 const runner=read(resolve(here,'run-linux-ingest-cpu.ps1'));
 const gate=runner.indexOf("node (Join-Path $prototypeDirectory 'measurement-gate.mjs')");
 assert.ok(gate>runner.indexOf('Canonical release control preparation failed'));
 assert.ok(gate<runner.indexOf('restart $container'));assert.ok(gate<runner.indexOf("'launch-linux-diagnostic.mjs'"));
 assert.match(runner,/\$Phase -cne 'ingest' -or -not \$CollectApiCpuProfile/);
 assert.match(runner,/--cpus 4 --memory 4g/);
});
test('coordinator retains exact shutdown/profile collection and cleanup failure',()=>{
 const text=read(resolve(here,'context/overlay/scripts/load/usage/release-enabled-scale.mjs'));
 assert.match(text,/'--cpu-prof', `--cpu-prof-dir=\$\{directory\}`/);
 assert.match(text,/owner\.rpc\('shutdown', undefined, 15_000\)/);
 assert.ok(text.indexOf('const exit = await owner.closed')<text.indexOf("readFileSync(resolve(directory, 'api.cpuprofile'))"));
 assert.match(text,/profile\.samples\?\.length > 0/);assert.match(text,/metrics\.capacityAccepted = false; \/\/ Never accepted/);
 assert.match(text,/metrics\.diagnosticTrafficPassed = true/);assert.match(text,/owner\.process\.kill\('SIGKILL'\)/);
 assert.match(text,/sourceClean, true/);assert.match(text,/const root = '\/source'/);assert.match(text,/cwd: '\/app'/);
});
test('cleanup still requires exact owner and confirmed removal',async()=>{
 const owner={run,name:'owned',imageId,imageIdentities:[imageId],pgContainerId};
 const wrong={Name:'/owned',Config:{Image:imageId,Labels:{'codex.usage-scale':'other'}},State:{Running:true}};
 let mutations=0;const result=await cleanupOwned({inspect:async()=>wrong,kill:async()=>mutations++,remove:async()=>mutations++},owner);
 assert.equal(result.cleanupPassed,false);assert.equal(mutations,0);
});
test('helper build pins local default builder and restores inherited selectors',()=>{
 const build=read(resolve(here,'build-cpu-helper.ps1'));
 assert.match(build,/--host \$endpoint build --builder default/);
 for(const name of ['BUILDX_BUILDER','DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS'])assert.ok(build.includes("'"+name+"'"));
 assert.match(build,/SetEnvironmentVariable\(\$selector,\$null,'Process'\)/);
 assert.match(build,/finally \{[\s\S]*SetEnvironmentVariable\(\$selector,\$savedSelectors\[\$selector\],'Process'\)/);
});
