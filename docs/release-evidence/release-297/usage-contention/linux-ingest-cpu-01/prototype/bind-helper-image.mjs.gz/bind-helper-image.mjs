import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {randomUUID,createHash} from 'node:crypto';
import {readFileSync,writeFileSync,copyFileSync,createReadStream} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {archiveIdentities} from '../release297-final-candidate-preparation-01/archive-identities.mjs';
const [context,build,candidateEvidence,hostClone]=process.argv.slice(2);assert.ok(context&&build&&candidateEvidence&&hostClone);
const here=dirname(fileURLToPath(import.meta.url)),endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
const read=file=>JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const candidate=read(resolve(candidateEvidence,'candidate-preparation.json'));assert.equal(candidate.passed,true);
const source=candidate.source,imageId=readFileSync(resolve(build,'image-id.txt'),'utf8').trim();assert.match(imageId,/^sha256:[a-f0-9]{64}$/);
const helper=await import(pathToFileURL(resolve(candidateEvidence,'reviewed-legacy-image-gate.mjs')));
const env={...process.env};for(const key of ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS'])delete env[key];
const invoke=(args,timeout=30000)=>execFileSync('docker',['--host',endpoint,...args],{env,timeout,encoding:'utf8',maxBuffer:16*1024*1024,stdio:['ignore','pipe','pipe'],windowsHide:true});
const clean=path=>{assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:path,encoding:'utf8'}).trim(),source);assert.equal(execFileSync('git',['status','--porcelain'],{cwd:path,encoding:'utf8'}).trim(),'');};
clean(resolve("C:\\Users\\zinka\\AppData\\Local\\Temp\\release297-linux-d649-context-02",'clean-source'));clean(hostClone);
const image=JSON.parse(invoke(['image','inspect',imageId]));helper.inspectImage(image,imageId,source);
assert.equal(image[0].Config.Labels['codex.usage-linux.candidate'],candidate.image.imageId);
writeFileSync(resolve(build,'image-inspect.json'),JSON.stringify(image,null,2)+'\n',{flag:'wx'});
invoke(['image','save','--output',resolve(build,'image.tar'),imageId],600000);
const configDigest=await helper.archiveConfigDigest(resolve(build,'image.tar'),source);
const identities=archiveIdentities(resolve(build,'image.tar'),imageId,configDigest);
const digest=createHash('sha256');for await(const chunk of createReadStream(resolve(build,'image.tar')))digest.update(chunk);
const archiveSha256=digest.digest('hex');
const name='schoolpilot-linux-runtime-proof-'+randomUUID(),ownership=randomUUID();
let attempted=false,passed=false,proof,cleanupPassed=false;
const proofPath=resolve(build,'runtime-probe.mjs');copyFileSync(resolve(here,'runtime-probe.mjs'),proofPath);
try{
  attempted=true;
  const stdout=invoke(['run','--rm','--name',name,'--label',`codex.usage-linux-proof=${ownership}`,
    '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--no-healthcheck','--workdir','/app',
    '--mount',`type=bind,source=${proofPath.replaceAll('\\','/')},target=/runtime-probe.mjs,readonly`,'--entrypoint','node',imageId,'/runtime-probe.mjs'],60000);
  proof=JSON.parse(stdout);assert.equal(proof.passed,true);assert.equal(proof.applicationSource,source);assert.equal(proof.candidateImageId,candidate.image.imageId);
  writeFileSync(resolve(build,'runtime-source-proof.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
  clean(resolve("C:\\Users\\zinka\\AppData\\Local\\Temp\\release297-linux-d649-context-02",'clean-source'));clean(hostClone);passed=true;
}catch(error){writeFileSync(resolve(build,'runtime-proof-failure.json'),JSON.stringify({passed:false,message:String(error.message).slice(0,1200)},null,2)+'\n',{flag:'wx'});process.exitCode=1;}
finally{
  try{
    const matches=invoke(['container','ls','--all','--filter',`name=^/${name}$`,'--format','{{.ID}}']).trim().split('\n').filter(Boolean);assert.ok(matches.length<=1);
    if(matches.length){const found=JSON.parse(invoke(['container','inspect',matches[0]]))[0];assert.equal(found.Name,'/'+name);assert.equal(found.Config.Labels['codex.usage-linux-proof'],ownership);
      assert.equal(found.Config.Image,imageId);assert.ok([identities.imageId,identities.platformManifestDigest,identities.configDigest].includes(found.Image));invoke(['container','rm','--force',found.Id]);}
    assert.equal(invoke(['container','ls','--all','--filter',`name=^/${name}$`,'--format','{{.ID}}']).trim(),'');cleanupPassed=true;
  }catch{passed=false;process.exitCode=1;}
  const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
  const result={schemaVersion:1,passed,prototypeValidated:passed&&cleanupPassed,applicationSource:source,candidateImageId:candidate.image.imageId,
    candidateConfigDigest:candidate.image.configDigest,candidateScanReceiptSha256:hash(resolve(candidateEvidence,'scan-receipt.json')),
    diagnosticImageId:imageId,diagnosticImageIdentities:[identities.imageId,identities.platformManifestDigest,identities.configDigest],
    diagnosticImage:identities,archiveSha256,runtimeSourceProofSha256:proof?hash(resolve(build,'runtime-source-proof.json')):null,
    harnessBindingSha256:hash(resolve(context,'overlay/binding.json')),diagnosticOnly:true,capacityAccepted:false,cleanupPassed,
    hostFixture:hostClone,sourceClone:resolve("C:\\Users\\zinka\\AppData\\Local\\Temp\\release297-linux-d649-context-02",'clean-source'),context,build,helperImageVulnerabilityScan:'not performed; diagnostic image is not a release artifact',
    productionMutations:0,registryPushes:0,measurementsRun:0,finishedAt:new Date().toISOString()};
  writeFileSync(resolve(build,'diagnostic-image-binding.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({passed,cleanupPassed,binding:resolve(build,'diagnostic-image-binding.json'),image:identities}));
}
