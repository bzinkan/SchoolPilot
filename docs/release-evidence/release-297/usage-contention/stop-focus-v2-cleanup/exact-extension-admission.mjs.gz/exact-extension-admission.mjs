import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const root = process.cwd(), ext = '<CLASSPILOT_WORKTREE>';
const imp = name => import(pathToFileURL(`${root}/src/${name}.ts`));
const {classpilotCommandFrameForTarget:make}=await imp('services/classpilotCommandDispatcher');
const {emptyClasspilotRestrictions}=await imp('services/classpilotClassroomState');
const source=fs.readFileSync(`${ext}/extension/service-worker.js`,'utf8');
const exact=source.slice(source.indexOf('function exactStudentBinding('),source.indexOf('\nfunction schoolPolicyScope(',source.indexOf('function exactStudentBinding(')));
const guard=source.slice(source.indexOf('function assertCurrentStudentBinding('),source.indexOf('\nfunction acceptsCurrentStudentBinding(',source.indexOf('function assertCurrentStudentBinding(')));
const context=vm.createContext({CONFIG:{schoolId:'school',deviceId:'device',activeStudentId:'student',activeStudentSessionId:'login'},studentAuthInvalidating:false,currentStudentControlRevision:()=>7});
vm.runInContext(`${exact}\n${guard}\nthis.admit=(frame)=>assertCurrentStudentBinding(frame,'produced Stop Focus',{requireFullAuthority:true});`,context);
const frame=make('school','stop-focus','stop-focus',{commandId:'stop'},{studentId:'student',studentName:'Student',studentSessionId:'login',deviceId:'device',available:true,controlRevision:6},{policy:'persistent_control',expiresAt:new Date('2026-10-02T12:01:00Z')},{schemaVersion:1,revision:7,teachingSessionId:'class',receivedAt:'2026-10-02T12:00:00Z',scheduledEndAt:null,hardExpiresAt:'2026-10-02T12:01:00Z',restrictions:emptyClasspilotRestrictions()},{authority:{teachingSessionId:'class',supervisionContextId:null},teachingSessionId:'class',supervisionContextId:null});
let admitted=false,errorCode=null;try{context.admit(frame);admitted=true;}catch(error){errorCode=error.code;}
const refusals=[];
if(admitted) for(const mutate of [f=>f.exactBinding.deviceId='wrong',f=>f.exactBinding.controlRevision=6,f=>f.command.exactBinding.studentSessionId='retired',f=>delete f.exactBinding.studentSessionId]) {const bad=structuredClone(frame);mutate(bad);assert.throws(()=>context.admit(bad));refusals.push(true);}
console.log(JSON.stringify({manifestVersion:JSON.parse(fs.readFileSync(`${ext}/extension/manifest.json`)).version,extensionSourceSha256:createHash('sha256').update(source).digest('hex'),parserSha256:createHash('sha256').update(exact).digest('hex'),fullAuthorityGuardSha256:createHash('sha256').update(guard).digest('hex'),frame,admitted,errorCode,refusedStaleWrongOrPartial:refusals.length,limitation:'Executes the exact 2.9.7 binding parser/full-authority gate used by handleRemoteControl; no browser or full handler side effects are simulated.'},null,2));
await (await imp('services/errorMonitor')).default.disposeAndWait();
const db=await imp('db'),scheduler=await imp('services/schedulerDb');await Promise.all([db.pool.end(),db.sessionPool.end(),scheduler.schedulerPool.end(),scheduler.schedulerLockPool.end()]);
