import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {randomBytes,createHash} from 'node:crypto';
const directory=dirname(fileURLToPath(import.meta.url)),output=join(directory,'attempt-01');mkdirSync(output);
const bindingFile=join(directory,'../release297-role-e95-ingest-cpu-build-01/role-image-binding.json'),binding=JSON.parse(readFileSync(bindingFile));
const hash=x=>createHash('sha256').update(x).digest('hex');
const run=randomBytes(6).toString('hex'),name='schoolpilot-three-fence-'+run;
const docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe',endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
const env={...process.env};for(const key of Object.keys(env))if(/^DOCKER_|^BUILDX_BUILDER$/.test(key))delete env[key];
const save=(name,value)=>writeFileSync(join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const files=['benchmark.mjs','templates.json','fixed-scalar.mjs','extraction.json','run.mjs'];
const hashes=Object.fromEntries(files.map(f=>[f,hash(readFileSync(join(directory,f)))]));
const call=(args,timeout=30000)=>{const r=spawnSync(docker,['--host',endpoint,...args],{env,encoding:'utf8',timeout,maxBuffer:4*1024*1024});if(r.status!==0)throw Object.assign(Error('THREE_FENCE_DOCKER_FAILED'),{code:'THREE_FENCE_DOCKER_FAILED',status:r.status});return r.stdout;};
const find=()=>{const ids=call(['ps','-a','--no-trunc','--filter','name=^/'+name+'$','--format','{{.ID}}']).trim().split(/\r?\n/).filter(Boolean);assert.ok(ids.length<=1);return ids.length?JSON.parse(call(['inspect',ids[0]]))[0]:null;};
const verify=x=>{assert.equal(x.Name,'/'+name);assert.equal(x.Config.Labels['codex.three-fence'],run);assert.equal(x.Config.Image,binding.roleImageId);assert.equal(x.Image,binding.runtimeConfigDigest);assert.equal(x.HostConfig.NetworkMode,'none');assert.equal(x.HostConfig.NanoCpus,1e9);assert.equal(x.HostConfig.Memory,2*1024**3);assert.equal(x.HostConfig.MemorySwap,2*1024**3);assert.equal(x.Config.User,'node');assert.equal(x.HostConfig.ReadonlyRootfs,true);assert.equal(x.Config.WorkingDir,'/app');assert.deepEqual(x.Config.Entrypoint,['node']);assert.deepEqual(x.Config.Cmd,['--expose-gc','/trial/benchmark.mjs']);assert.equal((x.Config.Env??[]).some(v=>v.startsWith('NODE_OPTIONS=')),false);};
let id=null,passed=false;
try{
 assert.equal(find(),null);const args=['create','--name',name,'--label','codex.three-fence='+run,'--network','none','--cpus','1','--memory','2g','--memory-swap','2g','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--init','--no-healthcheck','--user','node','--workdir','/app','--mount',`type=bind,source=${directory},target=/trial,readonly`,'--mount',`type=bind,source=${output},target=/result`,'--entrypoint','node',binding.roleImageId,'--expose-gc','/trial/benchmark.mjs'];
 save('plan.json',{run,name,args,source:binding.applicationSource,bindingSha256:hash(readFileSync(bindingFile)),runtimeSha256:binding.runtimeSha256,hashes,capacityAccepted:false,purpose:'Compile-only public API trial, no network or database. Expose-gc only; candidate default heap unchanged.'});
 try{call(args);}finally{const found=find();if(found){verify(found);id=found.Id;}}
 assert.ok(id);const initial=find();verify(initial);save('initial-inspect.json',initial);
 const capture=spawnSync(docker,['--host',endpoint,'start','--attach',id],{env,encoding:'utf8',timeout:120000,maxBuffer:4*1024*1024});writeFileSync(join(output,'stdout.log'),capture.stdout??'');writeFileSync(join(output,'stderr.log'),capture.stderr??'');
 const final=find();verify(final);save('final-inspect.json',final);assert.equal(capture.status,0);assert.equal(final.State.Running,false);assert.equal(final.State.ExitCode,0);assert.equal(final.State.OOMKilled,false);
 const result=JSON.parse(readFileSync(join(output,'result.json')));assert.equal(result.source,binding.applicationSource);assert.equal(result.node,'v22.23.3');assert.equal(result.realDatabaseCalls,0);assert.equal(result.parity.length,18);assert.equal(result.rounds.length,30);assert.equal(result.capacityAccepted,false);
 for(const[file,expected]of Object.entries(hashes))assert.equal(hash(readFileSync(join(directory,file))),expected);
 save('verification.json',{passed:true,source:binding.applicationSource,imageId:binding.roleImageId,runtimeSha256:binding.runtimeSha256,containerId:id,exitCode:0,forced:false,resultSha256:hash(readFileSync(join(output,'result.json'))),hashes,capacityAccepted:false});passed=true;
 process.stdout.write(JSON.stringify({output,summary:result.summary,parity:result.parity.length,capacityAccepted:false})+'\n');
}finally{
 const found=find();if(found){verify(found);if(id)assert.equal(found.Id,id);id=found.Id;call(['rm','--force','--volumes',id]);}assert.equal(find(),null);save('cleanup.json',{run,id,confirmedAbsent:true,cleanupPassed:true,proofPassed:passed,capacityAccepted:false});
}
