import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,statSync,existsSync} from 'node:fs';
import {resolve,relative,dirname,isAbsolute} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import os from 'node:os';
const root=os.tmpdir(),output=resolve(root,'release297-linux-ingest-cpu-external-evidence-01');assert.equal(existsSync(output),false);
mkdirSync(output);const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),rows=[];
const sanitize=text=>text.replace(/\b(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]*@/gi,value=>value.replace(/\/\/.*@/,'//[REDACTED]@'))
  .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'[REDACTED_JWT]')
  .replace(/(authorization\s*[:=]\s*(?:bearer\s+)?)[^\s"',}]+/gi,'$1[REDACTED]')
  .replace(/\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/gi,'[SYNTHETIC_ID_REDACTED]');
function archive(path,key){
  const raw=readFileSync(path),rawSha256=sha(raw);
  if(path.endsWith('cold-fixture-state.json')){rows.push({key,path,bytes:raw.length,rawSha256,contentArchived:false,reason:'Synthetic fixture identity state excluded'});return;}
  const clean=Buffer.from(sanitize(raw.toString('utf8'))),compressed=gzipSync(clean,{level:9}),target=resolve(output,key+'.gz');
  const contained=relative(output,target);assert.ok(contained&&!isAbsolute(contained)&&!contained.split(/[\\/]/).includes('..'));
  mkdirSync(dirname(target),{recursive:true});writeFileSync(target,compressed,{flag:'wx'});
  rows.push({key,path,bytes:raw.length,rawSha256,sanitizedBytes:clean.length,sanitizedSha256:sha(clean),gzipSha256:sha(compressed),archive:relative(output,target).replaceAll('\\','/'),redacted:!raw.equals(clean)});
}
function directory(path,key){for(const entry of readdirSync(path,{withFileTypes:true})){const child=resolve(path,entry.name),next=key+'/'+entry.name;if(entry.isDirectory())directory(child,next);else if(entry.name!=='image.tar')archive(child,next);}}
directory(resolve(root,'release297-linux-ingest-cpu-design-01'),'prototype');
directory(resolve(root,'release297-linux-helper-d649-ingest-cpu-build-01'),'helper-build');
directory(resolve(root,'release297-enabled-linux-ingest-cpu-01'),'ingest-cpu01');
archive(resolve(root,'release297-enabled-linux-ingest-cpu-01-runner.log'),'ingest-cpu01/runner.log');
// Phase-clipped analysis is still being finalized in a separate external directory; archive it separately after its owner freezes it.
const imageBinding=JSON.parse(readFileSync(resolve(root,'release297-linux-helper-d649-ingest-cpu-build-01/diagnostic-image-binding.json'),'utf8'));
const imagePath=resolve(root,'release297-linux-helper-d649-ingest-cpu-build-01/image.tar');
rows.push({key:'helper-build/image.tar',path:imagePath,bytes:statSync(imagePath).size,contentArchived:false,rawSha256:imageBinding.archiveSha256,hashSource:'Verified image-export binding; not rehashed during this text archival pass'});
const metrics=JSON.parse(readFileSync(resolve(root,'release297-enabled-linux-ingest-cpu-01/usage-scale.json'),'utf8')),phase=metrics.phases[0];
const summary={source:metrics.sourceRevision,profile:metrics.profile.name,diagnosticOnly:true,capacityAccepted:false,passed:false,failure:metrics.failure,
  heartbeats:phase.traffic.heartbeats,cpuProfile:metrics.cpuProfile,apiAcquisitions:phase.api.database.acquisitions,
  apiCpuMicroseconds:phase.api.cpuMicroseconds,apiEventLoop:phase.api.eventLoop,serverDrain:phase.serverDrain,
  childShutdownClean:metrics.childShutdownClean,allOwnedContainersCleanup:JSON.parse(readFileSync(resolve(root,'release297-enabled-linux-ingest-cpu-01/all-owned-linux-fixtures-cleanup.json'),'utf8')),
  currentDayAndCsvVerificationCompleted:false,reportsOrWorkersMeasured:false,
  exactCommand:'pwsh -NoProfile -File ./run-linux-ingest-cpu.ps1 -SourceRepository C:/Users/zinka/AppData/Local/Temp/release297-linux-d649-host-02 -DiagnosticImageManifest C:/Users/zinka/AppData/Local/Temp/release297-linux-helper-d649-ingest-cpu-build-01/diagnostic-image-binding.json -SchemaDatabase schoolpilot_redesign_usage_release297_20261002 -OutputDirectory C:/Users/zinka/AppData/Local/Temp/release297-enabled-linux-ingest-cpu-01 -Phase ingest -CollectApiCpuProfile',
  commandCwd:resolve(root,'release297-linux-ingest-cpu-design-01'),
  caveat:'Historical d649 application source before pending inbox projection. Linux shared namespace, no hard per-role CPU/RSS; profiler overhead; not production task capacity.'};
writeFileSync(resolve(output,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const manifest={schemaVersion:1,createdAt:new Date().toISOString(),externalOnly:true,primaryRepositoryWrites:0,
  status:'Failed full-offer Linux ingest diagnostic with successfully collected CPU profile; no deployment/capacity acceptance',
  sanitation:['credential-bearing URL prefixes','JWTs','authorization values','synthetic UUID identities'],
  sourceContentsUnmodified:true,summarySha256:sha(readFileSync(resolve(output,'summary.json'))),files:rows};
writeFileSync(resolve(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,files:rows.length,manifestSha256:sha(readFileSync(resolve(output,'manifest.json')))}));
