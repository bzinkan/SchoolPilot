// PREPARED ONLY. Run after the parent releases the capacity freeze. Local image
// build/export/scan only; no deploy.sh, AWS, ECR login/push, or task registration.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {randomUUID,createHash} from 'node:crypto';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {resolve,dirname,basename} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {archiveIdentities} from './archive-identities.mjs';
import {proveFloor} from './prove-synthetic-floor.mjs';
const [repositoryArgument,source]=process.argv.slice(2);
assert.ok(repositoryArgument);assert.match(source,/^[a-f0-9]{40}$/);
const repository=resolve(repositoryArgument),here=dirname(fileURLToPath(import.meta.url));
const endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
assert.equal(process.platform,'win32','This prepared command pins the reviewed local Windows Docker endpoint.');
const git=args=>execFileSync('git',args,{cwd:repository,encoding:'utf8',windowsHide:true,timeout:30_000}).trim();
const clean=()=>{assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'','Exact completely clean source required');};
clean();process.chdir(repository);
const saved=new Map(['BUILDX_BUILDER','DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_TLS'].map(key=>[key,process.env[key]]));
for(const key of saved.keys())delete process.env[key];process.env.DOCKER_HOST=endpoint;
const helperPath=resolve(repository,'scripts/verify-legacy-deploy-image.mjs');
const helper=await import(pathToFileURL(helperPath));
assert.equal(helper.SCANNER,'aquasec/trivy@sha256:af6acf9a6b85dfe389a1941505c0ce9efef52a4719635e1a962f022a3d855daa');
const evidence=helper.createEvidenceDirectory(source),tag=`schoolpilot-candidate-local:${source.slice(0,12)}-${Date.now()}`;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const write=(name,value)=>writeFileSync(resolve(evidence,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const run=async(args,log,{timeout=120000}={})=>{
  const result=await helper.runCommand('docker',['--host',endpoint,...args],{timeout});
  if(log){writeFileSync(resolve(evidence,log),result.stdout+'\n'+result.stderr,{flag:'wx'});}
  assert.equal(result.code,0,`Local Docker stage failed: ${log??args[0]}`);return result.stdout;
};
const receipt={schemaVersion:1,source,startedAt:new Date().toISOString(),passed:false,localOnly:true,sourceInitiallyClean:true,
  dockerEndpoint:endpoint,tag,scanner:helper.SCANNER,gate:'All HIGH and CRITICAL findings, including unfixed',
  productionMutations:0,registryPushes:0,taskRegistrations:0,usageActivationApproved:false,capacityAcceptance:false,diagnosticOnly:true,finalReleaseArtifactSelected:false,buildMode:'Fresh local build with --pull --no-cache; exact source/runtime/scan guards retained; final artifact selection awaits capacity and release checks',
  scope:'Exact local candidate artifact preparation. Does not replace final CI, actual production catalog/admission, rollback rehearsal, or live acceptance.'};
let inspectorAttempted=false,inspectorImage,inspectorName=`schoolpilot-candidate-proof-${randomUUID()}`,inspectorOwnership=randomUUID();
try{
  for(const name of [basename(fileURLToPath(import.meta.url)),'archive-identities.mjs','prove-synthetic-floor.mjs','inspect-compatibility.mjs'])copyFileSync(resolve(here,name),resolve(evidence,name));
  copyFileSync(helperPath,resolve(evidence,'reviewed-legacy-image-gate.mjs'));
  receipt.imageGateSourceSha256=sha(readFileSync(helperPath));
  await helper.verifyCleanSource(source);
  await run(['build','--builder','default','--pull','--no-cache','--platform','linux/amd64','--label',`org.opencontainers.image.revision=${source}`,
    '--tag',tag,'--iidfile',resolve(evidence,'build-image-id.txt'),'--progress','plain','.'],'build.log',{timeout:1_800_000});
  clean();
  inspectorImage=readFileSync(resolve(evidence,'build-image-id.txt'),'utf8').trim();assert.match(inspectorImage,/^sha256:[a-f0-9]{64}$/);
  const inspected=JSON.parse(await run(['image','inspect',inspectorImage]));
  helper.inspectImage(inspected,inspectorImage,source);write('image-inspect.json',inspected);
  const scan=await helper.scanBuiltImage({directory:evidence,sourceSha:source,imageRef:tag});
  const scanReceipt=JSON.parse(readFileSync(scan.receiptPath,'utf8'));
  assert.equal(scanReceipt.passed,true);assert.equal(scanReceipt.counts.HIGH,0);assert.equal(scanReceipt.counts.CRITICAL,0);
  assert.equal(scanReceipt.gate,'All HIGH and CRITICAL findings block regardless of fix availability');
  receipt.scan=scan;receipt.image=archiveIdentities(resolve(evidence,'input/image.tar'),inspectorImage,scanReceipt.configDigest);
  receipt.exportSha256=scanReceipt.archiveSha256;receipt.fullScanSha256=scanReceipt.reportSha256;receipt.scanCounts=scanReceipt.counts;
  const mount=resolve(evidence,'inspect-compatibility.mjs').replaceAll('\\','/');assert.ok(!/[\r\n,]/.test(mount));
  inspectorAttempted=true;
  const proofText=await run(['run','--rm','--name',inspectorName,'--label',`codex.candidate-proof=${inspectorOwnership}`,
    '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--no-healthcheck',
    '--mount',`type=bind,source=${mount},target=/proof.mjs,readonly`,'--entrypoint','node',inspectorImage,'/proof.mjs'],
    'embedded-compatibility.log',{timeout:60000});
  const proof=JSON.parse(proofText);assert.equal(proof.passed,true);assert.equal(proof.inventoryCount,129);
  assert.equal(proof.usageDefaultAndExplicitModesOff,true);write('embedded-compatibility.json',proof);
  receipt.syntheticFloor=await proveFloor(repository,source,evidence,inspectorImage);
  clean();receipt.sourceUnchangedAtFinish=true;receipt.passed=true;
}catch(error){receipt.failure=String(error.message).slice(0,600);process.exitCode=1;}
finally{
  if(inspectorAttempted){
    try{
      const ids=(await run(['container','ls','--all','--filter',`name=^/${inspectorName}$`,'--format','{{.ID}}'])).trim().split('\n').filter(Boolean);
      assert.ok(ids.length<=1);
      if(ids.length){const found=JSON.parse(await run(['container','inspect',ids[0]]))[0];assert.equal(found.Name,`/${inspectorName}`);
        assert.equal(found.Config?.Labels?.['codex.candidate-proof'],inspectorOwnership);
        assert.equal(found.Config?.Image,inspectorImage);
        const verifiedIdentities=new Set([receipt.image.imageId,receipt.image.platformManifestDigest,receipt.image.configDigest]);
        assert.ok(verifiedIdentities.has(found.Image),'Container runtime digest must belong to the same verified saved image');
        await run(['container','rm','--force',found.Id]);}
      assert.equal((await run(['container','ls','--all','--filter',`name=^/${inspectorName}$`,'--format','{{.ID}}'])).trim(),'');
      receipt.inspectorCleanupPassed=true;
    }catch{receipt.inspectorCleanupPassed=false;receipt.passed=false;process.exitCode=1;}
  }
  receipt.finishedAt=new Date().toISOString();write('candidate-preparation.json',receipt);
  for(const[key,value]of saved){if(value===undefined)delete process.env[key];else process.env[key]=value;}
  console.log(JSON.stringify({evidence,source,passed:receipt.passed,image:receipt.image??null,localOnly:true}));
}
