# Local function-level validation; no wrapper main path and no AWS calls.
$ErrorActionPreference='Stop'
$repo='[USERPROFILE]\.codex\worktrees\release-stabilization-297\SchoolPilot'
$root=$PSScriptRoot
. (Join-Path $repo 'scripts/run-mydesk-readiness.ps1')
function Invoke-AwsJson { throw 'AWS is forbidden in this local validation' }
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'run-release-metadata-inspector.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Parse failed'}
foreach($function in $ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $function.Extent.Text}
$records=[Collections.Generic.List[object]]::new()
function Check([string]$Name,[scriptblock]$Action){& $Action;$records.Add(@{name=$Name;passed=$true})}
function Rejected([scriptblock]$Action){$failed=$false;try{& $Action | Out-Null}catch{$failed=$true};if(-not $failed){throw 'Expected rejection'}}
$events=Get-Content -LiteralPath (Join-Path $root 'synthetic-transport.json') -Raw | ConvertFrom-Json
Check 'Complete bounded transport with legitimate extension hyphen' { $r=Read-SafeMetadataPayload $events;if($r.inventory.extensions[0].name -cne 'uuid-ossp' -or -not $r.pilot.school.classpilotEntitled){throw 'Unexpected valid result'} }
Check 'Missing transport rejected' {Rejected {Read-SafeMetadataPayload @()}}
Check 'Duplicate transport rejected' {Rejected {Read-SafeMetadataPayload @($events[0],$events[0])}}
Check 'Payload hash mismatch rejected' { $x=$events|ConvertTo-Json -Depth 30|ConvertFrom-Json;$p=$x[0].message|ConvertFrom-Json;$p.payloadSha256='0'*64;$x[0].message=$p|ConvertTo-Json -Compress;Rejected {Read-SafeMetadataPayload $x} }
Check 'Case-changed keys rejected' {Rejected {Assert-MetadataProperties ([pscustomobject]@{Name='foo'}) @('name') 'fixture'}}
Check 'Unexpected metadata fields rejected' {Rejected {Assert-MetadataProperties ([pscustomobject]@{name='foo';secret='synthetic'}) @('name') 'fixture'}}
Check 'Missing metadata fields rejected' {Rejected {Assert-MetadataProperties ([pscustomobject]@{name='foo'}) @('name','kind') 'fixture'}}
$expectedDigest='sha256:c87433cdf3d88e0c291a50d1ae74fbc116f167048f7db9d6c2d1d0ebfc52b9e8'
$sourceText=[IO.File]::ReadAllText((Join-Path $root 'inspect-release-metadata.mjs'))
$worker=[pscustomobject]@{taskDefinition=[pscustomobject]@{family='synthetic';taskRoleArn='synthetic-app-role';executionRoleArn='synthetic-execution-role';networkMode='awsvpc';containerDefinitions=@([pscustomobject]@{name='scheduler-worker';image='synthetic';environment=@([pscustomobject]@{name='GIT_SHA';value='synthetic'});secrets=@([pscustomobject]@{name='DATABASE_URL';valueFrom='synthetic-secret-ref'},[pscustomobject]@{name='UNRELATED';valueFrom='synthetic-drop'});mountPoints=@();logConfiguration=[pscustomobject]@{logDriver='awslogs';options=[pscustomobject]@{'awslogs-region'='us-east-1';'awslogs-group'='/ecs/schoolpilot-production-scheduler-worker';'awslogs-stream-prefix'='ecs'}}});volumes=@();placementConstraints=@();requiresCompatibilities=@('FARGATE');cpu='512';memory='1024'};tags=@()}
Check 'Task clone excludes app IAM role and unrelated secrets, fixed command and read-only root' { $r=New-InspectorRequest $worker 'schoolpilot-production-release-metadata-123456789012' ('a'*32);if($r.PSObject.Properties['taskRoleArn'] -or $r.containerDefinitions[0].secrets.Count -ne 1 -or $r.containerDefinitions[0].secrets[0].name -cne 'DATABASE_URL' -or -not $r.containerDefinitions[0].readonlyRootFilesystem -or $r.containerDefinitions[0].command[3] -cne $sourceText){throw 'Unsafe clone'} }
Check 'Unknown registered fields rejected' {Rejected {Get-RegistrationProjection ([pscustomobject]@{taskDefinition=[pscustomobject]@{family='fixture';unknown=1};tags=@()})}}
Check 'Registration comparison preserves tampered command' { $r=New-InspectorRequest $worker 'schoolpilot-production-release-metadata-123456789012' ('a'*32);$original=Get-CanonicalJsonSha256 $r;$response=[pscustomobject]@{taskDefinition=$r;tags=$r.tags};$response.taskDefinition.containerDefinitions[0].command=@('node','bad.js');if((Get-CanonicalJsonSha256 (Get-RegistrationProjection $response)) -ceq $original){throw 'Command masked'} }
$result=[ordered]@{schemaVersion=1;at=[DateTimeOffset]::UtcNow.ToString('o');wrapperSha256=(Get-FileHash -LiteralPath (Join-Path $root 'run-release-metadata-inspector.ps1')).Hash.ToLowerInvariant();status='passed_local_function_mocks_only';cases=$records.ToArray();limits=@('No AWS actions; Invoke-AwsJson is replaced with an unconditional rejection.','Does not exercise wrapper orchestration, task lost-response recovery, real SQL, TLS or serving-image compatibility.')}
[IO.File]::WriteAllText((Join-Path $root 'local-powershell-validation.json'),($result|ConvertTo-Json -Depth 10)+"`n",[Text.UTF8Encoding]::new($false))
Write-Output "Local PowerShell function cases: $($records.Count) passed."
