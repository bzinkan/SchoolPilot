import assert from 'node:assert/strict';
import test from 'node:test';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {json,validateConfig} from './binding.mjs';
const here=dirname(fileURLToPath(import.meta.url)),original=json(join(here,'final-config-02.json'));
test('actual8148/fallback scans, complete54 source reentry, schema and cleanup bind without Docker',()=>{
 const value=validateConfig(original,here);assert.equal(value.ledger.length,54);
});
for(const [label,change]of [
 ['wrong candidate source',value=>{value.source='e95a2b56476b1225434c1b0f3907db46c9d84fe3';}],
 ['substituted candidate image',value=>{value.candidate.image=structuredClone(value.fallback.image);}],
 ['changed scan receipt hash',value=>{value.candidate.scan.sha256='0'.repeat(64);}],
 ['changed actual schema hash',value=>{value.schema.sha256='0'.repeat(64);}],
 ['old schema source',value=>{value.schemaSource=value.fallback.source;}],
 ['missing source cleanup',value=>{delete value.rehearsalCleanup;}],
 ['changed launcher bytes binding',value=>{value.files.find(row=>row.name==='run.mjs').sha256='0'.repeat(64);}],
 ['different PostgreSQL image',value=>{value.postgresImage='sha256:'+'0'.repeat(64);}],
 ['capacity relabel',value=>{value.capacityAccepted=true;}],
])test(label+' is refused before fixture creation',()=>{
 const value=structuredClone(original);change(value);assert.throws(()=>validateConfig(value,here));
});
