import assert from 'node:assert/strict';
import {verifyBinding} from '../verify-binding.mjs';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
export function validateRelease(ready,release){
 assert.equal(ready.schemaVersion,1);assert.equal(release.schemaVersion,1);
 assert.equal(release.action,'release-diagnostic-measurement');
 for(const key of ['nonce','run','source','imageId','runtimeProfile','runtimeBindingSha256'])assert.equal(release[key],ready[key],key);
 assert.equal(release.diagnosticOnly,true);assert.equal(release.capacityAccepted,false);
}
export async function waitForRelease({output,run,source,imageId,bindingFile,timeoutMs=900000,intervalMs=1000,now=()=>Date.now(),sleep=ms=>new Promise(r=>setTimeout(r,ms))}){
 assert.match(run,/^[a-f0-9]{12}$/);assert.match(source,/^[a-f0-9]{40}$/);assert.match(imageId,/^sha256:[a-f0-9]{64}$/);
 const runtime=verifyBinding(bindingFile);
 const ready={schemaVersion:1,run,source,imageId,runtimeProfile:runtime.profile,runtimeBindingSha256:runtime.bindingSha256,nonce:randomUUID(),diagnosticOnly:true,capacityAccepted:false,preparedAt:new Date().toISOString()};
 const go=resolve(output,'measurement-go.json');assert.equal(existsSync(go),false,'Preexisting release marker refused');
 writeFileSync(resolve(output,'measurement-ready.json'),JSON.stringify(ready,null,2)+'\n',{flag:'wx'});
 const start=now();
 while(now()-start<timeoutMs){
  if(existsSync(go)){
   const bytes=readFileSync(go);validateRelease(ready,JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,'')));
   writeFileSync(resolve(output,'measurement-release-receipt.json'),JSON.stringify({...ready,releasedAt:new Date().toISOString(),releaseSha256:createHash('sha256').update(bytes).digest('hex')},null,2)+'\n',{flag:'wx'});
   return ready;
  }
  await sleep(intervalMs);
 }
 throw new Error('MEASUREMENT_RELEASE_EXPIRED');
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [output,run,source,imageId,bindingFile]=process.argv.slice(2);
 await waitForRelease({output,run,source,imageId,bindingFile});
}
