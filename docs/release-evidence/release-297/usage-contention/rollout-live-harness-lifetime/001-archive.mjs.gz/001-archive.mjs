import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, readdirSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, relative, basename } from 'node:path';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const root = String.raw`<LOCAL_USER_PROFILE>\.codex\worktrees\release-stabilization-297\SchoolPilot`;
const raw = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-live-harness-followup-01`;
const ci = String.raw`<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-ci-35712eb-rollout-01`;
const output = resolve(root, 'docs/release-evidence/release-297/usage-contention/rollout-live-harness-lifetime');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const final = json(resolve(raw, 'final-source-proof.json'));
const full = json(resolve(raw, 'full-01.json'));
assert.equal(full.exitCode, 0); assert.equal(full.sourceUnchanged, true);
assert.equal(final.testSha256, full.testAfter);
assert.equal(final.monitorSha256, '9f805b9bcd132ea5008b3253c3116feaf1f93bf64011659218f270a0ca6b437b');
assert.deepEqual(final.appChangedPaths, []); assert.equal(final.parseErrors, 0); assert.equal(final.diffCheckExitCode, 0);
assert.ok(final.fixtureCleanup.length > 0 && final.fixtureCleanup.every(row => row.absent));
assert.deepEqual(final.matchingOwnedProcesses, []);
assert.equal(existsSync(output), false); mkdirSync(output, { recursive: true });
function sanitize(value) {
  let text = value.toString('utf8');
  for (const prefix of [String.raw`<LOCAL_USER_PROFILE>`, String.raw`<LOCAL_USER_PROFILE>`, '<LOCAL_USER_PROFILE>']) text = text.replaceAll(prefix, '<LOCAL_USER_PROFILE>');
  return Buffer.from(text.replace(/\x1b\[[0-9;]*[A-Za-z]/g, '')
    .replace(/\b(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi, '<REDACTED_DATABASE_URL>')
    .replace(/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g, '<REDACTED_ACCESS_KEY>'));
}
const walk = directory => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
  const path = resolve(directory, entry.name);
  return entry.isDirectory() ? walk(path) : /\.(?:json|log|ps1|mjs|patch)$/.test(entry.name) ? [path] : [];
});
const files = [];
for (const [directory, label] of [[raw, 'local'], [ci, 'ci-35712']]) {
  for (const path of walk(directory).sort()) {
    const bytes = readFileSync(path), clean = sanitize(bytes), compressed = gzipSync(clean, { level: 9 });
    const file = `${String(files.length + 1).padStart(3, '0')}-${basename(path).slice(0, 48)}.gz`;
    writeFileSync(resolve(output, file), compressed, { flag: 'wx' });
    assert.deepEqual(gunzipSync(readFileSync(resolve(output, file))), clean);
    assert.equal(hash(readFileSync(path)), hash(bytes));
    files.push({ file, originalRelativePath: `${label}/${relative(directory, path).replaceAll('\\', '/')}`, rawBytes: bytes.length, rawSha256: hash(bytes), sanitizedBytes: clean.length, sanitizedSha256: hash(clean), gzipSha256: hash(compressed) });
  }
}
const manifest = {
  schemaVersion: 1, recordedAt: new Date().toISOString(), sourceHead: final.head,
  sourceState: 'Uncommitted test-only fixture follow-up after the listing checkpoint. No application, production monitor, rollback, helper library or CI workflow edits in this follow-up.',
  status: 'four_owned_fixture_lifetimes_corrected_full_mock_suite_passed',
  ciFailure: { source: '35712eb162632cb444c6464e30ce6064e989ef23', runId: 37114624863, artifactId: 11272015561, failure: 'Generic valid-401 monitor did not start.', observedCause: 'The production monitor rejected its configured generator process binding as not live before the first sample.', exactSubcauseKnown: false,
    limitation: 'Retained evidence cannot distinguish an expired 30-second fixture from unavailable process/path/start-time binding. The fixture lifetime was shorter than the existing 60-second startup allowance.',
    original204MonitorException: 'Remains unexplained; the unavailable-probe case passed with its expected load reason in the subsequent 35712 run.' },
  change: 'Only four sibling fatal-case harnesses now publish actual PID/start/path/nonce readiness and remain owned until release or verified rollback containment. Release is committed atomically; the abandonment ceiling is derived from existing test-only watchdogs. Live normal completion requires exit0. Already-exited completion is allowed only after the existing successful rollback assertion, with exact identity/status retained. All original monitor assertions and production timeouts are unchanged.',
  validation: {
    lifecycleAttempt01: { assertions: 9, passed: true, scope: 'Initial readiness, owner release and failed-case cleanup.' },
    targetedAttempt01: { ...json(resolve(raw, 'targeted-01.json')), passed: false, failure: 'New helper incorrectly required graceful exit0 after the monitor intentionally terminated its generator during successful Application rollback; retained as a fixture defect.' },
    lifecycleAttempt02: { assertions: 14, passed: true, scope: 'Corrected already-contained completion and rejection of unknown nonzero exits.' },
    targetedAttempt02: { ...json(resolve(raw, 'targeted-02.json')), assertions: 194, passed: true, scope: 'Startup prerequisites, original missing-probe cases and all four fatal rollback cases before final atomic-release hardening.' },
    finalLifecycle: { assertions: 15, passed: true, scope: 'Actual ready identity, staged release ignored until commit, owner release+exit0, unverified nonzero rejection, failure cleanup.' },
    finalFailureDiagnostics: { assertions: 5, passed: true },
    fullSuite: { ...full, assertions: 380, durationSeconds: 420.7, passed: true, scope: 'Default full AWS mock suite, with no targeted selector and all original assertions.' },
    parseErrors: 0, diffCheckExitCode: 0,
  },
  finalProof: final,
  preparationFailure: 'An external text-replacement draft expanded a replacement token unexpectedly. That unapplied draft and receipt are retained; corrected before repository mutation or test execution.',
  cleanup: 'Full-suite owned-process drain passed. Its exact temporary fixture is absent and no matching process remains. Release-file cleanup remains inside verified owned temporary paths.',
  productionActions: 0, capacityAccepted: false,
  limitations: ['Fresh final-head CI is still required.', 'This does not establish the exact subcause of the prior CI binding failure.', 'No production timeout, resource limit, monitoring authority or rollback assertion was weakened.'],
  sanitation: 'Local profile prefixes, ANSI escapes, database URL/access-key patterns sanitized. Only logs, code and bounded synthetic mock receipts are archived; no environment, credentials, Terraform state or encrypted backup files. Short archive filenames prevent Windows path-length failures. Raw originals remain unchanged outside Git.',
  files,
};
writeFileSync(resolve(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
writeFileSync(resolve(output, 'README.md'), '# Owned rollout harness lifetimes\n\nFour mock fatal-case generators now remain alive through their monitor case, with actual process readiness, an atomic owner-release signal, and bounded cleanup. A successful rollback may already have contained its exact generator; normal live completion still requires exit0. Production monitoring and rollback behavior are unchanged.\n\nFinal local verification passed the lifecycle proof (15 assertions), failure-evidence proof (5), and the complete default AWS mock suite (380). The earlier helper assertion failure and all CI evidence remain preserved. Fresh final-head CI is required.\n\nThe original CI binding failure is proven; its precise subcause is unknown. The older204 monitor exception remains unexplained. No capacity or deployment approval is implied.\n', { flag: 'wx' });
console.log(JSON.stringify({ path: output, files: files.length, manifestSha256: hash(readFileSync(resolve(output, 'manifest.json'))), testSha256: final.testSha256, monitorSha256: final.monitorSha256 }));
