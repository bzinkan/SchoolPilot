# Candidate image default runtime diagnostic — exact 0e427

This separately named diagnostic uses the existing exact helper8bed and candidate0e427 application/runtime bytes. No image is rebuilt and no application or inherited workload module is overlaid. The outer profile is `release-enabled-linux-role-ingest-candidate-default-v1`; the original inner profile remains explicit historical workload provenance.

The only runtime change is removing the harness-inserted `--max-old-space-size=512` from API, worker, generator and coordinator commands. A reviewed read-only `--import /runtime-fidelity.mjs` preloader records content-free numeric V8/heap-space information, Node/V8 version and exact flags at process start/exit and fixed existing message boundaries. It never logs request values. API/worker have phase-reset and snapshot facts; generator has phase-start and shutdown facts; coordinator retains process-start/exit V8 facts and its existing cgroup before/after facts. This avoids modifying the inherited coordinator module merely to add a V8 callback.

Quotas are unchanged: API1CPU/2GiB, worker0.5CPU/1GiB, generator2CPU/1GiB, coordinator0.5CPU/1GiB, PG4CPU/4GiB, Redis1CPU/256MiB. Pools remain16/2/5/observer2. Full6000 open-loop offers at100Hz over60seconds,20second request budget,5second API checkout,15second statements and100ms late-offer criterion are inherited unchanged. Ingestion has no report or rollup workload and cannot establish combined capacity. Historical seeding/control preparation keep512MiB plus the original600MiB assertion.

The candidate image has no NODE_OPTIONS and uses Node22.23.3. This is candidate-command fidelity; retained production metadata does not prove actual deployed command/environment overrides. The tiny network-none preloader smoke observed heap_size_limit1,098,907,648bytes under API2GiB, but it did not run the application or measure throughput. New-space size is an observed dynamic space size, not a configured semi-space maximum.

Exact host files and preloader are hash-bound before fixture creation and again before role launch. The cold gate binds source,image,run,nonce AND outer runtime profile/binding hash. The original exact-owned cleanup and nonzero coordinator exit proofs are retained. DiagnosticOnly remains true and capacityAccepted remains false on every path, regardless of throughput.

Validation: tests-02.log11/11, PowerShell parse-01.json0errors, native-preloader-proof-01.log actual22.23.3 start/exit0 and native-preloader-cleanup-01.json owned cleanup. These do not certify the subsequent measured run. Original files, historical profiles and prior failures remain untouched.

Launch already authorized to the held gate:

`pwsh -NoProfile -File generated/run-role-ingest-unprofiled.ps1 -SourceRepository <TEMP>/release297-role-0e427-unprofiled-host-01 -DiagnosticImageManifest runtime-image-binding.json -SchemaDatabase schoolpilot_redesign_usage_release297_20261002 -OutputDirectory <TEMP>/release297-role-ingest-default-0e427-01 -Phase ingest -DiagnosticOnly`

No release marker is written by this package; root controls the exact nonce release after all local heavy work stops.
