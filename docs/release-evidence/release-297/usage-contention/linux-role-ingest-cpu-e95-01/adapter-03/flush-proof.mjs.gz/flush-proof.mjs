import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {randomBytes,createHash} from 'node:crypto';
const dir=dirname(fileURLToPath(import.meta.url)), output=join(dir,'flush-proof-01');mkdirSync(output);
const bindingFile=join(dir,'../release297-role-e95-ingest-cpu-build-01/role-image-binding.json'),binding=JSON.parse(readFileSync(bindingFile));
const run=randomBytes(6).toString('hex'),name='schoolpilot-cpu-flush-'+run;
const docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe',endpoint='npipe:////./pipe/dockerDesktopLinuxEngine';
const hash=x=>createHash('sha256').update(x).digest('hex');
const save=(name,value)=>writeFileSync(join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const env={...process.env};for(const key of Object.keys(env))if(/^DOCKER_|^BUILDX_BUILDER$/.test(key))delete env[key];
const call=args=>{const r=spawnSync(docker,['--host',endpoint,...args],{env,encoding:'utf8',timeout:30000,maxBuffer:1024*1024});if(r.status!==0)throw Error('FLUSH_DOCKER_FAILED');return r.stdout;};
const find=()=>{const ids=call(['ps','-a','--filter','name=^/'+name+'$','--no-trunc','--format','{{.ID}}']).trim().split(/\r?\n/).filter(Boolean);assert.ok(ids.length<=1);return ids.length?JSON.parse(call(['inspect',ids[0]]))[0]:null;};
const verify=x=>{assert.equal(x.Name,'/'+name);assert.equal(x.Config.Labels['codex.cpu-flush'],run);assert.equal(x.Config.Image,binding.roleImageId);assert.equal(x.Image,binding.runtimeConfigDigest);assert.equal(x.HostConfig.NetworkMode,'none');assert.equal(x.HostConfig.NanoCpus,1e9);assert.equal(x.HostConfig.Memory,2*1024**3);assert.equal(x.Config.User,'node');};
writeFileSync(join(output,'api.cpuprofile'),'',{flag:'wx'});
let id=null,passed=false;
try{
 assert.equal(find(),null);
 const args=['create','--name',name,'--label','codex.cpu-flush='+run,'--network','none','--cpus','1','--memory','2g','--memory-swap','2g','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--init','--no-healthcheck','--user','node','--workdir','/app','--mount',`type=bind,source=${output},target=/evidence,readonly`,'--mount',`type=bind,source=${join(output,'api.cpuprofile')},target=/evidence/api.cpuprofile`,'--entrypoint','node',binding.roleImageId,'--cpu-prof','--cpu-prof-dir=/evidence','--cpu-prof-name=api.cpuprofile','--cpu-prof-interval=1000','--eval','let sum=0; for(let n=0;n<1000000;n++) sum+=Math.sqrt(n); process.stdout.write(JSON.stringify({node:process.version,uid:process.getuid(),sumFinite:Number.isFinite(sum)}));'];
 save('command.json',{run,name,args,bindingSha256:hash(readFileSync(bindingFile)),purpose:'Network-none profile file permission and flush; no application workload',capacityAccepted:false});
 try{call(args);}finally{const found=find();if(found){verify(found);id=found.Id;}}
 assert.ok(id);const stdout=call(['start','--attach',id]);writeFileSync(join(output,'stdout.log'),stdout);
 const x=find();verify(x);save('inspect.json',x);assert.equal(x.State.Running,false);assert.equal(x.State.ExitCode,0);assert.equal(x.State.OOMKilled,false);
 const runtime=JSON.parse(stdout);assert.equal(runtime.uid,1000);assert.equal(runtime.sumFinite,true);
 const raw=readFileSync(join(output,'api.cpuprofile')),profile=JSON.parse(raw);assert.ok(profile.nodes.length>0);assert.ok(profile.samples.length>0);assert.equal(profile.samples.length,profile.timeDeltas.length);
 save('result.json',{passed:true,run,imageId:binding.roleImageId,runtimeConfigDigest:binding.runtimeConfigDigest,node:runtime.node,uid:runtime.uid,bytes:raw.length,sha256:hash(raw),samples:profile.samples.length,exitCode:0,forced:false,capacityAccepted:false});passed=true;
}finally{
 const found=find();if(found){verify(found);if(id)assert.equal(found.Id,id);id=found.Id;call(['rm','--force','--volumes',id]);}assert.equal(find(),null);
 save('cleanup.json',{run,id,confirmedAbsent:true,cleanupPassed:true,proofPassed:passed,capacityAccepted:false});
}
