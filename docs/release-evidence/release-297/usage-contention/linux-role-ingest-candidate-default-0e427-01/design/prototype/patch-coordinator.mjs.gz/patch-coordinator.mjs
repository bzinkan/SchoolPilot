import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const replace=(text,from,to)=>{assert.equal(text.split(from).length-1,1,`Unique adapter anchor required: ${from.slice(0,70)}`);return text.replace(from,()=>to);};
// Input is the already reviewed current204 Linux overlay, not application code.
export function patchCoordinator(source){
 let text=replace(source,"import assert from 'node:assert/strict';","import assert from 'node:assert/strict';\nimport { getOwnedRoleCoordinator } from '/prototype/coordinator-owner.mjs';");
 const start=text.indexOf('async function child(name, file, extraEnv) {'),end=text.indexOf('\ntry {\n  const snapshot =',start);assert.ok(start>0&&end>start);assert.equal(text.indexOf('async function child(name, file, extraEnv) {',start+1),-1);
 text=text.slice(0,start)+`async function child(name, file, extraEnv) {
  const owner = await getOwnedRoleCoordinator().child(name, file, extraEnv);
  children.push(owner); return owner;
}`+text.slice(end);
 text=replace(text,'metrics.processes = { api: apiReady.pid, worker: workerReady.pid, generator: generatorReady.pid };',
  'metrics.processes = Object.fromEntries(Object.entries({api: apiReady, worker: workerReady, generator: generatorReady}).map(([role, ready]) => [role, `${ready.containerId}:${ready.pid}`]));');
 text=replace(text,"  await Promise.all([api.rpc('reset'), worker.rpc('reset')]);","  await Promise.all([api.rpc('reset'), worker.rpc('reset')]);\n  getOwnedRoleCoordinator().captureCoordinatorResources('before');");
 text=replace(text,"  phase.api = await api.rpc('snapshot'); phase.worker = await worker.rpc('snapshot');","  phase.api = await api.rpc('snapshot'); phase.worker = await worker.rpc('snapshot');\n  getOwnedRoleCoordinator().captureCoordinatorResources('after');");
 text=replace(text,'Generator, API and worker use separate Linux Node processes with512MiB heap caps in one diagnostic container; per-role CPU and RSS are not hard-limited. This does not establish production task capacity.',
  'Separate owned role containers enforce reviewed CPU/RSS ceilings and512MiB Node heaps. This prototype remains diagnostic until exact runtime, cgroup and cleanup validation is complete.');
 return {text,receipt:{inputSha256:createHash('sha256').update(source).digest('hex'),outputSha256:createHash('sha256').update(text).digest('hex'),applicationModulesChanged:0,workloadChanged:false,resourceAcceptance:false}};
}
