import assert from 'node:assert/strict';
import {writeFileSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {randomBytes,createHash} from 'node:crypto';
import {withRestoredSnapshot} from 'file:///C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot/scripts/load/usage/roles/restore-snapshot.mjs';
const run=randomBytes(6).toString('hex'),source='e95a2b56476b1225434c1b0f3907db46c9d84fe3',temp=process.env.TEMP;
const output=join(temp,'release297-e95-restore-restart-'+run),privateDirectory=output+'-private';
const options={run,source,mode:'diagnostic',purpose:'Zero-workload same-source snapshot restore, native validation, fresh cold restart and exact container plus anonymous-volume cleanup proof',
  snapshotDirectory:'C:/Users/zinka/.codex/artifacts/release297-synthetic-prepared-e95-75d8f6205c5c',snapshotManifestSha256:'847c9b8d7a0e717e77b72f75ca06f2e89d3d5050cce17b8b5cd731bde4070330',
  sourceDirectory:join(temp,'release297-role-e95-host-01'),evidenceDirectory:output,privateDirectory,
  endpoint:'npipe:////./pipe/dockerDesktopLinuxEngine',docker:'C:/Program Files/Docker/Docker/resources/bin/docker.exe'};
writeFileSync(join(temp,'release297-e95-restore-restart-proof-01-config.json'),JSON.stringify(options,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({run,output,stage:'restore-start',offeredRequests:0})+'\n');
try{
  await withRestoredSnapshot(options,async({ready,restartAfterRelease})=>{
    assert.equal(ready.source,source);assert.equal(ready.restorationPassed,true);assert.equal(ready.allValidationClientsClosed,true);
    const gate={run,source,nonce:ready.nonce,releasedAt:new Date().toISOString(),purpose:'Explicit zero-workload native restart proof; no workload release'};
    writeFileSync(join(output,'zero-workload-release.json'),JSON.stringify(gate,null,2)+'\n',{flag:'wx'});
    const cold=await restartAfterRelease(gate);assert.equal(cold.restarted,true);assert.equal(cold.pgContainerId,ready.pgContainerId);
    assert.ok(Date.parse(cold.after.StartedAt)>Date.parse(cold.before.StartedAt));
    writeFileSync(join(output,'zero-workload-proof.json'),JSON.stringify({run,source,passed:true,offeredRequests:0,apiRoleStarted:false,workerRoleStarted:false,capacityAccepted:false,cold},null,2)+'\n',{flag:'wx'});
  });
  const cleanup=JSON.parse(readFileSync(join(output,'cleanup.json')));assert.equal(cleanup.cleanupPassed,true);assert.equal(cleanup.confirmedAbsent,true);assert.equal(cleanup.handoffPassed,true);assert.equal(cleanup.volumes.length,1);assert.equal(cleanup.volumes[0].confirmedAbsent,true);
  const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
  process.stdout.write(JSON.stringify({run,output,passed:true,offeredRequests:0,cleanupSha256:hash(join(output,'cleanup.json')),coldSha256:hash(join(output,'cold-restart-receipt.json')),sourceSha256:hash(join(output,'restore-sources.json')),capacityAccepted:false})+'\n');
}catch(error){process.stderr.write(JSON.stringify({run,output,passed:false,code:'RESTORE_RESTART_NATIVE_FAILED',name:error?.name,capacityAccepted:false})+'\n');process.exitCode=1;}
