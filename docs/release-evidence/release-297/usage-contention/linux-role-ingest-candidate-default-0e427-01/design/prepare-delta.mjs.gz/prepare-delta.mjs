import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const base=process.argv[2], profile='release-enabled-linux-role-ingest-candidate-default-v1';
const sha=x=>createHash('sha256').update(x).digest('hex');
const once=(s,a,b)=>{assert.equal(s.split(a).length-1,1,a.slice(0,70));return s.replace(a,()=>b);};
const receipts=[];
function patch(file,fn){const input=readFileSync(join(base,file),'utf8'),out=fn(input);writeFileSync(join(base,file),out);receipts.push({file,inputSha256:sha(input),outputSha256:sha(out)});}
patch('prototype/role-plan.mjs',s=>{
 s=once(s,"import {join} from 'node:path';","import {join} from 'node:path';\nimport {fileURLToPath} from 'node:url';\nconst runtimePreload=fileURLToPath(new URL('./runtime-fidelity.mjs',import.meta.url));");
 s=once(s,"command=['--max-old-space-size=512',...profileArgs,","command=['--import','/runtime-fidelity.mjs',...profileArgs,");
 s=once(s,"const mounts=[{Type:'bind',Source:evidenceDirectory","assert.equal(apiCpuProfile,false,'Candidate-default diagnostic forbids CPU profiling');\n const mounts=[{Type:'bind',Source:runtimePreload,Destination:'/runtime-fidelity.mjs',RW:false},{Type:'bind',Source:evidenceDirectory");
 s=once(s,"'--entrypoint','node',imageId,...command];","'--mount',`type=bind,source=${runtimePreload},target=/runtime-fidelity.mjs,readonly`,'--entrypoint','node',imageId,...command];");
 s=once(s,'heapMiB:512','heapMiB:null,runtimeProfile:'+JSON.stringify(profile));return s;
});
patch('prototype/launch-role-preflight.mjs',s=>{
 s=once(s,"import {rolePlan} from './role-plan.mjs';","import {rolePlan} from './role-plan.mjs';\nimport {fileURLToPath} from 'node:url';");
 s=once(s,"const binding=JSON.parse(readFileSync(bindingFile,'utf8'));","const binding=JSON.parse(readFileSync(bindingFile,'utf8'));\n assert.equal(binding.runtimeFidelity.profile,'"+profile+"');\n assert.equal(binding.runtimeFidelity.applicationChanges,0);\n assert.equal(binding.runtimeFidelity.harnessImageChanged,false);\n const preloader=fileURLToPath(new URL('./runtime-fidelity.mjs',import.meta.url));\n assert.equal(sha(readFileSync(preloader)),binding.runtimeFidelity.preloaderSha256);\n for(const row of binding.runtimeFidelity.hostFiles) assert.equal(sha(readFileSync(new URL(row.file,import.meta.url))),row.sha256);\n");
 s=once(s,"const apiCpuProfile=environment.USAGE_RELEASE_CPU_PROFILE==='true';","assert.equal((image.Config.Env??[]).some(value=>value.startsWith('NODE_OPTIONS=')),false);\n const apiCpuProfile=environment.USAGE_RELEASE_CPU_PROFILE==='true';\n assert.equal(apiCpuProfile,false);assert.equal(environment.USAGE_RELEASE_PHASE,'ingest');");
 s=once(s,'schemaVersion:1,mode,roles:plans,applicationSource:','schemaVersion:1,mode,outerProfile:binding.runtimeFidelity.profile,runtimeFidelity:binding.runtimeFidelity,roles:plans,applicationSource:');
 return s;
});
patch('generated/run-role-ingest-unprofiled.ps1',s=>{
 s=once(s,"workloadProfile='release-enabled-linux-role-cgroups-ingest-unprofiled-100rps-v2'","workloadProfile='"+profile+"'; inheritedWorkloadProfile='release-enabled-linux-role-cgroups-ingest-unprofiled-100rps-v2'");
 s=once(s,'nodeOldSpaceMiB=512; productionMutations=0','nodeOldSpaceMiB=$null; historicalSeederOldSpaceMiB=512; roleRuntimeProfile=\''+profile+'\'; runtimePreloaderSha256=$linuxBinding.runtimeFidelity.preloaderSha256; productionMutations=0');return s;
});
writeFileSync(join(base,'patch-receipt.json'),JSON.stringify({profile,source:'0e427e3ca9b82125e0bb8692176accad21f4f699',applicationChanges:0,harnessImageChanged:false,changed:receipts,notExecuted:true},null,2)+'\n',{flag:'wx'});
