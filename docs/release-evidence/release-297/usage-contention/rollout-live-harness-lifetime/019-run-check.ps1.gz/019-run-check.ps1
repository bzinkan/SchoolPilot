param([ValidateSet('targeted','full')][string]$Check, [ValidatePattern('^[0-9]{2}$')][string]$Attempt='01')
$ErrorActionPreference = 'Stop'
$repository = '<LOCAL_USER_PROFILE>\.codex\worktrees\release-stabilization-297\SchoolPilot'
$output = '<LOCAL_USER_PROFILE>\AppData\Local\Temp\release297-live-harness-followup-01'
Set-Location -LiteralPath $repository
$logPath = Join-Path $output "$Check-$Attempt.log"
if (Test-Path -LiteralPath $logPath) { throw 'Evidence file already exists' }
$env:SCHOOLPILOT_ROLLOUT_TEST_EVIDENCE_DIRECTORY = Join-Path $output "$Check-$Attempt-failure-evidence"
$testBefore=(Get-FileHash 'tests/aws-rollout-automation.test.ps1' -Algorithm SHA256).Hash.ToLower()
$monitorBefore=(Get-FileHash 'scripts/load/aws-rollout-monitor.ps1' -Algorithm SHA256).Hash.ToLower()
$started=[DateTime]::UtcNow.ToString('o')
$arguments=@('-NoProfile','-File','tests/aws-rollout-automation.test.ps1')
if ($Check -eq 'targeted') { $arguments += '-LiveHarnessCasesOnly' }
& pwsh @arguments *> $logPath
$code=$LASTEXITCODE
$testAfter=(Get-FileHash 'tests/aws-rollout-automation.test.ps1' -Algorithm SHA256).Hash.ToLower()
$monitorAfter=(Get-FileHash 'scripts/load/aws-rollout-monitor.ps1' -Algorithm SHA256).Hash.ToLower()
$result=@{ check=$Check; command=('pwsh ' + ($arguments -join ' ')); exitCode=$code; startedAt=$started; finishedAt=[DateTime]::UtcNow.ToString('o'); testBefore=$testBefore; testAfter=$testAfter; monitorBefore=$monitorBefore; monitorAfter=$monitorAfter; sourceUnchanged=($testBefore -ceq $testAfter -and $monitorBefore -ceq $monitorAfter); appChangedPaths=@(git diff --name-only -- src) }
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output "$Check-$Attempt.json") -Encoding utf8
$result | ConvertTo-Json -Depth 5
if ($code -ne 0 -or -not $result.sourceUnchanged) { exit 1 }
