import fs from 'node:fs';import path from 'node:path';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
const root=process.cwd(),out=path.join(process.env.TEMP,'release297-fixed-query-compile-bcb2');fs.mkdirSync(out,{recursive:true});const require=createRequire(path.join(root,'package.json')),ts=require('typescript');const orm=require('drizzle-orm'),{sql,and,eq,isNull,isNotNull,or}=orm,{PgDialect}=require('drizzle-orm/pg-core'),{drizzle}=require('drizzle-orm/node-postgres');const schema=await import(pathToFileURL(path.join(root,'dist/schema/index.js'))),{currentStudentSessionAuthorityPredicate}=await import(pathToFileURL(path.join(root,'dist/services/classpilotStudentSessionAuthority.js')));const source=fs.readFileSync('src/services/storage.ts','utf8'),entitlement=fs.readFileSync('src/services/classpilotEntitlement.ts','utf8');const names=['sql','and','eq','isNull','isNotNull','or','currentStudentSessionAuthorityPredicate',...Object.keys(schema)],values=[sql,and,eq,isNull,isNotNull,or,currentStudentSessionAuthorityPredicate,...Object.values(schema)];
const entBody=entitlement.slice(entitlement.indexOf('export function classpilotEntitledSchoolPredicate'),entitlement.indexOf('export async function resolveClasspilotEntitlement'));const entJs=ts.transpileModule(entBody.replace('export function','function'),{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;const entitlementPredicate=new Function(...names,entJs+';return classpilotEntitledSchoolPredicate;')(...values);names.push('classpilotEntitledSchoolPredicate');values.push(entitlementPredicate);
let databaseCalls=0;const db=drizzle({query(){databaseCalls++;throw new Error('Compile only');}}),dialect=new PgDialect();names.push('dbInstance','LIVE_TEACHING_SESSION_MODE');values.push(db,'live');
const make=body=>new Function(...names,'options','foreground','controlState',body).bind(null,...values);
const binding=source.slice(source.indexOf('async function hasExactClasspilotTelemetryBinding('),source.indexOf('export type ClasspilotScreenshotAuthorityClaim'));
const rawTemplate=text=>{const tree=ts.createSourceFile('capture.ts',text,ts.ScriptTarget.Latest,true);let found;const visit=node=>{if(found)return;if(ts.isTaggedTemplateExpression(node)&&node.tag.getText(tree)==='sql'){found=node.getText(tree);return;}ts.forEachChild(node,visit);};visit(tree);assert.ok(found);return found};
const liveSql=rawTemplate(binding.slice(binding.indexOf(': (await dbInstance.execute')));
const oldLive=make('const bindingConditions=[eq(studentSessions.id,options.studentSessionId),eq(studentSessions.studentId,options.studentId),eq(studentSessions.deviceId,options.deviceId),currentStudentSessionAuthorityPredicate()];return '+liveSql+';');
const fence=source.slice(source.indexOf('async function assertClasspilotHeartbeatDeliveryCurrent('),source.indexOf('export async function withClasspilotStudentControlDeliveryAuthority<'));
const oldFence=make('return '+rawTemplate(fence)+';');
const foreground=source.slice(source.indexOf('const current = await transactionDb.execute(sql`',source.indexOf('export async function withClasspilotHeartbeatDeliveryAuthority<')));const oldForeground=make('return '+rawTemplate(foreground)+';');
const projection=source.slice(source.indexOf('export async function getClasspilotScreenshotAuthorityProjection('),source.indexOf('export async function withClasspilotScreenshotUploadAuthority'));
function builder(label){const start=projection.indexOf('const ['+label+'] = await dbInstance');assert.ok(start>=0);const from=start+('const ['+label+'] = await ').length,end=projection.indexOf('.for("share");',from)+'.for("share")'.length;assert.ok(end>from);return make('return '+projection.slice(from,end)+'.toSQL();');}
const oldBuilders={live_binding:oldLive,final_fence:oldFence,foreground_fence:oldForeground,screenshot_session:builder('session'),screenshot_control:builder('controlState'),screenshot_candidate:builder('candidate')};
const context=n=>({options:{schoolId:'school-'+n,studentId:'student-'+n,studentSessionId:'session-'+n,deviceId:'device-'+n},foreground:{teachingSessionId:'teaching-'+n,controlRevision:37+n},controlState:{teachingSessionId:'control-teaching-'+n}});const a=context(1),b=context(2);const compile=(fn,c)=>{const q=fn(c.options,c.foreground,c.controlState);return typeof q.sql==='string'?q:dialect.sqlToQuery(q)};

const fixture={source:'bcb2b33c6ef08243a1147d9818cfe3d668ea3f27',purpose:'Original compiled fence SQL and encoder typings; synthetic values only',queries:{}};
for(const name of ['live_binding','final_fence','foreground_fence']){
 const captured=compile(oldBuilders[name],a);
 fixture.queries[name]={sql:captured.sql,params:captured.params.map(value=>{
   for(const group of ['options','foreground'])for(const [key,bound]of Object.entries(a[group]))if(value===bound)return {binding:key};
   return {value};
 }),typings:captured.typings};
}
const target='tests/fixtures/classpilot-fixed-fence-sql.json';if(fs.existsSync(target))throw Error('Refuse overwrite');
fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,JSON.stringify(fixture,null,2)+'\n');console.log(target);
