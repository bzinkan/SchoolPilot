import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const modulePath = 'C:/GitHub/SP297-scan/scripts/verify-legacy-deploy-image.mjs';
const { createEvidenceDirectory, scanBuiltImage } = await import(pathToFileURL(modulePath));
const sourceSha = 'ed5599de0191b4b9961ed907586e1fc153ebd63b';
const root = path.join(process.env.TEMP, 'release297 legacy scan native 01');
mkdirSync(root, { recursive: false });
const directory = createEvidenceDirectory(sourceSha, root);
writeFileSync(path.join(root, 'run.json'), JSON.stringify({ sourceSha, directory, helper: modulePath, api: 'scanBuiltImage', limitation: 'Existing exact image; no image build or registry operation. CLI clean-source checks are separately mocked.' }, null, 2));
writeFileSync(path.join(directory, 'build-image-id.txt'), 'sha256:b81c75130c16f029ab34391638480685d82e6609cf84153e4f0c688f01c23cf7');
try {
  const result = await scanBuiltImage({ directory, sourceSha, imageRef: 'schoolpilot-rollback-local:ed5599de0191-20261003044443' }, { environment: { DOCKER_HOST: 'npipe:////./pipe/dockerDesktopLinuxEngine' } });
  writeFileSync(path.join(root, 'result.json'), JSON.stringify({ passed: true, result }, null, 2));
  console.log(JSON.stringify({ passed: true, directory, ...result }));
} catch (error) {
  writeFileSync(path.join(root, 'result.json'), JSON.stringify({ passed: false, message: error.message, cause: error.cause?.message }, null, 2));
  console.error(JSON.stringify({ passed: false, directory, message: error.message, cause: error.cause?.message }));
  process.exitCode = 1;
}
