# Resource-bounded Linux release harness: external prototype

Status: external runnable startup/combined harness prototype, with34 passing pure/mock tests. The socket/bootstrap, coordinator, host lifecycle and Docker-command adapters are implemented; no Docker image, real socket, container, database fixture or workload has been built or run from this directory. `resourceAcceptance` is always false. This does not certify the current release or reinterpret any historical diagnostic.

## Resource and source boundary

| Role | CPU ceiling | RSS ceiling | Node heap | Database pool budget |
|---|---:|---:|---:|---|
| API | 1 | 2 GiB | 512 MiB | application16, existing session2 |
| Worker | 0.5 | 1 GiB | 512 MiB | scheduler5 |
| Generator | 1 | 1 GiB | 512 MiB | none |
| Coordinator | 0.5 | 1 GiB | 512 MiB | existing observer2 only |

The generator/coordinator ceilings are explicit harness budgets proposed for review, not production service specifications. PostgreSQL remains4 CPU/4 GiB and Redis1 CPU/256 MiB. Memory-swap equals memory, so additional swap is unavailable. CPU throttling, memory peak/current, OOM counters and the exact cgroup limits must be recorded per role before and after the measured phase. These ceilings do not establish RDS I/O parity or scheduler-fleet capacity.

All role containers join the exact owned PostgreSQL container's network namespace. PostgreSQL remains on loopback5437, Redis on6387, and API binds its usual ephemeral loopback port. No control or API port is published. The existing host-only PostgreSQL preparation publication remains127.0.0.1. Each role has a separate process namespace and cgroup; identities are `{containerId,pid}`, not distinct numeric PIDs alone.

Each role starts from the same immutable candidate runtime plus an independently hashed harness overlay. `/app/dist`, runtime dependencies, Node binary and all application files remain byte-identical to the inspected candidate. Role shims reside under `/prototype`; copied harness files reside under `/diagnostic`. The original API/worker process and generator modules are unchanged. The existing source checkout and harness source hashes remain bound before and after the run; overlay changes are listed separately. No custom ORM/compiler, application diagnostics route, Docker socket, registry push or production access is introduced.

`generated-docker-plan.json` records exact commands, mounts, ceilings and allowed environment names. Zero image/PG IDs are explicit unresolved placeholders because no role helper has been built or fixture created; it cannot be executed as a plan. `inheritWorkloadContract` reads the actual profile/offering modules. The recorded profile currently has1000 maximum in-flight requests,100/s for60s,64 reports and48-second worker acceptance. No hand-copied limit substitutes for that bound input.

The complete run records cgroup `cpu.stat` (including usage, user/system, periods, nr_throttled and throttled_usec), memory.events, memory.current and memory.peak before/after the measured phase, as well as the source, image, runtime-receipt and harness hashes. API/worker samples surround reset→post-drain snapshot; generator samples surround the original phase RPC; coordinator samples are explicit hooks immediately after reset and after the two drained snapshots. The memory peak is the kernel's cumulative lifetime peak, with the before value retained; it is not falsely labelled a reset phase peak. No cgroup counter is reset. Startup/shutdown samples are recorded separately.

## Minimal interface diff

The current `release-enabled-scale.mjs` owns `child(name,file,extraEnv)`, which returns `{process,rpc,ready,closed,stdout}` from `fork`. Replace only this harness factory with an owned remote-role adapter while preserving each existing callsite:

```
child(name, file, extraEnv)
  -> remoteRole({name, exactFile, exactEnvironmentBinding, immutableContainerId})
  -> {process, rpc, ready, closed, stdout}
```

`process.connected`, `exitCode` and `kill()` describe the exact owned role, not the socket. `rpc` retains the current IDs, operation payloads,120-second default and the15-second shutdown deadline. The existing30-second ready deadline starts when the role is launched, rather than while dormant containers are created. Existing operations are `initialize`, `phase`, `correctness`, `reset`, `snapshot`, `quiesce`, `drain`, `rollup`, and `shutdown`; each role adapter must enforce its own subset. No arbitrary executable or environment mutation is accepted through RPC.

The child bootstrap authenticates, waits for the explicit launch event, installs the equivalent `process.send` and message/disconnect bridge, and then imports the exact original role module. Waiting for launch preserves the coordinator's original password/catalog/preparation work before application startup. `process.send` retains asynchronous completion semantics and calls its callback only after its frame is flushed or failed. It must not turn a false socket-write return into an unbounded user queue. Native log streams are captured by the host and closed before the exit receipt is accepted.

The original6000 offers at100/s,6000-success requirement,source-defined in-flight limit (currently1000),64 report requests, range/scope matrix,48-second complete-worker requirement, all two-school correctness checks and every deadline remain unchanged. The generator's monotonic timing runs inside its own cgroup. No catches reinterpret a refusal, timeout, late offer, failed drain or forced shutdown as success. The coordinator's observer pool remains exactly2; socket readiness and Docker inspection never create a probe database pool.

The coordinator workload tail is unchanged except three enumerated metadata edits: container:PID identities and before/after coordinator resource samples. `overlay-receipt.json` binds the original/output hashes and tests reproduce these allowed edits exactly. The startup-only mode uses the original role imports/readiness, API/worker quiescence and shutdown, but offers zero heartbeats/reports and performs zero rollups. It is a distinct startup/cleanup proof, never capacity evidence.

## Bootstrap and authenticated transport

1. The host validates a local Docker context and creates every role container with immutable image, run/source/role labels, exact network namespace and the ceilings above. Containers stay stopped while IDs are obtained. No role is selected later by a mutable name or label search.
2. The host writes protected per-role credential files, containing the exact run/source/container binding and a fresh256-bit nonce. A child can read only its own credential directory. The coordinator receives its own host-prepared registry of those bindings; children cannot read it. Neither credentials nor fixture/session tokens enter receipts, logs or hashes of emitted parameter values.
3. The coordinator listens only on127.0.0.1 at an ephemeral port and emits a nonsecret bridge-ready record. The host fills each role's binding with that exact port before starting the child. There is one authenticated connection per role, no reconnect/replay path. Mutual binding acknowledgement is required before the launch event. Unauthenticated clients may not allocate a full-size frame: a small handshake bound and bounded short handshake timer precede the normal frame decoder.
4. Frames use a four-byte length and JSON with version, strictly consecutive transport sequence, fixed kind and payload. Maximum16 MiB/frame,32 MiB native output buffering and32 pending RPCs per role are proposed bounds. Actual maximum correctness payload size must be measured before runtime acceptance; an oversized payload fails visibly instead of silently dropping or truncating data.
5. Request IDs must increase; matching concurrent responses may arrive in either ID order. Frame replay, unknown response ID, duplicate response, unexpected event, malformed payload or binding mismatch terminates the channel and marks evidence failed. There is no request retry that might duplicate rollups or shutdown.

`observed-payload-sizes.json` measures retained original response values from completed diagnostics without copying any payloads. It states that removed CSV fields and unrecorded initialization payloads were not measured. Actual sender/receiver peak frame bytes are recorded by the transport; native oversize is an explicit failed run, never truncation or a silently enlarged bound.

`owned-ipc-core.mjs` implements bounded framing, exact initial binding verification, transport sequencing, bounded RPC ownership and receipt checks. The authenticated listener/bootstrap, mutual challenge proofs, role-specific operation validation and source/launch verification are implemented and remain subject to native review. The nonce is never transmitted; both ends prove it over the fresh, identity-bound handshake transcript. Plain loopback transport relies on the isolated owned namespace and nonce; it is not a general remote RPC service.

## Ownership, deadlines and exit proof

A client-facing RPC timeout rejects that caller but retains ownership of the remote operation until its exact response or independently verified host exit. A disconnected socket rejects waiters without certifying cleanup. Late responses remain recorded failures. An exit that abandons another pending RPC cannot become clean merely because a shutdown response arrived first.

Host exit proof binds full container ID, immutable image, run, source, role and labels. The host must await Docker wait, stopped-state inspection, OOM/exit status and closed log streams. A valid receipt records these observations without credentials. Only the host can write `/host-receipts`; the coordinator mounts it read-only and children do not mount it. Coordinator termination requests use a separate writable request directory; the host revalidates the exact target's identity before acting. The coordinator cannot forge an exit receipt.

The existing shutdown sequence first drains and sends shutdown, waits up to its existing deadline, and requests termination only if necessary. Actual forced termination/removal is recorded distinctly from clean completion. A timed-out or disconnected owner remains failed after physical cleanup. Host finalization always attempts every owned role, then Redis and PostgreSQL, even if one failed. It must never delete a mismatched container or infer exit from a lost transport. Ownership mismatch leaves an explicit unresolved cleanup failure.

The host adapter and orchestrator are implemented. Mocked cases cover failure after partial creation; disconnect with active RPC; shutdown acknowledgement with outstanding RPC; OOM; forced termination; wrong-image/label receipt; late log closure; log failure before CLI exit; and cleanup continuing after one failure. Actual application COMMIT/RESET drain semantics remain the unchanged original harness and application tests; they are not re-proven by these transport mocks. Runtime tests must verify exact cgroup and process identities and that children cannot write host receipts.

## Acceptance and next implementation checkpoint

Existing application/harness acceptance remains the first gate. A separate resource receipt additionally requires verified role cgroups, actual pool budgets, immutable source/runtime/overlay fingerprints, all expected containers and independently clean exits. Three accepted cold combined runs must use the same final source/schema/artifacts. A previous shared-container run is neither accepted nor discarded by this new topology.

Before any workload: independently review the implemented adapters, generated Docker plan and mocks; build a separately bound local helper only when authorized; prove exact installed Node/Drizzle/app import identity and actual cgroup/mount permissions; then run the distinct tiny startup mode against a fresh owned local schema. The exact role environment allowlist is implemented, invokes the source-bound enabledReleaseEnvironment function, rejects remote DB/Redis endpoints, and verifies private values against container inspect without printing them. Ambient cloud/Docker/proxy credentials are excluded. The entry point requires an explicitly reviewed allowLocalRolePreflight binding; resource acceptance remains false even when startup passes.
