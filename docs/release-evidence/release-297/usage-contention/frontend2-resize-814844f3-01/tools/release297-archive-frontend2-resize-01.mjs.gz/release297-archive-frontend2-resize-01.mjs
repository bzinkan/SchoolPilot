import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {join,dirname} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
const temp='<TEMP>',root='C:/Users/zinka/.codex/worktrees/release-stabilization-297/SchoolPilot';
const raw=join(temp,'release297-frontend2-resize-proof-01'),ci=join(temp,'release297-ci-8148-frontend2-01');
const packet=join(temp,'release297-frontend2-resize-evidence-01');assert.equal(existsSync(packet),false);mkdirSync(packet);
const file='schoolpilot-app/scripts/classpilot-messages-roster-browser.test.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
const read=f=>JSON.parse(readFileSync(f,'utf8'));
const red=read(join(raw,'red.json')),green=read(join(raw,'green.json')),targeted=read(join(raw,'targeted.json')),shard=read(join(raw,'shard2.json')),quiet=read(join(raw,'host-quiet-01.json'));
assert.equal(red.exitCode,1);assert.equal(red.reproducedExpectedAssertion,true);assert.equal(green.exitCode,0);assert.equal(targeted.exitCode,0);assert.equal(shard.exitCode,1);
assert.equal(quiet.matchingOwnedTestProcesses.length,0);assert.equal(quiet.recentPlaywrightBrowserProcesses.length,0);
const patched=readFileSync(join(root,file));assert.equal(sha(patched),green.sourceSha256);assert.equal(targeted.testSourceSha256,green.sourceSha256);assert.equal(shard.testSourceSha256,green.sourceSha256);
const git=args=>execFileSync('git',args,{cwd:root,windowsHide:true,maxBuffer:4*1024**2});
assert.equal(git(['diff','--name-only','--','schoolpilot-app']).toString().trim(),file);
const original=git(['show','814844f344a45159152415b0fb6d7027f05b093e:'+file]),patch=git(['diff','--',file]);
writeFileSync(join(raw,'original-committed.test.mjs'),original,{flag:'wx'});writeFileSync(join(raw,'patched.test.mjs'),patched,{flag:'wx'});writeFileSync(join(raw,'test-only.patch'),patch,{flag:'wx'});
const log=readFileSync(join(ci,'job.log'),'utf8');assert.ok(log.includes('ok 36 - An asynchronous grade-association change preserves the focused linked editor until it closes'));
assert.ok(log.includes("the thread replaces the list"));
const summary={schemaVersion:1,baseSource:'814844f344a45159152415b0fb6d7027f05b093e',trackedFile:file,productionChanges:0,
  ci:{run:37153313271,job:111291457200,conclusion:'failure',rawLogSha256:sha(log),failureLine:627,expected:0,actual:1,assertion:'the thread replaces the list',rerunRequested:false},
  cause:{finding:'The test did not synchronize the responsive React layout after a viewport resize. An empty thread can render while panel width is still the prior value.',
    control:'An external fixture delays only trusted native resize-event delivery by 750ms, then invokes the unchanged application resize listeners.',
    red:'deferred=1, delivered=0, width=600; exact count1 versus0 failure',green:'deferred=1, delivered=1, width=600; all assertions pass',
    limitation:'The controlled model proves this race can cause the exact assertion; CI did not capture event timing, so its precise scheduling is not directly observed.'},
  change:'Wait for chat-thread-back, rendered only by the actual single-pane branch, before the existing unchanged zero-list assertion. No assertion, timeout or product behavior is relaxed.',
  checks:{controlledRed:{exitCode:1,expectedFailure:true},controlledGreen:{pass:1,fail:0},actualRoster:{pass:3,fail:0,skip:0},
    affectedShard:{exitCode:1,pass:78,fail:1,skip:0,stoppedAfter:'33 pure schedule cases +46 schedule browser cases; npm stopped before later suites',
      unrelatedFailure:'schedule-profiles-browser.test.mjs:2444 case36 navigation net::ERR_NO_BUFFER_SPACE, before product assertions',
      sameCasePassedInExactCi:true,automaticRerun:false}},
  cleanup:{checkedAt:quiet.capturedAt,matchingOwnedNodeProcesses:0,recentPlaywrightProcesses:0,processesKilled:false,networkReset:false},
  hostObservation:{tcpTotal:quiet.tcpTotal,states:quiet.states,dynamicTcpStart:49152,dynamicTcpPortCount:16384,
    limitation:'Post-run snapshot only. It does not establish contemporaneous global port exhaustion; buffer-pressure cause remains unproven and no owned leak was observed.'},
  finalTestSha256:sha(patched),rawEvidencePreserved:true,capacityAccepted:false};
const summaryBytes=JSON.stringify(summary,null,2)+'\n';writeFileSync(join(packet,'summary.json'),summaryBytes,{flag:'wx'});
const entries=[];
for(const [directory,prefix]of [[ci,'ci'],[raw,'proof']])for(const name of readdirSync(directory))entries.push({path:join(directory,name),relative:prefix+'/'+name});
for(const name of ['release297-fetch-ci-8148-frontend2.mjs','release297-frontend2-resize-proof.mjs','release297-frontend2-check.mjs','release297-archive-frontend2-resize-01.mjs'])entries.push({path:join(temp,name),relative:'tools/'+name});
const scrub=s=>s.replace(/(?:postgres(?:ql)?|redis):\/\/[^\s"'<>]+/gi,'<REDACTED_LOCAL_URL>').replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,'<REDACTED_TOKEN>').replace(/\b(?:ghp|ghs|github_pat)_[A-Za-z0-9_]+\b/g,'<REDACTED_GITHUB_TOKEN>').replace(/C:[\\/]+Users[\\/]+zinka[\\/]+AppData[\\/]+Local[\\/]+Temp/gi,'<TEMP>');
const files=[];
for(const entry of entries){
  const original=readFileSync(entry.path);let content=original.toString('utf8');assert.ok(Buffer.from(content).equals(original));
  if(entry.relative==='proof/host-quiet-01.json'){const value=JSON.parse(content);delete value.topOwners;content=JSON.stringify(value,null,2)+'\n';}
  const safe=Buffer.from(scrub(content));assert.equal(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/.test(safe.toString()),false);
  const gz=gzipSync(safe,{level:9}),path=entry.relative+'.gz';mkdirSync(dirname(join(packet,path)),{recursive:true});writeFileSync(join(packet,path),gz,{flag:'wx'});
  assert.equal(sha(gunzipSync(gz)),sha(safe));files.push({path,originalRelativePath:entry.relative,originalBytes:original.length,originalSha256:sha(original),sanitizedSha256:sha(safe),gzipSha256:sha(gz)});
}
const privacy={schemaVersion:1,files:files.length,rawCiAndLocalFailuresRetained:true,scope:'Synthetic frontend fixtures, CI logs and content-free cleanup/resource counts. No fixture DB/env/dump, request payload or secret files.',redactions:['temporary path prefix','credential-shaped URLs/tokens','unrelated process inventory omitted from safe host receipt'],privateKeyAndAccessKeyPatternCheckPassed:true};
const privacyBytes=JSON.stringify(privacy,null,2)+'\n';writeFileSync(join(packet,'privacy-review.json'),privacyBytes,{flag:'wx'});
const manifest={schemaVersion:1,baseSource:summary.baseSource,scope:'Test-only responsive-layout synchronization; original CI failure, controlled red/green, real targeted pass and unrelated local shard transport failure preserved',files,summarySha256:sha(summaryBytes),privacyReviewSha256:sha(privacyBytes),capacityAccepted:false,productionChanges:0};
const bytes=JSON.stringify(manifest,null,2)+'\n';writeFileSync(join(packet,'manifest.json'),bytes,{flag:'wx'});
console.log(JSON.stringify({packet,records:files.length,manifestSha256:sha(bytes),testSha256:sha(patched),summarySha256:sha(summaryBytes)}));
