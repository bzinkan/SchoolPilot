# External owned fixed-read executor proof

No application code was changed. All three native fixtures were exact-owned, local, restricted non-bypass role runs and were removed;0e427 application bindings stayed unchanged.

Attempt01 is failed (9pass,2fail including the enclosing case): a supposed malformed UUID was supplied to a text ID column, so no SQL failure occurred. Original source/log/results are retained. Attempt02 corrected the deliberate fault and added the public getTransactionStatus I-before-root/T-after-BEGIN check:12/12passed. Attempt03 repeated12/12success with exact before/after prototype bindings and only the eight eligible reads in its timing sequence.

The prototype verifies real canonical/flat/direct row and parameter parity, fractional timestamps and null mapping, raw date/array driver parsers, actual schoolA→B physical-client reuse with forced RLS, concurrent different clients, foreign-school and stale-store/token rejection, captured-field mutation, acknowledged unrelated/nested transaction rejection without committing the outer transaction, initiated query ownership through delayed settlement/real row-lock wait and caller failure, an early settled unawaited SQL error, and manual expiry. It does not prove all production authority races or optional SAVEPOINT recovery; all reads in this prototype are mandatory. No named server prepared statements were used.

For100sequences/800queries per round, eligible-attempt medians were canonical469msCPU/1197mswall, flat297msCPU/918mswall, direct140msCPU/744mswall. CPU ranges were421–515,188–329 and93–282ms respectively. Native Windows CPU samples were coarse, including a zero per-shape interval; warmup/GC and local I/O matter. The previous nine-shape attempt had direct slower than flat (203vs188msCPU). Therefore the cost direction merits consideration, but these results do not justify a current-Linux capacity forecast or a claim that any projected20second saving is attainable.

The eligible order is locked-school,locked-license,live-binding,screenshot-session,screenshot-control,screenshot-candidate,live-binding,final-fence. Unlocked entitlement belongs to middleware outside the private final root; foreground is an optional SAVEPOINT operation. Both are excluded from benefit claims. The sequence does not execute intervening production statements, Redis or HTTP; every alternative uses the same native transaction/client/read sequence.

## Simpler candidate for later review

The installed public Drizzle `select(...).prepare("")` caches its compiled SQL, field selection, nullable-join metadata, encoders and existing result mappers. Installed node-pg treats emptyname as unnamed: it does not persist a named plan and still sends Parse for parameterized execution. A private per-physical-client WeakMap could retain those five SELECT objects, then execute with fresh bindings under the same proven owned-root/token/I→T checks. This avoids custom output aliases/decoders, retains Drizzle execute/cache/tracing behavior, and is simpler than directSELECT adoption. It cannot remove a roundtrip or cache an authority result.

That alternative has only been inspected, not run. It still needs native same-client school reuse, stale/released/reborrowed callbacks, fresh Date objects, failure/rollback and concurrency proof. Prepared objects must never escape or retain caller options; actual default cache must remain no-op and authToken absent. The public transaction status reflects the last ReadyForQuery, so exclusive private-root ownership is still necessary against a separately queued concurrent BEGIN. Generic/WebSocket/RLS-off paths remain reference.

All artifact and source hashes are retained. No additional experiment is running.
