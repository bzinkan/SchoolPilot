import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, existsSync, copyFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { patchCoordinator, patchProfile, replaceOnce, sha256, PROFILE } from './prototype-core.mjs';

export function patchRunner(source) {
  let text = replaceOnce(source, 'param(\n', `param(
  [Parameter(Mandatory=$true)][string]$SourceRepository,
  [Parameter(Mandatory=$true)][string]$DiagnosticImageManifest,
`);
  text = replaceOnce(text, "$ErrorActionPreference = 'Stop'", `$ErrorActionPreference = 'Stop'
if ($Phase -cne 'combined' -or $CollectApiCpuProfile) { throw 'This Linux prototype supports only the complete combined diagnostic.' }
$DiagnosticOnly = $true
$prototypeDirectory = $PSScriptRoot`);
  text = replaceOnce(text, "$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))", `$repository = [IO.Path]::GetFullPath($SourceRepository)
$usageScripts = Join-Path $repository 'scripts/load/usage'
if (-not (Test-Path -LiteralPath (Join-Path $repository '.git') -PathType Container)) { throw 'Require self-contained clean clone, not a linked worktree.' }
if (Test-Path -LiteralPath (Join-Path $repository '.git/objects/info/alternates')) { throw 'Clone must not depend on external Git objects.' }
$linuxBinding = Get-Content -LiteralPath $DiagnosticImageManifest -Raw | ConvertFrom-Json -DateKind String
if ($linuxBinding.applicationSource -cnotmatch '^[a-f0-9]{40}$' -or $linuxBinding.diagnosticImageId -cnotmatch '^sha256:[a-f0-9]{64}$' -or $linuxBinding.candidateImageId -cnotmatch '^sha256:[a-f0-9]{64}$') { throw 'Exact local image/source bindings required before fixture creation.' }`);
  text = text.replaceAll("Join-Path $PSScriptRoot 'assert-fresh-evidence-directory.mjs'", "Join-Path $usageScripts 'assert-fresh-evidence-directory.mjs'");
  text = replaceOnce(text, "if (-not $DiagnosticOnly -and (git status --porcelain).Length -gt 0)", "if ((git status --porcelain).Length -gt 0)");
  text = replaceOnce(text, "$env:USAGE_SOURCE_REVISION = (git rev-parse HEAD).Trim()", `$env:USAGE_SOURCE_REVISION = (git rev-parse HEAD).Trim()
  if ($LASTEXITCODE -ne 0 -or $env:USAGE_SOURCE_REVISION -cne $linuxBinding.applicationSource) { throw 'Source does not match exact diagnostic image binding.' }`);
  text = replaceOnce(text, "--publish '127.0.0.1:5437:5432'", "--publish '127.0.0.1:5437:5437' --env 'PGPORT=5437'");
  text = replaceOnce(text, '$image *> (Join-Path $output \'container-create.log\')', "$image postgres -p 5437 *> (Join-Path $output 'container-create.log')");
  assert.equal(text.split('-p 5432').length - 1, 2); text = text.replaceAll('-p 5432', '-p 5437');
  text = text.replaceAll("$ports.'5432/tcp'", "$ports.'5437/tcp'");
  text = replaceOnce(text, "& $dockerExecutable --host $pinnedDockerHost run --detach --name $redisContainer", `$pgIdentity = (& $dockerExecutable --host $pinnedDockerHost inspect $container --format '{{.Id}}').Trim()
    if ($LASTEXITCODE -ne 0 -or $pgIdentity -cnotmatch '^[a-f0-9]{64}$') { throw 'Exact namespace owner ID required.' }
    & $dockerExecutable --host $pinnedDockerHost run --detach --name $redisContainer`);
  text = replaceOnce(text, "--publish '127.0.0.1:6387:6379'", '--network "container:$pgIdentity"');
  text = replaceOnce(text, "redis-server --save '' --appendonly no", "redis-server --port 6387 --save '' --appendonly no");
  text = replaceOnce(text, 'redis-cli PING', 'redis-cli -p 6387 PING');
  text = replaceOnce(text,
    `$redisPorts = & $dockerExecutable --host $pinnedDockerHost inspect $redisContainer --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json -DateKind String
    if ($redisPorts.'6379/tcp'[0].HostIp -cne '127.0.0.1' -or $redisPorts.'6379/tcp'[0].HostPort -cne '6387') { throw 'Redis must publish only the dedicated loopback port.' }`,
    `$redisNetwork = (& $dockerExecutable --host $pinnedDockerHost inspect $redisContainer --format '{{.HostConfig.NetworkMode}}').Trim()
    if ($LASTEXITCODE -ne 0 -or $redisNetwork -cne "container:$pgIdentity") { throw 'Redis must share only the exact owned PG namespace.' }`);
  text = replaceOnce(text,
    "node --max-old-space-size=512 scripts/load/usage/release-enabled-scale.mjs *> (Join-Path $output 'scale.log')",
    `# No credentials in arguments. Launcher forwards a fixed synthetic env allowlist.
    node (Join-Path $prototypeDirectory 'launch-linux-diagnostic.mjs') $dockerExecutable $pinnedDockerHost $DiagnosticImageManifest $run $pgIdentity $output *> (Join-Path $output 'linux-launcher.log')`);
  text = replaceOnce(text, "workloadProfile='release-enabled-isolated-100rps-v1'", `workloadProfile='${PROFILE}'; candidateImageId=$linuxBinding.candidateImageId; diagnosticImageId=$linuxBinding.diagnosticImageId; capacityAccepted=$false`);
  text = replaceOnce(text, "      if ($container -cnotmatch '^schoolpilot-usage-scale-[a-f0-9]{12}$'", `      node (Join-Path $prototypeDirectory 'measurement-gate.mjs') $output $run $env:USAGE_SOURCE_REVISION $linuxBinding.diagnosticImageId
      if ($LASTEXITCODE -ne 0) { throw 'Exact diagnostic release not verified; fixture will be cleaned.' }
      if ($container -cnotmatch '^schoolpilot-usage-scale-[a-f0-9]{12}$'`);
  const cleanupStart=text.lastIndexOf('} finally {\n  if ($redisCreated) {');
  assert.ok(cleanupStart>0); assert.ok(text.endsWith('exit $exitCode\n'));
  text=text.slice(0,cleanupStart)+`} finally {
  try {
    # Bounded, exact-owned cleanup attempts all roles even if one fails. No
    # uncertain create/stop outcome can be reclassified as successful cleanup.
    node (Join-Path $prototypeDirectory 'cleanup-linux-fixtures.mjs') $dockerExecutable $pinnedDockerHost $run $output $linuxBinding.diagnosticImageId ($redisImage ?? '') ($image ?? '') ($linuxBinding.diagnosticImageIdentities | ConvertTo-Json -Compress)
    if ($LASTEXITCODE -ne 0) { $exitCode = 1; Write-Warning 'Owned Linux fixture cleanup unconfirmed; inspect retained receipt.' }
  } catch { $exitCode = 1; Write-Warning 'Owned Linux fixture cleanup failed before a complete receipt.' }
  finally {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name,$saved[$name],'Process') }
    Pop-Location
  }
}
exit $exitCode
`;
  return text;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [repository, output] = process.argv.slice(2); assert.ok(repository && output);
  assert.ok(!existsSync(output), 'Use a fresh external prototype output');
  const here = dirname(fileURLToPath(import.meta.url));
  const revision = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repository, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: repository, encoding: 'utf8' });
  const sources = Object.fromEntries(['release-enabled-scale.mjs', 'release-enabled-profile.mjs', 'run-release-enabled-scale.ps1']
    .map(name => [name, readFileSync(resolve(repository, 'scripts/load/usage', name), 'utf8').replaceAll('\r\n', '\n')]));
  mkdirSync(resolve(output, 'overlay/scripts/load/usage'), { recursive: true });
  writeFileSync(resolve(output, 'overlay/scripts/load/usage/release-enabled-scale.mjs'), patchCoordinator(sources['release-enabled-scale.mjs']));
  writeFileSync(resolve(output, 'overlay/scripts/load/usage/release-enabled-profile.mjs'), patchProfile(sources['release-enabled-profile.mjs']));
  writeFileSync(resolve(output, 'run-linux-diagnostic.prototype.ps1'), patchRunner(sources['run-release-enabled-scale.ps1']));
  for (const name of ['measurement-gate.mjs', 'prototype-core.mjs', 'launch-linux-diagnostic.mjs', 'cleanup-linux-fixtures.mjs', 'verify-runtime.mjs', 'prepare-context.ps1', 'Dockerfile.prototype']) copyFileSync(resolve(here, name), resolve(output, name));
  writeFileSync(resolve(output, 'prototype-source-receipt.json'), JSON.stringify({ createdAt: new Date().toISOString(), revision,
    sourceClean: status.trim() === '', sourceStatus: status.trim().split('\n'), prototypeOnly: true, executedDockerOperations: 0,
    applicationSourceForFutureRun: null, candidateImageForFutureRun: null, sourceHashes: Object.fromEntries(Object.entries(sources).map(([name, text]) => [name, sha256(text)])),
    caveat: 'Prototype generated from the observed working tree. Regenerate and review against the eventual clean exact source before build; these are not final run bindings.' }, null, 2) + '\n');
  console.log(JSON.stringify({ output, revision, prototypeOnly: true }));
}
