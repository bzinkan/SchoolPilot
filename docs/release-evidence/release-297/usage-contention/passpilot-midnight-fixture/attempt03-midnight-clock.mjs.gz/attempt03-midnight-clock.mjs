import { mock } from 'node:test'; mock.timers.enable({ apis: ['Date'], now: new Date('2026-10-03T07:00:15.000Z') });
