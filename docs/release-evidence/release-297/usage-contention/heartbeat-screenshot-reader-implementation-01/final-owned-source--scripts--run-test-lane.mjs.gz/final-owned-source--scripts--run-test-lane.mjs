#!/usr/bin/env node
import { readdirSync, readFileSync } from "node:fs";
import { basename, join, relative, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const testsRoot = join(root, "tests");

const RLS_SERIAL = new Set([
  "fair-main-pool.integration.test.mjs",
  "classpilot-final-delivery-context.integration.test.ts",
  "classpilot-heartbeat-foreground-authority.integration.test.ts",
  "classpilot-heartbeat-screenshot-evidence.integration.test.ts",
  "classpilot-heartbeat-screenshot-installation.integration.test.ts",
  "classpilot-heartbeat-inbox-authority.integration.test.ts",
  "classpilot-telemetry-owner-projection.integration.test.ts",
  "classpilot-heartbeat-persistence-context.integration.test.ts",
  "tenant-context-reuse.integration.test.ts",
  "classpilot-usage-admission.integration.test.ts",
  "classpilot-private-chat-lifecycle.integration.test.ts",
  "classpilot-private-chat-lifecycle-rls.test.ts",
  "classpilot-focus.integration.test.ts",
  "classpilot-lesson-prerequisites.integration.test.ts",
  "passpilot-reports-v2.integration.test.ts",
  "passpilot-appointments-rls.test.ts",
  "classpilot-settings.test.ts",
  "student-information.integration.test.ts",
  "school-discipline.integration.test.ts",
  "mydesk-imports-http.integration.test.ts",
  "mydesk-imports.integration.test.ts",
  "mydesk-request-lifecycle.integration.test.ts",
  "mydesk-core.integration.test.ts",
  "mydesk-seating.integration.test.ts",
  "classpilot-roadmap-rls.test.ts",
  "audit-writes.test.ts",
  "classpilot-lifecycle-worker-pool.integration.test.ts",
  "classpilot-fab-parent-rls.integration.test.ts",
  "classpilot-schedule-change-rls.test.ts",
  "classpilot-tile-authorization-plan-self-provisioning.integration.test.ts",
  "cross-tenant-isolation.test.ts",
  "gopilot-rls-isolation.test.ts",
  "passpilot-canonical-runtime.test.ts",
  "passpilot-legacy-multiclass.test.ts",
  "passpilot-kiosk-sessions.test.ts",
  "passpilot-report-issuers.test.ts",
  "passpilot-rules-rls.test.ts",
  "classpilot-usage-rollup-rls.test.ts",
  "classpilot-usage-domain-map.integration.test.ts",
  "rls-tenant-context.test.ts",
]);

const DB_SERIAL = new Set([
  "tenant-context-reuse.integration.test.ts",
  "classpilot-usage-admission.integration.test.ts",
  "classpilot-lesson-prerequisite-frame.test.ts",
  "classpilot-stop-focus-frame.test.ts",
  "passpilot-appointments.integration.test.ts",
  "passpilot-appointment-eligibility-races.integration.test.ts",
  "passpilot-school-year.integration.test.ts",
  "classpilot-teacher-preferences-schema.integration.test.ts",
  "mydesk-redesign-schema.integration.test.ts",
  "mydesk-workspace-schema.integration.test.ts",
  "rls-enforcement.integration.test.ts",
  "mydesk-imports-schema.integration.test.ts",
  "import-processing-stages.integration.test.ts",
  "mydesk-seating-schema.integration.test.ts",
  "mydesk-attachments.integration.test.ts",
  "mydesk-schema.integration.test.ts",
  "passpilot-kiosk-schedule.integration.test.ts",
  "passpilot-rules.integration.test.ts",
  "classpilot-usage-rollup.test.ts",
  "api-pool-readiness.integration.test.ts",
  "classpilot-class-tools.integration.test.ts",
  "classpilot-fab-sync-pending.integration.test.ts",
  "classpilot-coverage-directory.integration.test.ts",
  "classpilot-coverage-deletion.integration.test.ts",
  "classpilot-supervision-review.integration.test.ts",
  "classpilot-portal-first-login.integration.test.ts",
  "classpilot-precise-restriction-fence.integration.test.ts",
  "classpilot-precise-restriction-dispatch.test.ts",
  "flight-path-precise-resources-routes.test.ts",
  "classpilot-schedule-profile-validation.integration.test.ts",
  "classpilot-schedule-profile-supervision.integration.test.ts",
  "classpilot-schedule-boundaries.integration.test.ts",
  "classpilot-schedule-config-repair.integration.test.ts",
  "classpilot-scheduled-classroom.integration.test.ts",
  "classpilot-chat-channel-control.integration.test.ts",
  "classpilot-chat-oversight.integration.test.ts",
  "classpilot-schedule-profiles.integration.test.ts",
  "safety-notification-bundling.integration.test.ts",
  "safety-report-pagination.integration.test.ts",
  "mailpilot-safety-durability.integration.test.ts",
  "ai-chat-flight-path-scope.test.ts",
  "classpilot-scheduling.integration.test.ts",
  "classpilot-monitoring-interruptions.integration.test.ts",
  "safety-center-migration.integration.test.ts",
  "safety-center.integration.test.ts",
  "roster-integrations.integration.test.ts",
  "classpilot-browsing-history.integration.test.ts",
  "daily-usage-rollup.integration.test.ts",
  "authenticate-operational-failure.test.ts",
  "auth-membership-lifecycle.test.ts",
  "classpilot-2-7-1-command-frame.test.ts",
  "classpilot-admin-analytics.test.ts",
  "classpilot-admin-classes.test.ts",
  "classpilot-ai-decision-route-privacy.test.ts",
  "classpilot-co-teacher-routes.test.ts",
  "shared-teaching-resources-routes.test.ts",
  "classpilot-coverage-hydration.test.ts",
  "classpilot-coverage.test.ts",
  "classpilot-entitlement.test.ts",
  "classpilot-entitlement-native.integration.test.ts",
  "classpilot-evidence-expiry-digest.test.ts",
  "classpilot-flight-path-import-contract.test.ts",
  "classpilot-heartbeat-presence.test.ts",
  "classpilot-instructional-calendar.test.ts",
  "classpilot-monitoring-reports.test.ts",
  "classpilot-runtime-security-contract.test.ts",
  // Live View revocation imports the tenant/database authority services.
  "classpilot-scheduled-live-view.test.ts",
  "classpilot-safety-spine-retention.test.ts",
  "classpilot-schedule-changes.test.ts",
  "classpilot-school-status-auth.test.ts",
  "classpilot-screenshot-publish-gate.test.ts",
  "classpilot-school-website-policy.integration.test.ts",
  "classpilot-sso-policy.test.ts",
  "classpilot-session-report-rollout.test.ts",
  "classpilot-session-summary-lifecycle.test.ts",
  "classpilot-supervision-lifecycle.test.ts",
  "classpilot-supervision-summaries.test.ts",
  "classpilot-student-auth.test.ts",
  "classpilot-student-session-auth-kind-guard.test.ts",
  "classpilot-student-session-lease-clock.integration.test.ts",
  "classpilot-student-session-recovery.integration.test.ts",
  "classpilot-device-upsert.integration.test.ts",
  "classpilot-student-data-contract.test.ts",
  "classpilot-teaching-sessions-recent.test.ts",
  "classpilot-tile-history-lateral.test.ts",
  "classpilot-tile-read-scope.test.ts",
  "classpilot-web-session-routing.test.ts",
  "classpilot-websocket-passive-authorization.test.ts",
  "error-monitor.test.ts",
  "gopilot-entitlement.test.ts",
  "gopilot-parent-containment.test.ts",
  "gopilot-runtime-contracts.test.ts",
  "gopilot-settings.test.ts",
  "gopilot-setup-deletion.test.ts",
  "gopilot-socket-containment.test.ts",
  "helmet-response-headers.test.ts",
  "gopilot-two-instance-realtime.test.ts",
  "google-staff-import-error-sanitization.test.ts",
  "heartbeat-tracking-settings-cache.test.ts",
  "multi-role-authorization.test.ts",
  "multi-school-readiness-routes.test.ts",
  "p0-traffic-schema.test.ts",
  "passpilot-clean-cutover-runtime.test.ts",
  "passpilot-overdue-lifecycle.test.ts",
  "passpilot-settings.test.ts",
  "public-registration-retired-route.test.ts",
  // This hermetic policy probe creates a role and table, then validates FORCE
  // RLS through SET ROLE. It requires the ordinary admin DB posture and must
  // not be repeated through the restricted RLS connection.
  "rls-policy.test.ts",
  "scheduler-lock.test.ts",
  "school-domain-guard-routes.test.ts",
  "school-domain-resolution.test.ts",
  "school-lifecycle-inquiries.test.ts",
  "student-email-domain.test.ts",
  "student-email-policy.test.ts",
  "student-removal-lifecycle.test.ts",
  "super-admin-school-counts.integration.test.ts",
  "staff-assignment-lifecycle.test.ts",
  "staff-assignment-integrity-readiness.test.ts",
  "staff-credential-realtime-contract.test.ts",
  "staff-identity-integrity.integration.test.ts",
  "staff-identity-lifecycle.test.ts",
  "staff-identity-monitoring.test.ts",
  "staff-password-login-policy.test.ts",
  "microsoft-sign-in-flow.test.ts",
]);

const INFRASTRUCTURE = /^(?:aws-|capacity-|credential-rotation-infra|database-insights|deploy-|ecs-|frontend-dependency|classpilot-(?:arrival-capacity|load-|tile-auth-plan-|tile-authorization-plan-check)|gopilot-containment-inventory|heartbeat-history-index-contract|hot-path-logging|migration-ledger|predeploy-safety|private-load|production-terraform|redis-ready|rls-allowlist-drift|soc2-|terraform-|runtime-config)/;

function discover(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) return discover(path);
    return /\.test\.(?:ts|mjs)$/.test(entry.name) ? [path] : [];
  });
}

const all = discover(testsRoot).sort();
const primaryLane = (path) => {
  const name = basename(path);
  if (RLS_SERIAL.has(name)) return "rls";
  if (DB_SERIAL.has(name)) return "db";
  if (INFRASTRUCTURE.test(name)) return "infrastructure";
  return "unit";
};

const requested = process.argv[2];
if (!["unit", "db", "rls", "infrastructure", "list"].includes(requested)) {
  process.stderr.write("Usage: node scripts/run-test-lane.mjs unit|db|rls|infrastructure|list\n");
  process.exit(2);
}

if (requested === "list") {
  const listing = all.map((path) =>
    `${primaryLane(path)}\t${relative(root, path).replaceAll("\\", "/")}\n`
  ).join("");
  // Piped stdout is asynchronous on some platforms. Do not exit while a
  // caller's complete lane inventory is still buffered in this process.
  await new Promise((resolve, reject) => {
    process.stdout.write(listing, (error) => error ? reject(error) : resolve());
  });
  process.exit(0);
}

// RLS tests deliberately run once in the ordinary DB posture and again with
// FORCE RLS. This is the one intentional overlap between otherwise exclusive
// primary lanes.
const selected = all.filter((path) => {
  const lane = primaryLane(path);
  if (requested === "db") return lane === "db" || lane === "rls";
  return lane === requested;
});
if (selected.length === 0) {
  process.stderr.write(`No tests classified for ${requested}\n`);
  process.exit(2);
}

const concurrency = requested === "unit" ? "4" : "1";
const result = spawnSync(process.execPath, [
  "--env-file-if-exists=.env",
  "--import", "./tests/test-environment.mjs",
  "--import", "tsx",
  "--test",
  `--test-concurrency=${concurrency}`,
  ...selected.map((path) => relative(root, path)),
], {
  cwd: root,
  env: process.env,
  stdio: "inherit",
});
process.exit(result.status ?? 1);
