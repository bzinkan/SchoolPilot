import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {prepare,SOURCE} from './prepare-campaign-config.mjs';
const input=JSON.parse(readFileSync(new URL('./input-template.json',import.meta.url)));
// Real new source/helper/runtime/scan are checked before this deliberately old
// snapshot is rejected. No config/attempt/fixture is created by this negative proof.
input.snapshotDirectory='C:/Users/zinka/.codex/artifacts/release297-synthetic-prepared-e95-75d8f6205c5c';
input.snapshotManifestSha256='847c9b8d7a0e717e77b72f75ca06f2e89d3d5050cce17b8b5cd731bde4070330';
let seen;
try{await prepare(input);}catch(error){seen=error;}
assert.ok(seen);assert.equal(seen.actual,'e95a2b56476b1225434c1b0f3907db46c9d84fe3');assert.equal(seen.expected,SOURCE);
for(const name of['campaignDirectory','evidenceDirectory','privateDirectory','configurationDirectory'])assert.equal(existsSync(input[name]),false);
writeFileSync(new URL('./binding-preflight-result.json',import.meta.url),JSON.stringify({source:SOURCE,actualCandidateHelperRuntimeAndHarnessBindingsChecked:true,historicalSourceRejected:seen.actual,configurationCreated:false,fixtureCreated:false,capacityAccepted:false},null,2)+'\n',{flag:'wx'});
console.log('Actual final candidate/helper/runtime/source bindings passed; historical e95 snapshot correctly refused before output.');
