import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const expectedSource='b11202fc305198d76e73c5e6d711b7dc9ed2d938';
const fixture=JSON.parse(readFileSync('/input/cold-fixture-state.json','utf8'));
assert.equal(fixture.sourceRevision,expectedSource);
assert.equal(process.env.EXPLAIN_SOURCE,expectedSource);
assert.equal(process.env.SCHEDULER_ENABLED,'true');
assert.ok(['127.0.0.1','localhost','[::1]'].includes(new URL(process.env.DATABASE_URL_PRIVILEGED).hostname));
const school=fixture.schools.find(s=>s.index===0);assert.ok(school);
const rollup=await import('/app/dist/services/classpilotUsageRollup.js');
const time=await import('/app/dist/util/schoolTime.js');
const scheduler=await import('/app/dist/services/schedulerDb.js');
const pool=scheduler.schedulerPool;
assert.equal(pool.options.max,5);assert.equal(pool.options.connectionTimeoutMillis,10000);assert.equal(pool.options.statement_timeout,60000);
const day=rollup.classpilotUsageRollupDay(time.addLocalDays(fixture.today,-2),'America/New_York');
const labels=new Map([[rollup.CLASSPILOT_USAGE_ROLLUP_LOCK_SQL,'schoolAdvisory'],[rollup.CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL,'priorCoverage'],[rollup.CLASSPILOT_USAGE_ROLLUP_DELETE_SQL,'delete'],[rollup.CLASSPILOT_USAGE_ROLLUP_INSERT_SQL,'insertExplained'],[rollup.CLASSPILOT_USAGE_ROLLUP_COMPLETE_SQL,'completeCoverage'],['BEGIN','begin'],['COMMIT','commit'],['ROLLBACK','rollback']]);
const result={schemaVersion:1,source:expectedSource,schoolIndex:0,diagnosticOnly:true,capacityAccepted:false,passed:false,querySequence:[],querySqlSha256:sha(rollup.CLASSPILOT_USAGE_ROLLUP_INSERT_SQL),embeddedHashes:Object.fromEntries(['services/classpilotUsageRollup.js','services/classpilotUsageRollupAdmission.js','services/schedulerDb.js'].map(p=>[p,sha(readFileSync('/app/dist/'+p))])),limitations:['One restricted worker login with canonical app.is_super=on; SQL school predicates unchanged.','EXPLAIN ANALYZE executes the INSERT inside the real production transaction/admission/budget path. It replaces its result row with plan output; the ordinary function return is therefore unavailable and is not correctness evidence.','One school from a restored immutable prepared synthetic snapshot, without concurrent API/report traffic; not a capacity comparison.','Execution Time is instrumented PostgreSQL elapsed time, not server CPU. Node timing includes driver/transport/scheduling.','WAL counters describe the explained statement including its work; EXPLAIN does not provide a general heap-versus-each-index WAL partition. Trigger timings can identify FK/coverage overhead; do not invent unreported attribution.']};
let insertCount=0, released=0, capturedPlan;
const adapted={query:(...args)=>pool.query(...args),connect:async()=>{
 const client=await pool.connect();
 return{release:error=>{released++;client.release(error);},query:async(text,values)=>{
  assert.equal(typeof text,'string');
  const label=labels.get(text)??'budgetTimeout';
  const observed={label,sqlSha256:sha(text),parametersSha256:sha(JSON.stringify(values??[]))};
  if(label==='budgetTimeout')assert.match(text,/^SELECT set_config\('statement_timeout'/);
  const started=performance.now();
  try{
   if(text===rollup.CLASSPILOT_USAGE_ROLLUP_INSERT_SQL){
    assert.equal(insertCount++,0,'One exact INSERT only');
    assert.deepEqual(values,[school.id,time.utcTimestampForSql(day.dayStartUtc),time.utcTimestampForSql(day.dayEndUtc),day.date,'[]']);
    const explained=await client.query('EXPLAIN (ANALYZE, BUFFERS, WAL, FORMAT JSON) '+text,values);
    capturedPlan=explained.rows[0]['QUERY PLAN'];assert.ok(Array.isArray(capturedPlan)&&capturedPlan.length===1);
    const raw=Buffer.from(JSON.stringify(capturedPlan,null,2)+'\n');result.rawPrivatePlanSha256=sha(raw);writeFileSync('/private/plan.json',raw);
    const sanitized=raw.toString('utf8').replace(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/gi,'<SYNTHETIC_ID>');writeFileSync('/out/plan.sanitized.json',sanitized);
    return explained;
   }
   return await client.query(text,values);
  }catch(error){observed.error={name:error.name,code:error.code};throw error;}
  finally{observed.elapsedMs=performance.now()-started;result.querySequence.push(observed);}
 }};
}};
try{
 const role=(await pool.query("SELECT rolsuper,rolbypassrls,current_setting('app.is_super') AS super_guc,current_setting('statement_timeout') AS statement_timeout FROM pg_roles WHERE rolname=current_user")).rows[0];assert.equal(role.rolsuper,false);assert.equal(role.rolbypassrls,false);assert.equal(role.super_guc,'on');assert.equal(role.statement_timeout,'1min');result.workerPosture=role;
 const settings=await pool.query("SELECT name,setting,unit FROM pg_settings WHERE name=ANY($1::text[]) ORDER BY name",[['fsync','synchronous_commit','full_page_writes','wal_compression','wal_sync_method','shared_buffers','work_mem','max_parallel_workers_per_gather','jit','track_io_timing','track_wal_io_timing']]);result.databaseSettings=settings.rows;
 result.optimizerStatistics=(await pool.query("SELECT c.relname,c.reltuples,c.relpages,s.n_live_tup,s.last_analyze,s.last_autoanalyze FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace LEFT JOIN pg_stat_user_tables s ON s.relid=c.oid WHERE n.nspname='public' AND c.relname=ANY($1::text[]) ORDER BY c.relname",[['heartbeats','students','classpilot_ai_decisions','classpilot_session_students','teaching_sessions','group_students','classpilot_usage_rollups','classpilot_usage_rollup_days']])).rows;
 const prior=(await pool.query(rollup.CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL,[school.id,day.date])).rows;assert.equal(prior.length,0,'Prepared snapshot must not already have heavy-day coverage');
 assert.equal(Number((await pool.query('SELECT COUNT(*) AS count FROM classpilot_usage_rollups WHERE school_id=$1 AND usage_date=$2::date',[school.id,day.date])).rows[0].count),0);
 const started=performance.now(),cpu=process.cpuUsage();
 const replacedReturn=await rollup.rollupClasspilotUsageDay(adapted,{schoolId:school.id,day,windowEndUtc:day.dayEndUtc,exclusions:[]});
 result.completeOperationMs=performance.now()-started;result.processCpuMicroseconds=process.cpuUsage(cpu);result.explainReplacedNormalReturn=replacedReturn;assert.deepEqual(replacedReturn,{rowCount:0,seconds:0,heartbeatCount:0});
 assert.equal(insertCount,1);assert.equal(released,1);assert.ok(result.completeOperationMs<=60000);
 assert.deepEqual(result.querySequence.filter(x=>x.label!=='budgetTimeout').map(x=>x.label),['begin','schoolAdvisory','priorCoverage','delete','insertExplained','completeCoverage','commit']);
 const actual=(await pool.query('SELECT COUNT(*)::int AS row_count,COALESCE(SUM(seconds),0)::bigint AS seconds,COALESCE(SUM(heartbeat_count),0)::bigint AS heartbeat_count FROM classpilot_usage_rollups WHERE school_id=$1 AND usage_date=$2::date',[school.id,day.date])).rows[0];
 result.storedCorrectness={rowCount:Number(actual.row_count),seconds:Number(actual.seconds),heartbeatCount:Number(actual.heartbeat_count)};assert.deepEqual(result.storedCorrectness,{rowCount:84000,seconds:10002500,heartbeatCount:1000000});
 const coverage=(await pool.query(rollup.CLASSPILOT_USAGE_ROLLUP_LAST_COMPUTED_SQL,[school.id,day.date])).rows[0];assert.equal(new Date(coverage.processed_through).getTime(),day.dayEndUtc.getTime());assert.equal(coverage.is_final,true);result.coverageCutoffCorrect=true;
 result.planSummary={planningMs:capturedPlan[0]['Planning Time'],executionMs:capturedPlan[0]['Execution Time'],root:capturedPlan[0].Plan['Node Type'],triggers:capturedPlan[0].Triggers??[]};result.passed=true;
}catch(error){result.failure={name:error.name,code:error.code,message:String(error.message).replace(/[a-f0-9]{8}-[a-f0-9-]{27,}/gi,'<SYNTHETIC_ID>').slice(0,500)};process.exitCode=1;}
finally{
 try{await pool.end();await scheduler.schedulerLockPool.end();await(await import('/app/dist/services/errorMonitor.js')).default.disposeAndWait();const db=await import('/app/dist/db.js');await db.pool.end();await db.sessionPool.end();result.poolCleanup=true;}catch(error){result.poolCleanup=false;result.cleanupError=error.name;process.exitCode=1;result.passed=false;}
 writeFileSync('/out/result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:result.passed,completeOperationMs:result.completeOperationMs,failure:result.failure,queryCount:result.querySequence.length,poolCleanup:result.poolCleanup}));
}
