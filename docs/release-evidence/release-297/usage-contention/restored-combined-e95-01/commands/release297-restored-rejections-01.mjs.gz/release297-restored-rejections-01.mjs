import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const temp=process.env.TEMP,driver=join(temp,'release297-restored-role-e95-driver-01/scripts/load/usage/roles'),run=join(temp,'release297-role-restored-combined-e95-01'),out=join(temp,'release297-restored-rejection-analysis-01');
mkdirSync(out);const hash=x=>createHash('sha256').update(x).digest('hex');
const raw=readFileSync(join(driver,'campaign-validation.mjs'),'utf8');
const source=raw.replace(/from '([^']+)'/g,(all,name)=>name.startsWith('.')?`from '${pathToFileURL(join(driver,name)).href}'`:all)+'\nexport {planCheck,imageCheck,preparationCheck,metricsCheck,ownershipCheck};\n';
writeFileSync(join(out,'validator-analysis.mjs'),source,{flag:'wx'});
const mod=await import(pathToFileURL(join(out,'validator-analysis.mjs'))),loader=await import(pathToFileURL(join(driver,'receipt-loader.mjs')));
const manifestRaw=readFileSync(join(run,'receipt-manifest.json')),planRaw=readFileSync(join(run,'run-plan.json'));
const loaded=loader.loadBoundRun(run,hash(manifestRaw),hash(planRaw));
const result={sourceSha256:hash(raw),receiptManifestSha256:hash(manifestRaw),rawUnchanged:true,checks:{}};
for(const name of ['planCheck','imageCheck','preparationCheck','metricsCheck','ownershipCheck']){try{mod[name](loaded.bundle,hash(planRaw));result.checks[name]={passed:true};}catch(error){result.checks[name]={passed:false,operator:error.operator,actual:error.actual,expected:error.expected,stack:String(error.stack).split('\n').filter(line=>line.includes('validator-analysis.mjs')).slice(0,2)};}}
writeFileSync(join(out,'first-rejections.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
