import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { patchCoordinator, patchProfile, linuxPlan, cleanupOwned, assertOwned, replaceOnce, PROFILE } from './prototype-core.mjs';
import { patchRunner } from './create-prototype.mjs';
import { cleanupFixtures } from './cleanup-linux-fixtures.mjs';
const repository = process.env.PROTOTYPE_SOURCE_REPOSITORY;
assert.ok(repository, 'Explicit read-only prototype source path required');
const read = name => readFileSync(resolve(repository, 'scripts/load/usage', name), 'utf8').replaceAll('\r\n', '\n');
const run='123456abcdef', source='a'.repeat(40), imageId=`sha256:${'b'.repeat(64)}`, pgContainerId='c'.repeat(64);
const env = { NODE_ENV:'test', USAGE_LOCAL_SCALE:'1', USAGE_SOURCE_REVISION:source,
  USAGE_SCALE_CONTAINER:`schoolpilot-usage-scale-${run}`, REDIS_URL:'redis://127.0.0.1:6387',
  DATABASE_URL:`postgresql://[REDACTED]@127.0.0.1:5437/schoolpilot_redesign_usage_scale_${run}`,
  ADMIN_DATABASE_URL:`postgresql://[REDACTED]@127.0.0.1:5437/schoolpilot_redesign_usage_scale_${run}`,
  DATABASE_URL_PRIVILEGED:`postgresql://[REDACTED]@127.0.0.1:5437/schoolpilot_redesign_usage_scale_${run}`,
  AWS_ACCESS_KEY_ID:'must-not-forward', DOCKER_HOST:'must-not-forward', NODE_OPTIONS:'--require evil', HTTP_PROXY:'must-not-forward' };
const input = {run,source,imageId,pgContainerId, evidenceDirectory:'C:\\Users\\Test User\\Artifacts', env};
const binding = {run,name:`schoolpilot-usage-linux-${run}`,imageId,pgContainerId};
const owned = running => ({ Id:'d'.repeat(64),Name:`/${binding.name}`, Image:imageId,
  Config:{Labels:{'codex.usage-scale':run,'codex.usage-linux':'diagnostic-only'}},
  HostConfig:{NetworkMode:`container:${pgContainerId}`,ReadonlyRootfs:true}, State:{Running:running} });

test('Linux diagnostic preserves full traffic while existing short diagnostic stays unchanged', async () => {
  let profile = patchProfile(read('release-enabled-profile.mjs'));
  profile=profile.replace("import { COLD_OPEN_LOOP_PROFILE } from './cold-open-loop-profile.mjs';", 'const COLD_OPEN_LOOP_PROFILE = { httpOffering: { schools:2 }, fullWorkerAcceptanceMs:48000 };');
  profile=profile.replace("import { releaseServerIsIdle } from './release-enabled-drain.mjs';", 'const releaseServerIsIdle=()=>true;');
  const module = await import(`data:text/javascript;base64,${Buffer.from(profile).toString('base64')}`);
  assert.deepEqual(module.releaseTrafficOptions({USAGE_RELEASE_LINUX_DIAGNOSTIC:'true',USAGE_RELEASE_DIAGNOSTIC:'true',USAGE_RELEASE_CPU_PROFILE:'false',USAGE_RELEASE_PHASE:'combined'}), {});
  assert.deepEqual(module.releaseTrafficOptions({USAGE_RELEASE_DIAGNOSTIC:'true'}), {durationMs:10000});
  assert.throws(()=>module.releaseTrafficOptions({USAGE_RELEASE_LINUX_DIAGNOSTIC:'true',USAGE_RELEASE_DIAGNOSTIC:'false'}));
  assert.equal(module.capacityAcceptance({diagnosticOnly:true}).acceptanceRun,false);
  assert.equal(module.RELEASE_ENABLED_PROFILE.reportOffers.total,64);
  assert.equal(module.RELEASE_ENABLED_PROFILE.name,PROFILE);
});
test('all existing numerical and correctness acceptance checks are byte-identical', () => {
  const original=read('release-enabled-profile.mjs'), patched=patchProfile(original);
  const section=text=>text.slice(text.indexOf('export function capacityAcceptance'),text.indexOf('export function releaseTrafficOptions'));
  assert.equal(section(patched),section(original));
  assert.match(section(patched),/expected === 6000/);
  assert.match(section(patched),/reports\?\.length === 64/);
});
test('coordinator has separate app and executed-harness binding and strict clean source', () => {
  const result=patchCoordinator(read('release-enabled-scale.mjs'));
  assert.match(result,/const root = '\/app'/);
  assert.match(result,/fork\(resolve\(harnessRoot/);
  assert.equal((result.match(/resolve\(harnessRoot, 'scripts\/load\/usage'/g)||[]).length,4);
  assert.match(result,/assert\.equal\(sourceClean, true/);
  assert.match(result,/assertRuntime\('\/prototype-tools\/base-runtime\.json'\)/);
  assert.doesNotMatch(result,/metrics\.capacityAccepted = Object\.values/);
  assert.match(result,/metrics\.diagnosticChecksPassed = Object\.entries/);
  assert.match(result,/metrics\.capacityAccepted = false; \/\/ Never accepted/);
});
test('timeout kills exact child and marks failure instead of a second ineffectual SIGTERM',()=>{
  const result=patchCoordinator(read('release-enabled-scale.mjs'));
  assert.match(result,/metrics\.childCleanupFailure = true; process\.exitCode = 1;\n      owner\.process\.kill\('SIGKILL'\)/);
  assert.match(result,/catch \{ metrics\.childCleanupFailure = true; process\.exitCode = 1; owner\.process\.kill\('SIGTERM'\)/);
  assert.match(result,/if \(!metrics\.childShutdownClean\) metrics\.diagnosticChecksPassed = false/);
});
test('exact anchors fail closed on unexpected upstream edits',()=>{
  assert.equal(replaceOnce('prefix MATCH suffix','MATCH',"literal $' and $` and $&"),"prefix literal $' and $` and $& suffix");
  assert.throws(()=>patchCoordinator(read('release-enabled-scale.mjs').replace('const root =','const renamedRoot =')));
  assert.throws(()=>patchProfile(patchProfile(read('release-enabled-profile.mjs'))));
});
test('runner keeps database/Redis caps, changes only owned internal ports/network and uses image-bound measurement',()=>{
  const result=patchRunner(read('run-release-enabled-scale.ps1'));
  assert.match(result,/--cpus 4 --memory 4g --memory-swap 4g/);
  assert.match(result,/--cpus 1 --memory 256m --memory-swap 256m/);
  assert.match(result,/127\.0\.0\.1:5437:5437/); assert.match(result,/postgres -p 5437/);
  assert.match(result,/--network "container:\$pgIdentity"/); assert.match(result,/redis-cli -p 6387 PING/);
  assert.doesNotMatch(result,/127\.0\.0\.1:6387:6379/);
  assert.match(result,/launch-linux-diagnostic\.mjs/);
  assert.match(result,/sourceRevision=\$env:USAGE_SOURCE_REVISION/);
  assert.match(result,/capacityAccepted=\$false/);
  assert.match(result,/exact current local versioned migration\/admission|Complete current local versioned migration\/admission/);
});
test('container args preserve spaces without shell and expose no credentials in arguments',()=>{
  const plan=linuxPlan(input);
  assert.ok(plan.args.includes('type=bind,source=C:\\Users\\Test User\\Artifacts,target=/evidence'));
  assert.ok(plan.args.includes(`container:${pgContainerId}`));
  assert.ok(plan.args.includes('--read-only')); assert.ok(plan.args.includes('--no-healthcheck'));
  assert.ok(!plan.args.includes('--privileged')); assert.ok(!plan.args.includes('--publish'));
  assert.ok(!plan.args.some(value=>value.includes('synthetic:')||value.includes('owner:')||value.includes('docker.sock')));
  assert.equal(plan.childEnv.AWS_ACCESS_KEY_ID,undefined); assert.equal(plan.childEnv.NODE_OPTIONS,undefined);
  assert.equal(plan.childEnv.DOCKER_HOST,undefined); assert.equal(plan.childEnv.HTTP_PROXY,undefined);
  assert.equal(plan.childEnv.USAGE_RELEASE_PHASE,'combined'); assert.equal(plan.childEnv.USAGE_RELEASE_DIAGNOSTIC,'true');
  assert.equal(plan.receipt.capacityAccepted,false);
});
test('container plan rejects remote DB, wrong namespace identity and ambiguous mount paths',()=>{
  assert.throws(()=>linuxPlan({...input,env:{...env,DATABASE_URL:env.DATABASE_URL.replace('127.0.0.1','production.invalid')}}));
  assert.throws(()=>linuxPlan({...input,env:{...env,DATABASE_URL:env.DATABASE_URL+'?host=remote.invalid'}}));
  assert.throws(()=>linuxPlan({...input,env:{...env,DATABASE_URL:env.DATABASE_URL+'#unexpected'}}));
  assert.throws(()=>linuxPlan({...input,env:{...env,DATABASE_URL:env.DATABASE_URL.replace('postgresql:','http:')}}));
  assert.throws(()=>linuxPlan({...input,pgContainerId:'mutable-name'}));
  assert.throws(()=>linuxPlan({...input,evidenceDirectory:'C:\\bad,readonly'}));
  assert.throws(()=>linuxPlan({...input,env:{...env,USAGE_SOURCE_REVISION:'f'.repeat(40)}}));
});
test('running owned container is killed, verified stopped, removed and verified absent',async()=>{
  const values=[owned(true),owned(false),null], calls=[];
  const result=await cleanupOwned({inspect:async()=>values.shift(),kill:async(id,signal)=>calls.push(['kill',id,signal]),remove:async id=>calls.push(['remove',id])},binding);
  assert.equal(result.cleanupPassed,true); assert.equal(result.terminated,true); assert.equal(result.removed,true);
  assert.deepEqual(calls.map(row=>row[0]),['kill','remove']); assert.equal(calls[0][2],'KILL');
});
test('unknown creation outcome already stopped is still removed',async()=>{
  const values=[owned(false),null],calls=[];
  const result=await cleanupOwned({inspect:async()=>values.shift(),kill:async()=>assert.fail('already stopped'),remove:async id=>calls.push(id)},binding);
  assert.equal(result.cleanupPassed,true); assert.equal(calls.length,1);
});
test('cleanup mismatch never kills or removes unrelated resources',async()=>{
  const value=owned(true); value.Config.Labels['codex.usage-scale']='ffffffffffff';
  const result=await cleanupOwned({inspect:async()=>value,kill:async()=>assert.fail('not owned'),remove:async()=>assert.fail('not owned')},binding);
  assert.equal(result.cleanupPassed,false); assert.equal(result.failure,'OWNED_LINUX_CLEANUP_UNCONFIRMED');
});
test('unconfirmed kill/removal and daemon inspection errors remain failures',async()=>{
  for(const stage of ['inspect','kill','remove']) {
    const result=await cleanupOwned({inspect:async()=>{if(stage==='inspect')throw Error();return owned(stage!=='remove')},kill:async()=>{throw Error()},remove:async()=>{throw Error()}},binding);
    assert.equal(result.cleanupPassed,false);
  }
});
test('already absent is successful only after a successful absent inspection',async()=>{
  const result=await cleanupOwned({inspect:async()=>null,kill:async()=>assert.fail(),remove:async()=>assert.fail()},binding);
  assert.equal(result.confirmedAbsent,true); assert.equal(result.cleanupPassed,true);
});
test('ownership includes immutable image and namespace, not label alone',()=>{
  for(const field of ['Image','Name']) {const row=owned(false);row[field]='wrong';assert.throws(()=>assertOwned(row,binding));}
  const row=owned(false);row.HostConfig.NetworkMode='host';assert.throws(()=>assertOwned(row,binding));
});
test('fixture cleanup continues to PG after harness or Redis cleanup failure',async()=>{
  const removed=[],resources=[['harness','schoolpilot-usage-linux-'],['redis','schoolpilot-usage-redis-'],['postgres','schoolpilot-usage-scale-']].map(([role,prefix])=>({role,name:prefix+run,image:imageId}));
  const result=await cleanupFixtures({inspect:async name=>removed.includes(name)?null:{Id:name,Name:`/${name}`,Image:imageId,Config:{Labels:{'codex.usage-scale':run}}},
    remove:async id=>{if(id.includes('redis'))throw Error('simulated');removed.push(id);}}, {run,resources});
  assert.equal(result.cleanupPassed,false);assert.equal(result.resources[1].cleanupPassed,false);assert.equal(result.resources[2].removed,true);
});
