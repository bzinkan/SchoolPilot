$ErrorActionPreference='Stop'
$repo='C:\Users\zinka\.codex\worktrees\release-stabilization-297\SchoolPilot'
$docker='C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$daemon='npipe:////./pipe/dockerDesktopLinuxEngine'
$run=[guid]::NewGuid().ToString('N').Substring(0,12)
$container='schoolpilot-focus-wire-'+$run
$database='focus_wire_'+$run
$owner='fixture_'+$run; $app='app_'+$run
$password=[guid]::NewGuid().ToString('N');$appPassword=[guid]::NewGuid().ToString('N')
$out=Join-Path $env:TEMP ('release297-focus-wire-native-'+$run)
New-Item -ItemType Directory -Path $out | Out-Null
$savedSelectors=@{}
foreach($name in @('DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','BUILDX_BUILDER')){
 $savedSelectors[$name]=[Environment]::GetEnvironmentVariable($name,'Process');[Environment]::SetEnvironmentVariable($name,$null,'Process')
}
Set-Location -LiteralPath $repo
$created=$false;$restrictedExit=1
$sourceFiles=@('src/services/storage.ts','src/routes/classpilot/devices.ts','src/realtime/websocket.ts','src/services/classpilotFocus.ts','tests/classpilot-focus.integration.test.ts','tests/classpilot-focus-wire.test.ts','tests/fixtures/classpilot-focus-wire-297.json')
function Snapshot { $rows=@();foreach($f in $sourceFiles){$rows += [ordered]@{file=$f;sha256=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower()}};return $rows }
Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-before.json') -Encoding utf8
try {
 $schema=Join-Path $out 'schema.sql'
 Copy-Item -LiteralPath (Join-Path $env:TEMP 'release297-enabled-combined-07/post-convergence-schema.sql') -Destination $schema
 $image=(& $docker --host $daemon inspect schoolpilot-db --format '{{.Image}}').Trim()
 if($LASTEXITCODE -ne 0 -or $image -notmatch '^sha256:[a-f0-9]{64}$'){throw 'Exact local PG image unavailable'}
 & $docker --host $daemon run --detach --name $container --label "codex.focus-wire=$run" --cpus 2 --memory 2g --publish '127.0.0.1::5432' --env "POSTGRES_DB=$database" --env "POSTGRES_USER=$owner" --env "POSTGRES_PASSWORD=$password" $image *> (Join-Path $out 'container-create.log')
 if($LASTEXITCODE -ne 0){throw 'Owned fixture creation failed'};$created=$true
 $ready=$false
 for($i=0;$i -lt 40;$i++) { & $docker --host $daemon exec $container pg_isready -h 127.0.0.1 -U $owner -d $database *> $null;if($LASTEXITCODE -eq 0){$ready=$true;break};Start-Sleep -Milliseconds 250 }
 if(-not $ready){throw 'Owned fixture not ready'}
 $ports=& $docker --host $daemon inspect $container --format '{{json .NetworkSettings.Ports}}' | ConvertFrom-Json
 if($ports.'5432/tcp'[0].HostIp -cne '127.0.0.1'){throw 'Fixture must stay loopback only'}
 $port=$ports.'5432/tcp'[0].HostPort
 Get-Content -LiteralPath $schema -Raw | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restore.log')
 if($LASTEXITCODE -ne 0){throw 'Exact current schema restore failed'}
 "CREATE ROLE $app LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT PASSWORD '$appPassword'; GRANT USAGE ON SCHEMA public TO $app; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $app;" | & $docker --host $daemon exec -i $container psql -U $owner -d $database -v ON_ERROR_STOP=1 *> (Join-Path $out 'restricted-role.log')
 if($LASTEXITCODE -ne 0){throw 'Restricted role grant failed'}
 $env:JWT_SECRET=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$env:SESSION_SECRET=$env:JWT_SECRET;$env:STUDENT_TOKEN_SECRET=$env:JWT_SECRET
 Remove-Item Env:RLS_TEST_ROLE -ErrorAction SilentlyContinue
 $env:NODE_ENV='test';$env:REDIS_URL='';$env:SCHEDULER_ENABLED='false';$env:RLS_GUC_ENABLED='true'
 $registry=Get-Content src/config/rlsRegistry.json -Raw | ConvertFrom-Json
 $env:RLS_ENABLED_TABLES=$registry.inventories.classpilotPrivateChatLifecyclePostExpand.tables -join ','
 $env:DATABASE_URL="postgresql://${owner}:${password}@127.0.0.1:${port}/$database";$env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL;$env:ADMIN_DATABASE_URL=$env:DATABASE_URL
 $env:DATABASE_URL="postgresql://${app}:${appPassword}@127.0.0.1:${port}/$database";$env:DATABASE_URL_PRIVILEGED=$env:DATABASE_URL
 $env:RLS_TEST_ROLE=$app
 node scripts/load/usage/bounded-fixture-step.mjs 120000 --import ./tests/test-environment.mjs --import tsx --test --test-concurrency=1 tests/classpilot-focus.integration.test.ts *> (Join-Path $out 'restricted.log')
 $restrictedExit=$LASTEXITCODE
 Snapshot | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'source-after.json') -Encoding utf8
 [ordered]@{executionRoleScope='Restricted NOSUPERUSER NOBYPASSRLS app; independent owner bootstrap only';restrictedExit=$restrictedExit;source=(git rev-parse HEAD).Trim();worktreeDirty=$true;container=$container;database=$database;schemaSource='Combined07 exact post-convergence schema-only dump';schemaRawSha256=(Get-FileHash -LiteralPath $schema -Algorithm SHA256).Hash.ToLower();productionMutations=0;sourceExecution='tsx';sharedDistRebuilt=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'execution.json') -Encoding utf8
 Write-Output ([ordered]@{evidence=$out;executionRoleScope='Restricted NOSUPERUSER NOBYPASSRLS app; independent owner bootstrap only';restrictedExit=$restrictedExit}|ConvertTo-Json -Compress)
} finally {
 if($created){
  $found=& $docker --host $daemon inspect $container | ConvertFrom-Json
  if($LASTEXITCODE -ne 0 -or $found.Count -ne 1 -or $found[0].Name -cne ('/'+$container) -or $container -cne ('schoolpilot-focus-wire-'+$run) -or $found[0].Config.Labels.'codex.focus-wire' -cne $run -or $found[0].Config.Image -cne $image -or $found[0].Image -cne $image){throw 'Owned fixture identity mismatch'}
  & $docker --host $daemon rm -f $container *> (Join-Path $out 'cleanup.log')
  if($LASTEXITCODE -ne 0){throw 'Owned cleanup failed'}
  [ordered]@{removed=$true;container=$container;exactNameLabelImageVerified=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'cleanup.json')
 }
 foreach($name in $savedSelectors.Keys){[Environment]::SetEnvironmentVariable($name,$savedSelectors[$name],'Process')}
}
if($restrictedExit -ne 0){exit 1}
