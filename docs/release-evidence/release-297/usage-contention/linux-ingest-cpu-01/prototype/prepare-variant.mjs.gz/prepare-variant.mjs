import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync,mkdirSync,readdirSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),temp=dirname(here);
const original=resolve(temp,'release297-linux-diagnostic-design-01'),baseContext=resolve(temp,'release297-linux-d649-context-02');
const read=file=>readFileSync(file,'utf8').replaceAll('\r\n','\n');
const replace=(text,before,after)=>{assert.equal(text.split(before).length-1,1,before);return text.replace(before,()=>after);};
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const oldProfile='release-enabled-linux-shared-namespace-diagnostic-100rps-v1';
const profile='release-enabled-linux-shared-namespace-ingest-cpu-100rps-v1';
let core=read(resolve(original,'prototype-core.mjs')).replaceAll(oldProfile,profile);
core=core.replaceAll("USAGE_RELEASE_CPU_PROFILE, 'false'","USAGE_RELEASE_CPU_PROFILE, 'true'")
 .replaceAll("USAGE_RELEASE_PHASE, 'combined'","USAGE_RELEASE_PHASE, 'ingest'")
 .replaceAll("USAGE_RELEASE_CPU_PROFILE: 'false'","USAGE_RELEASE_CPU_PROFILE: 'true'")
 .replaceAll("USAGE_RELEASE_PHASE: 'combined'","USAGE_RELEASE_PHASE: 'ingest'")
 .replace('Full60s/6000heartbeat/64report workload','Full60s/6000heartbeat ingest-only workload');
core=replace(core,"text = replaceOnce(text, 'const watchdog = setTimeout",`text = replaceOnce(text,
    "if (phaseName === 'ingest') assert.equal(phase.traffic.heartbeats?.accepted, true, 'Diagnostic ingestion failed');",
    "if (phaseName === 'ingest') { assert.equal(phase.traffic.heartbeats?.accepted, true, 'Diagnostic ingestion failed'); metrics.diagnosticTrafficPassed = true; }");
  text = replaceOnce(text, 'const watchdog = setTimeout`);
writeFileSync(resolve(here,'prototype-core.mjs'),core,{flag:'wx'});
for(const file of ['cleanup-linux-fixtures.mjs','verify-runtime.mjs'])copyFileSync(resolve(original,file),resolve(here,file));
let launch=read(resolve(original,'launch-linux-diagnostic.mjs'));
launch=replace(launch,"assert.equal(result.diagnosticChecksPassed, true); assert.equal(result.childShutdownClean, true);",`assert.equal(result.diagnosticTrafficPassed, true); assert.equal(result.childShutdownClean, true);
  assert.equal(result.cpuProfile?.enabled,true); assert.match(result.cpuProfile?.sha256,/^[a-f0-9]{64}$/);
  assert.ok(result.cpuProfile.samples>0); assert.equal(result.phases?.length,1); assert.equal(result.phases[0].name,'ingest');
  assert.equal(result.phases[0].traffic.heartbeats.expected,6000);`);
writeFileSync(resolve(here,'launch-linux-diagnostic.mjs'),launch,{flag:'wx'});
let runner=read(resolve(baseContext,'generated/run-linux-diagnostic.prototype.ps1')).replaceAll(oldProfile,profile);
runner=replace(runner,"if ($Phase -cne 'combined' -or $CollectApiCpuProfile) { throw 'This Linux prototype supports only the complete combined diagnostic.' }", "if ($Phase -cne 'ingest' -or -not $CollectApiCpuProfile) { throw 'This variant requires full ingest with CPU collection.' }");
runner=replace(runner,"      if ($container -cnotmatch '^schoolpilot-usage-scale-[a-f0-9]{12}$'",`      # Fixture preparation is complete. Wait for the coordinator's exact run-bound
      # release before cold restart; this changes no measured workload deadline.
      node (Join-Path $prototypeDirectory 'measurement-gate.mjs') $output $run $env:USAGE_SOURCE_REVISION $linuxBinding.diagnosticImageId
      if ($LASTEXITCODE -ne 0) { throw 'Measurement release was not verified; owned fixture will be cleaned.' }
      if ($container -cnotmatch '^schoolpilot-usage-scale-[a-f0-9]{12}$'`);
writeFileSync(resolve(here,'run-linux-ingest-cpu.ps1'),runner,{flag:'wx'});
let probe=read(resolve(original,'runtime-probe.mjs'))
 .replace("USAGE_RELEASE_CPU_PROFILE:'false',USAGE_RELEASE_PHASE:'combined'","USAGE_RELEASE_CPU_PROFILE:'true',USAGE_RELEASE_PHASE:'ingest'")
 .replace('expectedReports:64','expectedReports:0,reportMatrixUnchanged:64,collectApiCpuProfile:true');
writeFileSync(resolve(here,'runtime-probe.mjs'),probe,{flag:'wx'});
let binder=read(resolve(original,'bind-helper-image.mjs'));
assert.equal(binder.split("clean(resolve(context,'clean-source'));clean(hostClone);").length-1,2);
binder=binder.replaceAll("clean(resolve(context,'clean-source'));clean(hostClone);",`clean(resolve(${JSON.stringify(baseContext)},'clean-source'));clean(hostClone);`);
binder=replace(binder,"sourceClone:resolve(context,'clean-source')",`sourceClone:resolve(${JSON.stringify(baseContext)},'clean-source')`);
writeFileSync(resolve(here,'bind-helper-image.mjs'),binder,{flag:'wx'});
const {patchProfile,patchCoordinator}=await import('./prototype-core.mjs');
const context=resolve(here,'context');assert.equal(existsSync(context),false);
mkdirSync(resolve(context,'overlay/scripts/load/usage'),{recursive:true});
const helpers=resolve(baseContext,'overlay/scripts/load/usage');
for(const name of readdirSync(helpers))copyFileSync(resolve(helpers,name),resolve(context,'overlay/scripts/load/usage',name));
const sourceRoot=resolve(baseContext,'clean-source');
for(const [name,patch] of [['release-enabled-profile.mjs',patchProfile],['release-enabled-scale.mjs',patchCoordinator]])
 writeFileSync(resolve(context,'overlay/scripts/load/usage',name),patch(read(resolve(sourceRoot,'scripts/load/usage',name))));
const binding=JSON.parse(read(resolve(baseContext,'overlay/binding.json')));
binding.profile=profile;binding.parentCombinedBindingSha256=sha(readFileSync(resolve(baseContext,'overlay/binding.json')));
binding.purpose='Full 6000-offer ingest-only CPU diagnostic of historical d649 baseline; not current pending application or capacity acceptance.';
binding.executedHarnessSha256=Object.fromEntries(readdirSync(helpers).map(name=>[name,sha(readFileSync(resolve(context,'overlay/scripts/load/usage',name)))]));
writeFileSync(resolve(context,'overlay/binding.json'),JSON.stringify(binding,null,2)+'\n');
writeFileSync(resolve(context,'Dockerfile'),`# Local diagnostic derivative; untouched /app and exact /source inherited.\nARG DIAGNOSTIC_BASE\nFROM \${DIAGNOSTIC_BASE}\nUSER root\nCOPY --chown=node:node overlay/ /diagnostic/\nUSER node\nRUN node /prototype-tools/verify-runtime.mjs assert /prototype-tools/base-runtime.json\nHEALTHCHECK NONE\nWORKDIR /app\nENTRYPOINT ["node"]\nCMD ["--max-old-space-size=512", "/diagnostic/scripts/load/usage/release-enabled-scale.mjs"]\n`);
writeFileSync(resolve(context,'.dockerignore'),'**\n!Dockerfile\n!overlay/\n!overlay/**\n**/node_modules\n**/node_modules/**\n**/dist\n**/dist/**\n**/.env\n**/.env.*\n');
writeFileSync(resolve(here,'preparation.json'),JSON.stringify({preparedAt:new Date().toISOString(),profile,source:binding.applicationSource,
 candidateImageId:binding.candidateImageId,parentHelperImage:'sha256:eeca91c130ddcda195f9317805ae39c4e56c3d08918fde79aadf60725a9a86f0',
 context,sourceRoot,hostFixture:resolve(temp,'release297-linux-d649-host-02'),diagnosticOnly:true,capacityAccepted:false,
 measuredOffers:6000,measuredReports:0,measuredWorkerRollups:0,measurementGate:'fresh run/source/image binding before cold restart',
 cpuFlush:'Existing shutdown RPC drains owned work, closes pools, exits API normally; V8 writes api.cpuprofile on exit. Forced termination remains failure.',
 productionMutations:0,primaryFilesChanged:0},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({context,profile,applicationSource:binding.applicationSource}));
