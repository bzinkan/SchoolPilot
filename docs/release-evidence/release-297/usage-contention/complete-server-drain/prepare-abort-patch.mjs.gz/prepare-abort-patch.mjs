import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
const root=process.cwd(), directory=process.argv[2];
const files=['scripts/load/usage/release-enabled-drain.mjs','scripts/load/usage/release-enabled-drain.test.mjs'];
let source=readFileSync(resolve(root,files[0]),'utf8');
source=source.replace('gauges: releaseDrainGauges(snapshot()), ...(failure ?', 'gauges: releaseDrainGauges(snapshot()), physicallyIdle: releaseServerIsIdle(snapshot()),\n    abortedResponses: snapshot().http?.abortedResponses ?? null, ...(failure ?');
source=source.replace('if (emptyPasses === 2 && now() < deadline) return receipt(true);', `if (emptyPasses === 2 && now() < deadline) {
        stage = 'verification';
        // Physical quiescence cannot prove callback-owned pre-handler work
        // ended after a client abort. Never erase that uncertainty at reset.
        if (snapshot().http?.abortedResponses !== 0) return receipt(false, 'DRAIN_UNVERIFIABLE_ABORT');
        return receipt(true);
      }`);
let tests=readFileSync(resolve(root,files[1]),'utf8');
tests+=`\n
test('aborted or missing response evidence cannot certify preflight even after actual owners drain', async () => {
  for (const aborts of [1, undefined]) {
    const state = idleReleaseSnapshot(); state.http.abortedResponses = aborts;
    state.operations.operations.heartbeat_handler.activeOperations = 1;
    let pauses = 0;
    const result = await drainReleaseServer({ snapshot: () => state,
      drainClassification: empty, drainWebSocket: empty, drainTenantReleases: empty,
      pause: async () => { pauses++; state.operations.operations.heartbeat_handler.activeOperations = 0; },
    });
    assert.equal(pauses, 1, 'await the real handler rather than releasing ownership on abort');
    assert.equal(result.physicallyIdle, true); assert.equal(result.complete, false);
    assert.equal(result.failure, 'DRAIN_UNVERIFIABLE_ABORT');
    assert.equal(result.abortedResponses, aborts ?? null);
  }
});\n`;
let patch='';
for(let i=0;i<files.length;i++){
 const oldPath=resolve(directory,`abort-fix-old-${i}.txt`), newPath=resolve(directory,`abort-fix-new-${i}.txt`);
 writeFileSync(oldPath,readFileSync(resolve(root,files[i])));writeFileSync(newPath,i===0?source:tests);
 let diff;try{diff=execFileSync('git',['diff','--no-index','--no-ext-diff','--',oldPath,newPath],{encoding:'utf8'});}catch(e){if(e.status!==1)throw e;diff=e.stdout;}
 const lines=diff.split('\n'); const body=lines.slice(lines.findIndex(line=>line.startsWith('@@'))).join('\n');
 patch+=`diff --git a/${files[i]} b/${files[i]}\n--- a/${files[i]}\n+++ b/${files[i]}\n${body}`;
}
writeFileSync(resolve(directory,'preflight-abort-followup.patch'),patch);
console.log('Prepared external two-file patch; repository unchanged.');
